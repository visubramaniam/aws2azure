# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import os
import importlib


def commands():
    commands = {}
    files = os.listdir(os.path.dirname(__file__))

    for file in files:
        name, ext = os.path.splitext(file)
        if ext == '.py' and name[0:1] != ('_'):
            m = importlib.import_module('.'+name, __name__)
            commands.update(m.commands())

    return commands