# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import logging as logging_lib

from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.rest_client.manual.configuration import Configuration

logger = logging_lib.getLogger(__name__)


class volume_list_OptValidator(object):
    """
    volume_listのoptionに対してバリデーションを行うクラス
    """

    def invoke(self, ordered_dict_options):
        """
        ordered_dict_optionsに対して下記のバリデーションを行う
        * server_id_nicknameとserver_nicknameがどちらも指定されている場合はKARS19022-Eを出力して終了
        :param ordered_dict_options: オプション名をキー、オプション値を値としたOrderedDict
        :return: ordered_dict_optionsそのまま
        :rtype: OrderedDict
        """
        config = Configuration()
        common_util = CommonUtil()

        if ordered_dict_options['server_nickname'] is not None \
                and ordered_dict_options['server_id_nickname'] is not None:
            config.messageId = '19022'
            config.messageDict = {'MSKEY_param1': 'server_nickname', 'MSKEY_param2': 'server_id_nickname'}
            common_util.view_error()

        return ordered_dict_options
