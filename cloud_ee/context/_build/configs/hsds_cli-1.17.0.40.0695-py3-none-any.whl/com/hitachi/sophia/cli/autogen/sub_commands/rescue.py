# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)






def commands():
    commands= {}

    return commands

