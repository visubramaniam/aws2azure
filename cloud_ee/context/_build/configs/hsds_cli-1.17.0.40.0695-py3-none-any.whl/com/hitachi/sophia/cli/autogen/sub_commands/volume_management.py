# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--capacity','_capacity',type=int,metavar='<int>',help='The (logical) capacity of the volume (unit: MiB).',required=True)
@click.option('--number','_number',type=int,metavar='<int>',help='The number of volumes to be created.')
@click.option('--base_name_for_name','_base_name_for_name',type=str,metavar='<str>',help='A name which is set for a volume')
@click.option('--start_number_for_name','_start_number_for_name',type=int,metavar='<int>',help='A starting sequential number to the end of a name.')
@click.option('--number_of_digits_for_name','_number_of_digits_for_name',type=int,metavar='<int>',help='The number of digits of a serial number added to the end of a name.')
@click.option('--base_name','_base_name',type=str,metavar='<str>',help='A nickname which is set for a volume')
@click.option('--start_number','_start_number',type=int,metavar='<int>',help='A starting sequential number to the end of a nickname.')
@click.option('--number_of_digits','_number_of_digits',type=int,metavar='<int>',help='The number of digits of a serial number added to the end of a nickname. This value can be specified only when start_number is set.')
@click.option('--saving_setting','_saving_setting',type=str,metavar='<str>',help='Setting of the capacity saving function.')
@click.option('--pool_id','_pool_id',type=str,metavar='<str>',help='The ID of the storage pool where the volume is created.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--storage_controller_id','_storage_controller_id',type=str,metavar='<str>',help='The ID of the storage controller that manages the volume.')
@click.option('--fault_domain_id','_fault_domain_id',type=str,metavar='<str>',help='The ID of the fault domain that manages the volume.')
@click.option('--upper_limit_for_iops','_upper_limit_for_iops',type=int,metavar='<int>',help='Upper limit for the volume performance (IOPS).')
@click.option('--upper_limit_for_transfer_rate','_upper_limit_for_transfer_rate',type=int,metavar='<int>',help='Upper limit for the volume performance (MiB/sec).')
@click.option('--upper_alert_allowable_time','_upper_alert_allowable_time',type=int,metavar='<int>',help='Alert threshold (second) for the upper limit of volume performance.')
@click.option('--pool_id_name','_pool_id_name',metavar='<str>',help='The name of the storage pool where the volume is created.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_create(_capacity,_number,_base_name_for_name,_start_number_for_name,_number_of_digits_for_name,_base_name,_start_number,_number_of_digits,_saving_setting,_pool_id,_pool_id_name,_vps_id,_vps_id_name,_storage_controller_id,_fault_domain_id,_upper_limit_for_iops,_upper_limit_for_transfer_rate,_upper_alert_allowable_time,):
    """
    Creates a volume. 
    """
    def get_uuid_from_pool_list_with_pool_id_name(pool_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.pool_list(name=pool_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'pool_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _capacity is not None:
            subCommandLogtxt += "--capacity " + str(_capacity) + " "




        if _number is not None:
            subCommandLogtxt += "--number " + str(_number) + " "




        if _base_name_for_name is not None:
            subCommandLogtxt += "--base_name_for_name " + str(_base_name_for_name) + " "




        if _start_number_for_name is not None:
            subCommandLogtxt += "--start_number_for_name " + str(_start_number_for_name) + " "




        if _number_of_digits_for_name is not None:
            subCommandLogtxt += "--number_of_digits_for_name " + str(_number_of_digits_for_name) + " "




        if _base_name is not None:
            subCommandLogtxt += "--base_name " + str(_base_name) + " "




        if _start_number is not None:
            subCommandLogtxt += "--start_number " + str(_start_number) + " "




        if _number_of_digits is not None:
            subCommandLogtxt += "--number_of_digits " + str(_number_of_digits) + " "




        if _saving_setting is not None:
            subCommandLogtxt += "--saving_setting " + str(_saving_setting) + " "




        if _pool_id is not None:
            subCommandLogtxt += "--pool_id " + str(_pool_id) + " "

        if _pool_id_name is not None:
            subCommandLogtxt += "--pool_id_name " + str(_pool_id_name) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "



        if _storage_controller_id is not None:
            subCommandLogtxt += "--storage_controller_id " + str(_storage_controller_id) + " "




        if _fault_domain_id is not None:
            subCommandLogtxt += "--fault_domain_id " + str(_fault_domain_id) + " "




        if _upper_limit_for_iops is not None:
            subCommandLogtxt += "--upper_limit_for_iops " + str(_upper_limit_for_iops) + " "




        if _upper_limit_for_transfer_rate is not None:
            subCommandLogtxt += "--upper_limit_for_transfer_rate " + str(_upper_limit_for_transfer_rate) + " "




        if _upper_alert_allowable_time is not None:
            subCommandLogtxt += "--upper_alert_allowable_time " + str(_upper_alert_allowable_time) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--pool_id', _pool_id,'--pool_id_name', _pool_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        if _pool_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _pool_id):
            raise ValueError("Invalid value for `pool_id`, the format of UUID is invalid.")
        if _storage_controller_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_controller_id):
            raise ValueError("Invalid value for `storage_controller_id`, the format of UUID is invalid.")
        if _fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _fault_domain_id):
            raise ValueError("Invalid value for `fault_domain_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_create"





        if  _pool_id_name is not None and not re.search('^[\-A-Za-z0-9_]{1,32}$', _pool_id_name):
            raise ValueError("Invalid value for parameter `pool_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")


        if  _vps_id_name is not None and not re.search('^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _capacity is not None:
            if(isinstance(_capacity, str)):
                _capacity = SeparateArgs.check_backslash(_capacity)
                _capacity = _capacity.encode("utf-8").decode("unicode-escape")
        if _number is not None:
            if(isinstance(_number, str)):
                _number = SeparateArgs.check_backslash(_number)
                _number = _number.encode("utf-8").decode("unicode-escape")
        if _base_name_for_name is not None:
            if(isinstance(_base_name_for_name, str)):
                _base_name_for_name = SeparateArgs.check_backslash(_base_name_for_name)
                _base_name_for_name = _base_name_for_name.encode("utf-8").decode("unicode-escape")
        if _start_number_for_name is not None:
            if(isinstance(_start_number_for_name, str)):
                _start_number_for_name = SeparateArgs.check_backslash(_start_number_for_name)
                _start_number_for_name = _start_number_for_name.encode("utf-8").decode("unicode-escape")
        if _number_of_digits_for_name is not None:
            if(isinstance(_number_of_digits_for_name, str)):
                _number_of_digits_for_name = SeparateArgs.check_backslash(_number_of_digits_for_name)
                _number_of_digits_for_name = _number_of_digits_for_name.encode("utf-8").decode("unicode-escape")
        if _base_name is not None:
            if(isinstance(_base_name, str)):
                _base_name = SeparateArgs.check_backslash(_base_name)
                _base_name = _base_name.encode("utf-8").decode("unicode-escape")
        if _start_number is not None:
            if(isinstance(_start_number, str)):
                _start_number = SeparateArgs.check_backslash(_start_number)
                _start_number = _start_number.encode("utf-8").decode("unicode-escape")
        if _number_of_digits is not None:
            if(isinstance(_number_of_digits, str)):
                _number_of_digits = SeparateArgs.check_backslash(_number_of_digits)
                _number_of_digits = _number_of_digits.encode("utf-8").decode("unicode-escape")
        if _saving_setting is not None:
            if(isinstance(_saving_setting, str)):
                _saving_setting = SeparateArgs.check_backslash(_saving_setting)
                _saving_setting = _saving_setting.encode("utf-8").decode("unicode-escape")
        if _pool_id is not None:
            if(isinstance(_pool_id, str)):
                _pool_id = SeparateArgs.check_backslash(_pool_id)
                _pool_id = _pool_id.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")
        if _storage_controller_id is not None:
            if(isinstance(_storage_controller_id, str)):
                _storage_controller_id = SeparateArgs.check_backslash(_storage_controller_id)
                _storage_controller_id = _storage_controller_id.encode("utf-8").decode("unicode-escape")
        if _fault_domain_id is not None:
            if(isinstance(_fault_domain_id, str)):
                _fault_domain_id = SeparateArgs.check_backslash(_fault_domain_id)
                _fault_domain_id = _fault_domain_id.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_iops is not None:
            if(isinstance(_upper_limit_for_iops, str)):
                _upper_limit_for_iops = SeparateArgs.check_backslash(_upper_limit_for_iops)
                _upper_limit_for_iops = _upper_limit_for_iops.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_transfer_rate is not None:
            if(isinstance(_upper_limit_for_transfer_rate, str)):
                _upper_limit_for_transfer_rate = SeparateArgs.check_backslash(_upper_limit_for_transfer_rate)
                _upper_limit_for_transfer_rate = _upper_limit_for_transfer_rate.encode("utf-8").decode("unicode-escape")
        if _upper_alert_allowable_time is not None:
            if(isinstance(_upper_alert_allowable_time, str)):
                _upper_alert_allowable_time = SeparateArgs.check_backslash(_upper_alert_allowable_time)
                _upper_alert_allowable_time = _upper_alert_allowable_time.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.CreateVolumeParam import CreateVolumeParam
        tmp_create_volume_param = CreateVolumeParam()
        create_volume_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.VolumeNameParam import VolumeNameParam
        tmp_volume_name_param = VolumeNameParam()
        volume_name_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.VolumeNicknameParam import VolumeNicknameParam
        tmp_volume_nickname_param = VolumeNicknameParam()
        volume_nickname_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.VolumeQosParam import VolumeQosParam
        tmp_volume_qos_param = VolumeQosParam()
        volume_qos_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'capacity', _capacity)
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'number', _number)
        

        volume_name_param = commonutil.set_parameter_with_instance(volume_name_param, tmp_volume_name_param, 'base_name_for_name', _base_name_for_name)
        

        volume_name_param = commonutil.set_parameter_with_instance(volume_name_param, tmp_volume_name_param, 'start_number_for_name', _start_number_for_name)
        

        volume_name_param = commonutil.set_parameter_with_instance(volume_name_param, tmp_volume_name_param, 'number_of_digits_for_name', _number_of_digits_for_name)
        

        volume_nickname_param = commonutil.set_parameter_with_instance(volume_nickname_param, tmp_volume_nickname_param, 'base_name', _base_name)
        

        volume_nickname_param = commonutil.set_parameter_with_instance(volume_nickname_param, tmp_volume_nickname_param, 'start_number', _start_number)
        

        volume_nickname_param = commonutil.set_parameter_with_instance(volume_nickname_param, tmp_volume_nickname_param, 'number_of_digits', _number_of_digits)
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'saving_setting', _saving_setting)
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'pool_id', _pool_id)
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'vps_id', _vps_id)
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'storage_controller_id', _storage_controller_id)
        

        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'fault_domain_id', _fault_domain_id)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_limit_for_iops', _upper_limit_for_iops)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_limit_for_transfer_rate', _upper_limit_for_transfer_rate)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_alert_allowable_time', _upper_alert_allowable_time)
        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'name_param', volume_name_param)
        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'nickname_param', volume_nickname_param)
        create_volume_param = commonutil.set_parameter_with_instance(create_volume_param, tmp_create_volume_param, 'qos_param', volume_qos_param)
        _create_volume = create_volume_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _pool_id_name is not None:
            # pool_listを使ってpool_id_nameに対応するpool_idを取得
            _pool_id = get_uuid_from_pool_list_with_pool_id_name(_pool_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_volume is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateVolumeParam import CreateVolumeParam
                _create_volume = CreateVolumeParam()
            _create_volume.pool_id = _pool_id

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_volume is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateVolumeParam import CreateVolumeParam
                _create_volume = CreateVolumeParam()
            _create_volume.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_create(create_volume = _create_volume, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_delete(_id,_id_name,_vps_id,_vps_id_name,):
    """
    Deletes a volume. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "volume_delete"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_delete`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")










        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteVolumeParam import DeleteVolumeParam
        _delete_volume = DeleteVolumeParam()
        _delete_volume.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_volume is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteVolumeParam import DeleteVolumeParam
                _delete_volume = DeleteVolumeParam()
            _delete_volume.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_delete(_id, delete_volume = _delete_volume, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
@click.option('--additional_capacity','_additional_capacity',type=int,metavar='<int>',help='Logical capacity (in MiB) added to the volume.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_expand(_id,_id_name,_additional_capacity,_vps_id,_vps_id_name,):
    """
    Expands the volume capacity. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_expand"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _additional_capacity is not None:
            subCommandLogtxt += "--additional_capacity " + str(_additional_capacity) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_expand"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_expand`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






















        if _additional_capacity is not None:
            if(isinstance(_additional_capacity, str)):
                _additional_capacity = SeparateArgs.check_backslash(_additional_capacity)
                _additional_capacity = _additional_capacity.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ExpandVolumeParam import ExpandVolumeParam
        _expand_volume_param = ExpandVolumeParam()
        _expand_volume_param.additional_capacity = _additional_capacity
        _expand_volume_param.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _expand_volume_param is None:
                from com.hitachi.sophia.rest_client.autogen.models.ExpandVolumeParam import ExpandVolumeParam
                _expand_volume_param = ExpandVolumeParam()
            _expand_volume_param.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_expand(_id, expand_volume_param = _expand_volume_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--pool_id','_pool_id',metavar='<str>',help='The ID of the storage pool to which the volume belongs. ')
@click.option('--pool_name','_pool_name',metavar='<str>',help='The name of the storage pool to which the volume belongs (exact match). ')
@click.option('--pool_id_name','_pool_id_name',metavar='<str>',help='Alias of pool_name.')
@click.option('--server_id','_server_id',metavar='<str>',help='The ID of the compute node to which the volume is allocated. ')
@click.option('--server_id_nickname','_server_id_nickname',metavar='<str>',help='The nickname of the compute node to which the volume is allocated (exact match).')
@click.option('--server_nickname','_server_nickname',metavar='<str>',help='The nickname of the compute node to which the volume is allocated (partial match). This parameter is ignored if server_id is specified. ')
@click.option('--name','_name',metavar='<str>',help='The volume name (exact match). ')
@click.option('--id_name','_id_name',metavar='<str>',help='Alias of name.')
@click.option('--names','_names',metavar='<str>',help='A list of the volume names (exact match). You can specify plural names (up to 32) by delimiting them with commas (,). When names include commas, escape the commas with \\ (Backslash). ')
@click.option('--id_names','_id_names',metavar='<str>',help='Alias of names.')
@click.option('--nickname','_nickname',metavar='<str>',help='Volume nickname (partial match). ')
@click.option('--min_total_capacity','_min_total_capacity',type=int,metavar='<int>',help='Minimum volume capacity (MiB). ')
@click.option('--max_total_capacity','_max_total_capacity',type=int,metavar='<int>',help='Maximum volume capacity (MiB). ')
@click.option('--min_used_capacity','_min_used_capacity',type=int,metavar='<int>',help='Minimum occupied volume capacity (MiB). ')
@click.option('--max_used_capacity','_max_used_capacity',type=int,metavar='<int>',help='Maximum occupied volume capacity (MiB). ')
@click.option('--saving_setting','_saving_setting',metavar='<str>',help='Setting of the capacity saving function of volumes. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The maximum number of obtained volume information items.')
@click.option('--storage_controller_id','_storage_controller_id',metavar='<str>',help='Storage controller ID. ')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
@click.option('--primary_fault_domain_id','_primary_fault_domain_id',metavar='<str>',help='The ID of the primary fault domain that originally manages volumes. ')
@click.option('--is_primary_fault_domain','_is_primary_fault_domain',metavar='<bool>',help='Whether volumes are managed in the same fault domain as the primary fault domain. ')
@click.option('--current_fault_domain_id','_current_fault_domain_id',metavar='<str>',help='The ID of the current fault domain that manages volumes. ')
def volume_list(_pool_id,_pool_name,_pool_id_name,_server_id,_server_id_nickname,_server_nickname,_name,_id_name,_names,_id_names,_nickname,_min_total_capacity,_max_total_capacity,_min_used_capacity,_max_used_capacity,_saving_setting,_enumerate_context,_count,_storage_controller_id,_vps_id,_vps_id_name,_primary_fault_domain_id,_is_primary_fault_domain,_current_fault_domain_id,):
    """
    Obtains a list of volumes. 
    """
    def get_uuid_from_server_list_with_server_id_nickname(server_id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=server_id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'server_id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _pool_id is not None:
            subCommandLogtxt += "--pool_id " + str(_pool_id) + " "




        if _pool_name is not None:
            subCommandLogtxt += "--pool_name " + str(_pool_name) + " "

        if _pool_id_name is not None:
            subCommandLogtxt += "--pool_id_name " + str(_pool_id_name) + " "



        if _server_id is not None:
            subCommandLogtxt += "--server_id " + str(_server_id) + " "

        if _server_id_nickname is not None:
            subCommandLogtxt += "--server_id_nickname " + str(_server_id_nickname) + " "



        if _server_nickname is not None:
            subCommandLogtxt += "--server_nickname " + str(_server_nickname) + " "




        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "



        if _names is not None:
            subCommandLogtxt += "--names " + str(_names) + " "

        if _id_names is not None:
            subCommandLogtxt += "--id_names " + str(_id_names) + " "



        if _nickname is not None:
            subCommandLogtxt += "--nickname " + str(_nickname) + " "




        if _min_total_capacity is not None:
            subCommandLogtxt += "--min_total_capacity " + str(_min_total_capacity) + " "




        if _max_total_capacity is not None:
            subCommandLogtxt += "--max_total_capacity " + str(_max_total_capacity) + " "




        if _min_used_capacity is not None:
            subCommandLogtxt += "--min_used_capacity " + str(_min_used_capacity) + " "




        if _max_used_capacity is not None:
            subCommandLogtxt += "--max_used_capacity " + str(_max_used_capacity) + " "





        if _saving_setting is not None:
            subCommandLogtxt += "--saving_setting " + str(_saving_setting) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "




        if _storage_controller_id is not None:
            subCommandLogtxt += "--storage_controller_id " + str(_storage_controller_id) + " "





        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "



        if _primary_fault_domain_id is not None:
            subCommandLogtxt += "--primary_fault_domain_id " + str(_primary_fault_domain_id) + " "




        if _is_primary_fault_domain is not None:
            subCommandLogtxt += "--is_primary_fault_domain " + str(_is_primary_fault_domain) + " "




        if _current_fault_domain_id is not None:
            subCommandLogtxt += "--current_fault_domain_id " + str(_current_fault_domain_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _pool_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _pool_id):
            raise ValueError("Invalid value for `pool_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--pool_name', _pool_name,'--pool_id_name', _pool_id_name, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--server_id', _server_id,'--server_id_nickname', _server_id_nickname, 'false')
        commonutil.view_error()


        
        #UUIDチェック
        if _server_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _server_id):
            raise ValueError("Invalid value for `server_id`, the format of UUID is invalid.")
        


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--name', _name,'--id_name', _id_name, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--names', _names,'--id_names', _id_names, 'false')
        commonutil.view_error()


        
        #フィルター配列チェック
        if _names is not None:
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('names',
                                                            _names,
                                                            '^[\-A-Za-z0-9,\.:@_]{1,32}$',
                                                            '^[\\-A-Za-z0-9,\\.:@_]{1,32}$',
                                                            32,
                                                            32)
        


        
        


        
        


        
        


        
        


        
        
        


        #Enumチェック
        allowed_values = ["Disabled", "Compression"]
        if _saving_setting is not None:
            if _saving_setting not in allowed_values:
                raise ValueError(
                    "Invalid value for `saving_setting` ({0}), (Select only one) {1}"
                    .format(_saving_setting, allowed_values)
            )
        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        #UUIDチェック
        if _storage_controller_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_controller_id):
            raise ValueError("Invalid value for `storage_controller_id`, the format of UUID is invalid.")
        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        #UUIDチェック
        if _primary_fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _primary_fault_domain_id):
            raise ValueError("Invalid value for `primary_fault_domain_id`, the format of UUID is invalid.")
        


        
        


        
        #UUIDチェック
        if _current_fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _current_fault_domain_id):
            raise ValueError("Invalid value for `current_fault_domain_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "volume_list"

















        if  _server_id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _server_id_nickname):
            raise ValueError("Invalid value for parameter `server_id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `server_id` when calling `volume_list`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






























































        if _count is not None and _count > 500:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `500`")
#           raise ValueError("Invalid value for parameter `count` when calling `volume_list`, must be a value less than or equal to `500`")
        max_count = 8192
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `volume_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0












        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")









        if _is_primary_fault_domain is not None and ((_is_primary_fault_domain != "true" and _is_primary_fault_domain != "false") and (_is_primary_fault_domain != True and _is_primary_fault_domain != False)):
            raise ValueError("Invalid value for `is_primary_fault_domain`, the format of the boolean value is invalid.")


















        if _id_names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('id_names',
                                                            _id_names,
                                                            '^[\-A-Za-z0-9,\.:@_]{1,32}$',
                                                            '^[\\-A-Za-z0-9,\\.:@_]{1,32}$',
                                                            32,
                                                            32)


        from com.hitachi.sophia.cli.manual.sub_commands.opt_validator.volume_list_OptValidator import volume_list_OptValidator
        volume_list_opt_validator = volume_list_OptValidator()

        ordered_dict_options = collections.OrderedDict()
        ordered_dict_options['pool_id'] = _pool_id
        ordered_dict_options['pool_name'] = _pool_name
        ordered_dict_options['pool_id_name'] = _pool_id_name
        ordered_dict_options['server_id'] = _server_id
        ordered_dict_options['server_id_nickname'] = _server_id_nickname
        ordered_dict_options['server_nickname'] = _server_nickname
        ordered_dict_options['name'] = _name
        ordered_dict_options['id_name'] = _id_name
        ordered_dict_options['names'] = _names
        ordered_dict_options['id_names'] = _id_names
        ordered_dict_options['nickname'] = _nickname
        ordered_dict_options['min_total_capacity'] = _min_total_capacity
        ordered_dict_options['max_total_capacity'] = _max_total_capacity
        ordered_dict_options['min_used_capacity'] = _min_used_capacity
        ordered_dict_options['max_used_capacity'] = _max_used_capacity
        ordered_dict_options['saving_setting'] = _saving_setting
        ordered_dict_options['enumerate_context'] = _enumerate_context
        ordered_dict_options['count'] = _count
        ordered_dict_options['storage_controller_id'] = _storage_controller_id
        ordered_dict_options['vps_id'] = _vps_id
        ordered_dict_options['vps_id_name'] = _vps_id_name
        ordered_dict_options['primary_fault_domain_id'] = _primary_fault_domain_id
        ordered_dict_options['is_primary_fault_domain'] = _is_primary_fault_domain
        ordered_dict_options['current_fault_domain_id'] = _current_fault_domain_id

        result_dict = volume_list_opt_validator.invoke(ordered_dict_options)

        _pool_id, _pool_name, _pool_id_name, _server_id, _server_id_nickname, _server_nickname, _name, _id_name, _names, _id_names, _nickname, _min_total_capacity, _max_total_capacity, _min_used_capacity, _max_used_capacity, _saving_setting, _enumerate_context, _count, _storage_controller_id, _vps_id, _vps_id_name, _primary_fault_domain_id, _is_primary_fault_domain, _current_fault_domain_id,  = ParamValidatorUtil().get_opt_values_from_dict(result_dict)


                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumeSummaryList import VolumeSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if not _pool_id_name is None:
            _pool_name = _pool_id_name

        if _server_id_nickname is not None:
            # server_listを使ってserver_id_nicknameに対応するserver_idを取得
            _server_id = get_uuid_from_server_list_with_server_id_nickname(_server_id_nickname)

        if not _id_name is None:
            _name = _id_name

        if not _id_names is None:
            _names = _id_names

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)

        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.volume_list(pool_id=_pool_id, pool_name=_pool_name, server_id=_server_id, server_nickname=_server_nickname, name=_name, names=_names, nickname=_nickname, min_total_capacity=_min_total_capacity, max_total_capacity=_max_total_capacity, min_used_capacity=_min_used_capacity, max_used_capacity=_max_used_capacity, saving_setting=_saving_setting, enumerate_context=_enumerate_context, count=_count, storage_controller_id=_storage_controller_id, vps_id=_vps_id, primary_fault_domain_id=_primary_fault_domain_id, is_primary_fault_domain=_is_primary_fault_domain, current_fault_domain_id=_current_fault_domain_id, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.volume_list(pool_id=_pool_id, pool_name=_pool_name, server_id=_server_id, server_nickname=_server_nickname, name=_name, names=_names, nickname=_nickname, min_total_capacity=_min_total_capacity, max_total_capacity=_max_total_capacity, min_used_capacity=_min_used_capacity, max_used_capacity=_max_used_capacity, saving_setting=_saving_setting, enumerate_context=_enumerate_context, count=_count, storage_controller_id=_storage_controller_id, vps_id=_vps_id, primary_fault_domain_id=_primary_fault_domain_id, is_primary_fault_domain=_is_primary_fault_domain, current_fault_domain_id=_current_fault_domain_id, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
def volume_show(_id,_id_name,):
    """
    Obtains the volume information. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        


        
        
        
        
        
        #cliSubCommand = "volume_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_show`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Volume import Volume

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
@click.option('--name','_name',type=str,metavar='<str>',help='The new name of the volume.')
@click.option('--nickname','_nickname',type=str,metavar='<str>',help='The nickname of the volume. The same nickname can be specified for multiple volumes.')
@click.option('--upper_limit_for_iops','_upper_limit_for_iops',type=int,metavar='<int>',help='Upper limit for the volume performance (IOPS).')
@click.option('--upper_limit_for_transfer_rate','_upper_limit_for_transfer_rate',type=int,metavar='<int>',help='Upper limit for the volume performance (MiB/sec).')
@click.option('--upper_alert_allowable_time','_upper_alert_allowable_time',type=int,metavar='<int>',help='Alert threshold (second) for the upper limit of volume performance.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_set(_id,_id_name,_name,_nickname,_upper_limit_for_iops,_upper_limit_for_transfer_rate,_upper_alert_allowable_time,_vps_id,_vps_id_name,):
    """
    Edits the volume settings. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "




        if _nickname is not None:
            subCommandLogtxt += "--nickname " + str(_nickname) + " "




        if _upper_limit_for_iops is not None:
            subCommandLogtxt += "--upper_limit_for_iops " + str(_upper_limit_for_iops) + " "




        if _upper_limit_for_transfer_rate is not None:
            subCommandLogtxt += "--upper_limit_for_transfer_rate " + str(_upper_limit_for_transfer_rate) + " "




        if _upper_alert_allowable_time is not None:
            subCommandLogtxt += "--upper_alert_allowable_time " + str(_upper_alert_allowable_time) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_set"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_update`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _name is not None:
            if(isinstance(_name, str)):
                _name = SeparateArgs.check_backslash(_name)
                _name = _name.encode("utf-8").decode("unicode-escape")
        if _nickname is not None:
            if(isinstance(_nickname, str)):
                _nickname = SeparateArgs.check_backslash(_nickname)
                _nickname = _nickname.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_iops is not None:
            if(isinstance(_upper_limit_for_iops, str)):
                _upper_limit_for_iops = SeparateArgs.check_backslash(_upper_limit_for_iops)
                _upper_limit_for_iops = _upper_limit_for_iops.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_transfer_rate is not None:
            if(isinstance(_upper_limit_for_transfer_rate, str)):
                _upper_limit_for_transfer_rate = SeparateArgs.check_backslash(_upper_limit_for_transfer_rate)
                _upper_limit_for_transfer_rate = _upper_limit_for_transfer_rate.encode("utf-8").decode("unicode-escape")
        if _upper_alert_allowable_time is not None:
            if(isinstance(_upper_alert_allowable_time, str)):
                _upper_alert_allowable_time = SeparateArgs.check_backslash(_upper_alert_allowable_time)
                _upper_alert_allowable_time = _upper_alert_allowable_time.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchVolumeParam import PatchVolumeParam
        tmp_patch_volume_param = PatchVolumeParam()
        patch_volume_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.VolumeQosParam import VolumeQosParam
        tmp_volume_qos_param = VolumeQosParam()
        volume_qos_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        patch_volume_param = commonutil.set_parameter_with_instance(patch_volume_param, tmp_patch_volume_param, 'name', _name)
        

        patch_volume_param = commonutil.set_parameter_with_instance(patch_volume_param, tmp_patch_volume_param, 'nickname', _nickname)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_limit_for_iops', _upper_limit_for_iops)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_limit_for_transfer_rate', _upper_limit_for_transfer_rate)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_alert_allowable_time', _upper_alert_allowable_time)
        

        patch_volume_param = commonutil.set_parameter_with_instance(patch_volume_param, tmp_patch_volume_param, 'vps_id', _vps_id)
        patch_volume_param = commonutil.set_parameter_with_instance(patch_volume_param, tmp_patch_volume_param, 'qos_param', volume_qos_param)
        _edit_volume = patch_volume_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _edit_volume is None:
                from com.hitachi.sophia.rest_client.autogen.models.PatchVolumeParam import PatchVolumeParam
                _edit_volume = PatchVolumeParam()
            _edit_volume.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_update(_id, edit_volume = _edit_volume, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['volume_create'] = volume_create
    commands['volume_delete'] = volume_delete
    commands['volume_expand'] = volume_expand
    commands['volume_list'] = volume_list
    commands['volume_show'] = volume_show
    commands['volume_set'] = volume_set
    return commands

