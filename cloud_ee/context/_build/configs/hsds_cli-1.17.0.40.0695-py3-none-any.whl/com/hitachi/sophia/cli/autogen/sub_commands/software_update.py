# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--mode','_mode',type=str,metavar='<str>',help='Modes for updating the software.',required=True)
@click.option('--downgrade','_downgrade',metavar='<bool>',help='Whether to perform software downgrade. When you perform software downgrade, specify "true". However, if you do not perform software downgrade, specifying this option has no effect.')
def storage_update_software(_mode,_downgrade,):
    """
    Updates the storage software. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_update_software"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _mode is not None:
            subCommandLogtxt += "--mode " + str(_mode) + " "




        if _downgrade is not None:
            subCommandLogtxt += "--downgrade " + str(_downgrade) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.software_update import SoftwareUpdate as SoftwareUpdateApi
        api = SoftwareUpdateApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_update_software"



















        if _mode is not None:
            if(isinstance(_mode, str)):
                _mode = SeparateArgs.check_backslash(_mode)
                _mode = _mode.encode("utf-8").decode("unicode-escape")
        if _downgrade is not None:
            if(isinstance(_downgrade, str)):
                _downgrade = SeparateArgs.check_backslash(_downgrade)
                _downgrade = _downgrade.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.UpdateSoftwareParam import UpdateSoftwareParam
        _update_software_param = UpdateSoftwareParam()
        _update_software_param.mode = _mode
        _update_software_param.downgrade = _downgrade

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.software_update(update_software_param = _update_software_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_software_update_file_show():
    """
    Obtains the information of the update file of the storage software which performed transfer (upload) in the storage cluster. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_software_update_file_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.software_update import SoftwareUpdate as SoftwareUpdateApi
        api = SoftwareUpdateApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_software_update_file_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.SoftwareUpdateFile import SoftwareUpdateFile

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.software_update_file_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--software_update_file','_software_update_file',metavar='<file>',help='The update file of the storage software to be transferred to the storage cluster. ',required=True)
def storage_upload_software_update_file(_software_update_file,):
    """
    Transfers (uploads) the update file of the storage software to the storage cluster. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_upload_software_update_file"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _software_update_file is not None:
            subCommandLogtxt += "--software_update_file " + str(_software_update_file) + " "







        logger.info(subCommandLogtxt)

        
    

    
        #ファイルが存在するか
        if not(os.path.isfile(_software_update_file)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_software_update_file)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
    

    



        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

        #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()


    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.software_update_manual import storage_upload_software_update_file_manual
        storage_upload_software_update_file_manual(_software_update_file,callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
def storage_stop_software_update():
    """
    Requests the stop of updating the storage software. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_stop_software_update"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.software_update import SoftwareUpdate as SoftwareUpdateApi
        api = SoftwareUpdateApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_stop_software_update"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.stop_software_update(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['storage_update_software'] = storage_update_software
    commands['storage_software_update_file_show'] = storage_software_update_file_show
    commands['storage_upload_software_update_file'] = storage_upload_software_update_file
    commands['storage_stop_software_update'] = storage_stop_software_update
    return commands

