# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--journal_number','_journal_number',type=int,metavar='<int>',help='Journal number.',required=True)
@click.option('--data_overflow_watch_in_seconds','_data_overflow_watch_in_seconds',type=int,metavar='<int>',help='Monitoring time for data overflow (unit: seconds).')
@click.option('--is_inflow_control_enabled','_is_inflow_control_enabled',metavar='<bool>',help='Whether to restrict update I/O inflow to journal volumes.')
@click.option('--is_cache_mode_enabled','_is_cache_mode_enabled',metavar='<bool>',help='Whether to enable the cache mode setting.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--volume_ids','_volume_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='A list of IDs of volumes to be added to a journal.',required=True)
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def journal_create(_journal_number,_volume_ids,_data_overflow_watch_in_seconds,_is_inflow_control_enabled,_is_cache_mode_enabled,_vps_id,_vps_id_name,):
    """
    Creates a journal.
    """
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "




        if _volume_ids is not None:
            subCommandLogtxt += "--volume_ids " + str(_volume_ids) + " "




        if _data_overflow_watch_in_seconds is not None:
            subCommandLogtxt += "--data_overflow_watch_in_seconds " + str(_data_overflow_watch_in_seconds) + " "




        if _is_inflow_control_enabled is not None:
            subCommandLogtxt += "--is_inflow_control_enabled " + str(_is_inflow_control_enabled) + " "




        if _is_cache_mode_enabled is not None:
            subCommandLogtxt += "--is_cache_mode_enabled " + str(_is_cache_mode_enabled) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "journal_create"





        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _journal_number is not None:
            if(isinstance(_journal_number, str)):
                _journal_number = SeparateArgs.check_backslash(_journal_number)
                _journal_number = _journal_number.encode("utf-8").decode("unicode-escape")
        if _volume_ids is not None:
            if(isinstance(_volume_ids, str)):
                _volume_ids = SeparateArgs.check_backslash(_volume_ids)
                _volume_ids = _volume_ids.encode("utf-8").decode("unicode-escape")
        if _data_overflow_watch_in_seconds is not None:
            if(isinstance(_data_overflow_watch_in_seconds, str)):
                _data_overflow_watch_in_seconds = SeparateArgs.check_backslash(_data_overflow_watch_in_seconds)
                _data_overflow_watch_in_seconds = _data_overflow_watch_in_seconds.encode("utf-8").decode("unicode-escape")
        if _is_inflow_control_enabled is not None:
            if(isinstance(_is_inflow_control_enabled, str)):
                _is_inflow_control_enabled = SeparateArgs.check_backslash(_is_inflow_control_enabled)
                _is_inflow_control_enabled = _is_inflow_control_enabled.encode("utf-8").decode("unicode-escape")
        if _is_cache_mode_enabled is not None:
            if(isinstance(_is_cache_mode_enabled, str)):
                _is_cache_mode_enabled = SeparateArgs.check_backslash(_is_cache_mode_enabled)
                _is_cache_mode_enabled = _is_cache_mode_enabled.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateJournalParam import CreateJournalParam
        _create_journal = CreateJournalParam()
        _create_journal.journal_number = _journal_number
        _create_journal.volume_ids = _volume_ids
        _create_journal.data_overflow_watch_in_seconds = _data_overflow_watch_in_seconds
        _create_journal.is_inflow_control_enabled = _is_inflow_control_enabled
        _create_journal.is_cache_mode_enabled = _is_cache_mode_enabled
        _create_journal.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_journal is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateJournalParam import CreateJournalParam
                _create_journal = CreateJournalParam()
            _create_journal.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_create(create_journal = _create_journal, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Journal ID.')
@click.option('--journal_number','_journal_number',metavar='<integer>',help='Journal number.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def journal_delete(_id,_journal_number,_vps_id,_vps_id_name,):
    """
    Deletes a journal.
    """
    def get_uuid_from_journal_list_with_journal_number(journal_number):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()
            ### cli専用オプション 代替識別内 個別journal number check
            try:
                number = int(journal_number)
            except Exception:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, " + journal_number + " is not a valid integer")

            if journal_number is not None and int(journal_number) > 255:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")

            if journal_number is not None and int(journal_number) < 0:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")

            response = api.journal_list(journal_number=journal_number)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'journal_number', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--journal_number', _journal_number, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "journal_delete"











        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")










        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteJournalParam import DeleteJournalParam
        _delete_journal = DeleteJournalParam()
        _delete_journal.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _journal_number is not None:
            # journal_listを使ってjournal_numberに対応するidを取得
            _id = get_uuid_from_journal_list_with_journal_number(_journal_number)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_journal is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteJournalParam import DeleteJournalParam
                _delete_journal = DeleteJournalParam()
            _delete_journal.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_delete(_id, delete_journal = _delete_journal, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Journal ID.')
@click.option('--journal_number','_journal_number',metavar='<integer>',help='Journal number.')
@click.option('--data_overflow_watch_in_seconds','_data_overflow_watch_in_seconds',type=int,metavar='<int>',help='Monitoring time for data overflow (unit: seconds).')
@click.option('--is_inflow_control_enabled','_is_inflow_control_enabled',metavar='<bool>',help='Whether to restrict update I/O inflow to journal volumes.')
@click.option('--is_cache_mode_enabled','_is_cache_mode_enabled',metavar='<bool>',help='Whether to enable the cache mode setting.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--mu_number','_mu_number',type=int,metavar='<int>',help='Mirror unit number (MU number).')
@click.option('--copy_pace','_copy_pace',type=str,metavar='<str>',help='Copy speed.')
@click.option('--copy_speed','_copy_speed',type=str,metavar='<str>',help='Data-transfer speed (unit: bps).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def journal_set(_id,_journal_number,_data_overflow_watch_in_seconds,_is_inflow_control_enabled,_is_cache_mode_enabled,_vps_id,_vps_id_name,_mu_number,_copy_pace,_copy_speed,):
    """
    Changes the journal setting.
    """
    def get_uuid_from_journal_list_with_journal_number(journal_number):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()
            ### cli専用オプション 代替識別内 個別journal number check
            try:
                number = int(journal_number)
            except Exception:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, " + journal_number + " is not a valid integer")

            if journal_number is not None and int(journal_number) > 255:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")

            if journal_number is not None and int(journal_number) < 0:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")

            response = api.journal_list(journal_number=journal_number)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'journal_number', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "






        if _data_overflow_watch_in_seconds is not None:
            subCommandLogtxt += "--data_overflow_watch_in_seconds " + str(_data_overflow_watch_in_seconds) + " "




        if _is_inflow_control_enabled is not None:
            subCommandLogtxt += "--is_inflow_control_enabled " + str(_is_inflow_control_enabled) + " "




        if _is_cache_mode_enabled is not None:
            subCommandLogtxt += "--is_cache_mode_enabled " + str(_is_cache_mode_enabled) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "



        if _mu_number is not None:
            subCommandLogtxt += "--mu_number " + str(_mu_number) + " "




        if _copy_pace is not None:
            subCommandLogtxt += "--copy_pace " + str(_copy_pace) + " "




        if _copy_speed is not None:
            subCommandLogtxt += "--copy_speed " + str(_copy_speed) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--journal_number', _journal_number, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "journal_set"











        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _data_overflow_watch_in_seconds is not None:
            if(isinstance(_data_overflow_watch_in_seconds, str)):
                _data_overflow_watch_in_seconds = SeparateArgs.check_backslash(_data_overflow_watch_in_seconds)
                _data_overflow_watch_in_seconds = _data_overflow_watch_in_seconds.encode("utf-8").decode("unicode-escape")
        if _is_inflow_control_enabled is not None:
            if(isinstance(_is_inflow_control_enabled, str)):
                _is_inflow_control_enabled = SeparateArgs.check_backslash(_is_inflow_control_enabled)
                _is_inflow_control_enabled = _is_inflow_control_enabled.encode("utf-8").decode("unicode-escape")
        if _is_cache_mode_enabled is not None:
            if(isinstance(_is_cache_mode_enabled, str)):
                _is_cache_mode_enabled = SeparateArgs.check_backslash(_is_cache_mode_enabled)
                _is_cache_mode_enabled = _is_cache_mode_enabled.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")
        if _mu_number is not None:
            if(isinstance(_mu_number, str)):
                _mu_number = SeparateArgs.check_backslash(_mu_number)
                _mu_number = _mu_number.encode("utf-8").decode("unicode-escape")
        if _copy_pace is not None:
            if(isinstance(_copy_pace, str)):
                _copy_pace = SeparateArgs.check_backslash(_copy_pace)
                _copy_pace = _copy_pace.encode("utf-8").decode("unicode-escape")
        if _copy_speed is not None:
            if(isinstance(_copy_speed, str)):
                _copy_speed = SeparateArgs.check_backslash(_copy_speed)
                _copy_speed = _copy_speed.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchJournalParam import PatchJournalParam
        tmp_patch_journal_param = PatchJournalParam()
        patch_journal_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.MirrorUnitSetting import MirrorUnitSetting
        tmp_mirror_unit_setting = MirrorUnitSetting()
        mirror_unit_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        patch_journal_param = commonutil.set_parameter_with_instance(patch_journal_param, tmp_patch_journal_param, 'data_overflow_watch_in_seconds', _data_overflow_watch_in_seconds)
        

        patch_journal_param = commonutil.set_parameter_with_instance(patch_journal_param, tmp_patch_journal_param, 'is_inflow_control_enabled', _is_inflow_control_enabled)
        

        patch_journal_param = commonutil.set_parameter_with_instance(patch_journal_param, tmp_patch_journal_param, 'is_cache_mode_enabled', _is_cache_mode_enabled)
        

        patch_journal_param = commonutil.set_parameter_with_instance(patch_journal_param, tmp_patch_journal_param, 'vps_id', _vps_id)
        

        mirror_unit_setting = commonutil.set_parameter_with_instance(mirror_unit_setting, tmp_mirror_unit_setting, 'mu_number', _mu_number)
        

        mirror_unit_setting = commonutil.set_parameter_with_instance(mirror_unit_setting, tmp_mirror_unit_setting, 'copy_pace', _copy_pace)
        

        mirror_unit_setting = commonutil.set_parameter_with_instance(mirror_unit_setting, tmp_mirror_unit_setting, 'copy_speed', _copy_speed)
        patch_journal_param = commonutil.set_parameter_with_instance(patch_journal_param, tmp_patch_journal_param, 'mirror_unit', mirror_unit_setting)
        _edit_journal = patch_journal_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _journal_number is not None:
            # journal_listを使ってjournal_numberに対応するidを取得
            _id = get_uuid_from_journal_list_with_journal_number(_journal_number)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _edit_journal is None:
                from com.hitachi.sophia.rest_client.autogen.models.PatchJournalParam import PatchJournalParam
                _edit_journal = PatchJournalParam()
            _edit_journal.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_edit(_id, edit_journal = _edit_journal, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Journal ID.')
@click.option('--journal_number','_journal_number',metavar='<integer>',help='Journal number.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--volume_ids','_volume_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='ID of the volume to be added to a journal.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def journal_expand(_id,_journal_number,_volume_ids,_vps_id,_vps_id_name,):
    """
    Adds a volume to a journal.
    """
    def get_uuid_from_journal_list_with_journal_number(journal_number):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()
            ### cli専用オプション 代替識別内 個別journal number check
            try:
                number = int(journal_number)
            except Exception:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, " + journal_number + " is not a valid integer")

            if journal_number is not None and int(journal_number) > 255:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")

            if journal_number is not None and int(journal_number) < 0:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")

            response = api.journal_list(journal_number=journal_number)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'journal_number', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_expand"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "






        if _volume_ids is not None:
            subCommandLogtxt += "--volume_ids " + str(_volume_ids) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--journal_number', _journal_number, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "journal_expand"











        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _volume_ids is not None:
            if(isinstance(_volume_ids, str)):
                _volume_ids = SeparateArgs.check_backslash(_volume_ids)
                _volume_ids = _volume_ids.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ExpandJournalParam import ExpandJournalParam
        _add_volume_to_journal = ExpandJournalParam()
        _add_volume_to_journal.volume_ids = _volume_ids
        _add_volume_to_journal.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _journal_number is not None:
            # journal_listを使ってjournal_numberに対応するidを取得
            _id = get_uuid_from_journal_list_with_journal_number(_journal_number)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_volume_to_journal is None:
                from com.hitachi.sophia.rest_client.autogen.models.ExpandJournalParam import ExpandJournalParam
                _add_volume_to_journal = ExpandJournalParam()
            _add_volume_to_journal.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_expand(_id, add_volume_to_journal = _add_volume_to_journal, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
@click.option('--journal_number','_journal_number',type=int,metavar='<int>',help='Journal number.')
@click.option('--storage_controller_id','_storage_controller_id',metavar='<str>',help='Storage controller ID. ')
def journal_list(_vps_id,_vps_id_name,_journal_number,_storage_controller_id,):
    """
    Obtains a list of journal information.
    """
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "



        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "




        if _storage_controller_id is not None:
            subCommandLogtxt += "--storage_controller_id " + str(_storage_controller_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        #UUIDチェック
        if _storage_controller_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_controller_id):
            raise ValueError("Invalid value for `storage_controller_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "journal_list"

        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `journal_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `journal_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if _journal_number is not None and _journal_number > 255:
            raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `journal_number` when calling `journal_list`, must be a value less than or equal to `255`")
        if _journal_number is not None and _journal_number < 0:
            raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `journal_number` when calling `journal_list`, must be a value greater than or equal to `0`")























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.JournalList import JournalList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_list(vps_id = _vps_id, journal_number = _journal_number, storage_controller_id = _storage_controller_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Journal ID.')
@click.option('--journal_number','_journal_number',metavar='<integer>',help='Journal number.')
def journal_show(_id,_journal_number,):
    """
    Obtains journal information.
    """
    def get_uuid_from_journal_list_with_journal_number(journal_number):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()
            ### cli専用オプション 代替識別内 個別journal number check
            try:
                number = int(journal_number)
            except Exception:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, " + journal_number + " is not a valid integer")

            if journal_number is not None and int(journal_number) > 255:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")

            if journal_number is not None and int(journal_number) < 0:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")

            response = api.journal_list(journal_number=journal_number)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'journal_number', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--journal_number', _journal_number, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "journal_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Journal import Journal

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _journal_number is not None:
            # journal_listを使ってjournal_numberに対応するidを取得
            _id = get_uuid_from_journal_list_with_journal_number(_journal_number)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Journal ID.')
@click.option('--journal_number','_journal_number',metavar='<integer>',help='Journal number.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--volume_ids','_volume_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='ID of the volume to be deleted from a journal.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def journal_shrink(_id,_journal_number,_volume_ids,_vps_id,_vps_id_name,):
    """
    Deletes a journal volume from a journal.
    """
    def get_uuid_from_journal_list_with_journal_number(journal_number):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()
            ### cli専用オプション 代替識別内 個別journal number check
            try:
                number = int(journal_number)
            except Exception:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, " + journal_number + " is not a valid integer")

            if journal_number is not None and int(journal_number) > 255:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")

            if journal_number is not None and int(journal_number) < 0:
                raise ValueError("Invalid value for parameter `journal_number` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")

            response = api.journal_list(journal_number=journal_number)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'journal_number', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "journal_shrink"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _journal_number is not None:
            subCommandLogtxt += "--journal_number " + str(_journal_number) + " "






        if _volume_ids is not None:
            subCommandLogtxt += "--volume_ids " + str(_volume_ids) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.journal_management import JournalManagement as JournalManagementApi
        api = JournalManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--journal_number', _journal_number, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "journal_shrink"











        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _volume_ids is not None:
            if(isinstance(_volume_ids, str)):
                _volume_ids = SeparateArgs.check_backslash(_volume_ids)
                _volume_ids = _volume_ids.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ShrinkJournalParam import ShrinkJournalParam
        _delete_volume_to_journal = ShrinkJournalParam()
        _delete_volume_to_journal.volume_ids = _volume_ids
        _delete_volume_to_journal.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _journal_number is not None:
            # journal_listを使ってjournal_numberに対応するidを取得
            _id = get_uuid_from_journal_list_with_journal_number(_journal_number)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_volume_to_journal is None:
                from com.hitachi.sophia.rest_client.autogen.models.ShrinkJournalParam import ShrinkJournalParam
                _delete_volume_to_journal = ShrinkJournalParam()
            _delete_volume_to_journal.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.journal_shrink(_id, delete_volume_to_journal = _delete_volume_to_journal, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['journal_create'] = journal_create
    commands['journal_delete'] = journal_delete
    commands['journal_set'] = journal_set
    commands['journal_expand'] = journal_expand
    commands['journal_list'] = journal_list
    commands['journal_show'] = journal_show
    commands['journal_shrink'] = journal_shrink
    return commands

