# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--remote_serial_number','_remote_serial_number',type=str,metavar='<str>',help='Serial number of the remote storage system.',required=True)
@click.option('--remote_storage_type_id','_remote_storage_type_id',type=str,metavar='<str>',help='ID indicating the remote storage system model.',required=True)
@click.option('--path_group_id','_path_group_id',type=int,metavar='<int>',help='Path group ID.',required=True)
@click.option('--local_port_number','_local_port_number',type=str,metavar='<str>',help='Port number of the local storage system in CLx-y format.',required=True)
@click.option('--remote_port_number','_remote_port_number',type=str,metavar='<str>',help='Port number of the remote storage system in CLx-y format.',required=True)
@click.option('--timeout_value_for_remote_io_in_seconds','_timeout_value_for_remote_io_in_seconds',type=int,metavar='<int>',help='Timeout setting value for the RIO (remote IO) between the local storage system and remote storage system (unit: seconds).')
def remotepath_group_create(_remote_serial_number,_remote_storage_type_id,_path_group_id,_local_port_number,_remote_port_number,_timeout_value_for_remote_io_in_seconds,):
    """
    Creates a remote path group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remotepath_group_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _remote_serial_number is not None:
            subCommandLogtxt += "--remote_serial_number " + str(_remote_serial_number) + " "




        if _remote_storage_type_id is not None:
            subCommandLogtxt += "--remote_storage_type_id " + str(_remote_storage_type_id) + " "




        if _path_group_id is not None:
            subCommandLogtxt += "--path_group_id " + str(_path_group_id) + " "




        if _local_port_number is not None:
            subCommandLogtxt += "--local_port_number " + str(_local_port_number) + " "




        if _remote_port_number is not None:
            subCommandLogtxt += "--remote_port_number " + str(_remote_port_number) + " "




        if _timeout_value_for_remote_io_in_seconds is not None:
            subCommandLogtxt += "--timeout_value_for_remote_io_in_seconds " + str(_timeout_value_for_remote_io_in_seconds) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remotepath_group_create"



















        if _remote_serial_number is not None:
            if(isinstance(_remote_serial_number, str)):
                _remote_serial_number = SeparateArgs.check_backslash(_remote_serial_number)
                _remote_serial_number = _remote_serial_number.encode("utf-8").decode("unicode-escape")
        if _remote_storage_type_id is not None:
            if(isinstance(_remote_storage_type_id, str)):
                _remote_storage_type_id = SeparateArgs.check_backslash(_remote_storage_type_id)
                _remote_storage_type_id = _remote_storage_type_id.encode("utf-8").decode("unicode-escape")
        if _path_group_id is not None:
            if(isinstance(_path_group_id, str)):
                _path_group_id = SeparateArgs.check_backslash(_path_group_id)
                _path_group_id = _path_group_id.encode("utf-8").decode("unicode-escape")
        if _local_port_number is not None:
            if(isinstance(_local_port_number, str)):
                _local_port_number = SeparateArgs.check_backslash(_local_port_number)
                _local_port_number = _local_port_number.encode("utf-8").decode("unicode-escape")
        if _remote_port_number is not None:
            if(isinstance(_remote_port_number, str)):
                _remote_port_number = SeparateArgs.check_backslash(_remote_port_number)
                _remote_port_number = _remote_port_number.encode("utf-8").decode("unicode-escape")
        if _timeout_value_for_remote_io_in_seconds is not None:
            if(isinstance(_timeout_value_for_remote_io_in_seconds, str)):
                _timeout_value_for_remote_io_in_seconds = SeparateArgs.check_backslash(_timeout_value_for_remote_io_in_seconds)
                _timeout_value_for_remote_io_in_seconds = _timeout_value_for_remote_io_in_seconds.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateRemotePathGroupParam import CreateRemotePathGroupParam
        _create_remote_connection = CreateRemotePathGroupParam()
        _create_remote_connection.remote_serial_number = _remote_serial_number
        _create_remote_connection.remote_storage_type_id = _remote_storage_type_id
        _create_remote_connection.path_group_id = _path_group_id
        _create_remote_connection.local_port_number = _local_port_number
        _create_remote_connection.remote_port_number = _remote_port_number
        _create_remote_connection.timeout_value_for_remote_io_in_seconds = _timeout_value_for_remote_io_in_seconds

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_connection_create(create_remote_connection = _create_remote_connection, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote path group ID. ',required=True)
def remotepath_group_delete(_id,):
    """
    Deletes a remote path group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remotepath_group_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "remotepath_group_delete"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_connection_delete(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--local_storage_controller_id','_local_storage_controller_id',metavar='<str>',help='Controller ID for the local storage system. ')
@click.option('--remote_serial_number','_remote_serial_number',metavar='<str>',help='Serial number of the remote storage system. ')
@click.option('--remote_storage_type_id','_remote_storage_type_id',metavar='<str>',help='ID indicating the remote storage system model. ')
@click.option('--path_group_id','_path_group_id',type=int,metavar='<int>',help='Path group ID.')
def remotepath_group_list(_local_storage_controller_id,_remote_serial_number,_remote_storage_type_id,_path_group_id,):
    """
    Obtains a list of remote path groups. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remotepath_group_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _local_storage_controller_id is not None:
            subCommandLogtxt += "--local_storage_controller_id " + str(_local_storage_controller_id) + " "




        if _remote_serial_number is not None:
            subCommandLogtxt += "--remote_serial_number " + str(_remote_serial_number) + " "




        if _remote_storage_type_id is not None:
            subCommandLogtxt += "--remote_storage_type_id " + str(_remote_storage_type_id) + " "




        if _path_group_id is not None:
            subCommandLogtxt += "--path_group_id " + str(_path_group_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _local_storage_controller_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _local_storage_controller_id):
            raise ValueError("Invalid value for `local_storage_controller_id`, the format of UUID is invalid.")
        


        
        


        #Enumチェック
        allowed_values = ["R9", "M8"]
        if _remote_storage_type_id is not None:
            if _remote_storage_type_id not in allowed_values:
                raise ValueError(
                    "Invalid value for `remote_storage_type_id` ({0}), (Select only one) {1}"
                    .format(_remote_storage_type_id, allowed_values)
            )
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remotepath_group_list"







        if _remote_serial_number is not None and len(_remote_serial_number) > 6:
            raise ValueError("Invalid value for parameter `remote_serial_number` when calling `" + cliSubCommand + "`, length must be equal to `6`")
#           raise ValueError("Invalid value for parameter `remote_serial_number` when calling `remote_connection_list`, length must be equal to `6`")
        if _remote_serial_number is not None and len(_remote_serial_number) < 6:
            raise ValueError("Invalid value for parameter `remote_serial_number` when calling `" + cliSubCommand + "`, length must be equal to `6`")
#           raise ValueError("Invalid value for parameter `remote_serial_number` when calling `remote_connection_list`, length must be equal to `6`")
        if  _remote_serial_number is not None and not re.search('^[0-9]{6}$', _remote_serial_number):
            raise ValueError("Invalid value for parameter `remote_serial_number` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[0-9]{6}$/`")
#           raise ValueError("Invalid value for parameter `remote_serial_number` when calling `remote_connection_list`, must conform to the pattern `/^[0-9]{6}$/`")












        if _path_group_id is not None and _path_group_id > 255:
            raise ValueError("Invalid value for parameter `path_group_id` when calling `" + cliSubCommand + "`, must be a value less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `path_group_id` when calling `remote_connection_list`, must be a value less than or equal to `255`")
        if _path_group_id is not None and _path_group_id < 1:
            raise ValueError("Invalid value for parameter `path_group_id` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `path_group_id` when calling `remote_connection_list`, must be a value greater than or equal to `1`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.RemotePathGroupSummaryList import RemotePathGroupSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_connection_list(local_storage_controller_id = _local_storage_controller_id, remote_serial_number = _remote_serial_number, remote_storage_type_id = _remote_storage_type_id, path_group_id = _path_group_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote path group ID. ',required=True)
@click.option('--timeout_value_for_remote_io_in_seconds','_timeout_value_for_remote_io_in_seconds',type=int,metavar='<int>',help='Timeout setting value for the RIO (remote IO) between the local storage system and remote storage system (unit: seconds).',required=True)
def remotepath_group_set(_id,_timeout_value_for_remote_io_in_seconds,):
    """
    Changes the settings of a remote path group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remotepath_group_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _timeout_value_for_remote_io_in_seconds is not None:
            subCommandLogtxt += "--timeout_value_for_remote_io_in_seconds " + str(_timeout_value_for_remote_io_in_seconds) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remotepath_group_set"

























        if _timeout_value_for_remote_io_in_seconds is not None:
            if(isinstance(_timeout_value_for_remote_io_in_seconds, str)):
                _timeout_value_for_remote_io_in_seconds = SeparateArgs.check_backslash(_timeout_value_for_remote_io_in_seconds)
                _timeout_value_for_remote_io_in_seconds = _timeout_value_for_remote_io_in_seconds.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchRemotePathGroupParam import PatchRemotePathGroupParam
        _patch_remote_path_group = PatchRemotePathGroupParam()
        _patch_remote_path_group.timeout_value_for_remote_io_in_seconds = _timeout_value_for_remote_io_in_seconds

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_connection_update(_id, patch_remote_path_group = _patch_remote_path_group, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote path group ID. ',required=True)
@click.option('--local_port_number','_local_port_number',type=str,metavar='<str>',help='Port number of the local storage system in CLx-y format.',required=True)
@click.option('--remote_port_number','_remote_port_number',type=str,metavar='<str>',help='Port number of the remote storage system in CLx-y format.',required=True)
def remote_path_add(_id,_local_port_number,_remote_port_number,):
    """
    Adds a remote path to a remote path group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remote_path_add"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _local_port_number is not None:
            subCommandLogtxt += "--local_port_number " + str(_local_port_number) + " "




        if _remote_port_number is not None:
            subCommandLogtxt += "--remote_port_number " + str(_remote_port_number) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remote_path_add"

























        if _local_port_number is not None:
            if(isinstance(_local_port_number, str)):
                _local_port_number = SeparateArgs.check_backslash(_local_port_number)
                _local_port_number = _local_port_number.encode("utf-8").decode("unicode-escape")
        if _remote_port_number is not None:
            if(isinstance(_remote_port_number, str)):
                _remote_port_number = SeparateArgs.check_backslash(_remote_port_number)
                _remote_port_number = _remote_port_number.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.AddRemotePathParam import AddRemotePathParam
        _add_remote_path = AddRemotePathParam()
        _add_remote_path.local_port_number = _local_port_number
        _add_remote_path.remote_port_number = _remote_port_number

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_path_add(_id, add_remote_path = _add_remote_path, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote path group ID. ',required=True)
@click.option('--local_port_number','_local_port_number',type=str,metavar='<str>',help='Port number of the local storage system in CLx-y format.',required=True)
@click.option('--remote_port_number','_remote_port_number',type=str,metavar='<str>',help='Port number of the remote storage system in CLx-y format.',required=True)
def remote_path_delete(_id,_local_port_number,_remote_port_number,):
    """
    Deletes a remote path from a remote path group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remote_path_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _local_port_number is not None:
            subCommandLogtxt += "--local_port_number " + str(_local_port_number) + " "




        if _remote_port_number is not None:
            subCommandLogtxt += "--remote_port_number " + str(_remote_port_number) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remote_path_delete"

























        if _local_port_number is not None:
            if(isinstance(_local_port_number, str)):
                _local_port_number = SeparateArgs.check_backslash(_local_port_number)
                _local_port_number = _local_port_number.encode("utf-8").decode("unicode-escape")
        if _remote_port_number is not None:
            if(isinstance(_remote_port_number, str)):
                _remote_port_number = SeparateArgs.check_backslash(_remote_port_number)
                _remote_port_number = _remote_port_number.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.RemoveRemotePathParam import RemoveRemotePathParam
        _remove_remote_path = RemoveRemotePathParam()
        _remove_remote_path.local_port_number = _local_port_number
        _remove_remote_path.remote_port_number = _remote_port_number

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_path_delete(_id, remove_remote_path = _remove_remote_path, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote path group ID. ',required=True)
def remotepath_group_show(_id,):
    """
    Obtains information about a remote path group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remotepath_group_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remotepath_group_management import RemotepathGroupManagement as RemotepathGroupManagementApi
        api = RemotepathGroupManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "remotepath_group_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.RemotePathGroup import RemotePathGroup

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_path_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['remotepath_group_create'] = remotepath_group_create
    commands['remotepath_group_delete'] = remotepath_group_delete
    commands['remotepath_group_list'] = remotepath_group_list
    commands['remotepath_group_set'] = remotepath_group_set
    commands['remote_path_add'] = remote_path_add
    commands['remote_path_delete'] = remote_path_delete
    commands['remotepath_group_show'] = remotepath_group_show
    return commands

