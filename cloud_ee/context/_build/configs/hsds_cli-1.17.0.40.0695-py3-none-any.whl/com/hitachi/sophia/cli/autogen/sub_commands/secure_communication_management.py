# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--server_certificate','_server_certificate',metavar='<file>',help='The server certificate file (public key) to be transferred to the storage cluster. ',required=True)
@click.option('--secret_key','_secret_key',metavar='<file>',hidden=True,help='The server certificate file (private key) to be transferred to the storage cluster. ')
def server_certificate_import(_server_certificate,_secret_key,):
    """
    Imports the server certificate. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "server_certificate_import"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _server_certificate is not None:
            subCommandLogtxt += "--server_certificate " + str(_server_certificate) + " "









        logger.info(subCommandLogtxt)

        
    

    
        #ファイルが存在するか
        if not(os.path.isfile(_server_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_server_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        #ファイルが存在するか
        if not(os.path.isfile(_secret_key)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_secret_key)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
    

    



        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

        #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()


    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.secure_communication_management_manual import server_certificate_import_manual
        server_certificate_import_manual(_server_certificate,_secret_key,callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables the allowlist function for the web server.')
@click.option('--client_names','_client_names',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of senders set in allowlist of the web server.')
def web_server_access_setting_set(_is_enabled,_client_names,):
    """
    Edits the access settings of the web server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "web_server_access_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "




        if _client_names is not None:
            subCommandLogtxt += "--client_names " + str(_client_names) + " "








        logger.info(subCommandLogtxt)

        
    

    

    




    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.secure_communication_management_manual import web_server_access_setting_set_manual
        web_server_access_setting_set_manual(_is_enabled,_client_names,callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
def web_server_access_setting_show():
    """
    Obtains the access settings of the web server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "web_server_access_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.secure_communication_management import SecureCommunicationManagement as SecureCommunicationManagementApi
        api = SecureCommunicationManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "web_server_access_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.WebServerAccessSetting import WebServerAccessSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.web_server_firewall_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['server_certificate_import'] = server_certificate_import
    commands['web_server_access_setting_set'] = web_server_access_setting_set
    commands['web_server_access_setting_show'] = web_server_access_setting_show
    return commands

