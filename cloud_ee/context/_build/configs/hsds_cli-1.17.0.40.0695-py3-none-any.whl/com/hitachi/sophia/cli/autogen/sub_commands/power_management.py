# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--force','_force',metavar='<bool>',help='Specifies whether to shut down the storage cluster. Specify true to shut it down forcibly.')
@click.option('--reboot','_reboot',metavar='<bool>',help='Specifies whether to restart the storage cluster. Specify false to stop it, or true to restart it.')
@click.option('--config_parameter_setting_mode','_config_parameter_setting_mode',metavar='<bool>',help='Specifies whether to start the storage cluster in the configuration parameter setting mode after shutdown. Specify true to start the storage cluster in the configuration parameter setting mode. (Bare metal)(Cloud)')
def storage_shutdown(_force,_reboot,_config_parameter_setting_mode,):
    """
    Stops the storage cluster. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_shutdown"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _force is not None:
            subCommandLogtxt += "--force " + str(_force) + " "




        if _reboot is not None:
            subCommandLogtxt += "--reboot " + str(_reboot) + " "




        if _config_parameter_setting_mode is not None:
            subCommandLogtxt += "--config_parameter_setting_mode " + str(_config_parameter_setting_mode) + " "










        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.power_management import PowerManagement as PowerManagementApi
        api = PowerManagementApi(ApiClient())

        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_shutdown"

























        if _force is not None:
            if(isinstance(_force, str)):
                _force = SeparateArgs.check_backslash(_force)
                _force = _force.encode("utf-8").decode("unicode-escape")
        if _reboot is not None:
            if(isinstance(_reboot, str)):
                _reboot = SeparateArgs.check_backslash(_reboot)
                _reboot = _reboot.encode("utf-8").decode("unicode-escape")
        if _config_parameter_setting_mode is not None:
            if(isinstance(_config_parameter_setting_mode, str)):
                _config_parameter_setting_mode = SeparateArgs.check_backslash(_config_parameter_setting_mode)
                _config_parameter_setting_mode = _config_parameter_setting_mode.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ShutdownStorageParam import ShutdownStorageParam
        _shutdown_storage = ShutdownStorageParam()
        _shutdown_storage.force = _force
        _shutdown_storage.reboot = _reboot
        _shutdown_storage.config_parameter_setting_mode = _config_parameter_setting_mode

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_shutdown(shutdown_storage = _shutdown_storage, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['storage_shutdown'] = storage_shutdown
    return commands

