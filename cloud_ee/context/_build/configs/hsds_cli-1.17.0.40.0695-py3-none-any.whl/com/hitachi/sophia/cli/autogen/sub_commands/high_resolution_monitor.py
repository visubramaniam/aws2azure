# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--ids','_ids',metavar='<str>',help='The control port ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. This parameter must be specified. ',required=True)
def control_port_detail_performance_list(_ids,):
    """
    Obtains a list of control port performance information for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "control_port_detail_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "control_port_detail_performance_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ControlPortPerformanceListResponse import ControlPortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.control_port_performance_detail_list(_ids, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Control port ID ',required=True)
def control_port_detail_performance_show(_id,):
    """
    Obtains the information about performance of a specified control port for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "control_port_detail_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "control_port_detail_performance_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ControlPortPerformanceListResponse import ControlPortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.control_port_performance_detail_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--ids','_ids',metavar='<str>',help='The drive ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. This parameter must be specified. ',required=True)
def drive_detail_performance_list(_ids,):
    """
    Obtains a list of drive performance information for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_detail_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "drive_detail_performance_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DrivePerformanceListResponse import DrivePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.drive_performance_detail_list(_ids, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Drive ID ',required=True)
def drive_detail_performance_show(_id,):
    """
    Obtains the information about performance of a specified drive for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_detail_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "drive_detail_performance_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DrivePerformanceListResponse import DrivePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.drive_performance_detail_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--ids','_ids',metavar='<str>',help='The internode port ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. This parameter must be specified. ',required=True)
def internode_port_detail_performance_list(_ids,):
    """
    Obtains a list of internode port performance information for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "internode_port_detail_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "internode_port_detail_performance_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.InternodePortPerformanceListResponse import InternodePortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.internode_port_performance_detail_list(_ids, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Internode port ID ',required=True)
def internode_port_detail_performance_show(_id,):
    """
    Obtains the information about performance of a specified internode port for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "internode_port_detail_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "internode_port_detail_performance_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.InternodePortPerformanceListResponse import InternodePortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.internode_port_performance_detail_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--ids','_ids',metavar='<str>',help='The compute port ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. ')
@click.option('--names','_names',metavar='<str>',help='List of WWNs of the compute port for FC connection or the iSCSI names for iSCSI connections. You can specify plural values (up to 32) by delimiting them with commas (,).')
@click.option('--id_names','_id_names',metavar='<str>',help='Alias of names.')
def port_detail_performance_list(_ids,_names,_id_names,):
    """
    Obtains a list of compute port performance information for the high-resolution monitor. 
    """
    def get_uuid_from_port_list_with_names(names):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            names_list = uuidutil.escapeArrayValue(names)
            names_list = uuidutil.delete_duplication_array_value(names_list)
            names_list_str = uuidutil.arrayToString(names_list)


            response = api.port_list(names=names_list_str)

            uuidutil.determin_status_doce_of_list_reference(response)

            uuid_list = uuidutil.getUuidFromResponseForArray(response, names_list,'names','name','id')
            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_port_list_with_id_names(id_names):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            id_names_list = uuidutil.escapeArrayValue(id_names)
            id_names_list = uuidutil.delete_duplication_array_value(id_names_list)
            id_names_list_str = uuidutil.arrayToString(id_names_list)


            response = api.port_list(names=id_names_list_str)

            uuidutil.determin_status_doce_of_list_reference(response)

            uuid_list = uuidutil.getUuidFromResponseForArray(response, id_names_list,'id_names','name','id')
            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_detail_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "

        if _names is not None:
            subCommandLogtxt += "--names " + str(_names) + " "
        if _id_names is not None:
            subCommandLogtxt += "--id_names " + str(_id_names) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        ordered_dict_options = collections.OrderedDict()
        ordered_dict_options['ids'] = _ids
        ordered_dict_options['names'] = _names
        ordered_dict_options['id_names'] = _id_names
        param_validator_util.check_multi_parameter_combinations(ordered_dict_options, 'true')
        commonutil.view_error()


        
        
        


        
        
        
        
        
        #cliSubCommand = "port_detail_performance_list"














        if _names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('names',
                                                            _names,
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$',
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\\.[0-9]{4}\\-[0-9]{2}\\.[a-zA-Z0-9\\-:\\.]{0,211})|(eui\\.[0-9a-fA-F]{16}))$',
                                                            32,
                                                            223)
        if _id_names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('id_names',
                                                            _id_names,
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$',
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\\.[0-9]{4}\\-[0-9]{2}\\.[a-zA-Z0-9\\-:\\.]{0,211})|(eui\\.[0-9a-fA-F]{16}))$',
                                                            32,
                                                            223)




                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PortPerformanceListResponse import PortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _names is not None:
            # port_listを使ってnamesに対応するidsを取得
            _ids = get_uuid_from_port_list_with_names(_names)

        if _id_names is not None:
            # port_listを使ってid_namesに対応するidsを取得
            _ids = get_uuid_from_port_list_with_id_names(_id_names)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_performance_detail_list(_ids, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
def port_detail_performance_show(_id,_id_name,):
    """
    Obtains the information about performance of a specified compute port for the high-resolution monitor. 
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_detail_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "port_detail_performance_show"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_performance_detail_show`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PortPerformanceListResponse import PortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_performance_detail_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--ids','_ids',metavar='<str>',help='The storage node ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. This parameter must be specified. ')
def storage_node_detail_performance_list(_ids,):
    """
    Obtains a list of storage node performance information for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_detail_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_detail_performance_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodePerformanceListResponse import StorageNodePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_performance_detail_list(ids = _ids, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_detail_performance_show(_id,):
    """
    Obtains the information about performance of a specified storage node for the high-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_detail_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_detail_performance_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodePerformanceListResponse import StorageNodePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_performance_detail_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--ids','_ids',metavar='<str>',help='The volume ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. ')
@click.option('--names','_names',metavar='<str>',help='List of the volume names (exact match). You can specify plural values (up to 32) by delimiting them with commas (,). When names include commas, escape the commas with  \ (Backslash).')
@click.option('--id_names','_id_names',metavar='<str>',help='Alias of names.')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def volume_detail_performance_list(_ids,_names,_id_names,_vps_id,_vps_id_name,):
    """
    Obtains a list of volume performance information for the high-resolution monitor. 
    """
    def get_uuid_from_volume_list_with_names(names):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            names_list = uuidutil.escapeArrayValue(names)
            names_list = uuidutil.delete_duplication_array_value(names_list)
            names_list_str = uuidutil.arrayToString(names_list)


            response = api.volume_list(names=names_list_str)

            uuidutil.determin_status_doce_of_list_reference(response)

            uuid_list = uuidutil.getUuidFromResponseForArray(response, names_list,'names','name','id')
            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_volume_list_with_id_names(id_names):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            id_names_list = uuidutil.escapeArrayValue(id_names)
            id_names_list = uuidutil.delete_duplication_array_value(id_names_list)
            id_names_list_str = uuidutil.arrayToString(id_names_list)


            response = api.volume_list(names=id_names_list_str)

            uuidutil.determin_status_doce_of_list_reference(response)

            uuid_list = uuidutil.getUuidFromResponseForArray(response, id_names_list,'id_names','name','id')
            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_detail_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "

        if _names is not None:
            subCommandLogtxt += "--names " + str(_names) + " "
        if _id_names is not None:
            subCommandLogtxt += "--id_names " + str(_id_names) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        ordered_dict_options = collections.OrderedDict()
        ordered_dict_options['ids'] = _ids
        ordered_dict_options['names'] = _names
        ordered_dict_options['id_names'] = _id_names
        param_validator_util.check_multi_parameter_combinations(ordered_dict_options, 'true')
        commonutil.view_error()


        
        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "volume_detail_performance_list"







        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_performance_detail_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_performance_detail_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")









        if _names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('names',
                                                            _names,
                                                            '^[\-A-Za-z0-9,\.:@_]{1,32}$',
                                                            '^[\\-A-Za-z0-9,\\.:@_]{1,32}$',
                                                            32,
                                                            32)
        if _id_names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('id_names',
                                                            _id_names,
                                                            '^[\-A-Za-z0-9,\.:@_]{1,32}$',
                                                            '^[\\-A-Za-z0-9,\\.:@_]{1,32}$',
                                                            32,
                                                            32)




                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumePerformanceListResponse import VolumePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _names is not None:
            # volume_listを使ってnamesに対応するidsを取得
            _ids = get_uuid_from_volume_list_with_names(_names)

        if _id_names is not None:
            # volume_listを使ってid_namesに対応するidsを取得
            _ids = get_uuid_from_volume_list_with_id_names(_id_names)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_performance_detail_list(_ids, vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
def volume_detail_performance_show(_id,_id_name,):
    """
    Obtains the information about performance of a specified volume for the high-resolution monitor. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_detail_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.high_resolution_monitor import HighResolutionMonitor as HighResolutionMonitorApi
        api = HighResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "volume_detail_performance_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_performance_detail_show`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumePerformanceListResponse import VolumePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_performance_detail_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['control_port_detail_performance_list'] = control_port_detail_performance_list
    commands['control_port_detail_performance_show'] = control_port_detail_performance_show
    commands['drive_detail_performance_list'] = drive_detail_performance_list
    commands['drive_detail_performance_show'] = drive_detail_performance_show
    commands['internode_port_detail_performance_list'] = internode_port_detail_performance_list
    commands['internode_port_detail_performance_show'] = internode_port_detail_performance_show
    commands['port_detail_performance_list'] = port_detail_performance_list
    commands['port_detail_performance_show'] = port_detail_performance_show
    commands['storage_node_detail_performance_list'] = storage_node_detail_performance_list
    commands['storage_node_detail_performance_show'] = storage_node_detail_performance_show
    commands['volume_detail_performance_list'] = volume_detail_performance_list
    commands['volume_detail_performance_show'] = volume_detail_performance_show
    return commands

