"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""


class MncCheckUtil(object):
    @staticmethod
    def is_mnc_importable():
        """
        mncがインポートできるかどうか
        :return: true: インポート可能/false: インポート不可
        """

        is_mn = False

        try:
            import com.hitachi.sophia.cli.manual.mnc
            import com.hitachi.sophia.rest_client.manual.mnc
            is_mn = True
        except ImportError:
            pass

        return is_mn
