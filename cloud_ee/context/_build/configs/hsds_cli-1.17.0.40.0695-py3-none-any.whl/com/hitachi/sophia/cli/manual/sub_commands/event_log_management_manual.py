# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import traceback
import logging as loggingLib
import os

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil

from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil


logger = loggingLib.getLogger(__name__)

# TODO: SLIPPED
# 当該APIのコメントアウトを解除する際は、同フォルダ内にある"audit_log_management.py"の実装を参考にし修正すること
# def event_log_download_manual(_filepath, callback, debug):
#     """
#     イベントログファイルをダウンロードする
#     """
#
#     defaultFileName = "download-eventlog.zip"
#
#     logger = loggingLib.getLogger('hsdsClient')
#
#     from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import \
#         EventLogManagement as EventLogManagementApi
#     api = EventLogManagementApi(ApiClient())
#
#     fileutil = FileUtil(defaultFileName)
#
#     if (_filepath is None):
#         _filepath = defaultFileName
#
#     dirname, filename = fileutil.locate_download_file(_filepath)
#     download_path = os.path.join(dirname, filename)
#
#     #ファイルが存在するか
#     if (os.path.isfile(os.path.join(dirname, filename))):
#         # 既にファイルが存在している
#         mssageManagement = MessageManagement('')
#         messageId = '19006'
#         messageDict = {'filePath': os.path.abspath(_filepath)}
#         mssageManagement.viewMessageTxt(messageId, **messageDict)
#         exit(1)
#
#
#     try:
#
#         response = api.download_event_log_file(callback=callback, debug=debug , _preload_content=False)
#
#         if(response):
#             if(response.status!=200):
#                 click.echo(response.data)
#                 exit(1)
#
#     except Exception as e:
#         if (traceback):
#             logger.error(traceback.format_exc())
#         mssageManagement = MessageManagement('')
#         mssageManagement.viewMessage(e)
#
#     saveFile = None
#     try:
#         with open(download_path, 'wb') as saveFile:
#             saveFile.write(response.data)
#         saveFile.close()
#
#     except Exception as e:
#         #ファイルの保存に失敗
#         messageId = '19007'
#         strErr = ','.join(map(str, e.args))
#         messageDict = {'exception': strErr}
#         mssageManagement = MessageManagement('')
#         mssageManagement.viewMessageTxt(messageId, **messageDict)
#         exit(1)
#
#     finally:
#         if (saveFile):
#             saveFile.close()
#
#     print('Download event log file Success')




def event_log_setting_set_manual(_location_name, _syslog_servers, _smtp_settings,callback, debug):
    """
    Edits the event log settings.
    """
    commonutil = CommonUtil()

    cliSubCommand = "event_log_setting_set"

    from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import \
        EventLogManagement as EventLogManagementApi
    api = EventLogManagementApi(ApiClient())

    try:

        if _location_name is not None:
            if (isinstance(_location_name, str)):
                _location_name = SeparateArgs.check_backslash(_location_name)
                _location_name = _location_name.encode("utf-8").decode("unicode-escape")
        if _syslog_servers is not None:
            if (isinstance(_syslog_servers, str)):
                _syslog_servers = SeparateArgs.check_backslash(_syslog_servers)
                _syslog_servers = _syslog_servers.encode("utf-8").decode("unicode-escape")
        if _smtp_settings is not None:
            if (isinstance(_smtp_settings, str)):
                _smtp_settings = SeparateArgs.check_backslash(_smtp_settings)
                _smtp_settings = _smtp_settings.encode("utf-8").decode("unicode-escape")

        from com.hitachi.sophia.rest_client.autogen.models.PatchEventLogSettingParam import PatchEventLogSettingParam
        patch_event_log_setting_param = PatchEventLogSettingParam()

        from com.hitachi.sophia.rest_client.autogen.models.SyslogForwardingSettingOfEditEventLogSetting import \
            SyslogForwardingSettingOfEditEventLogSetting
        syslog_forwarding_setting_of_edit_event_log_setting = None
        from com.hitachi.sophia.rest_client.autogen.models.EmailReportSettingOfEditEventLogSetting import \
            EmailReportSettingOfEditEventLogSetting
        email_report_setting_of_edit_event_log_setting = None

        if (_location_name is not None):
            if (syslog_forwarding_setting_of_edit_event_log_setting is None):
                syslog_forwarding_setting_of_edit_event_log_setting = SyslogForwardingSettingOfEditEventLogSetting()
            syslog_forwarding_setting_of_edit_event_log_setting.location_name = _location_name

        param_arr = []
        param_arr.append('index')
        param_arr.append('is_enabled')
        param_arr.append('server_name')
        param_arr.append('port')
        param_arr.append('transport_protocol')

        from com.hitachi.sophia.rest_client.autogen.models.SyslogServerSettingOfEditEventLogSetting import \
            SyslogServerSettingOfEditEventLogSetting
        arr = None
        param_name = "syslog_servers"

        if _syslog_servers is not None:
            arr = []
            for __value in _syslog_servers:
                syslog_server_setting_of_edit_event_log_setting = SyslogServerSettingOfEditEventLogSetting()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'integer', 'index', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'integer', 'index', param_name)

                syslog_server_setting_of_edit_event_log_setting.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'boolean', 'is_enabled', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'boolean', 'is_enabled', param_name)

                syslog_server_setting_of_edit_event_log_setting.is_enabled = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'server_name', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'server_name', param_name)

                syslog_server_setting_of_edit_event_log_setting.server_name = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'integer', 'port', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'integer', 'port', param_name)

                syslog_server_setting_of_edit_event_log_setting.port = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'transport_protocol', param_arr,
                                                             param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'transport_protocol', param_name)

                syslog_server_setting_of_edit_event_log_setting.transport_protocol = tempval
                arr.append(syslog_server_setting_of_edit_event_log_setting)

            _syslog_servers = arr

        if (_syslog_servers is not None):
            if (syslog_forwarding_setting_of_edit_event_log_setting is None):
                syslog_forwarding_setting_of_edit_event_log_setting = SyslogForwardingSettingOfEditEventLogSetting()
            syslog_forwarding_setting_of_edit_event_log_setting.syslog_servers = _syslog_servers


        param_arr = []
        param_arr.append('index')
        param_arr.append('is_enabled')
        param_arr.append('smtp_server_name')
        param_arr.append('smtp_auth_account')
        param_arr.append('smtp_auth_password')
        param_arr.append('from_address')
        param_arr.append('to_address1')
        param_arr.append('to_address2')
        param_arr.append('to_address3')

        from com.hitachi.sophia.rest_client.autogen.models.SmtpSettingOfEditEventLogSetting import \
            SmtpSettingOfEditEventLogSetting
        arr = []
        param_name = "smtp_settings"

        if _smtp_settings is not None:
            for __value in _smtp_settings:
                smtp_setting_of_edit_event_log_setting = SmtpSettingOfEditEventLogSetting()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'integer', 'index', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'integer', 'index', param_name)

                smtp_setting_of_edit_event_log_setting.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'boolean', 'is_enabled', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'boolean', 'is_enabled', param_name)

                smtp_setting_of_edit_event_log_setting.is_enabled = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'smtp_server_name', param_arr,
                                                             param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'smtp_server_name', param_name)

                smtp_setting_of_edit_event_log_setting.smtp_server_name = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'smtp_auth_account', param_arr,
                                                             param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'smtp_auth_account', param_name)

                smtp_setting_of_edit_event_log_setting.smtp_auth_account = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'smtp_auth_password', param_arr,
                                                             param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'smtp_auth_password', param_name)

                smtp_setting_of_edit_event_log_setting.smtp_auth_password = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'from_address', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'from_address', param_name)

                smtp_setting_of_edit_event_log_setting.from_address = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'to_address1', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'to_address1', param_name)

                smtp_setting_of_edit_event_log_setting.to_address1 = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'to_address2', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'to_address2', param_name)

                smtp_setting_of_edit_event_log_setting.to_address2 = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value, 'string', 'to_address3', param_arr, param_name)

                # 型変換実施
                tempval = ObjectArrayUtil.convertType(tempval, 'string', 'to_address3', param_name)

                smtp_setting_of_edit_event_log_setting.to_address3 = tempval
                arr.append(smtp_setting_of_edit_event_log_setting)
            _smtp_settings = arr

        if _smtp_settings is not None:
            if (email_report_setting_of_edit_event_log_setting is None):
                email_report_setting_of_edit_event_log_setting = EmailReportSettingOfEditEventLogSetting()
            email_report_setting_of_edit_event_log_setting.smtp_settings = _smtp_settings

        patch_event_log_setting_param.syslog_forwarding_setting = syslog_forwarding_setting_of_edit_event_log_setting
        patch_event_log_setting_param.email_report_setting = email_report_setting_of_edit_event_log_setting
        _patch_event_log_setting = patch_event_log_setting_param

        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

        config = Configuration()
        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            # 空文字,Nullの場合はログインメッセージを表示しない
            if (login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        # _smtp_settings指定時、かつ、smtp_auth_password未指定時はプロンプトを出し、標準入力
        if _patch_event_log_setting.email_report_setting is not None \
                and _patch_event_log_setting.email_report_setting.smtp_settings is not None:
            if _patch_event_log_setting.email_report_setting.smtp_settings[0].smtp_auth_password is None:
                _std_in_password = commonutil.input_stdin('smtp_auth_password')
                if _std_in_password is not None:
                    if isinstance(_std_in_password, str):
                        _std_in_password = SeparateArgs.check_backslash(_std_in_password)
                        _std_in_password = _std_in_password.encode("utf-8").decode("unicode-escape")
                _patch_event_log_setting.email_report_setting.smtp_settings[0].smtp_auth_password = _std_in_password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_info_response = versioncheck.get_api_version()
        versioncheck.version_check(api_info_response)

        response = api.event_log_setting(patch_event_log_setting=_patch_event_log_setting, callback=None, debug="false")

        sub_command = "event_log_setting_set"
        output_util = OutputUtil()
        output_util.echo_normal(response, config.format, sub_command)
        #click.echo(response)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))







    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
