"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import re

class SeparateArgs(object):
    def separateArgs(ctx, param, value):
        # for文で一文字ずつ取り出して結合。
        # 区切り文字(カンマ)まで来たらリストに追加して配列にする
        list = []
        tmp = ''
        if value is None:
            return None

        for x in value:
            if (x != ','):
                tmp += x
            else:
                if tmp.endswith('\\') :
                    tmp = tmp.replace('\\',',')
                    continue
                else:
                    list.append(tmp)
                    tmp = ''
        list.append(tmp)

        return list

    def check_backslash(param):
        back_slash = "\\"
        count = 0
        # 入力された値の末尾に"\"があるか判定
        while param.endswith(back_slash):
            back_slash = back_slash + "\\"
            count += 1

        # "\"が奇数個の場合、"\"は無効なエスケープ文字なので、末尾の"\"を消す
        if count % 2 == 1:
            return SeparateArgs.escape_unexpect_escape_seq(param[:-1])
        # "\"が偶数個の場合、何もしない
        else:
            return SeparateArgs.escape_unexpect_escape_seq(param)

    # --------------------------------------------------------------------------
    # 期待外のエスケープシーケンスの'\'をエスケープする
    # --------------------------------------------------------------------------
    # CLIではパラメータ文字列中の\r, \n, \tを改行コード・タブとしてREST APIに渡すため、
    # str.encode("utf-8").decode("unicode-escape") のエンコード＆デコードを実行している。
    # この際に、不十分なエスケープシーケンスとしてエンコードエラーとなるパターンや、
    # 不要なエスケープシーケンスを解釈させないため、下記のパターンの'\'を'\\'にエスケープする。
    # ただし、\\a、\\\\a のように'\'が偶数個の場合は、エスケープしない＝'\'を加えない。
    # 
    # エスケープ対象
    #   - \u,\x,\N,\U : エンコードエラー（不十分なエスケープシーケンスと解釈される）
    #   - \a,\b,\f,\v : 利用しない制御文字
    #   - \0-9        : 文字コードを数値で指定する
    #   - \",\'       : エンコード＆デコード時に前の'\'が取り除かれる
    def escape_unexpect_escape_seq(param):
        def add_backslash(m):
            return '\\' + m.group(0)

        pattern = re.compile(r'(?<!\\)\\(\\\\)*[abfuvxNU0-9"\']')
        result = pattern.sub(add_backslash, param)
        return result
