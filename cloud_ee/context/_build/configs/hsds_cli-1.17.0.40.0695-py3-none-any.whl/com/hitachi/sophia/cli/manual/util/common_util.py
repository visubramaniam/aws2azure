"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import click
import collections
import json
import os
import re

from collections import OrderedDict

from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement


class CommonUtil(object):
    def view_error(self):
        # エラーメッセージを表示して処理中止
        config = Configuration()
        if config.messageId:
            mssageManagement = MessageManagement('')
            messageId = config.messageId
            messageDict = config.messageDict
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

    def input_password(self):
        # usernameが入力されている場合は、パスワード入力をさせる
        # (認証不要判定はusernameの有無を利用)
        config = Configuration()

        if config.username is not None and config.password is None:

            try:
                config.password = click.prompt('Password', hide_input=True, err=True)
            except click.exceptions.Abort as e:
                # パスワードの入力中に中断(ctrl+c)した場合
                click.echo('Aborted!', err=True)

                exit(1)

    def input_stdin(self, text):
        # プロンプトにtextを出力して標準入力をさせる
        try:
            param = click.prompt(text, hide_input=True, err=True)
            return param
        except click.exceptions.Abort as e:
            # 入力中に中断(ctrl+c)した場合
            click.echo('Aborted!', err=True)
            exit(1)

    def input_stdin_allow_empty(self, text):
        # プロンプトにtextを出力して標準入力をさせる(空入力＝指定無しを許容)
        try:
            param = click.prompt(text, hide_input=True, err=True, default="")
            if param == "":
                param = None
            return param
        except click.exceptions.Abort as e:
            # 入力中に中断(ctrl+c)した場合
            click.echo('Aborted!', err=True)
            exit(1)

    def getEnvironmentVariable(self, paramname):
        self.value = os.getenv(paramname)
        return self.value

    def getEnvironmentVariableDef(self, paramname, dafaultVal):
        self.value = os.getenv(paramname, dafaultVal)
        return self.value

    def getEnvironmentHsdsUser(self):
        config = Configuration()

        user = os.getenv('HSDS_USER')
        if user is not None:
            config.username = user

    def set_parameter_with_instance(self, target_object, instance, name, input_param):
        if input_param is not None:
            if target_object is None:
                target_object = instance
            setattr(target_object, name, input_param)

        return target_object

    def get_cli_exit_code_for_api_execution(self, status):
        # 400番台の場合
        if 400 <= status <= 499:
            return 4

        # 500番台以上の場合
        if 500 <= status:
            return 5

        # 上記以外
        return 0

    def get_response_status(self, response):
        d = json.loads(response)
        return d.get('httpStatusCode')

    def get_enumerate_context(self, response):
        d = json.loads(response)
        body = d.get('body')
        return body.get('enumerateContext')

    def get_previous_response_data(self, response):
        od = json.loads(response, object_pairs_hook=OrderedDict)
        del od['httpStatusCode']

        body = od.get('body')
        del body['data']

        # Jsonデータ生成
        # {
        #     "body": {
        #         "totalCount": xxx,
        #         "hasNext": xxx,
        #         "enumerateContext": xxx
        #     }
        # }
        return json.dumps(od, indent=4, separators=(',', ': '))

    def add_error_data_to_previous_data(self, final_data, response):
        od1 = json.loads(final_data, object_pairs_hook=OrderedDict)
        od2 = json.loads(response, object_pairs_hook=OrderedDict)

        body = od1.get('body')
        status = od2.get('httpStatusCode')
        error = od2.get('body')

        # Jsonデータ生成
        # {
        #     "httpStatusCode": xxx,
        #     "body": {
        #         "totalCount": xxx,
        #         "hasNext": xxx,
        #         "enumerateContext": xxx,
        #         "error": {…}
        #     }
        # }
        final_data = collections.OrderedDict()
        final_data['httpStatusCode'] = status
        final_data['body'] = body
        final_data['body']['error'] = error
        final_data = json.dumps(final_data, indent=4, separators=(',', ': '))
        return final_data

    def add_exception_data_to_previous_data(self, final_data, exception):
        od1 = json.loads(final_data, object_pairs_hook=OrderedDict)
        od2 = json.loads(exception, object_pairs_hook=OrderedDict)

        body = od1.get('body')

        # Jsonデータ生成
        # {
        #     "body": {
        #         "totalCount": xxx,
        #         "hasNext": xxx,
        #         "enumerateContext": xxx,
        #         "error": {…}
        #     }
        # }
        final_data = collections.OrderedDict()
        final_data['body'] = body
        final_data['body']['error'] = od2
        final_data = json.dumps(final_data, indent=4, separators=(',', ': '))
        return final_data

    def is_performance_objects(self, data):
        for dic in data:
            objects = dic.get('performanceObjects')
            if objects is not None:
                # このdataは低解像度モニターである
                return True

        # このdataは低解像度モニターでない
        return False

    def get_list_of_performance_objects_ids(self, data):
        id_list = []
        for dic in data:
            objects = dic.get('performanceObjects')
            if objects is not None:
                for object in objects:
                    id = object.get('id')
                    if id is not None:
                        id_list.append(id)

        return id_list

    def get_list_of_ids(self, data):
        id_list = []
        for dic in data:
            id = dic.get('id')
            if id is not None:
                id_list.append(id)

        return id_list

    def get_data_count_from_response(self, response):
        od = json.loads(response, object_pairs_hook=OrderedDict)
        body = od.get('body')
        data = body.get('data')

        id_list = []
        if len(data) != 0:
            if self.is_performance_objects(data) == True:
                id_list = self.get_list_of_performance_objects_ids(data)
            else:
                id_list = self.get_list_of_ids(data)

            # 重複したidを削除
            id_list = sorted(set(id_list), key=id_list.index)

        return id_list

    def update_total_count_for_response(self, response, total_data_count):
        od = json.loads(response, object_pairs_hook=OrderedDict)

        body = od.get('body')

        # totalCountは取得したリソース件数を出力する
        body['totalCount'] = total_data_count

        return json.dumps(od, indent=4, separators=(',', ': '))

    def update_total_count_for_final_data(self, final_data, total_data_count):
        od = json.loads(final_data, object_pairs_hook=OrderedDict)

        body = od.get('body')

        total_count = body.get('totalCount')

        # totalCountの値と現在取得しているリソース件件数を比較し、大きいほうを出力する
        body['totalCount'] = max([total_count, total_data_count])

        return json.dumps(od, indent=4, separators=(',', ': '))

    def convert_rest_responses_with_cli(self, response):
        j = json.loads(response)
        if j['httpStatusCode'] == 401:
            if j.get('body') != None and j['body'].get('messageId') != None:
                rest_message_id = j['body'].get('messageId')
                if rest_message_id == 'KARS20050-E':
                    message_id = '19300'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)

                elif rest_message_id == 'KARS20051-E':
                    message_id = '19301'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)

        elif j['httpStatusCode'] == 403:
            if j.get('body') != None and j['body'].get('messageId') != None:
                rest_message_id = j['body'].get('messageId')
                if rest_message_id == 'KARS20008-E':
                    message_id = '19302'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)

    def check_retry(self, response):
        j = json.loads(response)
        if j['httpStatusCode'] == 503:
            if j.get('body') != None and j['body'].get('solutionType') != None:
                rest_messege_solutionType = j['body'].get('solutionType')
                if rest_messege_solutionType == 'RETRY':
                    return True
                else:
                    return False
            else:
                return False
        else:
            return False

    def check_ignore_filename(self, filename):
        # ignore the filename
        # - start with "."
        # - include dir separater "/" or "\"
        return filename.startswith('.') or re.search('[\\\\/]+', filename)
