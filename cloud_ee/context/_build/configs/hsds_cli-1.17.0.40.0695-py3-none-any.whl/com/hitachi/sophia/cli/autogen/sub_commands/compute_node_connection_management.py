# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--target_chap_user_name','_target_chap_user_name',type=str,metavar='<str>',help='CHAP user name used for CHAP authentication on the compute port (i.e., target port).',required=True)
@click.option('--target_chap_secret','_target_chap_secret',type=str,metavar='<str>',hidden=True,help='CHAP secret used for CHAP authentication on the compute port (i.e., target port).')
@click.option('--initiator_chap_user_name','_initiator_chap_user_name',type=str,metavar='<str>',help='CHAP user name used for CHAP authentication on the initiator port of the compute node in mutual CHAP authentication.')
@click.option('--initiator_chap_secret','_initiator_chap_secret',type=str,metavar='<str>',hidden=True,help='CHAP secret used for CHAP authentication on the initiator port of the compute node in mutual CHAP authentication.')
def chap_user_create(_target_chap_user_name,_target_chap_secret,_initiator_chap_user_name,_initiator_chap_secret,):
    """
    Creates a CHAP user.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "chap_user_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _target_chap_user_name is not None:
            subCommandLogtxt += "--target_chap_user_name " + str(_target_chap_user_name) + " "




        if _initiator_chap_user_name is not None:
            subCommandLogtxt += "--initiator_chap_user_name " + str(_initiator_chap_user_name) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "chap_user_create"



















        if _target_chap_user_name is not None:
            if(isinstance(_target_chap_user_name, str)):
                _target_chap_user_name = SeparateArgs.check_backslash(_target_chap_user_name)
                _target_chap_user_name = _target_chap_user_name.encode("utf-8").decode("unicode-escape")
        if _initiator_chap_user_name is not None:
            if(isinstance(_initiator_chap_user_name, str)):
                _initiator_chap_user_name = SeparateArgs.check_backslash(_initiator_chap_user_name)
                _initiator_chap_user_name = _initiator_chap_user_name.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateChapUserParam import CreateChapUserParam
        _create_chap_user = CreateChapUserParam()
        _create_chap_user.target_chap_user_name = _target_chap_user_name
        _create_chap_user.initiator_chap_user_name = _initiator_chap_user_name

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _target_chap_secret is None:
            _target_chap_secret = commonutil.input_stdin('target_chap_secret')

        if _target_chap_secret is not None:
            if isinstance(_target_chap_secret, str):
                _target_chap_secret = SeparateArgs.check_backslash(_target_chap_secret)
                _target_chap_secret = _target_chap_secret.encode("utf-8").decode("unicode-escape")

        if _initiator_chap_secret is None:
            _initiator_chap_secret = commonutil.input_stdin_allow_empty('initiator_chap_secret (if omitted, press the [Enter] key)')

        if _initiator_chap_secret is not None:
            if isinstance(_initiator_chap_secret, str):
                _initiator_chap_secret = SeparateArgs.check_backslash(_initiator_chap_secret)
                _initiator_chap_secret = _initiator_chap_secret.encode("utf-8").decode("unicode-escape")

        _create_chap_user.target_chap_secret = _target_chap_secret
        _create_chap_user.initiator_chap_secret = _initiator_chap_secret

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.chap_user_create(create_chap_user = _create_chap_user, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--chap_user_id','_chap_user_id',metavar='<str>',help='ID of the CHAP user.')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='The name of the CHAP user who is allowed to access on the target side.')
def chap_user_delete(_chap_user_id,_chap_user_id_target_chap_user_name,):
    """
    Deletes a CHAP user.
    """
    def get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(chap_user_id_target_chap_user_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.chap_user_list(target_chap_user_name=chap_user_id_target_chap_user_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'chap_user_id_target_chap_user_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "chap_user_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _chap_user_id is not None:
            subCommandLogtxt += "--chap_user_id " + str(_chap_user_id) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--chap_user_id', _chap_user_id,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _chap_user_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _chap_user_id):
            raise ValueError("Invalid value for `chap_user_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "chap_user_delete"





        if  _chap_user_id_target_chap_user_name is not None and not re.search('^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$', _chap_user_id_target_chap_user_name):
            raise ValueError("Invalid value for parameter `chap_user_id_target_chap_user_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")
#           raise ValueError("Invalid value for parameter `chap_user_id` when calling `chap_user_delete`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _chap_user_id_target_chap_user_name is not None:
            # chap_user_listを使ってchap_user_id_target_chap_user_nameに対応するchap_user_idを取得
            _chap_user_id = get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(_chap_user_id_target_chap_user_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.chap_user_delete(_chap_user_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--target_chap_user_name','_target_chap_user_name',metavar='<str>',help='CHAP user name used for CHAP authentication on the compute port (that is, the target side) (exact match). ')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='Alias of target_chap_user_name.')
def chap_user_list(_target_chap_user_name,_chap_user_id_target_chap_user_name,):
    """
    Obtains a list of CHAP user information.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "chap_user_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _target_chap_user_name is not None:
            subCommandLogtxt += "--target_chap_user_name " + str(_target_chap_user_name) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--target_chap_user_name', _target_chap_user_name,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "chap_user_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ChapUserSummaryList import ChapUserSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if not _chap_user_id_target_chap_user_name is None:
            _target_chap_user_name = _chap_user_id_target_chap_user_name


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.chap_user_list(target_chap_user_name = _target_chap_user_name, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--chap_user_id','_chap_user_id',metavar='<str>',help='ID of the CHAP user.')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='The name of the CHAP user who is allowed to access on the target side.')
@click.option('--target_chap_user_name','_target_chap_user_name',type=str,metavar='<str>',help='CHAP user name used for CHAP authentication on the compute port (i.e., target port).')
@click.option('--target_chap_secret','_target_chap_secret',type=str,metavar='<str>',hidden=True,help='CHAP secret used for CHAP authentication on the compute port (i.e., target port).')
@click.option('--initiator_chap_user_name','_initiator_chap_user_name',type=str,metavar='<str>',help='CHAP user name used for CHAP authentication on the initiator port of the compute node in mutual CHAP authentication.')
@click.option('--initiator_chap_secret','_initiator_chap_secret',type=str,metavar='<str>',hidden=True,help='CHAP secret used for CHAP authentication on the initiator port of the compute node in mutual CHAP authentication.')
def chap_user_set(_chap_user_id,_chap_user_id_target_chap_user_name,_target_chap_user_name,_target_chap_secret,_initiator_chap_user_name,_initiator_chap_secret,):
    """
    Edits information about a CHAP user.
    """
    def get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(chap_user_id_target_chap_user_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.chap_user_list(target_chap_user_name=chap_user_id_target_chap_user_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'chap_user_id_target_chap_user_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "chap_user_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _chap_user_id is not None:
            subCommandLogtxt += "--chap_user_id " + str(_chap_user_id) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "






        if _target_chap_user_name is not None:
            subCommandLogtxt += "--target_chap_user_name " + str(_target_chap_user_name) + " "




        if _initiator_chap_user_name is not None:
            subCommandLogtxt += "--initiator_chap_user_name " + str(_initiator_chap_user_name) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--chap_user_id', _chap_user_id,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _chap_user_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _chap_user_id):
            raise ValueError("Invalid value for `chap_user_id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "chap_user_set"





        if  _chap_user_id_target_chap_user_name is not None and not re.search('^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$', _chap_user_id_target_chap_user_name):
            raise ValueError("Invalid value for parameter `chap_user_id_target_chap_user_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")
#           raise ValueError("Invalid value for parameter `chap_user_id` when calling `chap_user_set`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")




















        if _target_chap_user_name is not None:
            if(isinstance(_target_chap_user_name, str)):
                _target_chap_user_name = SeparateArgs.check_backslash(_target_chap_user_name)
                _target_chap_user_name = _target_chap_user_name.encode("utf-8").decode("unicode-escape")
        if _initiator_chap_user_name is not None:
            if(isinstance(_initiator_chap_user_name, str)):
                _initiator_chap_user_name = SeparateArgs.check_backslash(_initiator_chap_user_name)
                _initiator_chap_user_name = _initiator_chap_user_name.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchChapUserParam import PatchChapUserParam
        _edit_chap_user = PatchChapUserParam()
        _edit_chap_user.target_chap_user_name = _target_chap_user_name
        _edit_chap_user.initiator_chap_user_name = _initiator_chap_user_name

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _chap_user_id_target_chap_user_name is not None:
            # chap_user_listを使ってchap_user_id_target_chap_user_nameに対応するchap_user_idを取得
            _chap_user_id = get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(_chap_user_id_target_chap_user_name)

        if _target_chap_secret is None:
            _target_chap_secret = commonutil.input_stdin_allow_empty('target_chap_secret (if omitted, press the [Enter] key)')

        if _target_chap_secret is not None:
            if isinstance(_target_chap_secret, str):
                _target_chap_secret = SeparateArgs.check_backslash(_target_chap_secret)
                _target_chap_secret = _target_chap_secret.encode("utf-8").decode("unicode-escape")

        if _initiator_chap_secret is None:
            _initiator_chap_secret = commonutil.input_stdin_allow_empty('initiator_chap_secret (if omitted, press the [Enter] key)')

        if _initiator_chap_secret is not None:
            if isinstance(_initiator_chap_secret, str):
                _initiator_chap_secret = SeparateArgs.check_backslash(_initiator_chap_secret)
                _initiator_chap_secret = _initiator_chap_secret.encode("utf-8").decode("unicode-escape")

        _edit_chap_user.target_chap_secret = _target_chap_secret
        _edit_chap_user.initiator_chap_secret = _initiator_chap_secret

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.chap_user_set(_chap_user_id, edit_chap_user = _edit_chap_user, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--chap_user_id','_chap_user_id',metavar='<str>',help='ID of the CHAP user.')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='The name of the CHAP user who is allowed to access on the target side.')
def chap_user_show(_chap_user_id,_chap_user_id_target_chap_user_name,):
    """
    Obtains information about a CHAP user.
    """
    def get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(chap_user_id_target_chap_user_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.chap_user_list(target_chap_user_name=chap_user_id_target_chap_user_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'chap_user_id_target_chap_user_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "chap_user_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _chap_user_id is not None:
            subCommandLogtxt += "--chap_user_id " + str(_chap_user_id) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--chap_user_id', _chap_user_id,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _chap_user_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _chap_user_id):
            raise ValueError("Invalid value for `chap_user_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "chap_user_show"





        if  _chap_user_id_target_chap_user_name is not None and not re.search('^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$', _chap_user_id_target_chap_user_name):
            raise ValueError("Invalid value for parameter `chap_user_id_target_chap_user_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")
#           raise ValueError("Invalid value for parameter `chap_user_id` when calling `chap_user_show`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ChapUser import ChapUser

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _chap_user_id_target_chap_user_name is not None:
            # chap_user_listを使ってchap_user_id_target_chap_user_nameに対応するchap_user_idを取得
            _chap_user_id = get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(_chap_user_id_target_chap_user_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.chap_user_show(_chap_user_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--chap_user_id','_chap_user_id',type=str,metavar='<str>',help='ID of the CHAP user who is allowed to access the compute port in CHAP authentication.')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='The name of the CHAP user who is allowed to access on the target side.')
def port_auth_setting_chap_user_create(_id,_id_name,_chap_user_id,_chap_user_id_target_chap_user_name,):
    """
    Allows a CHAP user to access the compute port.
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(chap_user_id_target_chap_user_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.chap_user_list(target_chap_user_name=chap_user_id_target_chap_user_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'chap_user_id_target_chap_user_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_auth_setting_chap_user_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _chap_user_id is not None:
            subCommandLogtxt += "--chap_user_id " + str(_chap_user_id) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--chap_user_id', _chap_user_id,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'true')
        commonutil.view_error()


        
        if _chap_user_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _chap_user_id):
            raise ValueError("Invalid value for `chap_user_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "port_auth_setting_chap_user_create"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_auth_setting_chap_user_create`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")






        if  _chap_user_id_target_chap_user_name is not None and not re.search('^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$', _chap_user_id_target_chap_user_name):
            raise ValueError("Invalid value for parameter `chap_user_id_target_chap_user_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")
















        if _chap_user_id is not None:
            if(isinstance(_chap_user_id, str)):
                _chap_user_id = SeparateArgs.check_backslash(_chap_user_id)
                _chap_user_id = _chap_user_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ApproveChapUserParam import ApproveChapUserParam
        _approve_chap_user = ApproveChapUserParam()
        _approve_chap_user.chap_user_id = _chap_user_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)

        if _chap_user_id_target_chap_user_name is not None:
            # chap_user_listを使ってchap_user_id_target_chap_user_nameに対応するchap_user_idを取得
            _chap_user_id = get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(_chap_user_id_target_chap_user_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _approve_chap_user is None:
                from com.hitachi.sophia.rest_client.autogen.models.ApproveChapUserParam import ApproveChapUserParam
                _approve_chap_user = ApproveChapUserParam()
            _approve_chap_user.chap_user_id = _chap_user_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_auth_setting_chap_user_create(_id, approve_chap_user = _approve_chap_user, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--chap_user_id','_chap_user_id',metavar='<str>',help='ID of the CHAP user.')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='The name of the CHAP user who is allowed to access on the target side.')
def port_auth_setting_chap_user_delete(_id,_id_name,_chap_user_id,_chap_user_id_target_chap_user_name,):
    """
    Cancels compute port access permission for a CHAP user.
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(chap_user_id_target_chap_user_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.chap_user_list(target_chap_user_name=chap_user_id_target_chap_user_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'chap_user_id_target_chap_user_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_auth_setting_chap_user_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "



        if _chap_user_id is not None:
            subCommandLogtxt += "--chap_user_id " + str(_chap_user_id) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--chap_user_id', _chap_user_id,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _chap_user_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _chap_user_id):
            raise ValueError("Invalid value for `chap_user_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "port_auth_setting_chap_user_delete"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_auth_setting_chap_user_delete`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")






        if  _chap_user_id_target_chap_user_name is not None and not re.search('^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$', _chap_user_id_target_chap_user_name):
            raise ValueError("Invalid value for parameter `chap_user_id_target_chap_user_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")
#           raise ValueError("Invalid value for parameter `chap_user_id` when calling `port_auth_setting_chap_user_delete`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)

        if _chap_user_id_target_chap_user_name is not None:
            # chap_user_listを使ってchap_user_id_target_chap_user_nameに対応するchap_user_idを取得
            _chap_user_id = get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(_chap_user_id_target_chap_user_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_auth_setting_chap_user_delete(_id, _chap_user_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
def port_auth_setting_chap_user_list(_id,_id_name,):
    """
    Obtains a list of information about CHAP users who are allowed to access the compute port.
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_auth_setting_chap_user_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "port_auth_setting_chap_user_list"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_auth_setting_chap_user_list`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ApprovedChapUserList import ApprovedChapUserList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_auth_setting_chap_user_list(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--chap_user_id','_chap_user_id',metavar='<str>',help='ID of the CHAP user.')
@click.option('--chap_user_id_target_chap_user_name','_chap_user_id_target_chap_user_name',metavar='<str>',help='The name of the CHAP user who is allowed to access on the target side.')
def port_auth_setting_chap_user_show(_id,_id_name,_chap_user_id,_chap_user_id_target_chap_user_name,):
    """
    Obtains information about a CHAP user who is allowed to access the compute port.
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(chap_user_id_target_chap_user_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.chap_user_list(target_chap_user_name=chap_user_id_target_chap_user_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'chap_user_id_target_chap_user_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_auth_setting_chap_user_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "



        if _chap_user_id is not None:
            subCommandLogtxt += "--chap_user_id " + str(_chap_user_id) + " "

        if _chap_user_id_target_chap_user_name is not None:
            subCommandLogtxt += "--chap_user_id_target_chap_user_name " + str(_chap_user_id_target_chap_user_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--chap_user_id', _chap_user_id,'--chap_user_id_target_chap_user_name', _chap_user_id_target_chap_user_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _chap_user_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _chap_user_id):
            raise ValueError("Invalid value for `chap_user_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "port_auth_setting_chap_user_show"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_auth_setting_chap_user_show`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")






        if  _chap_user_id_target_chap_user_name is not None and not re.search('^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$', _chap_user_id_target_chap_user_name):
            raise ValueError("Invalid value for parameter `chap_user_id_target_chap_user_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")
#           raise ValueError("Invalid value for parameter `chap_user_id` when calling `port_auth_setting_chap_user_show`, must conform to the pattern `^[a-zA-Z0-9\.:@_\-\+=\[\]~ ]{1,223}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ApprovedChapUser import ApprovedChapUser

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)

        if _chap_user_id_target_chap_user_name is not None:
            # chap_user_listを使ってchap_user_id_target_chap_user_nameに対応するchap_user_idを取得
            _chap_user_id = get_uuid_from_chap_user_list_with_chap_user_id_target_chap_user_name(_chap_user_id_target_chap_user_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_auth_setting_chap_user_show(_id, _chap_user_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--auth_mode','_auth_mode',type=str,metavar='<str>',help='Authentication scheme of the compute port.')
@click.option('--is_discovery_chap_auth','_is_discovery_chap_auth',metavar='<bool>',help='Enables or disables CHAP authentication at the time of discovery in iSCSI connection.')
@click.option('--is_mutual_chap_auth','_is_mutual_chap_auth',metavar='<bool>',help='Enables or disables mutual CHAP authentication.')
def port_auth_setting_set(_id,_id_name,_auth_mode,_is_discovery_chap_auth,_is_mutual_chap_auth,):
    """
    Edits the authentication settings for the compute port for the target operation. 
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_auth_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _auth_mode is not None:
            subCommandLogtxt += "--auth_mode " + str(_auth_mode) + " "




        if _is_discovery_chap_auth is not None:
            subCommandLogtxt += "--is_discovery_chap_auth " + str(_is_discovery_chap_auth) + " "




        if _is_mutual_chap_auth is not None:
            subCommandLogtxt += "--is_mutual_chap_auth " + str(_is_mutual_chap_auth) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "port_auth_setting_set"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_auth_setting_set`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")




















        if _auth_mode is not None:
            if(isinstance(_auth_mode, str)):
                _auth_mode = SeparateArgs.check_backslash(_auth_mode)
                _auth_mode = _auth_mode.encode("utf-8").decode("unicode-escape")
        if _is_discovery_chap_auth is not None:
            if(isinstance(_is_discovery_chap_auth, str)):
                _is_discovery_chap_auth = SeparateArgs.check_backslash(_is_discovery_chap_auth)
                _is_discovery_chap_auth = _is_discovery_chap_auth.encode("utf-8").decode("unicode-escape")
        if _is_mutual_chap_auth is not None:
            if(isinstance(_is_mutual_chap_auth, str)):
                _is_mutual_chap_auth = SeparateArgs.check_backslash(_is_mutual_chap_auth)
                _is_mutual_chap_auth = _is_mutual_chap_auth.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchPortAuthSettingParam import PatchPortAuthSettingParam
        _edit_port_auth_setting = PatchPortAuthSettingParam()
        _edit_port_auth_setting.auth_mode = _auth_mode
        _edit_port_auth_setting.is_discovery_chap_auth = _is_discovery_chap_auth
        _edit_port_auth_setting.is_mutual_chap_auth = _is_mutual_chap_auth

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_auth_setting_set(_id, edit_port_auth_setting = _edit_port_auth_setting, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
def port_auth_setting_show(_id,_id_name,):
    """
    Obtains the authentication settings for the compute port for the target operation. 
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_auth_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "port_auth_setting_show"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_auth_setting_show`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PortAuthSetting import PortAuthSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_auth_setting_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--nickname','_nickname',type=str,metavar='<str>',help='The nickname of the compute port.')
@click.option('--name','_name',type=str,metavar='<str>',help='The iSCSI name of the compute port. For FC connection, this property cannot be specified.')
@click.option('--connection_type','_connection_type',type=str,metavar='<str>',help='Network connection type for FC connection.')
@click.option('--is_isns_client_enabled','_is_isns_client_enabled',metavar='<bool>',help='Enables or disables the iSNS client function for iSCSI connection.')
@click.option('--isns_servers','_isns_servers',metavar='<str>', multiple=True,help='iSNS server as the connection destination in the iSNS client function. index: ID of the iSNS server. server_name: IP address of the iSNS server. port: TCP port number of the iSNS server.')
def port_set(_id,_id_name,_nickname,_name,_connection_type,_is_isns_client_enabled,_isns_servers,):
    """
    Edits compute port settings. 
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _nickname is not None:
            subCommandLogtxt += "--nickname " + str(_nickname) + " "




        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "




        if _connection_type is not None:
            subCommandLogtxt += "--connection_type " + str(_connection_type) + " "




        if _is_isns_client_enabled is not None:
            subCommandLogtxt += "--is_isns_client_enabled " + str(_is_isns_client_enabled) + " "



        if len(_isns_servers) == 0:
            _isns_servers = None

        if _isns_servers is not None:
            subCommandLogtxt += "--isns_servers " + str(_isns_servers) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "port_set"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_edit`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")




















        if _nickname is not None:
            if(isinstance(_nickname, str)):
                _nickname = SeparateArgs.check_backslash(_nickname)
                _nickname = _nickname.encode("utf-8").decode("unicode-escape")
        if _name is not None:
            if(isinstance(_name, str)):
                _name = SeparateArgs.check_backslash(_name)
                _name = _name.encode("utf-8").decode("unicode-escape")
        if _connection_type is not None:
            if(isinstance(_connection_type, str)):
                _connection_type = SeparateArgs.check_backslash(_connection_type)
                _connection_type = _connection_type.encode("utf-8").decode("unicode-escape")
        if _is_isns_client_enabled is not None:
            if(isinstance(_is_isns_client_enabled, str)):
                _is_isns_client_enabled = SeparateArgs.check_backslash(_is_isns_client_enabled)
                _is_isns_client_enabled = _is_isns_client_enabled.encode("utf-8").decode("unicode-escape")
        if _isns_servers is not None:
            if(isinstance(_isns_servers, str)):
                _isns_servers = SeparateArgs.check_backslash(_isns_servers)
                _isns_servers = _isns_servers.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchPortParam import PatchPortParam
        tmp_patch_port_param = PatchPortParam()
        patch_port_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.FcInformationOfEditPort import FcInformationOfEditPort
        tmp_fc_information_of_edit_port = FcInformationOfEditPort()
        fc_information_of_edit_port = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.Ipv4InformationOfEditIscsiInformation import Ipv4InformationOfEditIscsiInformation
        tmp_ipv4_information_of_edit_iscsi_information = Ipv4InformationOfEditIscsiInformation()
        ipv4_information_of_edit_iscsi_information = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.Ipv6InformationOfEditIscsiInformation import Ipv6InformationOfEditIscsiInformation
        tmp_ipv6_information_of_edit_iscsi_information = Ipv6InformationOfEditIscsiInformation()
        ipv6_information_of_edit_iscsi_information = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.IscsiInformationOfEditPort import IscsiInformationOfEditPort
        tmp_iscsi_information_of_edit_port = IscsiInformationOfEditPort()
        iscsi_information_of_edit_port = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.Ipv4InformationOfEditNvmeInformation import Ipv4InformationOfEditNvmeInformation
        tmp_ipv4_information_of_edit_nvme_information = Ipv4InformationOfEditNvmeInformation()
        ipv4_information_of_edit_nvme_information = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.Ipv6InformationOfEditNvmeInformation import Ipv6InformationOfEditNvmeInformation
        tmp_ipv6_information_of_edit_nvme_information = Ipv6InformationOfEditNvmeInformation()
        ipv6_information_of_edit_nvme_information = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.NvmeTcpInformationOfEditPort import NvmeTcpInformationOfEditPort
        tmp_nvme_tcp_information_of_edit_port = NvmeTcpInformationOfEditPort()
        nvme_tcp_information_of_edit_port = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        patch_port_param = commonutil.set_parameter_with_instance(patch_port_param, tmp_patch_port_param, 'nickname', _nickname)
        

        patch_port_param = commonutil.set_parameter_with_instance(patch_port_param, tmp_patch_port_param, 'name', _name)
        

        fc_information_of_edit_port = commonutil.set_parameter_with_instance(fc_information_of_edit_port, tmp_fc_information_of_edit_port, 'connection_type', _connection_type)
        

        iscsi_information_of_edit_port = commonutil.set_parameter_with_instance(iscsi_information_of_edit_port, tmp_iscsi_information_of_edit_port, 'is_isns_client_enabled', _is_isns_client_enabled)
        

        

        param_arr = []
        param_arr.append('index')
        param_arr.append('server_name')
        param_arr.append('port')

        from com.hitachi.sophia.rest_client.autogen.models.IsnsServerOfEditIscsiInformation import IsnsServerOfEditIscsiInformation
        arr = []
        param_name = "isns_servers"

        if _isns_servers is not None:
            for __value in _isns_servers:
                isns_server_of_edit_iscsi_information = IsnsServerOfEditIscsiInformation()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'index',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'index',param_name)

                isns_server_of_edit_iscsi_information.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'server_name',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'server_name',param_name)

                isns_server_of_edit_iscsi_information.server_name = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'port',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'port',param_name)

                isns_server_of_edit_iscsi_information.port = tempval
                arr.append(isns_server_of_edit_iscsi_information)
            _isns_servers = arr

        iscsi_information_of_edit_port = commonutil.set_parameter_with_instance(iscsi_information_of_edit_port, tmp_iscsi_information_of_edit_port, 'isns_servers', _isns_servers)
        patch_port_param = commonutil.set_parameter_with_instance(patch_port_param, tmp_patch_port_param, 'fc_information', fc_information_of_edit_port)
        iscsi_information_of_edit_port = commonutil.set_parameter_with_instance(iscsi_information_of_edit_port, tmp_iscsi_information_of_edit_port, 'ipv4_information', ipv4_information_of_edit_iscsi_information)
        iscsi_information_of_edit_port = commonutil.set_parameter_with_instance(iscsi_information_of_edit_port, tmp_iscsi_information_of_edit_port, 'ipv6_information', ipv6_information_of_edit_iscsi_information)
        patch_port_param = commonutil.set_parameter_with_instance(patch_port_param, tmp_patch_port_param, 'iscsi_information', iscsi_information_of_edit_port)
        nvme_tcp_information_of_edit_port = commonutil.set_parameter_with_instance(nvme_tcp_information_of_edit_port, tmp_nvme_tcp_information_of_edit_port, 'ipv4_information', ipv4_information_of_edit_nvme_information)
        nvme_tcp_information_of_edit_port = commonutil.set_parameter_with_instance(nvme_tcp_information_of_edit_port, tmp_nvme_tcp_information_of_edit_port, 'ipv6_information', ipv6_information_of_edit_nvme_information)
        patch_port_param = commonutil.set_parameter_with_instance(patch_port_param, tmp_patch_port_param, 'nvme_tcp_information', nvme_tcp_information_of_edit_port)
        _edit_port = patch_port_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_edit(_id, edit_port = _edit_port, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--protocol','_protocol',metavar='<str>',help='The protocol for connecting compute ports. ')
@click.option('--storage_node_id','_storage_node_id',metavar='<str>',help='Storage node ID. ')
@click.option('--name','_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections. ')
@click.option('--id_name','_id_name',metavar='<str>',help='Alias of name.')
@click.option('--names','_names',metavar='<str>',help='A list of WWNs of the compute port for FC connection or the iSCSI names for iSCSI connections. You can specify plural names (up to 32) by delimiting them with commas (,). ')
@click.option('--id_names','_id_names',metavar='<str>',help='Alias of names.')
def port_list(_protocol,_storage_node_id,_name,_id_name,_names,_id_names,):
    """
    Obtains the list of compute port information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _protocol is not None:
            subCommandLogtxt += "--protocol " + str(_protocol) + " "




        if _storage_node_id is not None:
            subCommandLogtxt += "--storage_node_id " + str(_storage_node_id) + " "





        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "



        if _names is not None:
            subCommandLogtxt += "--names " + str(_names) + " "

        if _id_names is not None:
            subCommandLogtxt += "--id_names " + str(_id_names) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        


        #Enumチェック
        allowed_values = ["FC", "iSCSI", "NVMe_TCP"]
        if _protocol is not None:
            if _protocol not in allowed_values:
                raise ValueError(
                    "Invalid value for `protocol` ({0}), (Select only one) {1}"
                    .format(_protocol, allowed_values)
            )
        
        


        
        #UUIDチェック
        if _storage_node_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_node_id):
            raise ValueError("Invalid value for `storage_node_id`, the format of UUID is invalid.")
        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--name', _name,'--id_name', _id_name, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--names', _names,'--id_names', _id_names, 'false')
        commonutil.view_error()


        
        #フィルター配列チェック
        if _names is not None:
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('names',
                                                            _names,
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$',
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\\.[0-9]{4}\\-[0-9]{2}\\.[a-zA-Z0-9\\-:\\.]{0,211})|(eui\\.[0-9a-fA-F]{16}))$',
                                                            32,
                                                            223)
        


        
        
        
        
        
        #cliSubCommand = "port_list"
































        if _id_names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('id_names',
                                                            _id_names,
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$',
                                                            '^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\\.[0-9]{4}\\-[0-9]{2}\\.[a-zA-Z0-9\\-:\\.]{0,211})|(eui\\.[0-9a-fA-F]{16}))$',
                                                            32,
                                                            223)




                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PortSummaryList import PortSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if not _id_name is None:
            _name = _id_name

        if not _id_names is None:
            _names = _id_names


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_list(protocol = _protocol, storage_node_id = _storage_node_id, name = _name, names = _names, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
def port_show(_id,_id_name,):
    """
    Obtains the compute port information. 
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "port_show"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_show`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Port import Port

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--protocol','_protocol',type=str,metavar='<str>',help='The protocol for connecting compute ports.',required=True)
def port_switch_protocol(_protocol,):
    """
    Changes the protocol of compute ports. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_switch_protocol"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _protocol is not None:
            subCommandLogtxt += "--protocol " + str(_protocol) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "port_switch_protocol"



















        if _protocol is not None:
            if(isinstance(_protocol, str)):
                _protocol = SeparateArgs.check_backslash(_protocol)
                _protocol = _protocol.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PortSwitchProtocolParam import PortSwitchProtocolParam
        _port_switch_protocol_param = PortSwitchProtocolParam()
        _port_switch_protocol_param.protocol = _protocol

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_switch_protocol(port_switch_protocol_param = _port_switch_protocol_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['chap_user_create'] = chap_user_create
    commands['chap_user_delete'] = chap_user_delete
    commands['chap_user_list'] = chap_user_list
    commands['chap_user_set'] = chap_user_set
    commands['chap_user_show'] = chap_user_show
    commands['port_auth_setting_chap_user_create'] = port_auth_setting_chap_user_create
    commands['port_auth_setting_chap_user_delete'] = port_auth_setting_chap_user_delete
    commands['port_auth_setting_chap_user_list'] = port_auth_setting_chap_user_list
    commands['port_auth_setting_chap_user_show'] = port_auth_setting_chap_user_show
    commands['port_auth_setting_set'] = port_auth_setting_set
    commands['port_auth_setting_show'] = port_auth_setting_show
    commands['port_set'] = port_set
    commands['port_list'] = port_list
    commands['port_show'] = port_show
    commands['port_switch_protocol'] = port_switch_protocol
    return commands

