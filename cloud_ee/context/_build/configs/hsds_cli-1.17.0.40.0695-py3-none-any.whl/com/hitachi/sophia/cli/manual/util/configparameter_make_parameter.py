#!/usr/bin/env python3
# coding:utf-8

# 構成パラメータ作成モジュール
# IN:CSVファイル（変更前）、CSVファイル名（変更後）
# OUT:configurationParametersを、各ノード毎でリスト化
#     例：{configurationParameters:[{"key1":"Value1","Key2":"Value2",...}},
#                                  {"key1":"Value1","Key2":"Value2",...}]},
# 説明：構成一括変更に必要な、構成パラメータ情報を構成パラメータファイルに保存する。
# 新規に作成するパラメータ部分（ESXiから取得していた部分）
# guestinfo.hsds.nw.<各種NW設定パラメータ>
# 以下の設定は、固定値で設定を実施する。
# guestinfo.hsds.nw.setupnetwork = 1
# guestinfo.hsds.nw.*.interface = eth0/eth1/eth2～最大256
# guestinfo.hsds.configparam_status
# 以下のパラメータは不要の認識
# guestinfo.hsds.nw.*.macaddr
# guestinfo.hsds.maintenance (入力パラメータ）
# guestinfo.hsds.systemRandomId
# guestinfo.hsds.clusterrole.<ESXiのIP>_<HostName>
# guestinfo.hsds.clusterId (encription\Keyeenertor.cpp generatorTickectEncKey()にて設定）
# guestinfo.hsds.14069429150abcbf244c4c2fb2c4c46a49c93ca9457263ecd9ebb176de3a58bb （チケットのハッシュ値）
# -必要- guestinfo.hsds.917e63a76cf92a00f36dbb49b5e40df597c5a3fdbe68ed852b8216c328ecdc8d （静止点のハッシュ値）
# REST-APIが、設定オブジェクトの内容が32データ以内での仕様のため32データで区切る。
# 構成パラメータ作成のデータ構成は、以下の様な例になる。
# 例）
# {'<Beforeのcontrol.ipv4addr>':
# ['{"configurationParameters":[       <--分割１つ目
#   {"key":"guestinfo.hsds.nw.control.mtu", "value":"1500"},
#   {"key":"guestinfo.hsds.nw.control.ipv4addr", "value":"192.168.0.2"},
# ・・・
#   {"key":"...", "value":"...."}]}',  <---32データ目(または以内）
#  '{"configurationParameters":[       <--分割２つ目
#   {"key":"guestinfo.hsds.nw.ipv4route0.interface", "value":"xxx"},
#   {"key":"guestinfo.hsds.nw.ipv4route0.gateway", "value":"xxxx"},
# ・・・
#   {"key":"...", "value":"...."}]}',  <---32データ目(または以内）
#  '{"configurationParameters":[       <--分割３つ目
#   {"key":"guestinfo.hsds.nw.ipv4route1.interface", "value":"yyy"},
#   {"key":"guestinfo.hsds.nw.ipv4route1.gateway", "value":"yyyy"},
# ・・・
#   {"key":"...", "value":"...."}]}'  <---32データ目(または以内）
#   ],
# '<Beforeのcontrol.ipv4addr>':
# ['{"configurationParameters":[       <--分割１つ目
#   {"key":"guestinfo.hsds.nw.control.mtu", "value":"1500"},
#   {"key":"guestinfo.hsds.nw.control.ipv4addr", "value":"192.168.0.3"},
# ・・・
#   {"key":"...", "value":"...."}]}',  <---32データ目(または以内）
#  '{"configurationParameters":[       <--分割２つ目
#   {"key":"guestinfo.hsds.nw.ipv4route0.interface", "value":"zzz"},
#   {"key":"guestinfo.hsds.nw.ipv4route0.gateway", "value":"zzzz"},
#  ・・・
#   {"key":"...", "value":"...."}]}',  <---32データ目(または以内）
#  '{"configurationParameters":[       <--分割３つ目
#   {"key":"guestinfo.hsds.nw.ipv4route1.interface", "value":"xxxxx"},
#   {"key":"guestinfo.hsds.nw.ipv4route1.gateway", "value":"xxxxxx"},
# ・・・
#   {"key":"...", "value":"...."}]}'  <---32データ目(または以内） 
# ]
# }
# この関数の戻り値からREST-APIの文字列を取得する際は以下の様になります。
# 例）　configurationParameter_data['<Beforeのcontrol.ipv4addr>'][n]  n=0~（max=分割リスト数-1）


# 構成としては、構成一括変更、静止点コマンドでのConfigParam領域アクセスを
# 利用し、保存する情報とする。

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import csv
from collections import OrderedDict

def version_to_int(s: str) -> int:
    return int(s.replace('.', ''))

def get_native_config_csv_file_read(file_name):

    read_info = 'NONE'
    list_head = []
    dict_from_list = []
    general_head = []
    general_list = []
    errmsg = ""

    # 指定ファイルの読み込み
    with open(file_name, newline='') as f:
        csvreader = csv.reader(f)
        for row in csvreader:
            if read_info == 'END':
                # データ取得終了
                # print('-END-')
                break
            if read_info == 'CONTENT':
                # 次セクションの始まり確認
                if '[' in row[0] and ']' in row[0]:
                    read_info = 'END'
                else:
                    # Key(list_head):Value(row)の型でデータをリストに追加
                    # Make Content data [{key:val,key:val,.},{key:val.}]
                    dict_from_list.append(dict(zip(list_head, row)))
            if read_info == 'GENERAL_HEAD':
                if '[' in row[0] and ']' in row[0]:
                    read_info = 'NONE'
                else:
                    general_list.append(dict(zip(general_head, row)))

            # ヘッダ部（VMName・・・）を取得
            if read_info == 'HEAD':
                if 'HostName' in row:
                    read_info = 'CONTENT'
                    # Make Header
                    list_head = row

            # ヘッダ部(CSVVersion・・・)を取得
            if read_info == 'GENERAL':
                if 'CSVversion' in row:
                    read_info = 'GENERAL_HEAD'
                    general_head = row

            if read_info == 'NONE':
                # [Nodes]セクションを検索
                if '[Nodes]' in row:
                    read_info = 'HEAD'
                # [General]セクション検索
                if '[General]' in row:
                    read_info = 'GENERAL'

    # 辞書チェック
    if len(general_list) == 0:
        errmsg = "[General] section is invalid."
        return [], "", errmsg
    if len(dict_from_list) == 0:
        errmsg = "[Nodes] section is invalid."
        return [], "", errmsg

    # csv versionを設定
    csv_version = general_list[0]['CSVversion']

    return dict_from_list, csv_version, errmsg

# 構成パラメータ設定APIのデータ部を作成する


def set_native_commandList(config_data_before, param):
    # output_param = []
    config_param = {}
    param_cnt = 0
    work_list = []

    # Beforのリストの内容から、ノード数分ループする
    for row in config_data_before:
        # valueとなるデータを取得する
        for data_row in param:
            # set_param = {}
            if row['HostName'] in data_row:
                # config_param = {}
                param_key = row['ControlNWIPv4']
                config_head_str = '{\"configurationParameters\": ['
                for key_data, value_data in data_row.items():
                    # countをリセットする
                    param_cnt = 0
                    # work_listをリセットする
                    work_list = []
                    # 分割先頭文字列作成
                    config_value_str = config_head_str
                    for key_str, value_str in value_data.items():
                        if value_str == "":
                            continue
                        if param_cnt >= 32:
                            # configurationParametersを新たに作るために一旦閉じる
                            # 最後のカンマを削る
                            config_value_str = config_value_str[:-1]
                            config_value_str = config_value_str + ']}'
                            # リストに登録
                            work_list.append(config_value_str)
                            # configurationParametersを区切る
                            config_value_str = config_head_str
                            # countをリセットする
                            param_cnt = 0
                        config_value_str = config_value_str + '{\"key\":\"' + key_str + '\", \"value\":\"' + value_str + '\"},'
                        param_cnt += 1

                    # 最後のカンマを削る
                    config_value_str = config_value_str[:-1]
                    config_value_str = config_value_str + ']}'
                    work_list.append(config_value_str)

                # configurationParametersのValueを作成する
                config_param.setdefault(param_key, work_list)
    return config_param

# [Nodes]の内容を取得する
# 全ストレージノードの設定値を取得する


def make_native_network_parameters(nodes_after, after_csv_version):
    errmsg = ""
    param = []

    # v1.14 NVMeTCP対応
    # エラーメッセージの解像度を上げるため、項目名が正しいかチェックする
    errmsg = check_key(nodes_after, after_csv_version)
    if errmsg != "":
        return [], errmsg

    # nodes_afterより、APIキーとnodes_afterのデータを設定

    # Node数分ループする
    for row in nodes_after:
        # Nodes毎に初期化する
        data_dict = OrderedDict()
        reg_dict = {}
        # 'eth0'設定
        data_dict.setdefault('guestinfo.hsds.nw.control.interface', 'eth0')

        # ControlNWIPv4より取得
        data_dict.setdefault('guestinfo.hsds.nw.control.ipv4addr', row['ControlNWIPv4'])
        # ControlNWIPv4Subnetより取得
        data_dict.setdefault('guestinfo.hsds.nw.control.ipv4netmask', row['ControlNWIPv4Subnet'])

        # ControlNWMTUSizeより取得
        data_dict.setdefault('guestinfo.hsds.nw.control.mtu', row['ControlNWMTUSize'])

        # 'eth1'設定
        data_dict.setdefault('guestinfo.hsds.nw.internode.interface', 'eth1')

        # InternetNodeNWIPv4より取得
        data_dict.setdefault('guestinfo.hsds.nw.internode.ipv4addr', row['InterNodeNWIPv4'])
        # InterNodeNWIPv4Subnetより取得
        data_dict.setdefault('guestinfo.hsds.nw.internode.ipv4netmask', row['InterNodeNWIPv4Subnet'])
        # InterNodeNWMTUSizeより取得
        data_dict.setdefault('guestinfo.hsds.nw.internode.mtu', row['InterNodeNWMTUSize'])

        # 複数存在する可能性のあるデータ部取得（Guideより最大256個設定可能）
        num = 255
        for cnt in range(num):
            Content = cnt + 1

            # data_dict.setdefault('guestinfo.hsds.nw.compute{}.macaddr'.format(cnt),'')
            if version_to_int(after_csv_version) < version_to_int('01.14.00.00'):
                if 'iSCSIUniversalPortGroupName{}'.format(Content) in row:
                    # iSCSIUniversalPortGroupName{}より存在のみ取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.interface'.format(cnt), 'eth{}'.format(cnt + 2))
                # キーの存在確認
                if 'iSCSIUniversalIPv4Address{}'.format(Content) in row:
                    # iSCSIUniversalIPv4Address{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv4addr'.format(cnt), row['iSCSIUniversalIPv4Address{}'.format(Content)])

                if 'iSCSIUniversalIPv4Subnet{}'.format(Content) in row:
                    # iSCSIUniversalIPv4Subnet{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv4netmask'.format(cnt), row['iSCSIUniversalIPv4Subnet{}'.format(Content)])

                if 'iSCSIUniversalIPv4Gateway{}'.format(Content) in row:
                    # iSCSIUniversalIPv4Gateway{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv4gateway'.format(cnt), row['iSCSIUniversalIPv4Gateway{}'.format(Content)])

                if 'iSCSIUniversalIPv6Mode{}'.format(Content) in row:
                    # iSCSIUniversalIPv6Mode{}より取得
                    if row['iSCSIUniversalIPv6Mode{}'.format(Content)] == 'Enable':
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6mode'.format(cnt), 'true')
                    else:
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6mode'.format(cnt), 'false')

                if 'iSCSIUniversalIPv6Global1_{}'.format(Content) in row:
                    # iSCSIUniversalIPv6Global1_{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6global1'.format(cnt), row['iSCSIUniversalIPv6Global1_{}'.format(Content)])

                if 'iSCSIUniversalIPv6SubnetPrefix{}'.format(Content) in row:
                    # iSCSIUniversalIPv6SubnetPrefix{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6netmask'.format(cnt), row['iSCSIUniversalIPv6SubnetPrefix{}'.format(Content)])

                if 'iSCSIUniversalIPv6Gateway{}'.format(Content) in row:
                    # iSCSIUniversalIPv6Gateway{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6gateway'.format(cnt), row['iSCSIUniversalIPv6Gateway{}'.format(Content)])

                if 'iSCSIUniversalMTUSize{}'.format(Content) in row:
                    # iSCSIUniversalMTUSize{}より取得
                    data_dict.setdefault('guestinfo.hsds.nw.compute{}.mtu'.format(cnt), row['iSCSIUniversalMTUSize{}'.format(Content)])
            else:
                if 'NumberOfFCTargetPort' in row and row['NumberOfFCTargetPort'] == '0': # TODO エンハンスで FC Initiatorサポート時はComputePortProtocol1のチェックが必要
                    # iSCSI Universal Port使用時、NVMe Port使用時
                    if 'ComputeNWPortGroupName{}'.format(Content) in row:
                        # ComputeNWPortGroupName{}より存在のみ取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.interface'.format(cnt), 'eth{}'.format(cnt + 2))
                    # キーの存在確認
                    if 'ComputeNWIPv4Address{}'.format(Content) in row:
                        # ComputeNWIPv4Address{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv4addr'.format(cnt), row['ComputeNWIPv4Address{}'.format(Content)])

                    if 'ComputeNWIPv4Subnet{}'.format(Content) in row:
                        # ComputeNWIPv4Subnet{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv4netmask'.format(cnt), row['ComputeNWIPv4Subnet{}'.format(Content)])

                    if 'ComputeNWIPv4Gateway{}'.format(Content) in row:
                        # ComputeNWIPv4Gateway{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv4gateway'.format(cnt), row['ComputeNWIPv4Gateway{}'.format(Content)])

                    if 'ComputeNWIPv6Mode{}'.format(Content) in row:
                        # ComputeNWIPv6Mode{}より取得
                        if row['ComputeNWIPv6Mode{}'.format(Content)] == 'Enable':
                            data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6mode'.format(cnt), 'true')
                        else:
                            data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6mode'.format(cnt), 'false')

                    if 'ComputeNWIPv6Global1_{}'.format(Content) in row:
                        # ComputeNWIPv6Global1_{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6global1'.format(cnt), row['ComputeNWIPv6Global1_{}'.format(Content)])

                    if 'ComputeNWIPv6SubnetPrefix{}'.format(Content) in row:
                        # ComputeNWIPv6SubnetPrefix{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6netmask'.format(cnt), row['ComputeNWIPv6SubnetPrefix{}'.format(Content)])

                    if 'ComputeNWIPv6Gateway{}'.format(Content) in row:
                        # ComputeNWIPv6Gateway{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.ipv6gateway'.format(cnt), row['ComputeNWIPv6Gateway{}'.format(Content)])

                    if 'ComputeNWMTUSize{}'.format(Content) in row:
                        # ComputeNWMTUSize{}より取得
                        data_dict.setdefault('guestinfo.hsds.nw.compute{}.mtu'.format(cnt), row['ComputeNWMTUSize{}'.format(Content)])

            if 'ControlInterNodeNWIPv4RouteDestination{}'.format(Content) in row:
                # ControlInterNodeNWIPv4RouteDestination{}より取得
                data_dict.setdefault('guestinfo.hsds.nw.ipv4route{}.destination'.format(cnt), row['ControlInterNodeNWIPv4RouteDestination{}'.format(Content)])

            if 'ControlInterNodeNWIPv4RouteGateway{}'.format(Content) in row:
                # ControlInterNodeNWIPv4RouteGateway{}より取得
                data_dict.setdefault('guestinfo.hsds.nw.ipv4route{}.gateway'.format(cnt), row['ControlInterNodeNWIPv4RouteGateway{}'.format(Content)])

            if 'ControlInterNodeNWIPv4RouteInterface{}'.format(Content) in row:
                # B170027対策：controlの場合はeth0, internodeの場合はeth1を返却する。
                # B223401対策：ControlInterNodeNWIPv4RouteInterfaceに不正な値や空が入っていた場合は無視する
                #             csvのチェックはdry-checkで行うことで摘出できるので、ここでのチェックは行わない
                if row['ControlInterNodeNWIPv4RouteInterface{}'.format(Content)] == 'control':
                    data_dict.setdefault('guestinfo.hsds.nw.ipv4route{}.interface'.format(cnt), 'eth0')
                elif row['ControlInterNodeNWIPv4RouteInterface{}'.format(Content)] == 'internode':
                    data_dict.setdefault('guestinfo.hsds.nw.ipv4route{}.interface'.format(cnt), 'eth1')

        # setupnetworkの設定
        data_dict.setdefault('guestinfo.hsds.nw.setupnetwork', '1')

        # 917e63a76cf92a00f36dbb49b5e40df597c5a3fdbe68ed852b8216c328ecdc8dの設定
        data_dict.setdefault('guestinfo.hsds.917e63a76cf92a00f36dbb49b5e40df597c5a3fdbe68ed852b8216c328ecdc8d', 'NoService')

        # VMNameをキーに、上記作成辞書データをリストに追加
        reg_dict.setdefault(row['HostName'], data_dict)
        param.append(reg_dict)

    return param, ""

# v1.14 NVMeTCP対応
# エラーメッセージの解像度を上げるため、事前に不正なキーを洗い出す
def check_key(dict_list, csv_version):
    editable_keys = [
        'ControlNWIPv4',
        'ControlNWIPv4Subnet',
        'ControlNWMTUSize',
        'InterNodeNWIPv4',
        'InterNodeNWIPv4Subnet',
        'InterNodeNWMTUSize',
        'ControlInterNodeNWIPv4RouteDestination',
        'ControlInterNodeNWIPv4RouteGateway',
        'ControlInterNodeNWIPv4RouteInterface',
    ]

    conputenw_until_v1_13 = [
        'iSCSIUniversalIPv4Address',
        'iSCSIUniversalIPv4Subnet',
        'iSCSIUniversalIPv4Gateway',
        'iSCSIUniversalIPv6Mode',
        'iSCSIUniversalIPv6Global1_',
        'iSCSIUniversalIPv6SubnetPrefix',
        'iSCSIUniversalIPv6Gateway',
        'iSCSIUniversalMTUSize',
    ]

    conputenw_since_v1_14 = [
        'ComputeNWIPv4Address',
        'ComputeNWIPv4Subnet',
        'ComputeNWIPv4Gateway',
        'ComputeNWIPv6Mode',
        'ComputeNWIPv6Global1_',
        'ComputeNWIPv6SubnetPrefix',
        'ComputeNWIPv6Gateway',
        'ComputeNWMTUSize',
    ]

    try:
        if version_to_int(csv_version) < version_to_int('01.14.00.00'):
            editable_keys.extend(conputenw_until_v1_13)
        else:
            editable_keys.extend(conputenw_since_v1_14)
    except Exception as e:
        return "Setting is invalid. (Item name = CSVversion)"

    match = False
    unmatch_list = []
    for nodes in dict_list:
        for edit_key in editable_keys:
            for key in nodes:
                if edit_key in key:
                    match = True
                    break
            if match:
                match = False
                continue
            else:
                unmatch_list.append(edit_key)

    errmsg = ""
    if len(unmatch_list) > 0:
        errmsg = "Item name is invalid. (Item name = "
        dict1 = dict.fromkeys(unmatch_list)
        unmatch_list_deldup = list(dict1)
        errmsg = errmsg + ', '.join(unmatch_list_deldup)
        errmsg = errmsg + ")"
        return errmsg

    return ""


# 入力 変更前CSV、変更後CSV
# 出力 構成パラメータ設定API用コマンドの文字列で、各ノード毎のリスト形式
# 前提条件：hsdsmodify.pyにて、set_networkが実行されている状態


def get_data_configparameter_info(csv_before_name, csv_after_name):
    errmsg = ""
    # ファイル[Nodes]部読込（before）
    nodes_before, before_csv_version, errmsg = get_native_config_csv_file_read(csv_before_name)
    if errmsg != "":
        return [], errmsg

    # ファイル[Nodes]部読込（after）
    nodes_after, after_csv_version, errmsg = get_native_config_csv_file_read(csv_after_name)
    if errmsg != "":
        return [], errmsg

    param, errmsg = make_native_network_parameters(nodes_after, after_csv_version)
    if errmsg != "":
        return [], errmsg

    # 取得状況の成功・失敗と、設定した情報を戻り値のリスト・辞書形式にし戻す。
    # [{'configurationParams':{<guestinfo-key:Value>,
    #  <guestinfo-key:Value>・・・}"},
    #  {'Before_IP':"{'configurationParams':{'guestinfo.hsds.nw.xxxx':'value'}"},
    # ・・・
    #  {'Before_IP':"{'configurationParams':{'guestinfo.hsds.nw.xxxx':'value'}"}
    # ]

    config_param = set_native_commandList(nodes_before, param)

    return config_param, ""
