# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of control port records to be obtained. ')
def control_port_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of control port performance information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "control_port_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "control_port_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `control_port_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `control_port_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ControlPortPerformanceListPartialResponse import ControlPortPerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.control_port_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.control_port_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Control port ID ',required=True)
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def control_port_performance_show(_id,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified control port for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "control_port_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "control_port_performance_show"














        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ControlPortPerformanceListResponse import ControlPortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.control_port_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of drive records to be obtained. ')
def drive_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of drive performance information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "drive_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `drive_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `drive_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DrivePerformanceListPartialResponse import DrivePerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.drive_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.drive_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Drive ID ',required=True)
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def drive_performance_show(_id,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified drive for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "drive_performance_show"














        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DrivePerformanceListResponse import DrivePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.drive_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of internode port records to be obtained. ')
def internode_port_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of internode port performance information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "internode_port_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "internode_port_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `internode_port_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `internode_port_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.InternodePortPerformanceListPartialResponse import InternodePortPerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.internode_port_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.internode_port_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Internode port ID ',required=True)
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def internode_port_performance_show(_id,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified internode port for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "internode_port_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "internode_port_performance_show"














        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.InternodePortPerformanceListResponse import InternodePortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.internode_port_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of storage pool records to be obtained. ')
def pool_capacity_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of storage pool capacity information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_capacity_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "pool_capacity_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `pool_capacity_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `pool_capacity_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PoolCapacityListPartialResponse import PoolCapacityListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.pool_capacity_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.pool_capacity_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool. ')
@click.option('--id_name','_id_name',metavar='<str>',help='The name of the storage pool.')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def pool_capacity_performance_show(_id,_id_name,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about capacity of a specified storage pool for the low-resolution monitor. 
    """
    def get_uuid_from_pool_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.pool_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_capacity_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "




        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "pool_capacity_performance_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `pool_capacity_show`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")









        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PoolCapacityListResponse import PoolCapacityListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # pool_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_pool_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.pool_capacity_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of storage pool records to be obtained. ')
def pool_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of storage pool performance information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "pool_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `pool_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `pool_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PoolPerformanceListPartialResponse import PoolPerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.pool_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.pool_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool. ')
@click.option('--id_name','_id_name',metavar='<str>',help='The name of the storage pool.')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def pool_performance_show(_id,_id_name,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified storage pool for the low-resolution monitor. 
    """
    def get_uuid_from_pool_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.pool_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "




        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "pool_performance_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `pool_performance_show`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")









        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PoolPerformanceListResponse import PoolPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # pool_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_pool_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.pool_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of compute port records to be obtained. ')
def port_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of compute port performance information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "port_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `port_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `port_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PortPerformanceListPartialResponse import PortPerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.port_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.port_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--id_name','_id_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def port_performance_show(_id,_id_name,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified compute port for the low-resolution monitor. 
    """
    def get_uuid_from_port_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "port_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "




        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "port_performance_show"





        if  _id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `id` when calling `port_performance_show`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")









        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PortPerformanceListResponse import PortPerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # port_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_port_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.port_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of storage node records to be obtained. ')
def storage_node_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,):
    """
    Obtains a list of storage node performance information for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `storage_node_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `storage_node_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodePerformanceListPartialResponse import StorageNodePerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.storage_node_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.storage_node_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def storage_node_performance_show(_id,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified storage node for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_performance_show"














        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodePerformanceListResponse import StorageNodePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def storage_performance_show(_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of the storage cluster for the low-resolution monitor. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_performance_show"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StoragePerformanceListResponse import StoragePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_performance_show(start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of volume records to be obtained. ')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def volume_capacity_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,_vps_id,_vps_id_name,):
    """
    Obtains a list of volume capacity information for the low-resolution monitor. 
    """
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_capacity_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "volume_capacity_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `volume_capacity_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `volume_capacity_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0






        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_capacity_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_capacity_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumeCapacityListPartialResponse import VolumeCapacityListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)

        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.volume_capacity_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, vps_id=_vps_id, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.volume_capacity_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, vps_id=_vps_id, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def volume_capacity_performance_show(_id,_id_name,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about capacity of a specified volume for the low-resolution monitor. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_capacity_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "




        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_capacity_performance_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_capacity_show`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")









        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumeCapacityListResponse import VolumeCapacityListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_capacity_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
@click.option('--enumerate_context','_enumerate_context',metavar='<str>',help='Token that helps obtain the next batch records (you can restart information extraction from the location shown by the token). Do not specify this parameter for initial information extraction. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of volume records to be obtained. ')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def volume_performance_list(_start_time,_start_time_excluding,_end_time,_end_time_including,_enumerate_context,_count,_vps_id,_vps_id_name,):
    """
    Obtains a list of volume performance information for the low-resolution monitor. 
    """
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_performance_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "




        if _enumerate_context is not None:
            subCommandLogtxt += "--enumerate_context " + str(_enumerate_context) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        #UUIDチェック
        if _enumerate_context is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _enumerate_context):
            raise ValueError("Invalid value for `enumerate_context`, the format of UUID is invalid.")
        


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "volume_performance_list"








        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")











        if _count is not None and _count > 32768:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `32768`")
#           raise ValueError("Invalid value for parameter `count` when calling `volume_performance_list`, must be a value less than or equal to `32768`")
        max_count = 32768
        if _count is not None and _count < 0:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `count` when calling `volume_performance_list`, must be a value greater than or equal to `0`")
        if _count is None:
            _count = 0






        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_performance_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_performance_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumePerformanceListPartialResponse import VolumePerformanceListPartialResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)

        # countが 0 の場合
        is_all = False
        if _count == 0:
            # countをMAX値で更新
            logger.info('Since the count is 0, set the maximum value.')
            _count = max_count
            is_all = True

        output_util = OutputUtil()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # API実行(1回目)
        response = api.volume_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, vps_id=_vps_id, callback=None, debug="false")

        status = commonutil.get_response_status(response)
        if status == 200:
            # 全件取得の場合
            if is_all:
                # enumerate_contextがnull以外の場合はCLI内部で
                # 繰り返し取得APIを実行し、全件取得を試みる。

                # ヘッダ出力処理
                output_util.echo_data_list_with_header(response, config.format, cliSubCommand)

                # 取得したリソースのidリストを取得
                id_list = []
                id_list = commonutil.get_data_count_from_response(response)

                # enumerateContextを取得(1回目)
                _enumerate_context = commonutil.get_enumerate_context(response)

                while _enumerate_context:

                    # 前回データとして totalCount, hasNext, enumerateContext を取得
                    end_data = commonutil.get_previous_response_data(response)

                    try:
                        # API実行(2回目～)
                        response = api.volume_performance_list(start_time=_start_time, start_time_excluding=_start_time_excluding, end_time=_end_time, end_time_including=_end_time_including, enumerate_context=_enumerate_context, count=_count, vps_id=_vps_id, callback=None, debug="false")

                        status = commonutil.get_response_status(response)
                        if status == 200:
                            # data[]出力処理
                            output_util.echo_data_list(response, config.format, cliSubCommand)

                            # 取得したリソースのidリストを追加し、重複したidを削除
                            id_list = id_list + commonutil.get_data_count_from_response(response)
                            id_list = sorted(set(id_list), key=id_list.index)

                            # enumerateContextを取得(2回目～)
                            _enumerate_context = commonutil.get_enumerate_context(response)

                        else:
                            # 前回データの後ろにエラーデータを追加
                            final_data = commonutil.add_error_data_to_previous_data(end_data, response)
                            # 最終出力処理(エラー時)
                            final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                            output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                            exit(3)

                    except Exception as e:
                        if traceback:
                            logger.error(traceback.format_exc())
                        # 例外データを取得
                        msg_get = True
                        mssageManagement = MessageManagement('')
                        exception = mssageManagement.viewMessage(e, msg_get)
                        # 前回データの後ろに例外データを追加
                        final_data = commonutil.add_exception_data_to_previous_data(end_data, exception)
                        # 最終出力処理(例外時)
                        final_data = commonutil.update_total_count_for_final_data(final_data, len(id_list))
                        output_util.echo_data_list_finalize(final_data, config.format, cliSubCommand)
                        exit(3)

                # 最終出力処理(enumerate_contextがNone)
                response = commonutil.update_total_count_for_response(response, len(id_list))
                output_util.echo_data_list_finalize(response, config.format, cliSubCommand)
                exit(0)

            # 通常取得の場合(ユーザ指定値 または デフォルト値での取得)
            else:
                # 応答データを表示して終了
                output_util.echo_normal(response, config.format, cliSubCommand)

        # API実行(1回目)失敗の場合
        else:
            # 応答データを表示して終了
            output_util.echo_normal(response, config.format, cliSubCommand)

        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the monitor information to be obtained. If you specify start_time_excluding, you can specify whether to include or exclude the specified time. By default, the specified time is included. ')
@click.option('--start_time_excluding','_start_time_excluding',metavar='<bool>',help='Determines whether to include information of the specified start_time. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the monitor information to be obtained. If you specify end_time_including, you can specify whether to include or exclude the specified time. By default, the specified time is excluded. If it is omitted, it is the request receipt time. ')
@click.option('--end_time_including','_end_time_including',metavar='<bool>',help='Specify whether to include the specified end_time. ')
def volume_performance_show(_id,_id_name,_start_time,_start_time_excluding,_end_time,_end_time_including,):
    """
    Obtains the information about performance of a specified volume for the low-resolution monitor. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_performance_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "




        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _start_time_excluding is not None:
            subCommandLogtxt += "--start_time_excluding " + str(_start_time_excluding) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _end_time_including is not None:
            subCommandLogtxt += "--end_time_including " + str(_end_time_including) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.low_resolution_monitor import LowResolutionMonitor as LowResolutionMonitorApi
        api = LowResolutionMonitorApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_performance_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `volume_performance_show`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")









        if _start_time_excluding is not None and ((_start_time_excluding != "true" and _start_time_excluding != "false") and (_start_time_excluding != True and _start_time_excluding != False)):
            raise ValueError("Invalid value for `start_time_excluding`, the format of the boolean value is invalid.")












        if _end_time_including is not None and ((_end_time_including != "true" and _end_time_including != "false") and (_end_time_including != True and _end_time_including != False)):
            raise ValueError("Invalid value for `end_time_including`, the format of the boolean value is invalid.")
















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumePerformanceListResponse import VolumePerformanceListResponse

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_performance_show(_id, start_time = _start_time, start_time_excluding = _start_time_excluding, end_time = _end_time, end_time_including = _end_time_including, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['control_port_performance_list'] = control_port_performance_list
    commands['control_port_performance_show'] = control_port_performance_show
    commands['drive_performance_list'] = drive_performance_list
    commands['drive_performance_show'] = drive_performance_show
    commands['internode_port_performance_list'] = internode_port_performance_list
    commands['internode_port_performance_show'] = internode_port_performance_show
    commands['pool_capacity_performance_list'] = pool_capacity_performance_list
    commands['pool_capacity_performance_show'] = pool_capacity_performance_show
    commands['pool_performance_list'] = pool_performance_list
    commands['pool_performance_show'] = pool_performance_show
    commands['port_performance_list'] = port_performance_list
    commands['port_performance_show'] = port_performance_show
    commands['storage_node_performance_list'] = storage_node_performance_list
    commands['storage_node_performance_show'] = storage_node_performance_show
    commands['storage_performance_show'] = storage_performance_show
    commands['volume_capacity_performance_list'] = volume_capacity_performance_list
    commands['volume_capacity_performance_show'] = volume_capacity_performance_show
    commands['volume_performance_list'] = volume_performance_list
    commands['volume_performance_show'] = volume_performance_show
    return commands

