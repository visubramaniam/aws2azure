# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2021, 2024, Hitachi Vantara, Ltd.
"""
import json
import errno

import click
import logging as loggingLib
import os
import sys
import traceback
from os.path import expanduser
import time
import uuid
import re
from urllib.parse import urlparse

from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.configfile_util import ConfigfileUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.util.configparameter_make_parameter import get_data_configparameter_info
from com.hitachi.sophia.cli.manual.util.rest_certificate_util import RestCertificateUtil

# 自動生成対象外コード

logger = loggingLib.getLogger(__name__)
OS_REBOOT_WAIT_TIME = 3600

def get_control_address(const_csv):
    configfile_util = ConfigfileUtil()
    ret , address, errmsg = configfile_util.get_control_address_from_csv(const_csv)
    if ret == 1:
        show_errmsg("Error", "The file does not exist in the specified path.", "Specify the file path correctly and specify the option value correctly.\nFile: " + const_csv)
        logger.error('get_address_from_csv Failed.')
        exit(1)
    elif not ret == 0:
        show_errmsg("Error", "Configuration file is invalid.", "Please check the contents of configuration file.")
        exit(1)
    return address

def convert_rest_responses_with_cli_for_configraton_modify(response):
    d = json.loads(response)
    message_management = MessageManagement('')
    if d['httpStatusCode'] == 401:
        # 認証系エラー/チケットエラー
        if d.get('body') != None and d['body'].get('messageId') != None:
            click.echo("MessageId: {}".format(d['body'].get("messageId")))
            click.echo("Message: {}".format(d['body'].get("message")))
            click.echo("Cause: {}".format(d['body'].get("cause")))
            click.echo("Solution: {}".format(d['body'].get("solution")))
            return 1
    elif d['httpStatusCode'] == 403:
        # ロール不正
        if d.get('body') != None and d['body'].get('messageId') != None:
            rest_message_id = d['body'].get('messageId')
            if rest_message_id == 'KARS20008-E':
                message_id = '19221'
                message_dict = {'required_role': 'Secutiry'}
                message_management = MessageManagement('')
                message_management.viewMessageTxt(message_id, **message_dict)
                return 1
    elif d['httpStatusCode'] == 412:
        # プラットフォーム不正
        show_errmsg('Error', 'This command is not supported by the execution storage node.', 'Execute the command for the storage node in the bare metal environment.')
        return 1
    return 0

def check_sys_file_is_valid(const_csv, const_beforecsv):
    common_util = CommonUtil()
    output_util = OutputUtil()
    # dry-check API
    from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
        SystemManagement as SystemManagementApi
    api = SystemManagementApi(ApiClient())
    response = api.modify_configuration_dry_check(callback=None, debug="false", system_configuration_file=const_csv, before_system_configuration_file=const_beforecsv)
    if os.path.isfile(response) == False:
        click.echo('Message: Failed to modify configuration.')
        click.echo('Cause: An error occurred while running the command.')
        click.echo('Solution: Take action according to the Troubleshooting Guide.')
        return
    with open(response, mode='rt', encoding='utf-8') as f:
        jsonres = json.load(f)
        try:
            if jsonres["status"] == 0:
                click.echo('Status: Success')
            else:
                click.echo('Status: Error')
            output = jsonres["stdout"]
            output = output.replace('/dev/shm/hsdsmodify/SystemConfigurationFile.csv', const_csv)
            output = output.replace('/dev/shm/hsdsmodify/BeforeSystemConfigurationFile.csv', const_beforecsv)
            # check_format()エラー時、ファイル名のみ出力されるため、入力されたファイル名に変換する
            basename = os.path.basename(const_csv)
            before_basename = os.path.basename(const_beforecsv)
            output = output.replace('SystemConfigurationFile.csv', basename)
            output = output.replace('BeforeSystemConfigurationFile.csv', before_basename)
            click.echo('Message:')
            click.echo(output)
        except Exception as e:
            logger.error('configraton_modify check_sys_file_is_valid response error')
            logger.error(jsonres)
            try:
                if jsonres["messageId"] != None:
                    click.echo("MessageId: {}".format(jsonres["messageId"]))
                    click.echo("Message: {}".format(jsonres["message"]))
                    click.echo("Cause: {}".format(jsonres["cause"]))
                    click.echo("Solution: {}".format(jsonres["solution"]))
                else:
                    click.echo('Message: Failed to modify configuration.')
                    click.echo('Cause: An error occurred while running the command.')
                    click.echo('Solution: Take action according to the Troubleshooting Guide.')
            except Exception as e:
                click.echo('Message: Failed to modify configuration.')
                click.echo('Cause: An error occurred while running the command.')
                click.echo('Solution: Take action according to the Troubleshooting Guide.')
    is_file = os.path.isfile(response)
    if is_file:
        os.remove(response)
    #http_status = common_util.get_response_status(response)
    #if http_status == 200:
    #    jsonres = json.loads(response)
    #    click.echo('Message:')
    #    click.echo(jsonres['body'].get('stdout'))
    #else:
    #    # エラー処理
    #    # REST応答をCLIで変換
    #    ret = convert_rest_responses_with_cli_for_configraton_modify(response)
    #    if ret == 0:
    #        output_util.echo_error(response, 'text')
    #    logger.error('create_cluster_config_backup Failed.')
    return

def show_errmsg(status, message, action, config_file=None, before_config_file=None):
    #click.echo('Status: ' + status) # 静止点設定と合わせる
    if not config_file == None:
        message = message.replace('/dev/shm/hsdsmodify/SystemConfigurationFile.csv', config_file)
        basename = os.path.basename(config_file)
        message = message.replace('SystemConfigurationFile.csv', basename)
    if not before_config_file == None:
        message = message.replace('/dev/shm/hsdsmodify/BeforeSystemConfigurationFile.csv', before_config_file)
        before_basename = os.path.basename(before_config_file)
        message = message.replace('BeforeSystemConfigurationFile.csv', before_config_file)

    click.echo('Message: Failed to modify configuration.')
    click.echo('Cause: ' + message)
    if not action == '':
        click.echo('Solution: ' + action)
    return

def check_configparammode(const_address, fingerprint):
    # 全ノードが構成パラメータ設定モードかチェックする
    # 応答が返ってこないノードは障害ノード/ネットワーク不正の可能性があるが、
    # この段階では障害ノード対応の為のリトライの可能性もあり、
    # ロールバックの為ネットワーク設定終わりのの3/4までつき進める必要がある為無視する
    common_util = CommonUtil()
    restCertUtil = RestCertificateUtil()
    base_url = "/ConfigurationManager/simple"
    path = "/v1/objects/storage-node-configuration-parameter/polling-mode"

    roopaddress = const_address.copy()
    for host in roopaddress[:]:
        response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('GET', fingerprint, host, base_url, path, connection_timeout=40, read_timeout=300)
        if response is not None:
            http_status = common_util.get_response_status(response)
            if http_status == 200:
                jsonres = json.loads(response)
                if jsonres['body'].get('isEnabled') == 'true' or jsonres['body'].get('isEnabled') == 'True' or jsonres['body'].get('isEnabled') == True:
                    continue
                else:
                    # 構成パラメータ設定モードでない場合はエラーとする
                    # リトライ時でもここはパスしているはず
                    return 1
            else:
                # エラー処理
                # 認証系・ロール系・ticket・Platformエラーの場合はエラー変換して終了
                ret = convert_rest_responses_with_cli_for_configraton_modify(response)
                if ret == 1:
                    logger.error('check_configparammode auth Failed.')
                    exit(1)

                # その他はそのままエラーを出して継続
                logger.error('check_configparammode ' + host + ' error.')
        else:
            # rest_access_on_fingerprint_certificateでEXceprionが発生した場合
            if message_id == '19504':
                # 19504はノードが障害等で通信エラーになったもののため、この場合のみ継続させる
                logger.error('check_configparammode ' + host + ' 19504 error.')
                continue
            else:
                # サーバ証明書/その他エラーは表示して終了する
                message_management = MessageManagement('')
                if message_id == 'exception':
                    message_management.viewMessage(message_dict)
                else:
                    message_management.viewMessageTxt(message_id, **message_dict)
                logger.error('check_configparammode ' + host + ' ' + message_id + ' error.')
                exit(1)
    return 0

def set_mutex(const_address, uuid, renew_time, lock, fingerprint):
    # 全ノードの排他を設定する
    # 応答が返ってこないノードは障害ノード/ネットワーク不正の可能性があるが、
    # この段階では障害ノード対応の為のリトライの可能性もあり、
    # ロールバックの為ネットワーク設定終わりのの3/4までつき進める必要があるため無視する
    # 解放の場合はエラーで返さないで全ノード排他解放を打たせる
    # ---B169662 対応---
    # 先発の構成一括変更により全ノード再起動中の場合、突き進めてしまう場合がある
    # その為、初回の排他で3ノード以上排他が排他取得エラー以外のエラーで取れなかったら、構成一括変更をエラーにする。
    # return値0：正常
    # return値1：排他取得エラー
    # return値3：3ノード以上通信エラー
    common_util = CommonUtil()
    restCertUtil = RestCertificateUtil()
    base_url = "/ConfigurationManager/simple"
    path = "/v1/objects/storage-node-configuration-parameter/parameters"

    # 排他パラメータ生成
    setparam = '{\"pf_uuid\":\"' + uuid +'\",\"pf_expire\":' + str(renew_time) + ',\"pf_request\":\"' + lock + '\",\"pf_fileid\":\"hsdsmodify\"}'

    configparamater = {
        'configurationParameters': [{'key': 'exclusion', 'value': setparam}]
    }

    roopaddress = const_address.copy()
    errlist = []
    for host in roopaddress[:]:
        response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('PATCH', fingerprint, host, base_url, path, body=json.dumps(configparamater), connection_timeout=40, read_timeout=300)
        if response is not None:
            http_status = common_util.get_response_status(response)
            if http_status == 204:
                continue
            else:
                # エラー処理
                # 認証系・ロール系エラーは構成パラメータ設定モードチェックで通っているはず
                # 排他取得失敗のみエラーを返す
                if lock == "Lock": # 解放時は全ノード排他解放をエラーでも実施するのでエラーにはしない。全ノードやりきる
                    d = json.loads(response)
                    if d['httpStatusCode'] == 503: # 排他競合
                        return 1, []
                    elif d['httpStatusCode'] == 500: #ノードエラー
                        errlist.append(host)
                        continue

                # その他はログは出力するが続行
                errlist.append(host)
                logger.error('configraton_modify set_mutex ' + host + ' error.')
        else:
            # その他はログは出力するが続行
            # rest_access_on_fingerprint_certificateでEXceprionが発生した場合
            logger.error('configraton_modify set_mutex ' + host + ' error.')
            errlist.append(host)
            continue
    
    # BB169662対応
    if len(errlist) >= 3:
        return 3, errlist

    return 0, []

def set_configparameter(const_address, configparam, fingerprint):
    # 全ノードに対して構成パラメータを設定する
    # 応答が返ってこないノードは障害ノード/ネットワーク不正の可能性があるが、
    # 障害ノード対応の為のリトライの可能性もあるので無視する
    ret = 0
    common_util = CommonUtil()
    restCertUtil = RestCertificateUtil()
    base_url = "/ConfigurationManager/simple"
    path = "/v1/objects/storage-node-configuration-parameter/parameters"

    control_address = const_address.copy()
    errlist = []

    for host in control_address[:]:
        for param in configparam[str(host)]:
            #json_param=json.loads(param)
            response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('PATCH', fingerprint, host, base_url, path, body=param, connection_timeout=40, read_timeout=300)
            if response is not None:
                http_status = common_util.get_response_status(response)
                if http_status == 204:
                    continue
                else:
                    errlist.append(host)
                    continue
            else:
                # rest_access_on_fingerprint_certificateでEXceprionが発生した場合
                errlist.append(host)
                continue

    if len(errlist) > 0:
        logger.error('configraton_modify set_configparameter ' + str(errlist) + ' error.')
        ret = 1

    return ret

def polling_config_status(const_address, fingerprint, uuid):
    timeout = OS_REBOOT_WAIT_TIME
    start_time = time.time()
    err_address = const_address.copy()

    common_util = CommonUtil()
    restCertUtil = RestCertificateUtil()
    base_url = "/ConfigurationManager/simple"
    path = "/v1/objects/storage-node-configuration-parameter/parameters"
    configparamater = {
        'keys': "guestinfo.hsds.configparam_status"
    }

    while True:
        if time.time() - start_time > timeout:
            break

        for host in err_address[:]:
            response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('GET', fingerprint, host, base_url, path, quiery_params=configparamater, connection_timeout=40, read_timeout=300)
            if response is not None:
                http_status = common_util.get_response_status(response)
                if http_status == 200:
                    jsonres = json.loads(response)
                    if type(jsonres['body']['stdout']) is str:
                        configparam_status = json.loads(jsonres['body']['stdout'])["guestinfo.hsds.configparam_status"]
                    else:
                        configparam_status = jsonres['body']['stdout']["guestinfo.hsds.configparam_status"]

                    if configparam_status in 'enable':
                        err_address.remove(host)
                        # B168911 ノード再起動60分対策
                        # ノードが起動したら即排他取得(OS再起動待ちタイムアウトの60分)
                        # 起動が遅いノードがあった時、排他が解放されてしまうのを防止する
                        # エラーはハンドリングしない
                        mutex_address = []
                        mutex_address.append(host)
                        set_mutex(mutex_address, uuid, 3600, "Lock", fingerprint)
                else:
                    # ログは出力するが続行
                    logger.error('configraton_modify polling_config_status ' + host + ' http_status error.')
            else:
                # rest_access_on_fingerprint_certificateでEXceprionが発生した場合
                # ログは出力するが続行
                logger.error('configraton_modify polling_config_status ' + host + ' exception error.')
        
        if len(err_address) == 0:
            # 全てconfigparam_status:enable
            return 0, []

    return 1, err_address

def modify_configmodify(const_csv, const_beforecsv, fingerprint):
    # 編集後のユーザ指定管理ネットワークアドレスに対して構成一括変更APIを実行する
    configfile_util = ConfigfileUtil()
    ret , firstmaster, errmsg = configfile_util.get_first_master_node(const_csv)
    if not ret == 0:
        message = "Configuration file is invalid."
        action = "Please check the contents of configuration file."
        return 1, message, action

    common_util = CommonUtil()
    restCertUtil = RestCertificateUtil()
    base_url = "/ConfigurationManager/simple"
    path = "/v1/objects/storage/actions/modify-configuration/invoke"

    from requests_toolbelt import MultipartEncoder
    _csv_file_handle = open(const_csv, 'rb')
    _before_csv_file_handle = open(const_beforecsv, 'rb')
    payload = MultipartEncoder(
        fields = {
        'systemConfigurationFile': (const_csv, _csv_file_handle),
        'beforeSystemConfigurationFile': (const_beforecsv, _before_csv_file_handle),
        'mode': "Modify"
    }
    )

    response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('POST', fingerprint, firstmaster, base_url, path, body=payload, file=payload, connection_timeout=40, read_timeout=3600)

    # 結果に関わらずクローズ
    _csv_file_handle.close()
    _before_csv_file_handle.close()

    if response is not None:
        http_status = common_util.get_response_status(response)
        if http_status == 200:
            jsonres = json.loads(response)
            if type(jsonres['body']['status']) is str:
                status = json.loads(jsonres['body']['status'])
            else:
                status = jsonres['body']['status']

            if status != 0:
                logger.error('configraton_modify modify_configmodify ' + firstmaster + ' hsdsmodify status error.')
                logger.error('hsdsmodify output: ' + str(jsonres))
                if str(jsonres['body']['stderr']) is not None and not str(jsonres['body']['stderr']) == "":
                    message = "\n"
                    message = message + jsonres['body']['stderr']
                    message = message + "\nAn error occurred while running the command."
                else:
                    message = "An error occurred while running the command."
                action = "Take action according to the Troubleshooting Guide."
                return 1, message, action
        else:
            logger.error('configraton_modify modify_configmodify ' + firstmaster + ' hsdsmodify status error.')
            logger.error('hsdsmodify output: ' + str(json.loads(response)))
            message = "The request could not be executed."
            action = "Take action according to the Troubleshooting Guide."
            return 1, message, action
    else:
        # rest_access_on_fingerprint_certificateでEXceprionが発生した場合
        logger.error('configraton_modify modify_configmodify ' + firstmaster + ' exception error.')
        # 例外は例外のメッセージをそのまま出すので、return値2とする
        message_management = MessageManagement('')
        if message_id == 'exception':
            message_management.viewMessage(message_dict)
        else:
            message_management.viewMessageTxt(message_id, **message_dict)
        return 2, message_id, message_dict

    return 0, '', ''

def modify(uuid, after_address, before_address, const_csv, const_beforecsv, fingerprint):
    message = ''
    action = ''

    # 構成パラメータ設定モード確認
    logger.info("Stage 1/4 Checking nodes status is the configuration parameter setting mode.")
    click.echo("Stage 1/4 Checking nodes status is the configuration parameter setting mode.")
    ret = check_configparammode(before_address, fingerprint)
    if not ret == 0:
        message = "Some Storage nodes are not the configparamater setting mode."
        action = "Take action according to the Troubleshooting Guide."
        return "Error", message, action

    # 構成一括変更 構成パラメータ設定モード
    logger.info("Stage 2/4 Setting configuration parameters.")
    click.echo("Stage 2/4 Setting configuration parameters.")

    # 構成パラメータ生成
    configparam, errmsg = get_data_configparameter_info(const_beforecsv, const_csv)
    if len(configparam) <= 0:
        # 構成パラメータ不正
        message = "Configuration file is invalid."
        action = "Please check the contents of configuration file. " + errmsg
        return "Error", message, action

    # 排他取得
    ret, errlist = set_mutex(before_address, uuid, 180, "Lock", fingerprint)
    if ret == 1:
        message = "The specified operation could not be performed because another operation might be in progress."
        action = "Take action according to the Troubleshooting Guide."
        return "Error", message, action
    elif ret == 3:
        message = "The storage node could not be accessed. There is the storage node in an abnormal state or the specified operation could not be performed because another operation might be in progress. (IP address = " + ", ".join(map(str, errlist)) + ")"
        action = "Verify the network and the storage node status, and then retry the operation. If the same error occurs, take action according to the Troubleshooting Guide."
        return "Error", message, action
    # リトライの場合も考慮し、突き進める
    #elif not ret == 0:
    #    message = "The specified operation could not be performed."
    #    action = "Check the storage node status. If there is a problem, recover the storage node according to the Troubleshooting Guide. After the storage node status is recovered, try the operation again."
    #    return "Error", message, action

    # 構成パラメータ設定
    ret = set_configparameter(before_address, configparam, fingerprint)
    # リトライの場合も考慮し、突き進める
    #if not ret == 0:
    #    action = "Take action according to the Troubleshooting Guide."
    #    return "Error", message, action

    # config_status:enableポーリング
    logger.info("Stage 3/4 Checking that the configuration parameters have been set.")
    click.echo("Stage 3/4 Checking that the configuration parameters have been set.")
    click.echo("          This stage may wait up to 60 minutes.")
    ret, address = polling_config_status(after_address, fingerprint, uuid)
    if not ret == 0:
        message = "The status of the Storage node with IP address " + ", ".join(map(str, address)) + " is invalid."
        action = "Take action according to the Troubleshooting Guide."
        return "Error", message, action

    # 排他延長
    ret, errlist = set_mutex(after_address, uuid, 3600, "Lock", fingerprint)

    # 構成一括変更　構成一括変更モード
    logger.info("Stage 4/4 Changing the storage node configuration.")
    click.echo("Stage 4/4 Changing the storage node configuration.")
    ret, message, action = modify_configmodify(const_csv, const_beforecsv, fingerprint)
    if ret == 2:
        return "ShowError", message, action
    elif not ret == 0:
        return "Error", message, action

    return 'Success', message, action

def clear(uuid, after_address, before_address, fingerprint):
    # 終了処理がある場合はここに記載する

    # 排他解放
    # どこで終わったか不明なので新旧アドレスにすべて実施
    # 解放の場合はエラーハンドリングはしない
    all_address = []
    all_address.extend(after_address)
    all_address.extend(before_address)
    set_mutex(all_address, uuid, 0, "Unlock", fingerprint)
    return

def main(dry_check, const_csv, const_beforecsv):
    status = ''
    message = ''
    action = ''

    # csvからアドレスを取得
    after_address = get_control_address(const_csv)
    before_address = get_control_address(const_beforecsv)

    # dry-check
    if dry_check == 'true':
        check_sys_file_is_valid(const_csv, const_beforecsv)
        return

    # UUID生成
    modify_uuid = str(uuid.uuid4())

    # fingerprint取得
    cert = None
    fingerprint = None
    config = Configuration()
    if config.verify_ssl is True:
        # サーバ証明書検証あり
        parsed_url = urlparse(config.host)
        host = re.sub(r':443', "", parsed_url.netloc)

        restCertUtil = RestCertificateUtil()
        cert, fingerprint, errlist = restCertUtil.get_server_certificate(host, 443)
        if cert is None or fingerprint is None:
            # エラー発生
            # message_id = str(errlist[0][0])
            # message_dict = errlist[0][1]
            # message_management = MessageManagement('')
            # message_management.viewMessageTxt(message_id, **message_dict)
            click.echo("Message: {}".format(errlist[0][0]))
            click.echo("Cause: {}".format(errlist[0][1]))
            click.echo("Solution: {}".format(errlist[0][2]))
            exit(1)

    # 構成一括変更メイン処理
    status, message, action = modify(modify_uuid, after_address, before_address, const_csv, const_beforecsv, fingerprint)

    # 応答が返ってきた場合は結果に関わらず排他解放を必ず実施する
    clear(modify_uuid, after_address, before_address, fingerprint)

    # エラー処理
    if status == "Error":
        show_errmsg(status, message, action, config_file=const_csv, before_config_file=const_beforecsv)
        logger.error('configraton_modify Failed.')
        exit(1)
    elif status == "ShowError":
        # 表示済みなのでそのまま終了する
        logger.error('configraton_modify Failed.')
        exit(1)

    # 正常処理
    logger.error('The configuration modify was successful.')
    click.echo('Status: ' + status)
    click.echo('Message: The configuration modify was successful.')
    return

@click.command(options_metavar='<options>')
@click.option('--dry_check','_dry_check',metavar='<bool>',help='Check the changed part of SystemConfigurationFile.csv.')
@click.option('--new_system_configuration_file','_new_system_configuration_file',type=str,metavar='<str>',help='Specifies the SystemConfigurationFile.csv new edited.',required=True)
@click.option('--current_system_configuration_file','_current_system_configuration_file',type=str,metavar='<str>',help='Specifies the current SystemConfigurationFile.csv.',required=True)
def configuration_modify(_dry_check, _new_system_configuration_file, _current_system_configuration_file):
    """
    Modify configuration settings.
    """
    try:
        config = Configuration()
        common_util = CommonUtil()
        common_util.view_error()

        # 認証パラメータのチェック チケット認証のみサポート
        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('', '', 'true')
        auth_parameter_util.check_auth_parameter('', '', 'true')

        common_util.view_error()

        sub_command_log_txt = "Sub-command parameters : " + " "
        cli_sub_command = "configuration_modify"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cli_sub_command)
            common_util.view_error()

        # サブコマンドパラメータのログ出力
        if _dry_check is not None:
            sub_command_log_txt += "--dry_check " + str(_dry_check) + " "

        if _new_system_configuration_file is not None:
            sub_command_log_txt += "--new_system_configuration_file " + str(_new_system_configuration_file) + " "

        if _current_system_configuration_file is not None:
            sub_command_log_txt += "--current_system_configuration_file "+ str(_current_system_configuration_file) + " "

        logger.info(sub_command_log_txt)

        # 入力パラメータの補正
        if _dry_check is not None:
            if isinstance(_dry_check, str):
                _dry_check = SeparateArgs.check_backslash(_dry_check)
                _dry_check = _dry_check.encode("utf-8").decode("unicode-escape")
                if (_dry_check != 'true' and _dry_check != 'false'):
                    raise ValueError("The dry_check option that not boolean was specified.")

        # パラメータ必須チェック
        # ファイルの存在有無は以降の処理で行う
        if _new_system_configuration_file is None:
            raise ValueError("--new_system_configuration_file is required.")

        if _current_system_configuration_file is None:
            raise ValueError("--current_system_configuration_file is required.")

        # パスワード入力
        common_util.input_password()

        # 構成一括変更メイン処理
        main(_dry_check, _new_system_configuration_file, _current_system_configuration_file)
        exit(0)

    except OSError as e:  # OSError
        mssageManagement = MessageManagement('')
        # CLIを実行したディスクの空き容量が不足している
        if e.errno == errno.ENOSPC:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19214'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # CLIを実行したメンテナンスノードの空きメモリーが不足
        elif e.errno == errno.ENOMEM:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19029'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # システム全体でオープンされているファイルが多過ぎる
        elif e.errno == errno.ENFILE:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19034'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # その他のOSError
        else:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19060'
            str_err = ','.join(map(str, e.args))
            config.messageDict = {'exception': str_err}
            common_util = CommonUtil()
            common_util.view_error()

    except ValueError as e:
        if (traceback):
            logger.error(traceback.format_exc())
        logger.error(e)
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: {}".format(e))
        click.echo("Cause: Appropriate option is not specified.")
        click.echo("Solution: Specify the option value correctly.")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        config = Configuration()
        config.is_progress_shown = False
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    exit(1)

def commands():
    commands = {}
    commands['configuration_modify'] = configuration_modify
    return commands
