"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""


import os
import re
import logging as loggingLib

logger = loggingLib.getLogger(__name__)


class ConfigfileUtil(object):
    def get_control_address_from_csv(self, conf_csv_file):
        rtrn = 0 
        control_addr = []
        errmsg = ''
        try:
            if(not os.path.exists(conf_csv_file)):
                # ファイルが存在しない
                rtrn = 1
                errmsg = "The specified file does not exist."
                return rtrn, control_addr, errmsg

            # ファイル読み込み
            f = open(conf_csv_file, "r")
            line = f.readline()
            nodes_flg = False
            NodsValue = []
            while line:
                # Nodesセクション - 次のセクションまでの値を取得する
                wkstr = line.rstrip()
                if re.match("^\[[a-zA-Z0-9]+\]", wkstr):
                    blockname = wkstr.strip("[],")
                    if blockname == "Nodes":
                        nodes_flg = True
                    else:
                        if nodes_flg:
                            nodes_flg = False
                if nodes_flg:
                    NodsValue.append(wkstr)
                line = f.readline()
            f.close()

            # ControlNWIPv4列の取得
            colm_idx = 0
            control_addr_colm = "ControlNWIPv4"
            Nodscolm = NodsValue[1].split(',')
            for controlNWIPv4 in Nodscolm:
                if controlNWIPv4 == control_addr_colm:
                    break
                colm_idx += 1

            for row in NodsValue[2:]:
                control_addr.append(row.split(',')[colm_idx])

        except UnicodeDecodeError:
            rtrn = 2
            errmsg = "The encoding method of the configuration file is not UTF-8."
            # 構成ファイル(csv)のエンコーディングがUTF-8でない

        except Exception:
            rtrn = 3
            errmsg = "The configuration file is invalid."
            # 構成ファイル(csv)読み込みで例外発生

        return rtrn, control_addr, errmsg

    # AWS版 VMConfigurationFile.ymlから管理ポートIPアドレスを取得する
    def get_control_address_from_yaml(self, conf_vm_file):
        rtrn = 0
        control_addr = []
        errmsg = ''
        try:
            if(not os.path.exists(conf_vm_file)):
                # ファイルが存在しない
                rtrn = 1
                errmsg = "The specified file does not exist."
                return rtrn, control_addr, errmsg

            # yamlライブラリはpython標準ではないため使用しない
            # 作成されたストレージノードの数を確認
            created_storage_node_count = 0
            with open(conf_vm_file, "r") as f:
                lines = f.readlines()
                for line in lines:
                    if "StorageNodeCreate" in line and "Equals" in line and "[ON, ON]" in line:
                        created_storage_node_count += 1
            if created_storage_node_count == 0:
                logger.error("Storage node does not exitst.")
                raise Exception()

            # IPアドレスを確認
            # ヒットする例↓(m.group(1) = 10.160.165.5)
            # ControlNetworkIpv4Address01:
            # Type: String
            # Default: 10.160.165.5
            pattern = re.compile(r'ControlNetworkIpv4Address(\d{1,3}|TB):\s+Type:\s*String\s+Default:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', re.MULTILINE | re.DOTALL)
            match_ip_address_count = 0
            with open(conf_vm_file, "r") as f:
                data = f.read()
                for m in pattern.finditer(data):
                    control_addr.append(m.group(2))
                    match_ip_address_count += 1
                    if match_ip_address_count == created_storage_node_count:
                        # 作成されたストレージノード数よりも多くIPアドレスが入力されていても無視する
                        break
                if match_ip_address_count < created_storage_node_count:
                    logger.error("Not match ip address. matched_ipaddress = {}. created_storagenode = {}.".format(match_ip_address_count, created_storage_node_count))
                    raise Exception()
        except UnicodeDecodeError:
            rtrn = 2
            errmsg = "The encoding method of the configuration file is not UTF-8."
            # 構成ファイル(csv)のエンコーディングがUTF-8でない

        except Exception:
            rtrn = 3
            errmsg = "The configuration file is invalid."
            # 構成ファイル(csv)読み込みで例外発生

        return rtrn, control_addr, errmsg

    def get_first_master_node(self, conf_csv_file):
        rtrn = 0 
        first_master_ipaddr = ''
        errmsg = ''
        try:
            if(not os.path.exists(conf_csv_file)):
                # ファイルが存在しない
                rtrn = 1
                errmsg = "The specified file does not exist."
                return rtrn, first_master_ipaddr, errmsg

            # ファイル読み込み
            f = open(conf_csv_file, "r")
            line = f.readline()
            nodes_flg = False
            NodsValue = []
            while line:
                # Nodesセクション - 次のセクションまでの値を取得する
                wkstr = line.rstrip()
                if re.match("^\[[a-zA-Z0-9]+\]", wkstr):
                    blockname = wkstr.strip("[],")
                    if blockname == "Nodes":
                        nodes_flg = True
                    else:
                        if nodes_flg:
                            nodes_flg = False
                if nodes_flg:
                    NodsValue.append(wkstr)
                line = f.readline()
            f.close()

            # ControlNWIPv4列と、clustermasterの取得
            colm_idx = 0
            master_idx = 0
            control_addr_colm = "ControlNWIPv4"
            cluster_role_colm = "ClusterMasterRole"
            Nodscolm = NodsValue[1].split(',')
            for colm in Nodscolm:
                if colm == cluster_role_colm:
                    # clustermasterの行目を取得
                    master_idx = colm_idx
                if colm == control_addr_colm:
                    break
                colm_idx += 1

            for row in NodsValue[2:]:
                if row.split(',')[master_idx] == 'clustermaster':
                    first_master_ipaddr = row.split(',')[colm_idx]
                    break

        except UnicodeDecodeError:
            rtrn = 2
            errmsg = "The encoding method of the configuration file is not UTF-8."
            # 構成ファイル(csv)のエンコーディングがUTF-8でない

        except Exception:
            rtrn = 3
            errmsg = "The configuration file is invalid."
            # 構成ファイル(csv)読み込みで例外発生

        return rtrn, first_master_ipaddr, errmsg