# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--name','_name',type=str,metavar='<str>',help='Name of a virtual private storage (VPS).',required=True)
@click.option('--upper_limit_for_number_of_user_groups','_upper_limit_for_number_of_user_groups',type=int,metavar='<int>',help='Upper limit for the number of user groups of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_users','_upper_limit_for_number_of_users',type=int,metavar='<int>',help='Upper limit for the number of users of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_sessions','_upper_limit_for_number_of_sessions',type=int,metavar='<int>',help='Upper limit for the number of sessions of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_servers','_upper_limit_for_number_of_servers',type=int,metavar='<int>',help='Upper limit for the number of compute nodes of a virtual private storage (VPS).',required=True)
@click.option('--volume_settings','_volume_settings',metavar='<str>', multiple=True,help='Volume setting of a virtual private storage (VPS). pool_id: ID of a storage pool used for a virtual private storage (VPS). upper_limit_for_number_of_volumes: Upper limit for the number of volumes of a virtual private storage (VPS). upper_limit_for_capacity_of_volumes: Upper limit for the total volume capacity (MiB) of a virtual private storage (VPS). upper_limit_for_capacity_of_single_volume: Upper limit for the single volume capacity (MiB) of a virtual private storage (VPS). upper_limit_for_iops_of_volume: Upper limit for the volume performance (IOPS) of a virtual private storage (VPS). upper_limit_for_transfer_rate_of_volume: Upper limit for the volume performance (MiB/sec) of a virtual private storage (VPS). upper_alert_allowable_time_of_volume: Alert threshold (second) for the upper limit of volume performance of a virtual private storage (VPS). saving_setting_of_volume: Sets the Data reduction function of volumes to be created in a virtual private storage (VPS).',required=True)
def vps_create(_name,_upper_limit_for_number_of_user_groups,_upper_limit_for_number_of_users,_upper_limit_for_number_of_sessions,_upper_limit_for_number_of_servers,_volume_settings,):
    """
    Creates a virtual private storage (VPS). 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "vps_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "




        if _upper_limit_for_number_of_user_groups is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_user_groups " + str(_upper_limit_for_number_of_user_groups) + " "




        if _upper_limit_for_number_of_users is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_users " + str(_upper_limit_for_number_of_users) + " "




        if _upper_limit_for_number_of_sessions is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_sessions " + str(_upper_limit_for_number_of_sessions) + " "




        if _upper_limit_for_number_of_servers is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_servers " + str(_upper_limit_for_number_of_servers) + " "



        if len(_volume_settings) == 0:
            _volume_settings = None

        if _volume_settings is not None:
            subCommandLogtxt += "--volume_settings " + str(_volume_settings) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "vps_create"



















        if _name is not None:
            if(isinstance(_name, str)):
                _name = SeparateArgs.check_backslash(_name)
                _name = _name.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_user_groups is not None:
            if(isinstance(_upper_limit_for_number_of_user_groups, str)):
                _upper_limit_for_number_of_user_groups = SeparateArgs.check_backslash(_upper_limit_for_number_of_user_groups)
                _upper_limit_for_number_of_user_groups = _upper_limit_for_number_of_user_groups.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_users is not None:
            if(isinstance(_upper_limit_for_number_of_users, str)):
                _upper_limit_for_number_of_users = SeparateArgs.check_backslash(_upper_limit_for_number_of_users)
                _upper_limit_for_number_of_users = _upper_limit_for_number_of_users.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_sessions is not None:
            if(isinstance(_upper_limit_for_number_of_sessions, str)):
                _upper_limit_for_number_of_sessions = SeparateArgs.check_backslash(_upper_limit_for_number_of_sessions)
                _upper_limit_for_number_of_sessions = _upper_limit_for_number_of_sessions.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_servers is not None:
            if(isinstance(_upper_limit_for_number_of_servers, str)):
                _upper_limit_for_number_of_servers = SeparateArgs.check_backslash(_upper_limit_for_number_of_servers)
                _upper_limit_for_number_of_servers = _upper_limit_for_number_of_servers.encode("utf-8").decode("unicode-escape")
        if _volume_settings is not None:
            if(isinstance(_volume_settings, str)):
                _volume_settings = SeparateArgs.check_backslash(_volume_settings)
                _volume_settings = _volume_settings.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateVirtualPrivateStorageParam import CreateVirtualPrivateStorageParam
        _create_virtual_private_storage = CreateVirtualPrivateStorageParam()
        _create_virtual_private_storage.name = _name
        _create_virtual_private_storage.upper_limit_for_number_of_user_groups = _upper_limit_for_number_of_user_groups
        _create_virtual_private_storage.upper_limit_for_number_of_users = _upper_limit_for_number_of_users
        _create_virtual_private_storage.upper_limit_for_number_of_sessions = _upper_limit_for_number_of_sessions
        _create_virtual_private_storage.upper_limit_for_number_of_servers = _upper_limit_for_number_of_servers
        _create_virtual_private_storage.volume_settings = _volume_settings
        param_arr = []
        param_arr.append('pool_id')
        param_arr.append('upper_limit_for_number_of_volumes')
        param_arr.append('upper_limit_for_capacity_of_volumes')
        param_arr.append('upper_limit_for_capacity_of_single_volume')
        param_arr.append('upper_limit_for_iops_of_volume')
        param_arr.append('upper_limit_for_transfer_rate_of_volume')
        param_arr.append('upper_alert_allowable_time_of_volume')
        param_arr.append('saving_setting_of_volume')

        from com.hitachi.sophia.rest_client.autogen.models.VirtualPrivateStorageDefaultVolumeSettings import VirtualPrivateStorageDefaultVolumeSettings
        arr = []
        param_name = "volume_settings"

        if _volume_settings is not None:
            for __value in _volume_settings:
                _virtual_private_storage_default_volume_settings = VirtualPrivateStorageDefaultVolumeSettings()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'pool_id',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'pool_id',param_name)

                #UUID バリデーション
                if tempval is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', tempval):
                    raise ValueError("Invalid value for `pool_id`, the format of UUID is invalid.")

                _virtual_private_storage_default_volume_settings.pool_id = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'upper_limit_for_number_of_volumes',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'upper_limit_for_number_of_volumes',param_name)


                _virtual_private_storage_default_volume_settings.upper_limit_for_number_of_volumes = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'upper_limit_for_capacity_of_volumes',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'upper_limit_for_capacity_of_volumes',param_name)


                _virtual_private_storage_default_volume_settings.upper_limit_for_capacity_of_volumes = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'upper_limit_for_capacity_of_single_volume',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'upper_limit_for_capacity_of_single_volume',param_name)


                _virtual_private_storage_default_volume_settings.upper_limit_for_capacity_of_single_volume = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'upper_limit_for_iops_of_volume',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'upper_limit_for_iops_of_volume',param_name)


                _virtual_private_storage_default_volume_settings.upper_limit_for_iops_of_volume = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'upper_limit_for_transfer_rate_of_volume',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'upper_limit_for_transfer_rate_of_volume',param_name)


                _virtual_private_storage_default_volume_settings.upper_limit_for_transfer_rate_of_volume = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'upper_alert_allowable_time_of_volume',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'upper_alert_allowable_time_of_volume',param_name)


                _virtual_private_storage_default_volume_settings.upper_alert_allowable_time_of_volume = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'saving_setting_of_volume',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'saving_setting_of_volume',param_name)


                _virtual_private_storage_default_volume_settings.saving_setting_of_volume = tempval
                arr.append(_virtual_private_storage_default_volume_settings)
            _create_virtual_private_storage.volume_settings = arr

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.create_virtual_private_storage(create_virtual_private_storage = _create_virtual_private_storage, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='ID of a virtual private storage (VPS). ')
@click.option('--id_name','_id_name',metavar='<str>',help='Name of a virtual private storage (VPS).')
def vps_delete(_id,_id_name,):
    """
    Deletes a virtual private storage (VPS). 
    """
    def get_uuid_from_virtual_private_storage_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "vps_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        
        


        
        
        
        
        
        #cliSubCommand = "vps_delete"

        if  _id is not None and not re.search('^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for parameter `id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `id` when calling `delete_virtual_private_storage`, must conform to the pattern `/^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _id_name is not None and not re.search('^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `delete_virtual_private_storage`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # virtual_private_storage_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_virtual_private_storage_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.delete_virtual_private_storage(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='ID of a virtual private storage (VPS). ')
@click.option('--id_name','_id_name',metavar='<str>',help='Name of a virtual private storage (VPS).')
@click.option('--name','_name',type=str,metavar='<str>',help='The new name of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_user_groups','_upper_limit_for_number_of_user_groups',type=int,metavar='<int>',help='Upper limit for the number of user groups of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_users','_upper_limit_for_number_of_users',type=int,metavar='<int>',help='Upper limit for the number of users of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_sessions','_upper_limit_for_number_of_sessions',type=int,metavar='<int>',help='Upper limit for the number of sessions of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_servers','_upper_limit_for_number_of_servers',type=int,metavar='<int>',help='Upper limit for the number of compute nodes of a virtual private storage (VPS).')
@click.option('--upper_limit_for_number_of_volumes','_upper_limit_for_number_of_volumes',type=int,metavar='<int>',help='Upper limit for the number of volumes of a virtual private storage (VPS).')
@click.option('--upper_limit_for_capacity_of_volumes','_upper_limit_for_capacity_of_volumes',type=int,metavar='<int>',help='Upper limit for the total volume capacity (MiB) of a virtual private storage (VPS).')
@click.option('--upper_limit_for_capacity_of_single_volume','_upper_limit_for_capacity_of_single_volume',type=int,metavar='<int>',help='Upper limit for the single volume capacity (MiB) of a virtual private storage (VPS).')
@click.option('--upper_limit_for_iops_of_volume','_upper_limit_for_iops_of_volume',type=int,metavar='<int>',help='Upper limit for the volume performance (IOPS) of a virtual private storage (VPS).')
@click.option('--upper_limit_for_transfer_rate_of_volume','_upper_limit_for_transfer_rate_of_volume',type=int,metavar='<int>',help='Upper limit for the volume performance (MiB/sec) of a virtual private storage (VPS).')
@click.option('--upper_alert_allowable_time_of_volume','_upper_alert_allowable_time_of_volume',type=int,metavar='<int>',help='Alert threshold (second) for the upper limit of volume performance of a virtual private storage (VPS).')
@click.option('--saving_setting_of_volume','_saving_setting_of_volume',type=str,metavar='<str>',help='Sets the Data reduction function of volumes to be created in a virtual private storage (VPS).')
def vps_set(_id,_id_name,_name,_upper_limit_for_number_of_user_groups,_upper_limit_for_number_of_users,_upper_limit_for_number_of_sessions,_upper_limit_for_number_of_servers,_upper_limit_for_number_of_volumes,_upper_limit_for_capacity_of_volumes,_upper_limit_for_capacity_of_single_volume,_upper_limit_for_iops_of_volume,_upper_limit_for_transfer_rate_of_volume,_upper_alert_allowable_time_of_volume,_saving_setting_of_volume,):
    """
    Edits virtual private storage (VPS) settings. 
    """
    def get_uuid_from_virtual_private_storage_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "vps_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "




        if _upper_limit_for_number_of_user_groups is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_user_groups " + str(_upper_limit_for_number_of_user_groups) + " "




        if _upper_limit_for_number_of_users is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_users " + str(_upper_limit_for_number_of_users) + " "




        if _upper_limit_for_number_of_sessions is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_sessions " + str(_upper_limit_for_number_of_sessions) + " "




        if _upper_limit_for_number_of_servers is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_servers " + str(_upper_limit_for_number_of_servers) + " "




        if _upper_limit_for_number_of_volumes is not None:
            subCommandLogtxt += "--upper_limit_for_number_of_volumes " + str(_upper_limit_for_number_of_volumes) + " "




        if _upper_limit_for_capacity_of_volumes is not None:
            subCommandLogtxt += "--upper_limit_for_capacity_of_volumes " + str(_upper_limit_for_capacity_of_volumes) + " "




        if _upper_limit_for_capacity_of_single_volume is not None:
            subCommandLogtxt += "--upper_limit_for_capacity_of_single_volume " + str(_upper_limit_for_capacity_of_single_volume) + " "




        if _upper_limit_for_iops_of_volume is not None:
            subCommandLogtxt += "--upper_limit_for_iops_of_volume " + str(_upper_limit_for_iops_of_volume) + " "




        if _upper_limit_for_transfer_rate_of_volume is not None:
            subCommandLogtxt += "--upper_limit_for_transfer_rate_of_volume " + str(_upper_limit_for_transfer_rate_of_volume) + " "




        if _upper_alert_allowable_time_of_volume is not None:
            subCommandLogtxt += "--upper_alert_allowable_time_of_volume " + str(_upper_alert_allowable_time_of_volume) + " "




        if _saving_setting_of_volume is not None:
            subCommandLogtxt += "--saving_setting_of_volume " + str(_saving_setting_of_volume) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "vps_set"

        if  _id is not None and not re.search('^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for parameter `id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `id` when calling `update_vps`, must conform to the pattern `/^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _id_name is not None and not re.search('^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `update_vps`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")




















        if _name is not None:
            if(isinstance(_name, str)):
                _name = SeparateArgs.check_backslash(_name)
                _name = _name.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_user_groups is not None:
            if(isinstance(_upper_limit_for_number_of_user_groups, str)):
                _upper_limit_for_number_of_user_groups = SeparateArgs.check_backslash(_upper_limit_for_number_of_user_groups)
                _upper_limit_for_number_of_user_groups = _upper_limit_for_number_of_user_groups.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_users is not None:
            if(isinstance(_upper_limit_for_number_of_users, str)):
                _upper_limit_for_number_of_users = SeparateArgs.check_backslash(_upper_limit_for_number_of_users)
                _upper_limit_for_number_of_users = _upper_limit_for_number_of_users.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_sessions is not None:
            if(isinstance(_upper_limit_for_number_of_sessions, str)):
                _upper_limit_for_number_of_sessions = SeparateArgs.check_backslash(_upper_limit_for_number_of_sessions)
                _upper_limit_for_number_of_sessions = _upper_limit_for_number_of_sessions.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_servers is not None:
            if(isinstance(_upper_limit_for_number_of_servers, str)):
                _upper_limit_for_number_of_servers = SeparateArgs.check_backslash(_upper_limit_for_number_of_servers)
                _upper_limit_for_number_of_servers = _upper_limit_for_number_of_servers.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_number_of_volumes is not None:
            if(isinstance(_upper_limit_for_number_of_volumes, str)):
                _upper_limit_for_number_of_volumes = SeparateArgs.check_backslash(_upper_limit_for_number_of_volumes)
                _upper_limit_for_number_of_volumes = _upper_limit_for_number_of_volumes.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_capacity_of_volumes is not None:
            if(isinstance(_upper_limit_for_capacity_of_volumes, str)):
                _upper_limit_for_capacity_of_volumes = SeparateArgs.check_backslash(_upper_limit_for_capacity_of_volumes)
                _upper_limit_for_capacity_of_volumes = _upper_limit_for_capacity_of_volumes.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_capacity_of_single_volume is not None:
            if(isinstance(_upper_limit_for_capacity_of_single_volume, str)):
                _upper_limit_for_capacity_of_single_volume = SeparateArgs.check_backslash(_upper_limit_for_capacity_of_single_volume)
                _upper_limit_for_capacity_of_single_volume = _upper_limit_for_capacity_of_single_volume.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_iops_of_volume is not None:
            if(isinstance(_upper_limit_for_iops_of_volume, str)):
                _upper_limit_for_iops_of_volume = SeparateArgs.check_backslash(_upper_limit_for_iops_of_volume)
                _upper_limit_for_iops_of_volume = _upper_limit_for_iops_of_volume.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_transfer_rate_of_volume is not None:
            if(isinstance(_upper_limit_for_transfer_rate_of_volume, str)):
                _upper_limit_for_transfer_rate_of_volume = SeparateArgs.check_backslash(_upper_limit_for_transfer_rate_of_volume)
                _upper_limit_for_transfer_rate_of_volume = _upper_limit_for_transfer_rate_of_volume.encode("utf-8").decode("unicode-escape")
        if _upper_alert_allowable_time_of_volume is not None:
            if(isinstance(_upper_alert_allowable_time_of_volume, str)):
                _upper_alert_allowable_time_of_volume = SeparateArgs.check_backslash(_upper_alert_allowable_time_of_volume)
                _upper_alert_allowable_time_of_volume = _upper_alert_allowable_time_of_volume.encode("utf-8").decode("unicode-escape")
        if _saving_setting_of_volume is not None:
            if(isinstance(_saving_setting_of_volume, str)):
                _saving_setting_of_volume = SeparateArgs.check_backslash(_saving_setting_of_volume)
                _saving_setting_of_volume = _saving_setting_of_volume.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchVirtualPrivateStorageParam import PatchVirtualPrivateStorageParam
        _edit_virtual_private_storage = PatchVirtualPrivateStorageParam()
        _edit_virtual_private_storage.name = _name
        _edit_virtual_private_storage.upper_limit_for_number_of_user_groups = _upper_limit_for_number_of_user_groups
        _edit_virtual_private_storage.upper_limit_for_number_of_users = _upper_limit_for_number_of_users
        _edit_virtual_private_storage.upper_limit_for_number_of_sessions = _upper_limit_for_number_of_sessions
        _edit_virtual_private_storage.upper_limit_for_number_of_servers = _upper_limit_for_number_of_servers
        _edit_virtual_private_storage.upper_limit_for_number_of_volumes = _upper_limit_for_number_of_volumes
        _edit_virtual_private_storage.upper_limit_for_capacity_of_volumes = _upper_limit_for_capacity_of_volumes
        _edit_virtual_private_storage.upper_limit_for_capacity_of_single_volume = _upper_limit_for_capacity_of_single_volume
        _edit_virtual_private_storage.upper_limit_for_iops_of_volume = _upper_limit_for_iops_of_volume
        _edit_virtual_private_storage.upper_limit_for_transfer_rate_of_volume = _upper_limit_for_transfer_rate_of_volume
        _edit_virtual_private_storage.upper_alert_allowable_time_of_volume = _upper_alert_allowable_time_of_volume
        _edit_virtual_private_storage.saving_setting_of_volume = _saving_setting_of_volume

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # virtual_private_storage_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_virtual_private_storage_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.update_vps(_id, edit_virtual_private_storage = _edit_virtual_private_storage, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def vps_list():
    """
    Obtains a list of virtual private storage (VPS) information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "vps_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        
        


        
        
        
        
        
        #cliSubCommand = "vps_list"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VirtualPrivateStorageList import VirtualPrivateStorageList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.virtual_private_storage_list(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='ID of a virtual private storage (VPS). ')
@click.option('--id_name','_id_name',metavar='<str>',help='Name of a virtual private storage (VPS).')
def vps_show(_id,_id_name,):
    """
    Obtains virtual private storage (VPS) information. 
    """
    def get_uuid_from_virtual_private_storage_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "vps_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        
        


        
        
        
        
        
        #cliSubCommand = "vps_show"

        if  _id is not None and not re.search('^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for parameter `id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `id` when calling `virtual_private_storage_show`, must conform to the pattern `/^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _id_name is not None and not re.search('^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `virtual_private_storage_show`, must conform to the pattern `^(?!system$)[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VirtualPrivateStorage import VirtualPrivateStorage

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # virtual_private_storage_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_virtual_private_storage_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.virtual_private_storage_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['vps_create'] = vps_create
    commands['vps_delete'] = vps_delete
    commands['vps_set'] = vps_set
    commands['vps_list'] = vps_list
    commands['vps_show'] = vps_show
    return commands

