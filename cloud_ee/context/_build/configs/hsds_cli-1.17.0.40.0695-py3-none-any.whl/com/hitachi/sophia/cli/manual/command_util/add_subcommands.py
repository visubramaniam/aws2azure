"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
from com.hitachi.sophia.cli.autogen import sub_commands
from com.hitachi.sophia.cli.manual import sub_commands as sub_commands_manual

def commands():
    commands = {}
    commands.update(sub_commands.commands())
    commands.update(sub_commands_manual.commands())

    return commands