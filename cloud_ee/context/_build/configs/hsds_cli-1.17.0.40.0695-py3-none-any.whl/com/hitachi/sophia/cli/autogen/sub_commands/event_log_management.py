# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--target_server','_target_server',type=int,metavar='<int>',help='ID of the target SMTP server. ',required=True)
def smtp_server_root_certificate_download(_target_server,):
    """
    Obtains the root certificate of the SMTP server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "smtp_server_root_certificate_download"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _target_server is not None:
            subCommandLogtxt += "--target_server " + str(_target_server) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import EventLogManagement as EventLogManagementApi
        api = EventLogManagementApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "smtp_server_root_certificate_download"

        if _target_server is not None and _target_server > 1:
            raise ValueError("Invalid value for parameter `target_server` when calling `" + cliSubCommand + "`, must be equal to `1`")
#           raise ValueError("Invalid value for parameter `target_server` when calling `download_smtp_server_root_certificate`, must be a value less than or equal to `1`")
        if _target_server is not None and _target_server < 1:
            raise ValueError("Invalid value for parameter `target_server` when calling `" + cliSubCommand + "`, must be equal to  `1`")
#           raise ValueError("Invalid value for parameter `target_server` when calling `download_smtp_server_root_certificate`, must be a value greater than or equal to `1`")

















                

    
        
        
        
        
        try:

            defaultFileName = "download-smtp-server-root-certificate.crt"
        
            fileutil = FileUtil(defaultFileName)

            dirname, filename = fileutil.locate_download_file(defaultFileName)
            download_path = os.path.join(dirname, filename)
        
            #ファイルが存在するか
            if (os.path.isfile(os.path.join(dirname, filename))):
                # 既にファイルが存在している
                mssageManagement = MessageManagement('')
                messageId = '19006'
                messageDict = {'filePath': os.path.abspath(defaultFileName)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)


            if not ('Authorization' in config.api_key):
                warningbanner = WarningBanner()
                warningbanner.sub_command_name = cliSubCommand
                login_message_response = warningbanner.get_login_message()
                login_message = warningbanner.view_warning_banner(login_message_response)

                commonutil.view_error()

                #空文字,Nullの場合はログインメッセージを表示しない
                if(login_message):
                    click.echo(login_message, err=True)

            commonutil.input_password()

            #ファイルが存在するか(2回目)
            if (os.path.isfile(os.path.join(dirname, filename))):
                # 既にファイルが存在している
                mssageManagement = MessageManagement('')
                messageId = '19006'
                messageDict = {'filePath': os.path.abspath(defaultFileName)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)



            # ストレージクラスターとCLIのバージョンチェック
            versioncheck = VersionCheck()
            api_version_response = versioncheck.get_api_version()
            versioncheck.version_check(api_version_response)

            response = api.download_smtp_server_root_certificate(_target_server, callback=None, debug="false" ,_preload_content=False)

        # print(response)
            if(response):
            
                cli_response = collections.OrderedDict()
                cli_response['httpStatusCode'] = response.status
            
                if(response.status!=200):
                    if response.data:
                        cli_response['body'] = ApiClient().deserialize_json_to_body_or_exit(response, _preload_content=False)
                    
                    data = json.dumps(cli_response, indent=4, separators=(',', ': '))
                    output_util = OutputUtil()
                    output_util.echo_normal(data, config.format, cliSubCommand)

                    #click.echo(data)
                    exit(commonutil.get_cli_exit_code_for_api_execution(response.status))

        except Exception as e:
            if (traceback):
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

        saveFile = None
        try:
            with open(download_path, 'wb') as saveFile:
                saveFile.write(response.data)
            if config.format == 'text':
                click.echo('Message: ' + 'Download completed.')
                click.echo('Output File Path: ' + os.path.abspath(defaultFileName))
            else:
                cli_response['message'] = 'Download completed.'
                cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
                cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
                click.echo(cli_response)

            #cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
            cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
            #click.echo(cli_response)

        except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
            messageId = '19007'
            messageDict = {
                'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                    defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except FileExistsError as e:  # 既にファイルが存在している
            messageId = '19007'
            messageDict = {'exception': 'A file has already existed. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except OSError as e:  # OSError かつ errno ENOSPCの場合
            if e.errno == errno.ENOSPC:
                messageId = '19007'
                messageDict = {
                    'exception': 'No more space for writing is available on the device. (File path = ' + os.path.abspath(
                        defaultFileName) + ')'}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

            else:
                messageId = '19007'
                strErr = ','.join(map(str, e.args))
                messageDict = {'exception': strErr}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

        except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
            messageId = '19007'
            messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except Exception as e:
            #ファイルの保存に失敗
            messageId = '19007'
            strErr = ' '.join(map(str, e.args))
            messageDict = {'exception': strErr}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)

            exit(1)
        finally:
            if (saveFile):
                saveFile.close()

        #print('Download external auth server crl file Success')
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--severity','_severity',metavar='<str>',help='The severity of the event. Only events with the specified severity are extracted.  Either severity or severity_ge can be specified. If you specify both parameters at the same time, HTTP status code 400 (Bad Request) is returned. ')
@click.option('--severity_ge','_severity_ge',metavar='<str>',help='The severity of the event. Events with the specified severity or higher are extracted.  (Severity: Info < Warning < Error < Critical < Unknown)  Unknown events are output regardless of the selected severity level.  Either severity or severity_ge can be specified. If you specify both parameters at the same time, HTTP status code 400 (Bad Request) is returned. ')
@click.option('--start_time','_start_time',metavar='<datetime>',help='The start date and time of the event log you obtain. The data of the specified time is included in the obtained event log. ')
@click.option('--end_time','_end_time',metavar='<datetime>',help='The end date and time of the event log you obtain. The data of the specified time is included in the obtained event log. ')
@click.option('--max_events','_max_events',type=int,metavar='<int>',help='Maximum number of event log records that can be obtained. ')
def event_log_list(_severity,_severity_ge,_start_time,_end_time,_max_events,):
    """
    Obtains a list of event logs. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "event_log_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _severity is not None:
            subCommandLogtxt += "--severity " + str(_severity) + " "




        if _severity_ge is not None:
            subCommandLogtxt += "--severity_ge " + str(_severity_ge) + " "




        if _start_time is not None:
            subCommandLogtxt += "--start_time " + str(_start_time) + " "




        if _end_time is not None:
            subCommandLogtxt += "--end_time " + str(_end_time) + " "




        if _max_events is not None:
            subCommandLogtxt += "--max_events " + str(_max_events) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import EventLogManagement as EventLogManagementApi
        api = EventLogManagementApi(ApiClient())

        


        #Enumチェック
        allowed_values = ["Info", "Warning", "Error", "Critical"]
        if _severity is not None:
            if _severity not in allowed_values:
                raise ValueError(
                    "Invalid value for `severity` ({0}), (Select only one) {1}"
                    .format(_severity, allowed_values)
            )
        
        


        #Enumチェック
        allowed_values = ["Info", "Warning", "Error", "Critical"]
        if _severity_ge is not None:
            if _severity_ge not in allowed_values:
                raise ValueError(
                    "Invalid value for `severity_ge` ({0}), (Select only one) {1}"
                    .format(_severity_ge, allowed_values)
            )
        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "event_log_list"

























        if _max_events is not None and _max_events > 1000:
            raise ValueError("Invalid value for parameter `max_events` when calling `" + cliSubCommand + "`, must be a value less than or equal to `1000`")
#           raise ValueError("Invalid value for parameter `max_events` when calling `event_log_list`, must be a value less than or equal to `1000`")
        if _max_events is not None and _max_events < 1:
            raise ValueError("Invalid value for parameter `max_events` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `max_events` when calling `event_log_list`, must be a value greater than or equal to `1`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.EventLogList import EventLogList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.event_log_list(severity = _severity, severity_ge = _severity_ge, start_time = _start_time, end_time = _end_time, max_events = _max_events, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--location_name','_location_name',type=str,metavar='<str>',help='Location information for Syslog transfer. When specifying this option, also specify syslog_servers.')
@click.option('--syslog_servers','_syslog_servers',metavar='<str>', multiple=True,help='Syslog server to which event logs are transferred. Up to two servers can be specified. When you want to specify two servers, specify this option twice. index: ID of the Syslog server. is_enabled: Whether event logs are transferred to the Syslog server. server_name: Host name or IP address (IPv4) of the Syslog server. port: Port number of the Syslog server. transport_protocol: Communication protocol.')
@click.option('--smtp_settings','_smtp_settings',metavar='<str>', multiple=True,help='SMTP setting for event log transfer destination. index: ID of the SMTP server. is_enabled: Whether event logs are transferred using the SMTP setting. smtp_server_name: Host name or IP address (IPv4) of the SMTP server. smtp_auth_account: SMTP authentication account. from_address: Source E-mail address. to_address1: Destination E-mail address 1. to_address2: Destination E-mail address 2. to_address3: Destination E-mail address 3.')
def event_log_setting_set(_location_name,_syslog_servers,_smtp_settings,):
    """
    Edits the event log settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "event_log_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _location_name is not None:
            subCommandLogtxt += "--location_name " + str(_location_name) + " "



        if len(_syslog_servers) == 0:
            _syslog_servers = None

        if _syslog_servers is not None:
            subCommandLogtxt += "--syslog_servers " + str(_syslog_servers) + " "


        if len(_smtp_settings) == 0:
            _smtp_settings = None






        logger.info(subCommandLogtxt)

        
    

    

    




    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.event_log_management_manual import event_log_setting_set_manual
        event_log_setting_set_manual(_location_name,_syslog_servers,_smtp_settings,callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
def event_log_setting_show():
    """
    Obtains the event log settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "event_log_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import EventLogManagement as EventLogManagementApi
        api = EventLogManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "event_log_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.EventLogSetting import EventLogSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.event_log_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Event log ID ',required=True)
def event_log_show(_id,):
    """
    Obtains the event log. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "event_log_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import EventLogManagement as EventLogManagementApi
        api = EventLogManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "event_log_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.EventLog import EventLog

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.event_log_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--root_certificate','_root_certificate',metavar='<file>',help='Root certificate file used in communication with the SMTP server. ',required=True)
@click.option('--target_server','_target_server',type=int,metavar='<int>',help='ID of the target SMTP server. ',required=True)
def smtp_server_root_certificate_import(_root_certificate,_target_server,):
    """
    Imports the SMTP server root certificate. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "smtp_server_root_certificate_import"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _root_certificate is not None:
            subCommandLogtxt += "--root_certificate " + str(_root_certificate) + " "


        if _target_server is not None:
            subCommandLogtxt += "--target_server " + str(_target_server) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.event_log_management import EventLogManagement as EventLogManagementApi
        api = EventLogManagementApi(ApiClient())



        
        


        
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "smtp_server_root_certificate_import"







        if _target_server is not None and _target_server > 1:
            raise ValueError("Invalid value for parameter `target_server` when calling `" + cliSubCommand + "`, must be equal to `1`")
#           raise ValueError("Invalid value for parameter `target_server` when calling `import_root_certificate_smtp_server`, must be a value less than or equal to `1`")
        if _target_server is not None and _target_server < 1:
            raise ValueError("Invalid value for parameter `target_server` when calling `" + cliSubCommand + "`, must be equal to  `1`")
#           raise ValueError("Invalid value for parameter `target_server` when calling `import_root_certificate_smtp_server`, must be a value greater than or equal to `1`")























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        
        #ファイルが存在するか
        if not(os.path.isfile(_root_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_root_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        
        #ファイルが存在するか 2回目
        if not(os.path.isfile(_root_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_root_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.import_root_certificate_smtp_server(_root_certificate, _target_server, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _root_certificate) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_root_certificate) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['smtp_server_root_certificate_download'] = smtp_server_root_certificate_download
    commands['event_log_list'] = event_log_list
    commands['event_log_setting_set'] = event_log_setting_set
    commands['event_log_setting_show'] = event_log_setting_show
    commands['event_log_show'] = event_log_show
    commands['smtp_server_root_certificate_import'] = smtp_server_root_certificate_import
    return commands

