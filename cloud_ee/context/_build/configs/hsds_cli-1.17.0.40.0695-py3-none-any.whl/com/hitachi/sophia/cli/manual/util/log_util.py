"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import errno
import logging as loggingLib
import logging.handlers
import os
import sys
import traceback
from logging import Formatter
from  pathlib import PurePath

from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil


class LogUtil(object):
    def __init__(self):
        # デフォルトのログファイル
        self.defaultCliLogFile = '~/hsds/cli/hsds_cli.log'
        self.loggerHandler = None
        self.logger = None

    def cliLogInit(self):

        commonutil = CommonUtil()

        """
        CLI ロギング初期設定
        """
        # 環境変数で設定されたログレベルの取得
        # 　ない場合、INFOを設定する
        cliLogLevel = commonutil.getEnvironmentVariableDef('CLI_LOG_LEVEL', 'INFO')

        cliLogFile = self.defaultCliLogFile
        '''
        # 仕様変更により、ログ出力先及びファイル名は、デフォルトのユーザのホームディレクトリ/hsds/cli/hsds_cli.logに固定
        # cliLogFileの先頭が~から始まる場合、 user のホームディレクトリのパスに置き換える
        if cliLogFile[0] == '~':
            wkcliLogFile = os.path.expanduser(cliLogFile)
            cliLogFile = wkcliLogFile
            if os.path.basename(cliLogFile) == "":
                print("Invallid Log File NamePath Make Errore!")
                sys.exit()
        '''

        wkcliLogFile = os.path.expanduser(cliLogFile)
        cliLogFile = wkcliLogFile

        # ディレクトリがない場合、作成する
        logdir = os.path.dirname(cliLogFile)

        try:
            os.makedirs(logdir, mode=0o755, exist_ok=True)
            # アクセス権の変更 Linux only
            if self.os_name() == 'posix':
                # ~/hsds ~/hsds/cliのアクセス権を変更する処理
                home_dir = os.path.expanduser('~/')
                join_dirname = ''
                dir_flag = False  # ~/より上のディレクトリのアクセス権を変更しないためのフラグ　~/まできたらTrueにする
                abspath = PurePath(logdir)
                path_parts = abspath.parts
                for dirname in path_parts:
                    if dirname == '/':
                        continue
                    else:
                        join_dirname = join_dirname + '/' + dirname
                        if join_dirname + '/' == home_dir:
                            dir_flag = True
                            continue
                        if dir_flag == True:
                            if os.path.exists(join_dirname) == True:
                                os.chmod(join_dirname, 0o755)
        except Exception as e:
            traceback_str = traceback.format_exc()
            # 作成しようとしたディレクトリと同じ名前のファイルが存在している場合 ~/hsdsというファイルが存在
            if isinstance(e, FileExistsError) or isinstance(e, NotADirectoryError):
                self.print_mkdir_FileExistError(logdir)
                sys.exit(1)

            # アクセス権
            elif isinstance(e, PermissionError):
                self.print_mkdir_PermissionError(logdir)
                sys.exit(1)

            # ~/hsds/cliが存在しない
            elif isinstance(e, FileNotFoundError):
                if self.os_name() == 'posix':
                    # Linuxの場合、chmodの前にディレクトリが削除された場合のエラー
                    self.print_open_FileNotFoundError(logdir)
                else:
                    # Windowsの場合、~/hsdsが存在している場合にFileNotFoundErrorが発生する かつ chmodoを実行しない
                    self.print_mkdir_FileExistError(logdir)

                sys.exit(1)

            elif isinstance(e, OSError):
                # メモリ不足(既存メッセージ流用） 12 /* Out of memory */
                if e.errno == errno.ENOMEM:
                    self.print_mkdir_ENOMEM()
                    sys.exit(1)

                # システム全体でオープンされているファイルが多過ぎる 23 /* File table overflow */
                elif e.errno == errno.ENFILE:
                    self.print_mkdir_ENFILE()
                    sys.exit(1)

                # ファイルシステムに十分な空き容量がない 28 /* No space left on device */
                elif e.errno == errno.ENOSPC:
                    self.print_mkdir_ENOSPC(logdir)
                    sys.exit(1)

                # Read-onlyファイルシステム  30 /* Read-only file system */
                elif e.errno == errno.EROFS:
                    self.print_mkdir_EROFS(logdir)
                    sys.exit(1)

                # ユーザのディスク制限を超過しました 122 /* Quota exceeded */
                elif e.errno == errno.EDQUOT:
                    self.print_mkdir_EDQUOT(logdir)
                    sys.exit(1)
                else:
                    print(traceback.format_exc(), file=sys.stderr)
                    sys.exit(1)
            else:
                print(traceback.format_exc(), file=sys.stderr)
                sys.exit(1)

        # logging を warnings モジュールと統合
        loggingLib.captureWarnings(True)

        # Root loggerの定義
        logger = loggingLib.getLogger()
        self.logger = logger

        # ログレベルの設定
        if cliLogLevel == 'DEBUG':
            logger.setLevel(logging.DEBUG)
        elif cliLogLevel == 'INFO':
            logger.setLevel(logging.INFO)
        elif cliLogLevel == 'WARNING':
            logger.setLevel(logging.WARNING)
        elif cliLogLevel == 'ERROR':
            logger.setLevel(logging.ERROR)
        elif cliLogLevel == 'CRITICAL':
            logger.setLevel(logging.CRITICAL)
        else:
            # 上記以外の値が設定されていた場合、INFOに設定する
            logger.setLevel(logging.INFO)

        # ログ出力フォーマット設定
        formatter_hsdsFormatter = Formatter(
            '[%(asctime)s] T=%(thread)d (%(module)s.py : %(lineno)s) %(funcName)s() called. <%(levelname)s> %(message)s')

        # loggerのハンドラー生成
        self.loggerHandler = self.generateLoggerHandler(logger, cliLogFile, formatter_hsdsFormatter)

        logger.info('master_command.py root logger setup complete!!')

        # time.sleep(30)

        return

    def generateLoggerHandler(self, logger, cliLogFile, formatter_hsdsFormatter):
        # loggerのハンドラー生成
        # UTの後始末のため、分離している
        logdir = os.path.dirname(cliLogFile)

        try:
            file_handler = logging.handlers.RotatingFileHandler(cliLogFile, 'a', 10000000, 10)
            file_handler.setFormatter(formatter_hsdsFormatter)

            # root loggerのハンドラーをセット
            logger.addHandler(file_handler)

            return file_handler

        except Exception as e:
            # ~/hsds/cliが存在しない
            if isinstance(e, FileNotFoundError):
                self.print_open_FileNotFoundError(logdir)
                sys.exit(1)

            # ログファイルと同じ名前のディレクトリが存在している
            elif isinstance(e, IsADirectoryError):
                self.print_open_IsADirecotoryError(cliLogFile)
                sys.exit(1)

            # アクセス権
            elif isinstance(e, PermissionError):
                # Windowsでは、~/hsds/cli/hsds_cli.logというディレクトリがある場合、PermissionErrorが発生する
                if 'nt' == self.os_name():
                    if os.path.exists(cliLogFile):
                        if os.path.isdir(cliLogFile):
                            self.print_open_IsADirecotoryError(cliLogFile)
                            sys.exit(1)
                self.print_open_PermissionError(cliLogFile)
                sys.exit(1)


            elif isinstance(e, OSError):
                # メモリ不足(既存メッセージ流用） 12 /* Out of memory */
                if e.errno == errno.ENOMEM:
                    self.print_mkdir_ENOMEM()
                    sys.exit(1)

                # システム全体でオープンされているファイルが多過ぎる 23 /* File table overflow */ makedirsとメッセージ共通
                elif e.errno == errno.ENFILE:
                    self.print_mkdir_ENFILE()
                    sys.exit(1)

                # ファイルシステムに十分な空き容量がない 28 /* No space left on device */
                elif e.errno == errno.ENOSPC:
                    self.print_open_ENOSPC(cliLogFile)
                    sys.exit(1)

                # Read-onlyファイルシステム  30 /* Read-only file system */
                elif e.errno == errno.EROFS:
                    self.print_open_EROFS(cliLogFile)
                    sys.exit(1)

                # ユーザのディスク制限を超過しました 122 /* Quota exceeded */
                elif e.errno == errno.EDQUOT:
                    self.print_open_EDQUOT(cliLogFile)
                    sys.exit(1)

                else:
                    print(traceback.format_exc(), file=sys.stderr)
                    sys.exit(1)
            else:
                print(traceback.format_exc(), file=sys.stderr)
                sys.exit(1)

    def print_mkdir_FileExistError(self, logdir):
        print('Message Id: KARS19600-E', file=sys.stderr)
        print('Message: A log storing directory could not be created.', file=sys.stderr)
        print('Cause: A file with the same name as that of the log storing directory exists. (Path = {logdir})'.format(
            logdir=logdir), file=sys.stderr)
        print('Solution: Delete the file indicated in the path, and then retry the operation.', file=sys.stderr)
        return

    def print_mkdir_PermissionError(self, logdir):
        print('Message Id: KARS19601-E', file=sys.stderr)
        print('Message: A log storing directory could not be created.', file=sys.stderr)
        print('Cause: An access right required to create a directory has not been assigned. (Path = {logdir})'.format(
            logdir=logdir), file=sys.stderr)
        print(
            'Solution: Verify that an access right required to create a directory indicated in the path is assigned. If not, assign the access right.',
            file=sys.stderr)
        return

    def print_mkdir_ENOMEM(self):
        print('Message Id: KARS19029-E', file=sys.stderr)
        print('Message: An error occurred while running the command.', file=sys.stderr)
        print(
            'Cause: The free memory capacity of the maintenance node or the controller node in which the CLI was executed is insufficient or the command cannot be run on the maintenance node.',
            file=sys.stderr)
        print('Solution: Take action according to the troubleshooting guide.', file=sys.stderr)
        return

    def print_mkdir_ENFILE(self):
        print('Message Id: KARS19602-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print('Cause: The number of opened files reached the system upper limit.', file=sys.stderr)
        print(
            'Solution: For the controller node, close unnecessary files. For the maintenance node, close unnecessary files or restart the maintenance node.',
            file=sys.stderr)
        return

    def print_mkdir_ENOSPC(self, logdir):
        print('Message Id: KARS19603-E', file=sys.stderr)
        print('Message: A log storing directory could not be created.', file=sys.stderr)
        print('Cause: The file system does not have sufficient free capacity. (Path = {logdir})'.format(logdir=logdir),
              file=sys.stderr)
        print('Solution: Delete unnecessary files on the disk where a directory indicated in the path exists.',
              file=sys.stderr)
        return

    def print_mkdir_EROFS(self, logdir):
        print('Message Id: KARS19604-E', file=sys.stderr)
        print('Message: A log storing directory could not be created.', file=sys.stderr)
        print('Cause: The file system in which the target directory exists is read only. (Path = {logdir})'.format(
            logdir=logdir), file=sys.stderr)
        print('Solution: Contact the administrator who manages the controller node in which the CLI was executed.',
              file=sys.stderr)
        return

    def print_mkdir_EDQUOT(self, logdir):
        print('Message Id: KARS19605-E', file=sys.stderr)
        print('Message: A log storing directory could not be created.', file=sys.stderr)
        print('Cause: The upper limit of the disk quota has been exceeded. (Path = {logdir})'.format(logdir=logdir),
              file=sys.stderr)
        print('Solution: Contact the administrator who manages the controller node in which the CLI was executed.',
              file=sys.stderr)
        return

    def print_open_FileNotFoundError(self, logdir):
        print('Message Id: KARS19606-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print('Cause: A log storing directory was deleted during the log file initialization. (Path = {logDir})'.format(
            logDir=logdir), file=sys.stderr)
        print('Solution: Retry the CLI operation.', file=sys.stderr)
        return

    def print_open_IsADirecotoryError(self, cliLogFile):
        print('Message Id: KARS19607-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print('Cause: A directory with the same name as that of the log file exists. (Path = {logFile})'.format(
            logFile=cliLogFile), file=sys.stderr)
        print('Solution: Delete the directory indicated in the path, and then retry the operation.', file=sys.stderr)
        return

    def print_open_PermissionError(self, cliLogFile):
        print('Message Id: KARS19608-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print('Cause: An access right required to create a file has not been assigned. (Path = {logFile})'.format(
            logFile=cliLogFile), file=sys.stderr)
        print(
            'Solution: Verify that an access right required to create a file indicated in the path is assigned. If not, assign the access right.',
            file=sys.stderr)
        return

    def print_open_ENOSPC(self, cliLogFile):
        print('Message Id: KARS19609-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print('Cause: The file system does not have sufficient free capacity. (Path = {logFile})'.format(
            logFile=cliLogFile), file=sys.stderr)
        print('Solution: Delete unnecessary files on the disk where a file indicated in the path exists.',
              file=sys.stderr)
        return

    def print_open_EROFS(self, cliLogFile):
        print('Message Id: KARS19610-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print('Cause: The file system in which the target directory exists is read only. (Path = {logFile})'.format(
            logFile=cliLogFile), file=sys.stderr)
        print('Solution: Contact the administrator who manages the controller node in which the CLI was executed.',
              file=sys.stderr)
        return

    def print_open_EDQUOT(self, cliLogFile):
        print('Message Id: KARS19611-E', file=sys.stderr)
        print('Message: The log file could not be initialized.', file=sys.stderr)
        print(
            'Cause: The upper limit of the disk quota has been exceeded. (Path = {logFile})'.format(logFile=cliLogFile),
            file=sys.stderr)
        print('Solution: Contact the administrator who manages the controller node in which the CLI was executed.',
              file=sys.stderr)
        return

    '''
    UT用 os.nameは戻り値を持たないため、モックが使えない
    '''

    def os_name(self):
        if os.name == 'nt':
            return 'nt'
        else:
            return 'posix'
