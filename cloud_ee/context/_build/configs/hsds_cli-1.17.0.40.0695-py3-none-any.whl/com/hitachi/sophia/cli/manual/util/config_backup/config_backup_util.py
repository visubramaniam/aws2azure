"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import collections
import errno
import hashlib
import logging as loggingLib
import os
import pathlib
import platform
from re import S
import shutil
import sys
import tarfile
import tempfile
import traceback
import json
import subprocess
import datetime
import time
from os.path import expanduser
from urllib.parse import urlparse

import click
from filecmp import dircmp

from pathlib import Path

from com.hitachi.sophia.cli.manual.util.tarfile_util import TarfileUtil
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.progress_util import ProgressUtil

logger = loggingLib.getLogger(__name__)


class ConfigBackupUtil(object):
    def create_data_dir(self, temp_dir, csv_file, setup_yml_file, vm_conf_file, partial_vm_conf_file_list, version_file, cluster_id_file, cluster_tar):
        """
        temp_dirにdataディレクトリを作成し、クラスタ構成バックアップファイル、バージョンファイル、clusterIDファイル、
        構成ファイルを格納する
        :param temp_dir: dataディレクトリ作成先パス
        :param csv_file: csvファイルパス (構成ファイル)
        :param setup_yml_file: setupymlファイルパス (構成ファイル)
        :param version_file: versionファイルパス
        :param cluster_id_file: clusterIDファイルパス
        :param cluster_tar: クラスタ構成バックアップファイルパス
        :return: dataディレクトリパス
        """
        config = Configuration()
        data_dir = os.path.join(temp_dir, 'data')

        # dataディレクトリを作る
        os.makedirs(data_dir, exist_ok=True)

        # ファイルをコピー
        shutil.move(csv_file, data_dir)
        if setup_yml_file is not None:
            # ESXi版のみ
            shutil.move(setup_yml_file, data_dir)
        if vm_conf_file is not None:
            # AWS版のみ
            shutil.move(vm_conf_file, data_dir)
        if partial_vm_conf_file_list is not None:
            # AWS版のみ listで渡される
            for src in partial_vm_conf_file_list:
                shutil.move(src, data_dir)
        shutil.move(version_file, data_dir)
        shutil.move(cluster_id_file, data_dir)
        shutil.move(cluster_tar, data_dir)

        return data_dir

    def create_config_backup_dir(self, wk_dir, tar_file, checksum):
        """
        hsds_config_backup_<yyyymmdd>_<HHMMSS>ディレクトリを作成し、data.tarとchecksumを格納する
        :param wk_dir: 作成するディレクトリ名
        :param tar_file: data.tarのファイルパス
        :param checksum: checksumのファイルパス
        :return:
        """
        # hsds_config_backup_YYYYMMDD_HHMMSSディレクトリを作る
        os.makedirs(wk_dir, exist_ok=True)

        # ファイルをコピー
        shutil.move(tar_file, wk_dir)
        shutil.move(checksum, wk_dir)

    def create_tar_file(self, tar_file_name, args):
        """
        List argsに指定されたファイルをtarファイルに追加する
        :param tar_file_name:  作成するtarファイルのファイルパス
        :param args: tarファイルに追加するファイルのリスト
        :return:
        """
        with tarfile.open(tar_file_name, 'w') as tar:
            for name in args:
                arc_name = os.path.basename(name)
                tar.add(name, arcname=arc_name)

    def create_checksum(self, config_file, output_checksum_file):
        """
        チェックサムファイルを作成する
        :param config_file: チェックサムファイル作成の対象となるファイル data.tar
        :param output_checksum_file: 出力するチェックサムファイルのファイルパス
        :return:
        """
        h = hashlib.sha256()
        # sha256のブロックサイズは512bits(64バイト)
        read_length = h.block_size * 64
        try:
            with open(config_file, 'rb') as f:
                read_data = f.read(read_length)
                # データがなくなるまでループ
                while read_data:
                    # ハッシュオブジェクトに追加して経産
                    h.update(read_data)
                    # データの続きを読み込む
                    read_data = f.read(read_length)
        except FileNotFoundError:
            logger.error('Config File not found.')
            config = Configuration()
            config.messageId = config.messageId = '19505'
            common_util = CommonUtil()
            common_util.view_error()
        except Exception as e:
            logger.error('Config File Open Error.')
            config = Configuration()
            config.messageId = '19505'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # サポートB票172008 ユーザーや保守員が手動で確認する可能性のあるファイルでは改行を付けて表示したときにプロンプトが崩れないようにする
        # 改行コードはコントローラーノードのOSに依らず「LF」固定
        with open(output_checksum_file, 'w', encoding='UTF-8', newline="\n")as write_file:
            write_file.write(h.hexdigest())
            write_file.write("\n")

    def get_backup_data_file_name(self, internal_id, version):
        """
        構成バックアップファイルのファイル名(tar）と元となるディレクトリ名を作成する
        :param internal_id: internalId
        :param version: バージョン
        :return: path_name hsds_config_backup_<InternalID>_<VERSION>_<yyyymmdd>_<HHMMSS>
                         file_name hsds_config_backup_<InternalID>_<VERSION>_<yyyymmdd>_<HHMMSS>.tar
                         ただし、VERSIONはAABBCCDD形式(ドットなし)
        """
        dt = datetime.datetime.now()
        yyyymmdd = format(dt, '%Y%m%d')
        hhmmss = format(dt, '%H%M%S')
        version_wo_dots = version.replace('.', '')
        str_file_name = 'hsds_config_backup_{INTERNAL_ID}_{VERSION}_{YYYYMMDD}_{HHMMSS}.tar'
        str_path_name = 'hsds_config_backup_{INTERNAL_ID}_{VERSION}_{YYYYMMDD}_{HHMMSS}'
        file_name = str_file_name.format(INTERNAL_ID=internal_id, VERSION=version_wo_dots,
                                         YYYYMMDD=yyyymmdd, HHMMSS=hhmmss)
        path_name = str_path_name.format(INTERNAL_ID=internal_id, VERSION=version_wo_dots,
                                         YYYYMMDD=yyyymmdd, HHMMSS=hhmmss)

        return path_name, file_name

    def is_host_primary_master(self):
        """
        storage_master_node_primary_flag_showのResponse中のHTTPステータスコードをみて、指定されたホストがprimaryか判定
        :return:
        """

        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())
        config = Configuration()

        response = api.storage_master_node_primary_flag_show(callback=None, debug="false")

        common_util = CommonUtil()
        status = common_util.get_response_status(response)
        if status == 200:
            return True
        elif status == 404:
            config = Configuration()
            config.messageId = '19201'
            return False
        else:
            logger.error('Unexpected response of storage_master_node_primary_flag_show. status:' + str(status))
            output_util = OutputUtil()
            output_util.echo_error(response, 'text')
            exit(1)

    def get_job_status(self, response):
        """
        job_showのresponseから、ジョブの進捗状況を返す
        :param response:
        :return: job.status
        """
        try:
            d = json.loads(response)
            body = d.get('body')
            return body.get('status')
        except AttributeError as e:
            return None

    def get_job_state(self, response):
        """
        job_showのresponseから、ジョブの状態を返す
        :param response:
        :return: job.state
        """
        try:
            d = json.loads(response)
            # getを使うとKeyErroが出ない
            body = d.get('body')
            return body.get('state')
        except AttributeError as e:
            return None

    def maintenance_command_exists_for_esxi(self):
        """
        /opt/hesmn/mnservice_restricted_bin/vagrant_up.shがあるか確認する
        :return:
        """
        maintenance_command = '/opt/hesmn/mnservice_restricted_bin/vagrant_up.sh'
        return os.path.isfile(maintenance_command)

    def maintenance_command_exists_for_aws(self):
        """
        /usr/bin/hsdsinstallがあるか確認する
        :return:
        """
        maintenance_command = '/usr/bin/hsdsinstall'
        return os.path.isfile(maintenance_command)

    def set_environment_variable_vcenter_user(self, _vcenter_user):
        """
        環境変数 HSDS_VCENTER_USER と --user ともに指定されいなければ False
        --userがあれば、環境変数を書き換える
        入力パラメータ _vcenter_user
        :param _vcenter_user:
        :return:
        """
        config = Configuration()
        hsds_vcenter_user = os.environ.get('HSDS_VCENTER_USER')

        # パラメータ 環境変数ともに設定されていなければFalse
        # メッセージは修正予定
        if _vcenter_user is None:
            if hsds_vcenter_user is None:
                logger.error('Neither vcenter_user nor HSDS_VCENTER_USER is specified.')
                config.messageId = '19204'
                return False
            else:
                return True
        else:
            os.environ['HSDS_VCENTER_USER'] = _vcenter_user
            return True

    def set_environment_variable_vcenter_password(self, _vcenter_password):
        """
        環境変数 HSDS_VCENTER_PASSWORD と --password ともに指定されいなければ False
        --passwordがあれば、環境変数を書き換える
        入力パラメータ _vcenter_password
        :param _vcenter_password:
        :return:
        """
        config = Configuration()

        hsds_vcenter_password = os.environ.get('HSDS_VCENTER_PASSWORD')

        # パラメータ 環境変数ともに設定されていなければFalse
        # メッセージは修正予定
        if _vcenter_password is None:
            if hsds_vcenter_password is None:
                logger.error('Neither vcenter_password nor HSDS_VCENTER_PASSWORD is specified.')
                config.messageId = '19205'
                config.messageDict = {'parameter': '--vcenter_password'}
                return False
            else:
                return True
        else:
            os.environ['HSDS_VCENTER_PASSWORD'] = _vcenter_password
            return True

    def dir_compare(self, dir1, dir2):
        """
        dir1とdir2を比較、サブフォルダの中は対象外
        :param dir1:
        :param dir2:
        :return:
        """
        dcmp = dircmp(dir1, dir2)

        # dir1だけにあるファイルおよびサブディレクトリ
        if len(dcmp.left_only) != 0:
            return False

        # dir2だけにあるファイルおよびサブディレクトリ
        if len(dcmp.right_only) != 0:
            return False

        # dir1および dir2 の両方にあり、ディレクトリ間でタイプが異なるか、 os.stat() がエラーを報告するような名前
        if len(dcmp.common_funny) != 0:
            return False

        # dir1とdir2の両方に存在し、クラスのファイル比較オペレータに基づいて内容が異なるファイル
        if len(dcmp.diff_files) != 0:
            return False

        return True

    #  後で使う化も
    # def get_response_body(self, response):
    #     d = json.loads(response, object_pairs_hook=collections.OrderedDict)
    #     body = d.get('body')
    #     response_body = json.dumps(body, indent=4, separators=(',', ': '))
    #     return response_body
    #
    # def get_response_body_error(self, response):
    #     d = json.loads(response, object_pairs_hook=collections.OrderedDict)
    #     body = d.get('body')
    #     body_error = body.get('error')
    #     response_body_error = json.dumps(body_error, indent=4, separators=(',', ': '))
    #     return response_body_error

    # def get_body_error(self, response):
    #     d = json.loads(response)
    #     body = d.get('body')
    #     return body.get('error')
    #
    # def get_body_cause(self, response):
    #     d = json.loads(response)
    #     body = d.get('body')
    #     return body.get('cause')
    #
    # def get_body_solution(self, response):
    #     d = json.loads(response)
    #     body = d.get('body')
    #     return body.get('solution')
    #
    # def get_body_error_cause(self, response):
    #     d = json.loads(response)
    #     body = d.get('body')
    #     body_error = body.get('error')
    #     return body_error.get('cause')
    #
    # def get_body_error_solution(self, response):
    #     d = json.loads(response)
    #     body = d.get('body')
    #     body_error = body.get('error')
    #     return body_error.get('solution')

    def get_job_id(self, response):
        try:
            d = json.loads(response)
            body = d.get('body')
            return body.get('jobId')
        except AttributeError as e:
            return None

    def get_storage_internal_id_cluster_id_and_version(self, res):
        """
        storage_showのレスポンスボディから、internalId, (cluster)id, softwareVersionを取り出す関数
        :param res: storage_showのレスポンスボディ
        :return: (internalId, id, softwareVersion)のタプル。キーがないものや値が取れなかったものにはNoneが入る。
        """
        try:
            d = json.loads(res)
            body = d.get('body')
            if body is not None:
                return body.get('internalId'), body.get('id'), body.get('softwareVersion')
            else:
                return None, None, None
        except ValueError as e:
            logger.error('JSON Decode Error: ' + ' '.join(map(str, e.args)))
            return None, None, None

    def create_version_file(self, version, dir_path):
        """
        versionファイルを作成
        :param version: (str)バージョン番号
        :param dir_path: ファイル作成先のディレクトリパス
        :return: 作成したファイルのパス
        """
        return self._create_file_and_write_value(dir_path, 'version', version)

    def create_cluster_id_file(self, cluster_id, dir_path):
        """
        clusterIDファイルを作成
        :param cluster_id: (str)クラスタID
        :param dir_path: ファイル作成先のディレクトリパス
        :return: 作成したファイルのパス
        """
        return self._create_file_and_write_value(dir_path, 'clusterID', cluster_id)

    def _create_file_and_write_value(self, dir_path, filename, value):
        """
        valueを書き込んだ名前filenameのファイルをdir_pathに作成
        :param dir_path: ファイル作成先のディレクトリパス
        :param filename: 作成するファイル名
        :param value: ファイルに書き込む値
        :return: 作成したファイルのパス
        """
        # サポートB票172008 ユーザーや保守員が手動で確認する可能性のあるファイルでは改行を付けて表示したときにプロンプトが崩れないようにする
        # 改行コードはコントローラーノードのOSに依らず「LF」固定
        file_path = os.path.join(dir_path, filename)
        with open(file_path, 'w', newline="\n") as f:
            f.write(value)
            f.write("\n")
            f.flush()
        return file_path

    def check_checksum(self, tar_file):

        try:
            dir_name = os.path.splitext(os.path.basename(tar_file))[0]
            with tarfile.open(tar_file, 'r') as tar:
                # cluster_yyyymmdd_HHMMSS/data.tarのchecksumを計算
                info = tar.getmember(dir_name + '/data.tar')
                with tempfile.TemporaryDirectory() as extract_dir:
                    tar.extract(info, path=extract_dir)
                    target_file_dir = os.path.join(extract_dir, dir_name)
                    target_file_path = os.path.join(target_file_dir, 'data.tar')

                    h = hashlib.sha256()
                    # sha256のブロックサイズは512bits(64バイト)
                    read_length = h.block_size * 64
                    # 解凍されたファイル名
                    with open(target_file_path, 'rb') as f:
                        read_data = f.read(read_length)
                        # データがなくなるまでループ
                        while read_data:
                            # ハッシュオブジェクトに追加して経産
                            h.update(read_data)
                            # データの続きを読み込む
                            read_data = f.read(read_length)

                    hash_data_tar = h.hexdigest()

                # checksumの値を取得
                info = tar.getmember(dir_name + '/checksum')
                info_checksum = tar.extractfile(info).read()
                hash_checksum = info_checksum.decode("utf-8").replace('\n', '')

                if hash_data_tar == hash_checksum:
                    return True
                else:
                    return False

        except tarfile.TarError as e:  # tarアーカイブの操作に失敗した
            if traceback:
                logger.error(traceback.format_exc())
            return False

        except KeyError as e:  # アーカイブに期待するファイルが存在しない
            if traceback:
                logger.error(traceback.format_exc())
            return False

        except UnicodeError as e:  # エンコーディングエラー
            if traceback:
                logger.error(traceback.format_exc())
            return False

        except FileNotFoundError as e:
            if traceback:
                logger.error(traceback.format_exc())
            return False

    def config_file_export_for_esxi(self, _host, _user, _password, export_dir):
        """
        構成エクスポートを実行する
        :param _host:
        :param _user:
        :param _password:
        :param export_dir: 構成ファイルのエクスポート先
        :return:
        """
        parsed_url = urlparse(_host)
        address_with_port = parsed_url.netloc
        host_address = (address_with_port.split(":"))[0]

        _shell = '/opt/hesmn/mnservice_restricted_bin/vagrant_up.sh'
        config = Configuration()
        try:
            cmd = []
            cmd.append(_shell)
            cmd.append('--export')
            cmd.append('--primary_master_ip')
            cmd.append(host_address)
            cmd.append('--user')
            cmd.append(_user)
            cmd.append('--password')
            cmd.append(_password)
            cmd.append('--output_directory')
            cmd.append(export_dir)
            if config.verify_ssl is False:
                cmd.append('--ignore_certificate_errors')

            subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=False)
            return True, 0
        except subprocess.CalledProcessError as e:
            err_message = e.output.decode()
            log_txt = '/opt/hesmn/mnservice_restricted_bin/vagrant_up.sh ' + err_message
            logger.error(log_txt)
            rc = e.returncode
            config.message_management = MessageManagement('')
            if rc == 1:
                logger.error('vagrant_up.sh failed. rc = 1')
                config.messageId = '19206'
            elif rc == 2:
                logger.error('vagrant_up.sh failed.  rc = 2')
                config.messageId = '19207'
            elif rc == 3:
                logger.error('vagrant_up.sh failed.  rc = 3')
                config.messageId = '19208'
            elif rc == 5:
                logger.error('vagrant_up.sh failed.  rc = 5')
                config.messageId = '19506'
            elif rc == 11:
                logger.error('vagrant_up.sh failed.  rc = 11')
                config.messageId = '19209'
            elif rc == 21:
                logger.error('vagrant_up.sh failed.  rc = 21')
                config.messageId = '19210'
            elif rc == 22:
                logger.error('vagrant_up.sh failed.  rc = 22')
                config.messageId = '19211'
            elif rc == 235:
                logger.error('vagrant_up.sh failed.  rc = 235')
                config.messageId = '19222'
            elif rc == 238:
                logger.error('vagrant_up.sh failed.  rc = 238')
                config.messageId = '19212'
            elif rc == 253:
                logger.error('vagrant_up.sh failed.  rc = 253')
                config.messageId = '19213'
            elif rc == 255:
                logger.error('vagrant_up.sh failed.  rc = 255')
                config.messageId = '19213'
            else:
                logger.error('hsdsinstall failed.  unknown rc = {}'.format(rc))
                config.messageId = '19213'
            return False, rc

    def config_file_export_for_aws(self, _host, _user, _password, export_dir):
        """
        構成エクスポートを実行する
        :param _host:
        :param _user:
        :param _password:
        :param export_dir: 構成ファイルのエクスポート先
        :return:
        """
        parsed_url = urlparse(_host)
        address_with_port = parsed_url.netloc
        host_address = (address_with_port.split(":"))[0]

        # 前処理で、チェック済みのためNoneチェックはしない
        _command = self.check_and_get_hsdsinstall_commnad_path()
        config = Configuration()
        try:
            cmd = []
            cmd.append(_command)
            cmd.append('--export')
            cmd.append('--host')
            cmd.append(host_address)
            cmd.append('--user')
            cmd.append(_user)
            cmd.append('--output_directory')
            cmd.append(export_dir)
            if config.verify_ssl is False:
                cmd.append('--ignore_certificate_errors')

            subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=False)
            return True, 0
        except subprocess.CalledProcessError as e:
            err_message = e.output.decode()
            log_txt = _command + ' ' + err_message
            logger.error(log_txt)
            rc = e.returncode
            config.message_management = MessageManagement('')
            if rc == 1:
                logger.error('hsdsinstall failed. rc = 1')
                config.messageId = '19206'
            elif rc == 2:
                logger.error('hsdsinstall failed.  rc = 2')
                config.messageId = '19207'
            elif rc == 3:
                logger.error('hsdsinstall failed.  rc = 3')
                config.messageId = '19208'
            elif rc == 5:
                logger.error('hsdsinstall failed.  rc = 5')
                config.messageId = '19506'
            elif rc == 11:
                logger.error('hsdsinstall failed.  rc = 11')
                config.messageId = '19209'
            elif rc == 21:
                # AWS CLI(認証失敗、接続失敗)
                logger.error('hsdsinstall failed.  rc = 21')
                config.messageId = '19210'
            elif rc == 107:
                logger.error('hsdsinstall failed.  rc = 107')
                config.messageId = '19222'
            elif rc == 110:
                logger.error('hsdsinstall failed.  rc = 110')
                config.messageId = '19212'
            elif rc == 125:
                logger.error('hsdsinstall failed.  rc = 125')
                config.messageId = '19213'
            elif rc == 127:
                logger.error('hsdsinstall failed.  rc = 127')
                config.messageId = '19213'
            else:
                logger.error('hsdsinstall failed.  unknown rc = {}'.format(rc))
                config.messageId = '19213'
            return False, rc

    def config_file_export_for_native(self, download_path):
        # Nativeでは公開APIのエクスポートAPIとダウンロードAPIを実行する。
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())
        job_id = None
        for i in range(21):
            # エクスポートAPI
            response = api.configuration_file_create(callback=None, debug="false")
            common_util = CommonUtil()
            output_util = OutputUtil()
            config = Configuration()
            http_status = common_util.get_response_status(response)
            if common_util.check_retry(response):
                if i > 19:
                    logger.error('configration_file export kick failed.')
                    config.messageId = '19213'
                    common_util.view_error()
                else:
                    time.sleep(1)
                    continue
            elif http_status != 202:
                d = json.loads(response)
                if d.get('body') is not None and d['body'].get('messageId') is not None:
                    rest_message_id = d['body'].get('messageId')
                    if rest_message_id == 'KARS10013-E':
                        # 構成ファイルが何らかの操作と衝突したケース
                        logger.error('configration_file export kick failed (conflict other operation).')
                        config.messageId = '19207'
                        common_util.view_error()
                    else:
                        logger.error('configration_file export kick failed.')
                        config.messageId = '19213'
                        common_util.view_error()
                else:
                    logger.error('configration_file export kick failed.')
                    config.messageId = '19213'
                    common_util.view_error()
            else:
                job_id = self.get_job_id(response)
                break

        # 構成ファイルエクスポート完了確認
        from com.hitachi.sophia.rest_client.autogen.apis.overall import Overall as OverallApi
        api = OverallApi(ApiClient())
        common_util = CommonUtil()
        config_backup_util = ConfigBackupUtil()
        config = Configuration()
        output_util = OutputUtil()
        http_status_503_count = 0

        update_count = 0
        max_update_count = 3

        while True:
            time.sleep(5)

            response = api.job_show(job_id, callback=None, debug="false")
            http_status = common_util.get_response_status(response)

            if common_util.check_retry(response):
                if http_status_503_count > 0:
                    logger.error('job_show failed.')
                    config.messageId = '19213'
                    common_util.view_error()
                else:
                    http_status_503_count += 1
                    continue
            elif http_status != 200:
                config_backup_util.convert_rest_responses_with_cli_for_config_backup(response)
                config.messageId = '19213'
                common_util.view_error()
            else:
                d = json.loads(response)
                job_status = config_backup_util.get_job_status(response)
                if job_status is None:
                    logger.error('The response is broken. job_status not found.')
                    config.messageId = '19213'
                    common_util.view_error()
                elif job_status == 'Initializing':
                    pass
                elif job_status == 'Running':
                    pass
                elif job_status == 'Completed':
                    job_state = config_backup_util.get_job_state(response)
                    if job_state is None:
                        logger.error('The response is broken. job_state not found.')
                        config.messageId = '19213'
                        common_util.view_error()
                    elif job_state == 'Queued':
                        pass
                    elif job_state == 'Started':
                        pass
                    elif job_state == 'Failed':
                        if d.get('body') is not None and d['body'].get('messageId') is not None:
                            rest_message_id = d['body'].get('messageId')
                            if rest_message_id == 'KARS10013-E':
                                # 構成ファイルが何らかの操作と衝突したケース
                                logger.error('configration_file export failed (conflict other operation).')
                                config.messageId = '19207'
                                common_util.view_error()
                            else:
                                logger.error('configration_file export failed.')
                                config.messageId = '19213'
                                common_util.view_error()
                        else:
                            logger.error('configration_file export failed.')
                            config.messageId = '19213'
                            common_util.view_error()
                    elif job_state == 'Succeeded':
                        # 構成ファイルエクスポート完了
                        logger.info('configration_file export success.')
                        break
                    else:
                        # 想定外のjob state
                        log_txt = 'job_show error. unknown job state. ' + job_state
                        logger.error(log_txt)
                        config.messageId = '19213'
                        common_util.view_error()
                else:
                    log_txt = 'job_show error. unknown job status. ' + job_status
                    logger.error(log_txt)
                    config.messageId = '19213'
                    common_util.view_error()

            if update_count < max_update_count:
                update_count += 1
            else:
                logger.error('config_file_export timeout.')
                config.messageId = '19213'
                common_util.view_error()
        # 構成ファイルエクスポート完了確認終わり

        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())
        # ダウンロードAPI
        response = api.configuration_file_download(callback=None, debug="false", _preload_content=False)
        common_util = CommonUtil()
        output_util = OutputUtil()
        logger.info(response.status)
        if response.status != 200:
            time.sleep(3)
            logger.error('configration_file download Failed. (retry)')
            response = api.configuration_file_download(callback=None, debug="false", _preload_content=False)
            common_util = CommonUtil()
            output_util = OutputUtil()
            logger.info(response)
            if response.status != 200:
                # バックアップ内で実行しているエクスポートは完了を待つため、10016がREST応答される場合はユーザー自発の構成ファイルエクスポートと衝突したケース
                # 19213を出して再実施を促す。
                logger.error('configration_file download Failed.')
                message_id = '19213'
                message_dict = {}
                message_management = MessageManagement('')
                message_management.viewMessageTxt(message_id, **message_dict)
                exit(1)
        saveFile = None
        logger.info('configration_file download success.')
        with open(download_path, 'wb') as saveFile:
            saveFile.write(response.data)


    def judge_job_result(self, job_id, bar):
        """
        クラスタ構成バックアップ作成APIの結果を判定する
        :param job_id:
        :param bar
        :return:
        """
        import time
        from com.hitachi.sophia.rest_client.autogen.apis.overall import Overall as OverallApi
        api = OverallApi(ApiClient())
        common_util = CommonUtil()
        config_backup_util = ConfigBackupUtil()
        config = Configuration()
        output_util = OutputUtil()
        http_status_503_count = 0
        progress_util = ProgressUtil()

        sleep_time = 30
        max_progressbar_update_count = 72
        progressbar_update_count = 0
        while True:

            time.sleep(sleep_time)

            response = api.job_show(job_id, callback=None, debug="false")
            http_status = common_util.get_response_status(response)

            if common_util.check_retry(response):

                if http_status_503_count > 0:
                    logger.error('job_show failed.')
                    output_util.echo_error(response, 'text')
                    exit(1)
                else:
                    http_status_503_count += 1
                    continue

            elif http_status != 200:
                config_backup_util.convert_rest_responses_with_cli_for_config_backup(response)

                # Response.bodyを出力
                logger.error('job_show failed.')
                output_util.echo_error(response, 'text')
                exit(1)
                # UT用
                # return False

            else:
                job_status = config_backup_util.get_job_status(response)
                if job_status is None:
                    logger.error('The response is broken. job_status not found.')
                    config.messageId = '19505'
                    return False
                elif job_status == 'Initializing':
                    pass
                elif job_status == 'Running':
                    pass
                elif job_status == 'Completed':
                    job_state = config_backup_util.get_job_state(response)
                    if job_state is None:
                        logger.error('The response is broken. job_state not found.')
                        config.messageId = '19505'
                        return False
                    elif job_state == 'Queued':
                        pass
                    elif job_state == 'Started':
                        pass
                    elif job_state == 'Failed':
                        # エラー処理 APIのレスポンスボディにおけるerror属性のオブジェクトを取り出して出力する
                        output_util.echo_error(response, 'text')
                        exit(1)
                        # UT用
                        # return False

                    elif job_state == 'Succeeded':
                        # プログレスバー更新 #4
                        # クラスタ構成バックアップファイル作成Job終了確認ポーリング((残りのポーリング数×30秒)+10秒)
                        length = ((max_progressbar_update_count - progressbar_update_count) * 30) + 10
                        progress_util.update_progressbar(bar, length)
                        return True
                    else:
                        # 想定外のjob state
                        lot_txt = 'job_show error. unknown job state. ' + job_state
                        logger.error(lot_txt)
                        config.messageId = '19505'
                        return False
                else:
                    log_txt = 'job_show error. unknown job status. ' + job_status
                    logger.error(log_txt)
                    config.messageId = '19505'
                    return False

            # ループ回数が25以下の場合
            if progressbar_update_count < max_progressbar_update_count:
                # プログレスバー更新 #4
                # クラスタ構成バックアップファイル作成Job終了確認ポーリング(30秒周期)
                progress_util.update_progressbar(bar, 30)
                progressbar_update_count += 1

    def delete_dir(self, dir_name):
        """
        ディレクトリを削除する
        :param dir_name:
        :return:
        """
        if os.path.isdir(dir_name):
            shutil.rmtree(dir_name)

    def get_home(self):
        return expanduser("~")

    def convert_rest_responses_with_cli_for_config_backup(self, response):
        d = json.loads(response)
        if d['httpStatusCode'] == 401:
            if d.get('body') != None and d['body'].get('messageId') != None:
                rest_message_id = d['body'].get('messageId')
                if rest_message_id == 'KARS20011-E':
                    message_id = '19218'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)

        elif d['httpStatusCode'] == 412:
            if d.get('body') != None and d['body'].get('messageId') != None:
                rest_message_id = d['body'].get('messageId')
                if rest_message_id == 'KARS15591-E':
                    message_id = '19219'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)
        elif d['httpStatusCode'] == 404:
            if d.get('body') != None and d['body'].get('messageId') != None:
                rest_message_id = d['body'].get('messageId')
                if rest_message_id == 'KARS15022-E':
                    message_id = '19221'
                    message_dict = {'required_role': 'Service'}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)

    def check_and_get_hsdsinstall_commnad_path(self):
        """
        hsdsinstallコマンドパスチェックおよび取得
        :param :
        :return: hsdsinstallコマンドパス
        """
        # OS別のコマンド名とvenvコマンド相対パスを取得
        command_name, venv_command_relative_path = self.get_hsdsinstall_commnad_name()
        logger.info('command_name is ' + command_name + '. venv_command_relative_path is ' + venv_command_relative_path + '.')

        # venvを使用しているか
        if os.environ.get('VIRTUAL_ENV') != None:
            # venv内hsdsinstallコマンド存在チェック
            venv_root_dir = os.environ['VIRTUAL_ENV']
            logger.info('venv_root_dir is ' + venv_root_dir + '.')

            hsdsinstall_path = os.path.join(venv_root_dir, venv_command_relative_path)
            if os.path.isfile(hsdsinstall_path):
                logger.info('hsdsinstall_path is ' + hsdsinstall_path + '.')
                return hsdsinstall_path

        # システムパス内hsdsinstallコマンド存在チェック
        path_dirs_string = os.environ.get('PATH')
        logger.info('path_dirs_string is ' + str(path_dirs_string) + '.')
        if path_dirs_string is None:
            path_dirs = []
        else:
            path_dirs = path_dirs_string.split(os.pathsep)
        for _directory in path_dirs:
            if _directory == "":
                continue
            hsdsinstall_path = os.path.join(_directory, command_name)
            if os.path.isfile(hsdsinstall_path):
                logger.info('hsdsinstall_path is ' + hsdsinstall_path + '.')
                return hsdsinstall_path

        logger.info('hsdsinstall is not found.')
        return None

    # return: (command_name, venv_command_relative_path)
    def get_hsdsinstall_commnad_name(self):
        """
        hsdsinstallコマンドパス取得
        :param :
        :return:hsdsinstallコマンド、hsdsinstallコマンドディレクトリ
        """
        # Todo OS判定結果を他の処理実行時にも使用するかもしれないため、OS判定処理は1つの関数として独立される
        # OS判定
        plat = platform.system()
        logger.info('platform is ' + plat + '.')
        if plat == "Linux":
            command_name = 'hsdsinstall'
            venv_command_relative_path = os.path.join('bin', command_name)
        elif plat == "Windows":
            command_name = 'hsdsinstall.exe'
            venv_command_relative_path = os.path.join('Scripts', command_name)
        else:
            logger.error('Error due to unsupported OS.')
            config = Configuration()
            config.messageId = '19505'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()
            exit(1)

        return (command_name, venv_command_relative_path)