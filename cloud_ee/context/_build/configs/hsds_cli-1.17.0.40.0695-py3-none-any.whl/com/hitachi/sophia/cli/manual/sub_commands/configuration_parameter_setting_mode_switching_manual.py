# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2021, 2024, Hitachi Vantara, Ltd.
"""
import collections
import json

import click
import logging as loggingLib
import os
import traceback
import time
import ipaddress
from enum import IntEnum
import urllib3
import re
import json
from urllib.parse import urlparse

from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.util.configfile_util import ConfigfileUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.rest_certificate_util import RestCertificateUtil

# 自動生成対象外コード
# 構成パラメータ設定モード切り替えCLI
# ESXi版以外で使用

logger = loggingLib.getLogger(__name__)

def is_valid_hostname(hostname: str) -> bool:
    if len(hostname) > 255:
        return False

    # strip exactly one dot from the right, if present
    if hostname[-1] == ".":
        hostname = hostname[:-1]
    allowed = re.compile(r"(?!-)[A-Z0-9-]{1,63}(?<!-)$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))

@click.command(options_metavar='<options>')
@click.option('--mode', '_mode', type=str, metavar='<str>', help='Configuration parameter setting mode.', required=True)
@click.option('--system_configuration_file', '_system_configuration_file', type=str, metavar='<str>', help='Specifies the configuration file. (Bare metal)')
@click.option('--vm_configuration_file', '_vm_configuration_file', type=str, metavar='<str>', help='Specifies the VM configuration file. (Cloud)')
@click.option('--targets', '_targets', type=str, metavar='<str>',help='List of IP address (IPv4) for the control network or FQDN.')
def configuration_parameter_setting_mode(_mode, _system_configuration_file, _vm_configuration_file, _targets):
    """
    Switches the configuration parameter setting mode of a storage node.
    """
    # configuration_parameter_setting_modeを切り替える.
    try:
        config = Configuration()
        common_util = CommonUtil()
        configfile_util = ConfigfileUtil()
        common_util.view_error()

        # 認証パラメータのチェック チケット認証のみサポート
        # manual/util/auth_parameters_util.py
        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('', '', 'true')
        auth_parameter_util.check_auth_parameter('', '', 'true')

        # Configurationインスタンスにエラーメッセージが格納されていたら出力して処理終了
        # 引数指定に問題があればここで終了
        # manual/util/common_util.py
        common_util.view_error()

        sub_command_log_txt = "Sub-command parameters : " + " "
        cli_sub_command = "configuration_parameter_setting_mode"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cli_sub_command)
            common_util.view_error()
        elif config.format == 'json':
            logger.error("Not available sub-command.")
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: When the subcommand is {}, json cannot be specified for --format.".format("configuration_parameter_setting_mode"))
            click.echo("Solution: Specify text for --format.")
            exit(1)

        # サブコマンドパラメータのログ出力 パスワードは、伏せ字
        if _mode is not None:
            sub_command_log_txt += "--mode " + str(_mode) + " "
        if _system_configuration_file is not None:
            sub_command_log_txt += "--system_configuration_file " + str(_system_configuration_file) + " "
        if _vm_configuration_file is not None:
            sub_command_log_txt += "--vm_configuration_file " + str(_vm_configuration_file) + " "
        if _targets is not None:
            sub_command_log_txt += "--targets " + str(_targets) + " "

        logger.info(sub_command_log_txt)

        common_util.input_password()

        # 引数確認
        # _mode
        mode_bool = _mode
        if _mode is not None:
            mode_bool = SeparateArgs.check_backslash(mode_bool)
            mode_bool = mode_bool.encode("utf-8").decode("unicode-escape")
            if mode_bool not in ["enable", "disable"]:
                raise ValueError("Invalid value for --mode.")

            if mode_bool == "enable":
                mode_bool = True
            if mode_bool == "disable":
                mode_bool = False

        # 構成パラメータ設定モード参照対象のストレージノード情報を取得
        sys_conf_dict = {}
        if _system_configuration_file is None and _vm_configuration_file is None and _targets is None:
            raise ValueError("--system_configuration_file or --targets is required. (Bare metal) --vm_configuration_file or --targets is required.  (Cloud)")
        elif _system_configuration_file is not None:
            if _vm_configuration_file is not None:
                # _system_configuration_fileと_vm_configuration_fileをどちらも指定したケース
                # どのプラットフォーム種別なのか判断がつかないため引数エラーに倒す
                raise ValueError("--system_configuration_file or --targets can be specified. (Bare metal) --vm_configuration_file or --targets can be specified. (Cloud)")
            if _targets is not None:
                click.echo("Both --system_configuration_file and --targets are set. --targets is ignored.")
            # _system_configuration_file
            if os.path.isfile(_system_configuration_file):
                rtrn, control_addr, errmsg = configfile_util.get_control_address_from_csv(_system_configuration_file)
                if rtrn != 0:
                    logger.error(errmsg)
                    click.echo("Message: {}".format(errmsg))
                    click.echo("Cause: Appropriate file is not specified.")
                    click.echo("Solution: Review configuration file and specify the option value correctly.")
                    exit(1)
                sys_conf_dict = {"Nodes": []}
                for addr in control_addr:
                    sys_conf_dict["Nodes"].append({"HostName": "", "ControlNWIPv4": addr})
                with open(_system_configuration_file) as f:
                    # HostNameを取得する。
                    lines = f.readlines()
                    required_line_flag = False
                    for line in lines:
                        if required_line_flag:
                            # [Nodes]セクションより後の行。
                            for node in sys_conf_dict["Nodes"]:
                                if node["ControlNWIPv4"] in line:
                                    # 管理ポートアドレスを含んでいる行からHostNameを取得する。
                                    node["HostName"] = line.split(",")[0]
                        if "[Nodes]" in line:
                            required_line_flag = True
            else:
                raise FileNotFoundError("Specified configuration file does not exist.")
        elif _vm_configuration_file is not None:
            if _targets is not None:
                click.echo("Both --vm_configuration_file and --targets are set. --targets is ignored.")
            # _vm_configuration_file
            rtrn, control_addr, errmsg = configfile_util.get_control_address_from_yaml(_vm_configuration_file)
            if rtrn != 0:
                logger.error(errmsg)
                click.echo("Message: {}".format(errmsg))
                click.echo("Cause: Appropriate file is not specified.")
                click.echo("Solution: Review configuration file and specify the option value correctly.")
                exit(1)
            sys_conf_dict = {"Nodes": []}
            for addr in control_addr:
                sys_conf_dict["Nodes"].append({"HostName": "", "ControlNWIPv4": addr})
        else:
            # _targets
            targets_str = _targets
            targets_str = SeparateArgs.check_backslash(targets_str)
            targets_str = targets_str.encode("utf-8").decode("unicode-escape")
            target_list = targets_str.split(",")
            sys_conf_dict["Nodes"] = []
            for target in target_list:
                # IPアドレスの書式チェック
                try:
                    ipaddress.IPv4Address(target.strip())
                except ipaddress.AddressValueError:
                    # FQDNの書式チェック
                    if not is_valid_hostname(target):
                        raise ValueError("--targets has invalid value.")
                sys_conf_dict["Nodes"].append({"HostName": "", "ControlNWIPv4": target})

        # 実行に時間がかかることを通知しておく
        click.echo('Takes several minutes to complete request.')

        # fingerprint取得
        cert = None
        fingerprint = None
        config = Configuration()
        if config.verify_ssl is True:
            # サーバ証明書検証あり
            parsed_url = urlparse(config.host)
            host = re.sub(r':443', "", parsed_url.netloc)

            restCertUtil = RestCertificateUtil()
            cert, fingerprint, errlist = restCertUtil.get_server_certificate(host, 443)
            if cert is None or fingerprint is None:
                # エラー発生
                click.echo("Message: {}".format(errlist[0][0]))
                click.echo("Cause: {}".format(errlist[0][1]))
                click.echo("Solution: {}".format(errlist[0][2]))
                exit(1)

        # 構成パラメータ設定モード切り替え
        logger.info("Switch configuration parameter setting mode.")
        common_util = CommonUtil()
        restCertUtil = RestCertificateUtil()
        base_url = "/ConfigurationManager/simple"
        path = "/v1/objects/storage-node-configuration-parameter/polling-mode"
        is_error = False

        # 各ストレージへ構成パラメータ設定モード切替APIを実行
        for node in sys_conf_dict["Nodes"]:
            # REST API実行
            response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('PATCH', fingerprint, node["ControlNWIPv4"], base_url, path, body=json.dumps({"isEnabled": mode_bool}), connection_timeout=20, read_timeout=20)
            # REST API実行結果切り分け
            if response is not None:
                # httpStatusCode取得
                http_status_code = common_util.get_response_status(response)
                d = json.loads(response)
                if http_status_code == 200:
                    # 構成パラメータ設定モード切替成功
                    logger.info("[{}] success to switch setting mode.".format(node["ControlNWIPv4"]))
                    click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], d['body']['isEnabled']))
                    continue
                elif http_status_code == 401:
                    is_error = True
                    # 認証失敗の場合
                    logger.error("Unauthorized.")
                    click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                    if d.get('body') != None and d['body'].get('messageId') != None:
                        click.echo("MessageId: {}".format(d['body'].get("messageId")))
                        click.echo("Message: {}".format(d['body'].get("message")))
                        click.echo("Cause: {}".format(d['body'].get("cause")))
                        click.echo("Solution: {}".format(d['body'].get("solution")))
                    click.echo("")
                    continue
                elif http_status_code == 403:
                    is_error = True
                    # 権限不足の場合
                    logger.error("Forbidden.")
                    click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                    if d.get('body') != None and d['body'].get('messageId') != None:
                        rest_message_id = d['body'].get('messageId')
                        if rest_message_id == 'KARS20008-E':
                            message_id = '19221'
                            message_dict = {'required_role': 'Security'}
                            message_management = MessageManagement('')
                            message_management.viewMessageTxt(message_id, **message_dict)
                    click.echo("")
                    continue
                elif http_status_code == 412:
                    is_error = True
                    # 適切なプラットフォームではない場合
                    logger.error("Not available sub-command.")
                    click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                    click.echo("Message: The command could not be executed.")
                    click.echo("Cause: This command is not supported by the destination storage cluster.")
                    click.echo("Solution: Verify that the destination of the command is correct. If the destination is correct, see the manual corresponding to the platform type to verify that the procedure is correct.")
                    click.echo("")
                    continue
                elif http_status_code == 500:
                    is_error = True
                    # 構成パラメータ設定モード切替失敗
                    # 内部エラー
                    logger.error("[{}] failed to switch setting mode(internal_error httpStatusCode=500).".format(node["ControlNWIPv4"]))
                    click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                    if d.get('body') != None and d['body'].get('messageId') != None:
                        click.echo("MessageId: {}".format(d['body'].get("messageId")))
                        click.echo("Message: {}".format(d['body'].get("message")))
                        click.echo("Cause: {}".format(d['body'].get("cause")))
                        click.echo("Solution: {}".format(d['body'].get("solution")))
                        click.echo("")
                    continue
                elif http_status_code == 503:
                    # 多重実行の検出によるガード
                    # リトライしておく
                    logger.error("[{}] failed to switch setting mode because other processes is running(failed_flock httpStatusCode=503). Retry to switch setting mode.".format(node["ControlNWIPv4"]))
                    time.sleep(3)
                    response, message_id, message_dict = restCertUtil.rest_access_on_fingerprint_certificate('PATCH', fingerprint, node["ControlNWIPv4"], base_url, path, body=json.dumps({"isEnabled": mode_bool}), connection_timeout=20, read_timeout=20)

                    if response is not None:
                        http_status_code = common_util.get_response_status(response)
                        d = json.loads(response)
                        if http_status_code == 200:
                            logger.info("[{}] success to switch setting mode.".format(node["ControlNWIPv4"]))
                            click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], d['body']['isEnabled']))
                            continue
                        else:
                            is_error = True
                            logger.error("[{}] failed to switch setting mode(internal_error).".format(node["ControlNWIPv4"]))
                            click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                            if d.get('body') != None and d['body'].get('messageId') != None:
                                click.echo("MessageId: {}".format(d['body'].get("messageId")))
                                click.echo("Message: {}".format(d['body'].get("message")))
                                click.echo("Cause: {}".format(d['body'].get("cause")))
                                click.echo("Solution: {}".format(d['body'].get("solution")))
                                click.echo("")
                            continue
                    else:
                        is_error = True
                        # rest_access_on_fingerprint_certificateでEXceprionが発生した場合
                        click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                        message_management = MessageManagement('')
                        if message_id == 'exception':
                            message_management.viewMessage(message_dict, msg_get=True)
                            click.echo("")
                        else:
                            message_management.viewMessageTxt(message_id, **message_dict)
                            click.echo("")
                        logger.error('check_configparammode ' + node["ControlNWIPv4"] + ' ' + message_id + ' error.')
                        continue
                else:
                    is_error = True
                    # その他のエラー
                    logger.error("[{}] failed to switch setting mode(internal_error).".format(node["ControlNWIPv4"]))
                    click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                    if d.get('body') != None and d['body'].get('messageId') != None:
                        click.echo("MessageId: {}".format(d['body'].get("messageId")))
                        click.echo("Message: {}".format(d['body'].get("message")))
                        click.echo("Cause: {}".format(d['body'].get("cause")))
                        click.echo("Solution: {}".format(d['body'].get("solution")))
                        click.echo("")
                    continue
            else:
                is_error = True
                # rest_access_on_fingerprint_certificateでExceprionが発生した場合
                click.echo("{}[{}] Configuration parameter setting mode : {}".format(node["HostName"], node["ControlNWIPv4"], "Error"))
                message_management = MessageManagement('')
                if message_id == 'exception':
                    message_management.viewMessage(message_dict, msg_get=True)
                    click.echo("")
                else:
                    message_management.viewMessageTxt(message_id, **message_dict)
                    click.echo("")
                logger.error('check_configparammode ' + node["ControlNWIPv4"] + ' ' + message_id + ' error.')
                continue

        # 異常があった場合
        if is_error:
            exit(1)

    except FileNotFoundError as e:
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: {}".format(e))
        click.echo("Cause: The file does not exist in the specified path.")
        click.echo("Solution: Specify the file path correctly.")
        exit(1)
    except ValueError as e:
        if (traceback):
            logger.error(traceback.format_exc())
        logger.error(e)
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: {}".format(e))
        click.echo("Cause: Appropriate option is not specified.")
        click.echo("Solution: Specify the option value correctly.")
        exit(1)
    except urllib3.exceptions.MaxRetryError as e:
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: An error has occurred when executing the command.")
        click.echo("Cause: Communication with storage node failed.")
        click.echo("Solution: Check if the specified IP address or FQDN is correct and verify whether network communication between the controller node and the storage node is possible.")
        exit(1)
    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        logger.error(e)
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: An error has occurred when executing the command.")
        click.echo("Cause: An unexpected error occurred.")
        click.echo("Solution: Collect the logs, and then contact customer support.")
        exit(1)


def commands():
    commands = {}
    commands['configuration_parameter_setting_mode'] = configuration_parameter_setting_mode
    return commands
