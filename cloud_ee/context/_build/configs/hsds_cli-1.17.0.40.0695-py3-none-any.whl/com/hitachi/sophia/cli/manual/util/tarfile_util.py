"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import tarfile


class TarfileUtil(object):
    def tar_extract(self, tar_file, mode, dir_name):
        # tarアーカイブをアーカイブ名のディレクトリ配下に解凍する
        with tarfile.open(tar_file, mode) as tar:
            tar.extractall(path=dir_name)
