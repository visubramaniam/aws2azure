# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--target_server','_target_server',metavar='<str>',help='Target external authentication server.',required=True)
def external_auth_server_root_certificate_download(_target_server,):
    """
    Downloads a root certificate used in communication with the external authentication server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "external_auth_server_root_certificate_download"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _target_server is not None:
            subCommandLogtxt += "--target_server " + str(_target_server) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        #Enumチェック
        allowed_values = ["primary1", "secondary1"]
        if _target_server is not None:
            if _target_server not in allowed_values:
                raise ValueError(
                    "Invalid value for `target_server` ({0}), (Select only one) {1}"
                    .format(_target_server, allowed_values)
            )
        
        
        


        
        
        
        
        
        #cliSubCommand = "external_auth_server_root_certificate_download"


















                

    
        
        
        
        
        try:

            defaultFileName = "download-external-auth-server-root-certificate.crt"
        
            fileutil = FileUtil(defaultFileName)

            dirname, filename = fileutil.locate_download_file(defaultFileName)
            download_path = os.path.join(dirname, filename)
        
            #ファイルが存在するか
            if (os.path.isfile(os.path.join(dirname, filename))):
                # 既にファイルが存在している
                mssageManagement = MessageManagement('')
                messageId = '19006'
                messageDict = {'filePath': os.path.abspath(defaultFileName)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)


            if not ('Authorization' in config.api_key):
                warningbanner = WarningBanner()
                warningbanner.sub_command_name = cliSubCommand
                login_message_response = warningbanner.get_login_message()
                login_message = warningbanner.view_warning_banner(login_message_response)

                commonutil.view_error()

                #空文字,Nullの場合はログインメッセージを表示しない
                if(login_message):
                    click.echo(login_message, err=True)

            commonutil.input_password()

            #ファイルが存在するか(2回目)
            if (os.path.isfile(os.path.join(dirname, filename))):
                # 既にファイルが存在している
                mssageManagement = MessageManagement('')
                messageId = '19006'
                messageDict = {'filePath': os.path.abspath(defaultFileName)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)



            # ストレージクラスターとCLIのバージョンチェック
            versioncheck = VersionCheck()
            api_version_response = versioncheck.get_api_version()
            versioncheck.version_check(api_version_response)

            response = api.download_external_auth_server_root_certificate(_target_server, callback=None, debug="false" ,_preload_content=False)

        # print(response)
            if(response):
            
                cli_response = collections.OrderedDict()
                cli_response['httpStatusCode'] = response.status
            
                if(response.status!=200):
                    if response.data:
                        cli_response['body'] = ApiClient().deserialize_json_to_body_or_exit(response, _preload_content=False)
                    
                    data = json.dumps(cli_response, indent=4, separators=(',', ': '))
                    output_util = OutputUtil()
                    output_util.echo_normal(data, config.format, cliSubCommand)

                    #click.echo(data)
                    exit(commonutil.get_cli_exit_code_for_api_execution(response.status))

        except Exception as e:
            if (traceback):
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

        saveFile = None
        try:
            with open(download_path, 'wb') as saveFile:
                saveFile.write(response.data)
            if config.format == 'text':
                click.echo('Message: ' + 'Download completed.')
                click.echo('Output File Path: ' + os.path.abspath(defaultFileName))
            else:
                cli_response['message'] = 'Download completed.'
                cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
                cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
                click.echo(cli_response)

            #cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
            cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
            #click.echo(cli_response)

        except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
            messageId = '19007'
            messageDict = {
                'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                    defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except FileExistsError as e:  # 既にファイルが存在している
            messageId = '19007'
            messageDict = {'exception': 'A file has already existed. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except OSError as e:  # OSError かつ errno ENOSPCの場合
            if e.errno == errno.ENOSPC:
                messageId = '19007'
                messageDict = {
                    'exception': 'No more space for writing is available on the device. (File path = ' + os.path.abspath(
                        defaultFileName) + ')'}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

            else:
                messageId = '19007'
                strErr = ','.join(map(str, e.args))
                messageDict = {'exception': strErr}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

        except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
            messageId = '19007'
            messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except Exception as e:
            #ファイルの保存に失敗
            messageId = '19007'
            strErr = ' '.join(map(str, e.args))
            messageDict = {'exception': strErr}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)

            exit(1)
        finally:
            if (saveFile):
                saveFile.close()

        #print('Download external auth server crl file Success')
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--root_certificate','_root_certificate',metavar='<file>',help='Root certificate file used in communication with the external authentication server. ',required=True)
@click.option('--target_server','_target_server',metavar='<str>',help='Target external authentication server.',required=True)
def external_auth_server_root_certificate_import(_root_certificate,_target_server,):
    """
    Imports a root certificate used in communication with the external authentication server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "external_auth_server_root_certificate_import"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _root_certificate is not None:
            subCommandLogtxt += "--root_certificate " + str(_root_certificate) + " "


        if _target_server is not None:
            subCommandLogtxt += "--target_server " + str(_target_server) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        


        #Enumチェック
        allowed_values = ["primary1", "secondary1"]
        if _target_server is not None:
            if _target_server not in allowed_values:
                raise ValueError(
                    "Invalid value for `target_server` ({0}), (Select only one) {1}"
                    .format(_target_server, allowed_values)
            )
        
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "external_auth_server_root_certificate_import"






























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        
        #ファイルが存在するか
        if not(os.path.isfile(_root_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_root_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        
        #ファイルが存在するか 2回目
        if not(os.path.isfile(_root_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_root_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.import_root_certificate_external_auth_server(_root_certificate, _target_server, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _root_certificate) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_root_certificate) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ',required=True)
@click.option('--current_password','_current_password',type=str,metavar='<str>',hidden=True,help='Current password.')
@click.option('--new_password','_new_password',type=str,metavar='<str>',hidden=True,help='New password.')
def user_password_set(_user_id,_current_password,_new_password,):
    """
    Changes the password of the user. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('','','')
        auth_parameter_util.check_auth_parameter('','','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_password_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "











        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_password_set"

        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `user_role`, length must be less than or equal to `255`")
        if _user_id is not None and len(_user_id) < 5:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `5`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `user_role`, length must be greater than or equal to `5`")
        if  _user_id is not None and not re.search('^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `user_role`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")



























                
        from com.hitachi.sophia.rest_client.autogen.models.ChangePasswordParam import ChangePasswordParam
        _change_password = ChangePasswordParam()

    
        
        from com.hitachi.sophia.rest_client.autogen.models.User import User

    
        



        if _current_password is None:
            _current_password = commonutil.input_stdin('current_password')

        if _current_password is not None:
            if isinstance(_current_password, str):
                _current_password = SeparateArgs.check_backslash(_current_password)
                _current_password = _current_password.encode("utf-8").decode("unicode-escape")

        if _new_password is None:
            _new_password = commonutil.input_stdin('new_password')

        if _new_password is not None:
            if isinstance(_new_password, str):
                _new_password = SeparateArgs.check_backslash(_new_password)
                _new_password = _new_password.encode("utf-8").decode("unicode-escape")

        _change_password.current_password = _current_password
        _change_password.new_password = _new_password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.user_role(_user_id, change_password = _change_password, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def external_auth_server_setting_verify_connectivity():
    """
    Verifies the connection with the external authentication server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "external_auth_server_setting_verify_connectivity"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "external_auth_server_setting_verify_connectivity"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ExternalAuthServerConnectionVerification import ExternalAuthServerConnectionVerification

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_external_auth_server_setting_actions_verify_connectivity_invoke_post(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def external_auth_server_setting_show():
    """
    Obtains the settings of the external authentication server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "external_auth_server_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "external_auth_server_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ExternalAuthServerSetting import ExternalAuthServerSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_external_auth_server_setting_get(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables external authentication.')
@click.option('--auth_protocol','_auth_protocol',type=str,metavar='<str>',help='Authentication protocol used for external authentication.')
@click.option('--mapping_mode','_mapping_mode',type=str,metavar='<str>',help='Unit of mapping to the LDAP server.')
@click.option('--primary_ldap_server_url','_primary_ldap_server_url',type=str,metavar='<str>',help='URL of the primary LDAP server.')
@click.option('--secondary_ldap_server_url','_secondary_ldap_server_url',type=str,metavar='<str>',help='URL of the secondary LDAP server.')
@click.option('--is_start_tls_enabled','_is_start_tls_enabled',metavar='<bool>',help='Enables or disables StartTLS communication for LDAP authentication.')
@click.option('--base_dn','_base_dn',type=str,metavar='<str>',help='Distinguished Name (Base DN) used as the point from where a user or user group will be searched for LDAP authentication.')
@click.option('--bind_dn','_bind_dn',type=str,metavar='<str>',help='Distinguished Name (Bind DN) used for performing a search on a tree specified in base_dn.')
@click.option('--bind_dn_password','_bind_dn_password',type=str,metavar='<str>',hidden=True,help='Password for "Distinguished Name" specified in bind_dn.')
@click.option('--user_id_attribute','_user_id_attribute',type=str,metavar='<str>',help='LDAP Attribute Type mapped as a user ID.')
@click.option('--user_tree_dn','_user_tree_dn',type=str,metavar='<str>',help='Distinguished Name (Base DN) used as the point from where a user will be searched for LDAP authentication.')
@click.option('--user_object_class','_user_object_class',type=str,metavar='<str>',help='LDAP object class to be mapped as a user.')
@click.option('--external_group_name_attribute','_external_group_name_attribute',type=str,metavar='<str>',help='LDAP Attribute Type to be mapped as externalGroupName in a user group.')
@click.option('--user_group_tree_dn','_user_group_tree_dn',type=str,metavar='<str>',help='Distinguished Name (Base DN) used as the point from where a user group will be searched for LDAP authentication.')
@click.option('--user_group_object_class','_user_group_object_class',type=str,metavar='<str>',help='LDAP object class to be mapped as a user group.')
@click.option('--timeout_seconds','_timeout_seconds',type=int,metavar='<int>',help='Timeout time (seconds) applied to the connection to the LDAP server.')
@click.option('--retry_interval_milliseconds','_retry_interval_milliseconds',type=int,metavar='<int>',help='Retry interval (milliseconds) in communication with the LDAP server.')
@click.option('--max_retries','_max_retries',type=int,metavar='<int>',help='Number of retries in communication with the LDAP server.')
def external_auth_server_setting_set(_is_enabled,_auth_protocol,_mapping_mode,_primary_ldap_server_url,_secondary_ldap_server_url,_is_start_tls_enabled,_base_dn,_bind_dn,_bind_dn_password,_user_id_attribute,_user_tree_dn,_user_object_class,_external_group_name_attribute,_user_group_tree_dn,_user_group_object_class,_timeout_seconds,_retry_interval_milliseconds,_max_retries,):
    """
    Edits the settings of the external authentication server. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "external_auth_server_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "




        if _auth_protocol is not None:
            subCommandLogtxt += "--auth_protocol " + str(_auth_protocol) + " "




        if _mapping_mode is not None:
            subCommandLogtxt += "--mapping_mode " + str(_mapping_mode) + " "




        if _primary_ldap_server_url is not None:
            subCommandLogtxt += "--primary_ldap_server_url " + str(_primary_ldap_server_url) + " "




        if _secondary_ldap_server_url is not None:
            subCommandLogtxt += "--secondary_ldap_server_url " + str(_secondary_ldap_server_url) + " "




        if _is_start_tls_enabled is not None:
            subCommandLogtxt += "--is_start_tls_enabled " + str(_is_start_tls_enabled) + " "




        if _base_dn is not None:
            subCommandLogtxt += "--base_dn " + str(_base_dn) + " "




        if _bind_dn is not None:
            subCommandLogtxt += "--bind_dn " + str(_bind_dn) + " "




        if _user_id_attribute is not None:
            subCommandLogtxt += "--user_id_attribute " + str(_user_id_attribute) + " "




        if _user_tree_dn is not None:
            subCommandLogtxt += "--user_tree_dn " + str(_user_tree_dn) + " "




        if _user_object_class is not None:
            subCommandLogtxt += "--user_object_class " + str(_user_object_class) + " "




        if _external_group_name_attribute is not None:
            subCommandLogtxt += "--external_group_name_attribute " + str(_external_group_name_attribute) + " "




        if _user_group_tree_dn is not None:
            subCommandLogtxt += "--user_group_tree_dn " + str(_user_group_tree_dn) + " "




        if _user_group_object_class is not None:
            subCommandLogtxt += "--user_group_object_class " + str(_user_group_object_class) + " "




        if _timeout_seconds is not None:
            subCommandLogtxt += "--timeout_seconds " + str(_timeout_seconds) + " "




        if _retry_interval_milliseconds is not None:
            subCommandLogtxt += "--retry_interval_milliseconds " + str(_retry_interval_milliseconds) + " "




        if _max_retries is not None:
            subCommandLogtxt += "--max_retries " + str(_max_retries) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "external_auth_server_setting_set"













        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")
        if _auth_protocol is not None:
            if(isinstance(_auth_protocol, str)):
                _auth_protocol = SeparateArgs.check_backslash(_auth_protocol)
                _auth_protocol = _auth_protocol.encode("utf-8").decode("unicode-escape")
        if _mapping_mode is not None:
            if(isinstance(_mapping_mode, str)):
                _mapping_mode = SeparateArgs.check_backslash(_mapping_mode)
                _mapping_mode = _mapping_mode.encode("utf-8").decode("unicode-escape")
        if _primary_ldap_server_url is not None:
            if(isinstance(_primary_ldap_server_url, str)):
                _primary_ldap_server_url = SeparateArgs.check_backslash(_primary_ldap_server_url)
                _primary_ldap_server_url = _primary_ldap_server_url.encode("utf-8").decode("unicode-escape")
        if _secondary_ldap_server_url is not None:
            if(isinstance(_secondary_ldap_server_url, str)):
                _secondary_ldap_server_url = SeparateArgs.check_backslash(_secondary_ldap_server_url)
                _secondary_ldap_server_url = _secondary_ldap_server_url.encode("utf-8").decode("unicode-escape")
        if _is_start_tls_enabled is not None:
            if(isinstance(_is_start_tls_enabled, str)):
                _is_start_tls_enabled = SeparateArgs.check_backslash(_is_start_tls_enabled)
                _is_start_tls_enabled = _is_start_tls_enabled.encode("utf-8").decode("unicode-escape")
        if _base_dn is not None:
            if(isinstance(_base_dn, str)):
                _base_dn = SeparateArgs.check_backslash(_base_dn)
                _base_dn = _base_dn.encode("utf-8").decode("unicode-escape")
        if _bind_dn is not None:
            if(isinstance(_bind_dn, str)):
                _bind_dn = SeparateArgs.check_backslash(_bind_dn)
                _bind_dn = _bind_dn.encode("utf-8").decode("unicode-escape")
        if _user_id_attribute is not None:
            if(isinstance(_user_id_attribute, str)):
                _user_id_attribute = SeparateArgs.check_backslash(_user_id_attribute)
                _user_id_attribute = _user_id_attribute.encode("utf-8").decode("unicode-escape")
        if _user_tree_dn is not None:
            if(isinstance(_user_tree_dn, str)):
                _user_tree_dn = SeparateArgs.check_backslash(_user_tree_dn)
                _user_tree_dn = _user_tree_dn.encode("utf-8").decode("unicode-escape")
        if _user_object_class is not None:
            if(isinstance(_user_object_class, str)):
                _user_object_class = SeparateArgs.check_backslash(_user_object_class)
                _user_object_class = _user_object_class.encode("utf-8").decode("unicode-escape")
        if _external_group_name_attribute is not None:
            if(isinstance(_external_group_name_attribute, str)):
                _external_group_name_attribute = SeparateArgs.check_backslash(_external_group_name_attribute)
                _external_group_name_attribute = _external_group_name_attribute.encode("utf-8").decode("unicode-escape")
        if _user_group_tree_dn is not None:
            if(isinstance(_user_group_tree_dn, str)):
                _user_group_tree_dn = SeparateArgs.check_backslash(_user_group_tree_dn)
                _user_group_tree_dn = _user_group_tree_dn.encode("utf-8").decode("unicode-escape")
        if _user_group_object_class is not None:
            if(isinstance(_user_group_object_class, str)):
                _user_group_object_class = SeparateArgs.check_backslash(_user_group_object_class)
                _user_group_object_class = _user_group_object_class.encode("utf-8").decode("unicode-escape")
        if _timeout_seconds is not None:
            if(isinstance(_timeout_seconds, str)):
                _timeout_seconds = SeparateArgs.check_backslash(_timeout_seconds)
                _timeout_seconds = _timeout_seconds.encode("utf-8").decode("unicode-escape")
        if _retry_interval_milliseconds is not None:
            if(isinstance(_retry_interval_milliseconds, str)):
                _retry_interval_milliseconds = SeparateArgs.check_backslash(_retry_interval_milliseconds)
                _retry_interval_milliseconds = _retry_interval_milliseconds.encode("utf-8").decode("unicode-escape")
        if _max_retries is not None:
            if(isinstance(_max_retries, str)):
                _max_retries = SeparateArgs.check_backslash(_max_retries)
                _max_retries = _max_retries.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchExternalAuthServerSettingParam import PatchExternalAuthServerSettingParam
        tmp_patch_external_auth_server_setting_param = PatchExternalAuthServerSettingParam()
        patch_external_auth_server_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.LdapSettingOfEditExternalAuthServerSetting import LdapSettingOfEditExternalAuthServerSetting
        tmp_ldap_setting_of_edit_external_auth_server_setting = LdapSettingOfEditExternalAuthServerSetting()
        ldap_setting_of_edit_external_auth_server_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        patch_external_auth_server_setting_param = commonutil.set_parameter_with_instance(patch_external_auth_server_setting_param, tmp_patch_external_auth_server_setting_param, 'is_enabled', _is_enabled)
        

        patch_external_auth_server_setting_param = commonutil.set_parameter_with_instance(patch_external_auth_server_setting_param, tmp_patch_external_auth_server_setting_param, 'auth_protocol', _auth_protocol)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'mapping_mode', _mapping_mode)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'primary_ldap_server_url', _primary_ldap_server_url)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'secondary_ldap_server_url', _secondary_ldap_server_url)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'is_start_tls_enabled', _is_start_tls_enabled)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'base_dn', _base_dn)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'bind_dn', _bind_dn)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'bind_dn_password', _bind_dn_password)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'user_id_attribute', _user_id_attribute)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'user_tree_dn', _user_tree_dn)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'user_object_class', _user_object_class)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'external_group_name_attribute', _external_group_name_attribute)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'user_group_tree_dn', _user_group_tree_dn)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'user_group_object_class', _user_group_object_class)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'timeout_seconds', _timeout_seconds)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'retry_interval_milliseconds', _retry_interval_milliseconds)
        

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'max_retries', _max_retries)
        patch_external_auth_server_setting_param = commonutil.set_parameter_with_instance(patch_external_auth_server_setting_param, tmp_patch_external_auth_server_setting_param, 'ldap_setting', ldap_setting_of_edit_external_auth_server_setting)
        _patch_external_auth_server_setting_param = patch_external_auth_server_setting_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.ExternalAuthServerSetting import ExternalAuthServerSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _bind_dn_password is None:
            _bind_dn_password = commonutil.input_stdin_allow_empty('bind_dn_password (if omitted, press the [Enter] key)')

        if _bind_dn_password is not None:
            if isinstance(_bind_dn_password, str):
                _bind_dn_password = SeparateArgs.check_backslash(_bind_dn_password)
                _bind_dn_password = _bind_dn_password.encode("utf-8").decode("unicode-escape")

        ldap_setting_of_edit_external_auth_server_setting = commonutil.set_parameter_with_instance(ldap_setting_of_edit_external_auth_server_setting, tmp_ldap_setting_of_edit_external_auth_server_setting, 'bind_dn_password', _bind_dn_password)
        patch_external_auth_server_setting_param = commonutil.set_parameter_with_instance(patch_external_auth_server_setting_param, tmp_patch_external_auth_server_setting_param, 'ldap_setting', ldap_setting_of_edit_external_auth_server_setting)
        _patch_external_auth_server_setting_param = patch_external_auth_server_setting_param

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_external_auth_server_setting_patch(patch_external_auth_server_setting_param = _patch_external_auth_server_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def user_auth_setting_show():
    """
    Obtains the user authentication settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_auth_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "user_auth_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserAuthSetting import UserAuthSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_auth_setting_get(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--min_length','_min_length',type=int,metavar='<int>',help='Minimum number of characters in a password.')
@click.option('--min_number_of_upper_case_chars','_min_number_of_upper_case_chars',type=int,metavar='<int>',help='Minimum number of uppercase alphabetical characters contained in a password.')
@click.option('--min_number_of_lower_case_chars','_min_number_of_lower_case_chars',type=int,metavar='<int>',help='Minimum number of lowercase alphabetical characters contained in a password.')
@click.option('--min_number_of_numerals','_min_number_of_numerals',type=int,metavar='<int>',help='Minimum number of numerals (0 to 9) contained in a password.')
@click.option('--min_number_of_symbols','_min_number_of_symbols',type=int,metavar='<int>',help='Minimum number of symbols (excluding alphanumeric characters) contained in a password.')
@click.option('--number_of_password_history','_number_of_password_history',type=int,metavar='<int>',help='Number of generations for which password reuse is prohibited assuming the current password as generation 1.')
@click.option('--requires_initial_password_reset','_requires_initial_password_reset',metavar='<bool>',help='Whether a new user is forced to change the default password before the initial login.')
@click.option('--min_age_days','_min_age_days',type=int,metavar='<int>',help='Number of days after which you can change the password again after you changed the password last.')
@click.option('--max_age_days','_max_age_days',type=int,metavar='<int>',help='Number of days during which the password is valid after changing the password last.')
@click.option('--max_attempts','_max_attempts',type=int,metavar='<int>',help='Number of consecutive login failures until the account is locked.')
@click.option('--lockout_seconds','_lockout_seconds',type=int,metavar='<int>',help='Number of seconds after which the account is unlocked after it is locked due to consecutive login failures.')
@click.option('--max_lifetime_seconds','_max_lifetime_seconds',type=int,metavar='<int>',help='Token lifetime.')
@click.option('--max_idle_seconds','_max_idle_seconds',type=int,metavar='<int>',help='Time until a session times out.')
def user_auth_setting_set(_min_length,_min_number_of_upper_case_chars,_min_number_of_lower_case_chars,_min_number_of_numerals,_min_number_of_symbols,_number_of_password_history,_requires_initial_password_reset,_min_age_days,_max_age_days,_max_attempts,_lockout_seconds,_max_lifetime_seconds,_max_idle_seconds,):
    """
    Edits the user authentication settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_auth_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _min_length is not None:
            subCommandLogtxt += "--min_length " + str(_min_length) + " "




        if _min_number_of_upper_case_chars is not None:
            subCommandLogtxt += "--min_number_of_upper_case_chars " + str(_min_number_of_upper_case_chars) + " "




        if _min_number_of_lower_case_chars is not None:
            subCommandLogtxt += "--min_number_of_lower_case_chars " + str(_min_number_of_lower_case_chars) + " "




        if _min_number_of_numerals is not None:
            subCommandLogtxt += "--min_number_of_numerals " + str(_min_number_of_numerals) + " "




        if _min_number_of_symbols is not None:
            subCommandLogtxt += "--min_number_of_symbols " + str(_min_number_of_symbols) + " "




        if _number_of_password_history is not None:
            subCommandLogtxt += "--number_of_password_history " + str(_number_of_password_history) + " "




        if _requires_initial_password_reset is not None:
            subCommandLogtxt += "--requires_initial_password_reset " + str(_requires_initial_password_reset) + " "




        if _min_age_days is not None:
            subCommandLogtxt += "--min_age_days " + str(_min_age_days) + " "




        if _max_age_days is not None:
            subCommandLogtxt += "--max_age_days " + str(_max_age_days) + " "




        if _max_attempts is not None:
            subCommandLogtxt += "--max_attempts " + str(_max_attempts) + " "




        if _lockout_seconds is not None:
            subCommandLogtxt += "--lockout_seconds " + str(_lockout_seconds) + " "




        if _max_lifetime_seconds is not None:
            subCommandLogtxt += "--max_lifetime_seconds " + str(_max_lifetime_seconds) + " "




        if _max_idle_seconds is not None:
            subCommandLogtxt += "--max_idle_seconds " + str(_max_idle_seconds) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "user_auth_setting_set"













        if _min_length is not None:
            if(isinstance(_min_length, str)):
                _min_length = SeparateArgs.check_backslash(_min_length)
                _min_length = _min_length.encode("utf-8").decode("unicode-escape")
        if _min_number_of_upper_case_chars is not None:
            if(isinstance(_min_number_of_upper_case_chars, str)):
                _min_number_of_upper_case_chars = SeparateArgs.check_backslash(_min_number_of_upper_case_chars)
                _min_number_of_upper_case_chars = _min_number_of_upper_case_chars.encode("utf-8").decode("unicode-escape")
        if _min_number_of_lower_case_chars is not None:
            if(isinstance(_min_number_of_lower_case_chars, str)):
                _min_number_of_lower_case_chars = SeparateArgs.check_backslash(_min_number_of_lower_case_chars)
                _min_number_of_lower_case_chars = _min_number_of_lower_case_chars.encode("utf-8").decode("unicode-escape")
        if _min_number_of_numerals is not None:
            if(isinstance(_min_number_of_numerals, str)):
                _min_number_of_numerals = SeparateArgs.check_backslash(_min_number_of_numerals)
                _min_number_of_numerals = _min_number_of_numerals.encode("utf-8").decode("unicode-escape")
        if _min_number_of_symbols is not None:
            if(isinstance(_min_number_of_symbols, str)):
                _min_number_of_symbols = SeparateArgs.check_backslash(_min_number_of_symbols)
                _min_number_of_symbols = _min_number_of_symbols.encode("utf-8").decode("unicode-escape")
        if _number_of_password_history is not None:
            if(isinstance(_number_of_password_history, str)):
                _number_of_password_history = SeparateArgs.check_backslash(_number_of_password_history)
                _number_of_password_history = _number_of_password_history.encode("utf-8").decode("unicode-escape")
        if _requires_initial_password_reset is not None:
            if(isinstance(_requires_initial_password_reset, str)):
                _requires_initial_password_reset = SeparateArgs.check_backslash(_requires_initial_password_reset)
                _requires_initial_password_reset = _requires_initial_password_reset.encode("utf-8").decode("unicode-escape")
        if _min_age_days is not None:
            if(isinstance(_min_age_days, str)):
                _min_age_days = SeparateArgs.check_backslash(_min_age_days)
                _min_age_days = _min_age_days.encode("utf-8").decode("unicode-escape")
        if _max_age_days is not None:
            if(isinstance(_max_age_days, str)):
                _max_age_days = SeparateArgs.check_backslash(_max_age_days)
                _max_age_days = _max_age_days.encode("utf-8").decode("unicode-escape")
        if _max_attempts is not None:
            if(isinstance(_max_attempts, str)):
                _max_attempts = SeparateArgs.check_backslash(_max_attempts)
                _max_attempts = _max_attempts.encode("utf-8").decode("unicode-escape")
        if _lockout_seconds is not None:
            if(isinstance(_lockout_seconds, str)):
                _lockout_seconds = SeparateArgs.check_backslash(_lockout_seconds)
                _lockout_seconds = _lockout_seconds.encode("utf-8").decode("unicode-escape")
        if _max_lifetime_seconds is not None:
            if(isinstance(_max_lifetime_seconds, str)):
                _max_lifetime_seconds = SeparateArgs.check_backslash(_max_lifetime_seconds)
                _max_lifetime_seconds = _max_lifetime_seconds.encode("utf-8").decode("unicode-escape")
        if _max_idle_seconds is not None:
            if(isinstance(_max_idle_seconds, str)):
                _max_idle_seconds = SeparateArgs.check_backslash(_max_idle_seconds)
                _max_idle_seconds = _max_idle_seconds.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchUserAuthSettingParam import PatchUserAuthSettingParam
        tmp_patch_user_auth_setting_param = PatchUserAuthSettingParam()
        patch_user_auth_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.PasswordComplexitySettingOfEditUserAuthSetting import PasswordComplexitySettingOfEditUserAuthSetting
        tmp_password_complexity_setting_of_edit_user_auth_setting = PasswordComplexitySettingOfEditUserAuthSetting()
        password_complexity_setting_of_edit_user_auth_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.PasswordAgeSettingOfEditUserAuthSetting import PasswordAgeSettingOfEditUserAuthSetting
        tmp_password_age_setting_of_edit_user_auth_setting = PasswordAgeSettingOfEditUserAuthSetting()
        password_age_setting_of_edit_user_auth_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.LockoutSettingOfEditUserAuthSetting import LockoutSettingOfEditUserAuthSetting
        tmp_lockout_setting_of_edit_user_auth_setting = LockoutSettingOfEditUserAuthSetting()
        lockout_setting_of_edit_user_auth_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.SessionSettingOfEditUserAuthSetting import SessionSettingOfEditUserAuthSetting
        tmp_session_setting_of_edit_user_auth_setting = SessionSettingOfEditUserAuthSetting()
        session_setting_of_edit_user_auth_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        password_complexity_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_complexity_setting_of_edit_user_auth_setting, tmp_password_complexity_setting_of_edit_user_auth_setting, 'min_length', _min_length)
        

        password_complexity_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_complexity_setting_of_edit_user_auth_setting, tmp_password_complexity_setting_of_edit_user_auth_setting, 'min_number_of_upper_case_chars', _min_number_of_upper_case_chars)
        

        password_complexity_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_complexity_setting_of_edit_user_auth_setting, tmp_password_complexity_setting_of_edit_user_auth_setting, 'min_number_of_lower_case_chars', _min_number_of_lower_case_chars)
        

        password_complexity_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_complexity_setting_of_edit_user_auth_setting, tmp_password_complexity_setting_of_edit_user_auth_setting, 'min_number_of_numerals', _min_number_of_numerals)
        

        password_complexity_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_complexity_setting_of_edit_user_auth_setting, tmp_password_complexity_setting_of_edit_user_auth_setting, 'min_number_of_symbols', _min_number_of_symbols)
        

        password_complexity_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_complexity_setting_of_edit_user_auth_setting, tmp_password_complexity_setting_of_edit_user_auth_setting, 'number_of_password_history', _number_of_password_history)
        

        password_age_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_age_setting_of_edit_user_auth_setting, tmp_password_age_setting_of_edit_user_auth_setting, 'requires_initial_password_reset', _requires_initial_password_reset)
        

        password_age_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_age_setting_of_edit_user_auth_setting, tmp_password_age_setting_of_edit_user_auth_setting, 'min_age_days', _min_age_days)
        

        password_age_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(password_age_setting_of_edit_user_auth_setting, tmp_password_age_setting_of_edit_user_auth_setting, 'max_age_days', _max_age_days)
        

        lockout_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(lockout_setting_of_edit_user_auth_setting, tmp_lockout_setting_of_edit_user_auth_setting, 'max_attempts', _max_attempts)
        

        lockout_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(lockout_setting_of_edit_user_auth_setting, tmp_lockout_setting_of_edit_user_auth_setting, 'lockout_seconds', _lockout_seconds)
        

        session_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(session_setting_of_edit_user_auth_setting, tmp_session_setting_of_edit_user_auth_setting, 'max_lifetime_seconds', _max_lifetime_seconds)
        

        session_setting_of_edit_user_auth_setting = commonutil.set_parameter_with_instance(session_setting_of_edit_user_auth_setting, tmp_session_setting_of_edit_user_auth_setting, 'max_idle_seconds', _max_idle_seconds)
        patch_user_auth_setting_param = commonutil.set_parameter_with_instance(patch_user_auth_setting_param, tmp_patch_user_auth_setting_param, 'password_complexity_setting', password_complexity_setting_of_edit_user_auth_setting)
        patch_user_auth_setting_param = commonutil.set_parameter_with_instance(patch_user_auth_setting_param, tmp_patch_user_auth_setting_param, 'password_age_setting', password_age_setting_of_edit_user_auth_setting)
        patch_user_auth_setting_param = commonutil.set_parameter_with_instance(patch_user_auth_setting_param, tmp_patch_user_auth_setting_param, 'lockout_setting', lockout_setting_of_edit_user_auth_setting)
        patch_user_auth_setting_param = commonutil.set_parameter_with_instance(patch_user_auth_setting_param, tmp_patch_user_auth_setting_param, 'session_setting', session_setting_of_edit_user_auth_setting)
        _patch_user_auth_setting_param = patch_user_auth_setting_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserAuthSetting import UserAuthSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_auth_setting_patch(patch_user_auth_setting_param = _patch_user_auth_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
def user_group_list(_vps_id,):
    """
    Obtains the list of user groups. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_group_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "user_group_list"

        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `v1_objects_user_groups_get`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserGroupSummaryList import UserGroupSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_groups_get(vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_group_id','_user_group_id',type=str,metavar='<str>',help='User group ID.',required=True)
@click.option('--external_group_name','_external_group_name',type=str,metavar='<str>',help='Name of the group registered with an external authorization server when the external authorization server is linked.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--role_names','_role_names',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of roles of the user group.',required=True)
@click.option('--scope','_scope',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of virtual private storage (VPS) IDs to which the user group is allowed access.')
def user_group_create(_user_group_id,_role_names,_external_group_name,_vps_id,_scope,):
    """
    Creates a user group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_group_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _user_group_id is not None:
            subCommandLogtxt += "--user_group_id " + str(_user_group_id) + " "




        if _role_names is not None:
            subCommandLogtxt += "--role_names " + str(_role_names) + " "




        if _external_group_name is not None:
            subCommandLogtxt += "--external_group_name " + str(_external_group_name) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "




        if _scope is not None:
            subCommandLogtxt += "--scope " + str(_scope) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_group_create"



















        if _user_group_id is not None:
            if(isinstance(_user_group_id, str)):
                _user_group_id = SeparateArgs.check_backslash(_user_group_id)
                _user_group_id = _user_group_id.encode("utf-8").decode("unicode-escape")
        if _role_names is not None:
            if(isinstance(_role_names, str)):
                _role_names = SeparateArgs.check_backslash(_role_names)
                _role_names = _role_names.encode("utf-8").decode("unicode-escape")
        if _external_group_name is not None:
            if(isinstance(_external_group_name, str)):
                _external_group_name = SeparateArgs.check_backslash(_external_group_name)
                _external_group_name = _external_group_name.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")
        if _scope is not None:
            if(isinstance(_scope, str)):
                _scope = SeparateArgs.check_backslash(_scope)
                _scope = _scope.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateUserGroupParam import CreateUserGroupParam
        _create_user_group_param = CreateUserGroupParam()
        _create_user_group_param.user_group_id = _user_group_id
        _create_user_group_param.role_names = _role_names
        _create_user_group_param.external_group_name = _external_group_name
        _create_user_group_param.vps_id = _vps_id
        _create_user_group_param.scope = _scope

    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserGroup import UserGroup

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_groups_post(create_user_group_param = _create_user_group_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_group_id','_user_group_id',metavar='<str>',help='User group ID. ',required=True)
def user_group_delete(_user_group_id,):
    """
    Deletes a user group. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_group_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_group_id is not None:
            subCommandLogtxt += "--user_group_id " + str(_user_group_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "user_group_delete"

        if _user_group_id is not None and len(_user_group_id) > 64:
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `64`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_delete`, length must be less than or equal to `64`")
        if _user_group_id is not None and len(_user_group_id) < 1:
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_delete`, length must be greater than or equal to `1`")
        if  _user_group_id is not None and not re.search('^[a-zA-Z0-9!#\\$%&\'\\-\\.@\\^_`\\{\\}~]{1,64}$', _user_group_id):
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[a-zA-Z0-9!#\\$%&'\\-\\.@\\^_`\\{\\}~]{1,64}$/`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_delete`, must conform to the pattern `/^[a-zA-Z0-9!#\\$%&'\\-\\.@\\^_`\\{\\}~]{1,64}$/`")

















                

    
        
        

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_groups_user_group_id_delete(_user_group_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_group_id','_user_group_id',metavar='<str>',help='User group ID. ',required=True)
def user_group_show(_user_group_id,):
    """
    Obtains user group information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_group_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_group_id is not None:
            subCommandLogtxt += "--user_group_id " + str(_user_group_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "user_group_show"

        if _user_group_id is not None and len(_user_group_id) > 64:
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `64`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_get`, length must be less than or equal to `64`")
        if _user_group_id is not None and len(_user_group_id) < 1:
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_get`, length must be greater than or equal to `1`")
        if  _user_group_id is not None and not re.search('^[a-zA-Z0-9!#\\$%&\'\\-\\.@\\^_`\\{\\}~]{1,64}$', _user_group_id):
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[a-zA-Z0-9!#\\$%&'\\-\\.@\\^_`\\{\\}~]{1,64}$/`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_get`, must conform to the pattern `/^[a-zA-Z0-9!#\\$%&'\\-\\.@\\^_`\\{\\}~]{1,64}$/`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserGroup import UserGroup

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_groups_user_group_id_get(_user_group_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_group_id','_user_group_id',metavar='<str>',help='User group ID. ',required=True)
@click.option('--role_names','_role_names',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of roles of the user group.')
@click.option('--scope','_scope',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of virtual private storage (VPS) IDs to which the user group is allowed access.')
def user_group_set(_user_group_id,_role_names,_scope,):
    """
    Edits user group information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_group_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_group_id is not None:
            subCommandLogtxt += "--user_group_id " + str(_user_group_id) + " "







        if _role_names is not None:
            subCommandLogtxt += "--role_names " + str(_role_names) + " "




        if _scope is not None:
            subCommandLogtxt += "--scope " + str(_scope) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_group_set"

        if _user_group_id is not None and len(_user_group_id) > 64:
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `64`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_patch`, length must be less than or equal to `64`")
        if _user_group_id is not None and len(_user_group_id) < 1:
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_patch`, length must be greater than or equal to `1`")
        if  _user_group_id is not None and not re.search('^[a-zA-Z0-9!#\\$%&\'\\-\\.@\\^_`\\{\\}~]{1,64}$', _user_group_id):
            raise ValueError("Invalid value for parameter `user_group_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[a-zA-Z0-9!#\\$%&'\\-\\.@\\^_`\\{\\}~]{1,64}$/`")
#           raise ValueError("Invalid value for parameter `user_group_id` when calling `v1_objects_user_groups_user_group_id_patch`, must conform to the pattern `/^[a-zA-Z0-9!#\\$%&'\\-\\.@\\^_`\\{\\}~]{1,64}$/`")
























        if _role_names is not None:
            if(isinstance(_role_names, str)):
                _role_names = SeparateArgs.check_backslash(_role_names)
                _role_names = _role_names.encode("utf-8").decode("unicode-escape")
        if _scope is not None:
            if(isinstance(_scope, str)):
                _scope = SeparateArgs.check_backslash(_scope)
                _scope = _scope.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchUserGroupParam import PatchUserGroupParam
        _patch_user_group_param = PatchUserGroupParam()
        _patch_user_group_param.role_names = _role_names
        _patch_user_group_param.scope = _scope

    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserGroup import UserGroup

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_user_groups_user_group_id_patch(_user_group_id, patch_user_group_param = _patch_user_group_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
def user_list(_vps_id,):
    """
    Obtains the list of users. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "user_list"

        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `v1_objects_users_get`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.UserList import UserList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_get(vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',type=str,metavar='<str>',help='User ID.',required=True)
@click.option('--password','_password',type=str,metavar='<str>',hidden=True,help='User password.')
@click.option('--authentication','_authentication',type=str,metavar='<str>',help='Authentication type.')
@click.option('--is_enabled_console_login','_is_enabled_console_login',metavar='<bool>',help='Specifies whether to make the user a console user. (Bare metal)(Cloud)')
@click.option('--user_group_ids','_user_group_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of user group IDs to which the user belongs.',required=True)
def user_create(_user_id,_password,_user_group_ids,_authentication,_is_enabled_console_login,):
    """
    Creates a user. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "




        if _user_group_ids is not None:
            subCommandLogtxt += "--user_group_ids " + str(_user_group_ids) + " "




        if _authentication is not None:
            subCommandLogtxt += "--authentication " + str(_authentication) + " "




        if _is_enabled_console_login is not None:
            subCommandLogtxt += "--is_enabled_console_login " + str(_is_enabled_console_login) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_create"



















        if _user_id is not None:
            if(isinstance(_user_id, str)):
                _user_id = SeparateArgs.check_backslash(_user_id)
                _user_id = _user_id.encode("utf-8").decode("unicode-escape")
        if _user_group_ids is not None:
            if(isinstance(_user_group_ids, str)):
                _user_group_ids = SeparateArgs.check_backslash(_user_group_ids)
                _user_group_ids = _user_group_ids.encode("utf-8").decode("unicode-escape")
        if _authentication is not None:
            if(isinstance(_authentication, str)):
                _authentication = SeparateArgs.check_backslash(_authentication)
                _authentication = _authentication.encode("utf-8").decode("unicode-escape")
        if _is_enabled_console_login is not None:
            if(isinstance(_is_enabled_console_login, str)):
                _is_enabled_console_login = SeparateArgs.check_backslash(_is_enabled_console_login)
                _is_enabled_console_login = _is_enabled_console_login.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateUserParam import CreateUserParam
        _create_user = CreateUserParam()
        _create_user.user_id = _user_id
        _create_user.user_group_ids = _user_group_ids
        _create_user.authentication = _authentication
        _create_user.is_enabled_console_login = _is_enabled_console_login

    
        
        from com.hitachi.sophia.rest_client.autogen.models.User import User

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _password is None:
            _password = commonutil.input_stdin_allow_empty('password (if omitted, press the [Enter] key)')

        if _password is not None:
            if isinstance(_password, str):
                _password = SeparateArgs.check_backslash(_password)
                _password = _password.encode("utf-8").decode("unicode-escape")

        _create_user.password = _password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_post(create_user = _create_user, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ',required=True)
@click.option('--user_group_ids','_user_group_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of user group IDs to which a user is to be added.',required=True)
def user_add_user_group(_user_id,_user_group_ids,):
    """
    Adds a user to user groups. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_add_user_group"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "







        if _user_group_ids is not None:
            subCommandLogtxt += "--user_group_ids " + str(_user_group_ids) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_add_user_group"

        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_actions_add_user_group_invoke_post`, length must be less than or equal to `255`")
        if _user_id is not None and len(_user_id) < 5:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `5`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_actions_add_user_group_invoke_post`, length must be greater than or equal to `5`")
        if  _user_id is not None and not re.search('^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_actions_add_user_group_invoke_post`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
























        if _user_group_ids is not None:
            if(isinstance(_user_group_ids, str)):
                _user_group_ids = SeparateArgs.check_backslash(_user_group_ids)
                _user_group_ids = _user_group_ids.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.AddUserToUserGroupParam import AddUserToUserGroupParam
        _add_user_to_user_group_param = AddUserToUserGroupParam()
        _add_user_to_user_group_param.user_group_ids = _user_group_ids

    
        
        from com.hitachi.sophia.rest_client.autogen.models.User import User

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_user_id_actions_add_user_group_invoke_post(_user_id, add_user_to_user_group_param = _add_user_to_user_group_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ',required=True)
@click.option('--user_group_ids','_user_group_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of user group IDs from which a user is to be deleted.',required=True)
def user_delete_user_group(_user_id,_user_group_ids,):
    """
    Deletes a user from user groups. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_delete_user_group"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "







        if _user_group_ids is not None:
            subCommandLogtxt += "--user_group_ids " + str(_user_group_ids) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_delete_user_group"

        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_actions_delete_user_group_invoke_post`, length must be less than or equal to `255`")
        if _user_id is not None and len(_user_id) < 5:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `5`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_actions_delete_user_group_invoke_post`, length must be greater than or equal to `5`")
        if  _user_id is not None and not re.search('^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_actions_delete_user_group_invoke_post`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
























        if _user_group_ids is not None:
            if(isinstance(_user_group_ids, str)):
                _user_group_ids = SeparateArgs.check_backslash(_user_group_ids)
                _user_group_ids = _user_group_ids.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteUserFromUserGroupParam import DeleteUserFromUserGroupParam
        _delete_user_from_user_group_param = DeleteUserFromUserGroupParam()
        _delete_user_from_user_group_param.user_group_ids = _user_group_ids

    
        
        from com.hitachi.sophia.rest_client.autogen.models.User import User

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_user_id_actions_delete_user_group_invoke_post(_user_id, delete_user_from_user_group_param = _delete_user_from_user_group_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ',required=True)
def user_delete(_user_id,):
    """
    Deletes a user. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "user_delete"

        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_delete`, length must be less than or equal to `255`")
        if _user_id is not None and len(_user_id) < 5:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `5`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_delete`, length must be greater than or equal to `5`")
        if  _user_id is not None and not re.search('^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_delete`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")

















                

    
        
        

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_user_id_delete(_user_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ',required=True)
def user_show(_user_id,):
    """
    Obtains user information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        
        
        
        
        #cliSubCommand = "user_show"

        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_get`, length must be less than or equal to `255`")
        if  _user_id is not None and not re.search('^self$|^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^self$|^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_get`, must conform to the pattern `/^self$|^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.User import User

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_user_id_get(_user_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ',required=True)
@click.option('--password','_password',type=str,metavar='<str>',hidden=True,help='New password.')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables the user.')
def user_set(_user_id,_password,_is_enabled,):
    """
    Edits user information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "user_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.user_role_management import UserRoleManagement as UserRoleManagementApi
        api = UserRoleManagementApi(ApiClient())



        
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "user_set"

        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_patch`, length must be less than or equal to `255`")
        if _user_id is not None and len(_user_id) < 5:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `5`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_patch`, length must be greater than or equal to `5`")
        if  _user_id is not None and not re.search('^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `v1_objects_users_user_id_patch`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
























        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchUserParam import PatchUserParam
        _patch_user_param = PatchUserParam()
        _patch_user_param.is_enabled = _is_enabled

    
        
        from com.hitachi.sophia.rest_client.autogen.models.User import User

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _password is None:
            _password = commonutil.input_stdin_allow_empty('password (if omitted, press the [Enter] key)')

        if _password is not None:
            if isinstance(_password, str):
                _password = SeparateArgs.check_backslash(_password)
                _password = _password.encode("utf-8").decode("unicode-escape")

        _patch_user_param.password = _password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_users_user_id_patch(_user_id, patch_user_param = _patch_user_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['external_auth_server_root_certificate_download'] = external_auth_server_root_certificate_download
    commands['external_auth_server_root_certificate_import'] = external_auth_server_root_certificate_import
    commands['user_password_set'] = user_password_set
    commands['external_auth_server_setting_verify_connectivity'] = external_auth_server_setting_verify_connectivity
    commands['external_auth_server_setting_show'] = external_auth_server_setting_show
    commands['external_auth_server_setting_set'] = external_auth_server_setting_set
    commands['user_auth_setting_show'] = user_auth_setting_show
    commands['user_auth_setting_set'] = user_auth_setting_set
    commands['user_group_list'] = user_group_list
    commands['user_group_create'] = user_group_create
    commands['user_group_delete'] = user_group_delete
    commands['user_group_show'] = user_group_show
    commands['user_group_set'] = user_group_set
    commands['user_list'] = user_list
    commands['user_create'] = user_create
    commands['user_add_user_group'] = user_add_user_group
    commands['user_delete_user_group'] = user_delete_user_group
    commands['user_delete'] = user_delete
    commands['user_show'] = user_show
    commands['user_set'] = user_set
    return commands

