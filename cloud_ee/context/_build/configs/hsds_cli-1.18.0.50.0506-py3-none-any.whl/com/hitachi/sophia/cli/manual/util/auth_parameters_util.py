"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import click
import traceback
import logging as loggingLib
import re
import json
import collections

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.rest_client.manual.configuration import Configuration

logger = loggingLib.getLogger(__name__)

class AuthParametersUtil(object):

    # 環境変数から認証パラメータを取得する関数
    # ユーザ認証オプション未指定時 or --auth_ticketのみ指定時 に、トークンファイル/HSDS_USER読み込み
    def set_auth_parameter(self,is_support_basic_auth,is_support_token,is_support_ticket):
        comUtil = CommonUtil()

        config = Configuration()

        #usernameが入力されている場合はリターン
        if config.username is not None:
            return

        # tokenが入力されている場合はリターン
        if config.api_key_prefix.get('Authorization') == 'Session' \
                or 'AuthToken' in config.api_key:
            return

        # ticketをサポートし、かつ指定されている場合は環境変数からユーザ名を取得
        if is_support_ticket and config.api_key_prefix.get('Authorization') == 'Ticket':
            comUtil.getEnvironmentHsdsUser()
            #取得有無に関わらずリターン
            return

        # ここから下がユーザ認証オプション未指定時

        #tokenをサポートする場合は環境変数から値を取得
        #if(is_support_token):
            #auth_token = comUtil.getEnvironmentVariable('HSDS_TOKEN')
            #if (auth_token):
            #    config.api_key_prefix['Authorization'] = 'Session'
            #    config.api_key['Authorization'] = auth_token
            #    return

        # basicをサポートする場合は環境変数から値を取得
        if (is_support_basic_auth):
            comUtil.getEnvironmentHsdsUser()

        return

    # 認証パラメータをチェックする関数
    def check_auth_parameter(self,is_support_basic_auth,is_support_token,is_support_ticket):

        config = Configuration()

        #basic認証及びtoken認証のみに対応したAPI実行時
        if (is_support_basic_auth) and (is_support_token) and not (is_support_ticket):
            #--auth_ticketが入力された場合はエラーとする
            if (config.api_key_prefix.get('Authorization') == 'Ticket'):
                config.messageId = '19019'
                return

            #--userか--auth_tokenのいずれかが入力されていない場合はエラーとする
            if config.username is None and (config.api_key_prefix.get('Authorization') != 'Session'):
                config.messageId = '19003'
                return

            # --user(オプション)と--auth_tokenの両方が入力されている場合はエラーとする
            # なお、下記理由により下記のそれぞれの条件は不要
            # * --user指定時はトークンファイルは読まれない
            # * --auth_token指定時は環境変数HSDS_USERは読まれない
            # * トークンファイル読み込み時はHSDS_USERは読まれない
            if config.username is not None and (config.api_key_prefix.get('Authorization') == 'Session'):
                config.messageId = '19022'
                config.messageDict = {'MSKEY_param1': "user", 'MSKEY_param2': "auth_token"}
                return

            # (--user未指定時かつ)--passwordと--auth_tokenの両方が入力されている場合はエラーとする
            if config.password is not None and (config.api_key_prefix.get('Authorization') == 'Session'):
                config.messageId = '19022'
                config.messageDict = {'MSKEY_param1': "auth_token", 'MSKEY_param2': "password"}
                return

        # 認証不要なAPI実行時
        if not (is_support_basic_auth) and not (is_support_token) and not (is_support_ticket):
            # --user,--password,--auth_token,--auth_ticketが入力された場合はエラーとする
            if config.username is not None or config.password is not None or ('Authorization' in config.api_key):
                config.messageId = '19009'
                return

        # basic認証のみのAPI実行時
        if (is_support_basic_auth) and not (is_support_token) and not (is_support_ticket):
            #--auth_token,--auth_ticketが入力された場合はエラーとする
            if ('Authorization' in config.api_key):
                config.messageId = '19010'
                return

            #--userが入力されない場合はエラーとする
            if config.username is None:
                config.messageId = '19011'
                return

        # basic認証及びtoken認証及びticket認証に対応したAPI実行時
        if (is_support_basic_auth) and (is_support_token) and (is_support_ticket):
            #--auth_ticket入力有りで--userが入力されない場合はエラーとする
            if config.username is None and (config.api_key_prefix.get('Authorization') == 'Ticket'):
                config.messageId = '19017'
                return

            #--user,--auth_token,--auth_ticketのいずれも入力されていない場合はエラーとする
            if config.username is None and not ('Authorization' in config.api_key):
                config.messageId = '19018'
                return

            # --user(オプション)と--auth_tokenの両方が入力されている場合はエラーとする
            # なお、下記理由により下記のそれぞれの条件は不要
            # * --user指定時はトークンファイルは読まれない
            # * --auth_token指定時は環境変数HSDS_USERは読まれない
            # * トークンファイル読み込み時はHSDS_USERは読まれない
            if config.username is not None and (config.api_key_prefix.get('Authorization') == 'Session'):
                config.messageId = '19022'
                config.messageDict = {'MSKEY_param1': "user", 'MSKEY_param2': "auth_token"}
                return

            # (--user未指定時かつ)--passwordと--auth_tokenの両方が入力されている場合はエラーとする
            if config.password is not None and (config.api_key_prefix.get('Authorization') == 'Session'):
                config.messageId = '19022'
                config.messageDict = {'MSKEY_param1': "auth_token", 'MSKEY_param2': "password"}

        # ticket認証のみのAPI実行時
        if not (is_support_basic_auth) and not (is_support_token) and (is_support_ticket):
            #--auth_tokenが入力された場合はエラーとする
            if ('AuthToken' in config.api_key) or (config.api_key_prefix.get('Authorization') == 'Session'):
                config.messageId = '19020'
                return

            #--userと--auth_tiketが入力されていない場合はエラーとする
            if config.username is None or (config.api_key_prefix.get('Authorization') != 'Ticket'):
                config.messageId = '19017'
                return

        # token認証のみに対応したサブコマンドなし
        # basic認証およびticket認証のみに対応したサブコマンドなし
        # token認証およびticket認証のみに対応したサブコマンドなし

        return
