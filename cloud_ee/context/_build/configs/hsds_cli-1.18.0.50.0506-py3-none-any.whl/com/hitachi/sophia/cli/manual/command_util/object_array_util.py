"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
class ObjectArrayUtil(object):
    # 文字列から型変換実施
    def convertType(param,type,key,paramName):
        # 整数の場合は整数に型変換
        if type == 'integer' and param != None:
            try:
                param = int(param)
            except ValueError:
                raise ValueError("invalid request for "+paramName+",invalid value(not integer):" + key)

        # boolの場合はboolに型変換
        if type == 'boolean' and param != None:
            if param != 'false' and param != 'true':
                raise ValueError("invalid request for "+paramName+",invalid value(The format of the boolean value is invalid):" + key)

        # listの場合はlistに格納
        if type == 'array' and param != None:
            #空配列指定
            if(param=='[]'):
                return []
            elif(param.startswith('[') and param.endswith(']')):
                paramvals = param[1:len(param)-1]
                #[]の中に'['or']'がある
                if ('[' in paramvals or ']' in paramvals):
                    raise ValueError("invalid request for " + paramName + ",invalid value:" + param)
                paramvals_split = paramvals.split(',')
                return paramvals_split
            # []で囲まれていない場合はエラー
            else:
                raise ValueError("invalid request for " + paramName + ",invalid value:" + param)

        # array型意外で'[]'が指定されて場合はエラーとする
        if type == 'string':
            if(param!=None):
                if ('[' in param or ']' in param):
                    raise ValueError("invalid request for " + paramName + ",invalid value:" + param)

        return param

    # 文字列から指定されたパラメータの値を取得する
    def getArrayParamValue(input_param,param_type,param_name,key_list,paramName):

        if input_param is None:
            return None

        if param_name is None:
            return None

        input_param_dict = ObjectArrayUtil.convert_dictionary(input_param,param_type, param_name,key_list,paramName)

        if not (param_name) in input_param_dict:
            return None

        return input_param_dict[param_name]

    # input_param -> 辞書型に変換するメソッド
    def convert_dictionary(input_param,param_type, param_name,key_list,paramName):
        input_param_list = []
        # カンマで分割し、リストを得る。
        input_param_split = input_param.split(',')

        input_param_split_rebuild =[]
        # 配列パラメータを再構築
        # [aaa,bbbb,ccc]のような値が分割されているので、これを再度合体する
        array_value = ''
        array_flag = False
        for item in input_param_split:
            # 前要素に=[の指定があった
            if(array_flag):
                if(item.endswith(']')):
                    input_param_split_rebuild.append(array_value + ',' +item)
                    # flagをリセット
                    array_flag = False
                #最後尾以外に']'がある
                #elif(']' in item):
                #    raise ValueError("invalid request for " + paramName + ",invalid value:" + array_value)
                else:
                    array_value = array_value + ',' +item
            else:
                if('=[' in item):
                    array_value = item
                    array_flag = True
                    if (item.endswith(']')):
                        input_param_split_rebuild.append(item)
                        # flagをリセット
                        array_flag = False
                #先頭以外に'['を指定
                #elif('[' in item):
                #    raise ValueError("invalid request for " + paramName + ",invalid value:" + array_value)
                else:
                    input_param_split_rebuild.append(item)

        #array_flagが立ったままということは、[]が閉じていない
        if(array_flag):
            equalSplitted = array_value.split('=')
            raise ValueError("invalid request for " + paramName + ",invalid value:" + equalSplitted[1])

        for item in input_param_split_rebuild:
            equalSplitted = item.split('=')
            if(len(equalSplitted)==2):
                # keyが正しいかチェック
                ObjectArrayUtil.checkParameterKey(equalSplitted[0],key_list,paramName)

                if(equalSplitted[1])=='':
                    if param_name == equalSplitted[0]:
                        # string型以外はエラーとする(string型の場合は空文字指定のケース)
                        if param_type != 'string':
                            # valueがない
                            raise ValueError("invalid request for "+paramName+",invalid value:" + equalSplitted[0])

                input_param_list.append(equalSplitted)

            elif(len(equalSplitted)==0):
                # keyもvalueもない
                raise ValueError("invalid value for "+paramName+",key and value is required.")

            elif(len(equalSplitted)==1):
                # keyが正しいかチェック
                ObjectArrayUtil.checkParameterKey(equalSplitted[0], key_list,paramName)
                # valueがない
                raise ValueError("invalid request for "+paramName+",invalid value:" + equalSplitted[0])

            elif(len(equalSplitted)>2):
                # valueが不正(valueに=が混入)
                raise ValueError("invalid request for "+paramName+",invalid value:" + equalSplitted[0])

        # 辞書型に変換
        input_param_dict = dict(input_param_list)

        return input_param_dict

    def checkParameterKey(key,keylist,paramName):
        if not key in keylist:
            raise ValueError("invalid request for "+paramName+",invalid key:" + key)
