"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import sys
from contextlib import redirect_stdout

import click
import json
import copy
import re
import csv
import os
import collections
from collections import OrderedDict

from com.hitachi.sophia.cli.autogen.util.json_dict import JsonDict as jdict
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.progress_util import ProgressUtil
from com.hitachi.sophia.rest_client.manual.configuration import Configuration


class OutputUtil(object):
    # クラス変数
    basic_uri_cli_sub_command_dict = {}
    new_response_dict = {}
    attribute_dict = {
        "permittedCapacityInTiB": "Permitted Capacity In TiB",
        "totalPoolCapacityInGiB": "Total Pool Capacity In GiB",
        "checkedOutLicenseUsageInTiB": "Checked Out License Usage In TiB",
        "estimatedPoolCapacityInTiB": "Estimated Pool Capacity In TiB",
        "differenceCapacityInTiB": "Difference Capacity In TiB",
    }

    def __init__(self) -> object:
        """

        :rtype: object
        """
        self.basic_uri_cli_sub_command_dict = json.loads(
            jdict.basic_uri_cli_sub_command_dict_json
        )

    def _del_dic(self, data, keys: list):
        """
        keysに指定されたキーとバリューを辞書から削除する
        :param data: 辞書
        :param keys: 削除するキーを辞書のネスト構造順に定義したリスト
        :return:
        """
        if len(keys) == 1:
            del data[keys[0]]
            return
        else:
            temp_key = keys.pop(0)
            temp_data = data[temp_key]
            self._del_dic(temp_data, keys)
            data[temp_key].update(temp_data)

    def _del_dic_main(self, dic_data: dict, del_list: list) -> object:
        """
        del_listに指定されたキーとバリューを辞書から削除するメイン部
        del_listの要素をひとつづつ"."で分割したListにして、_del_dicをコールする
        :param dic_data:
        :param del_list:
        :return:
        """
        work_data = copy.deepcopy(dic_data)
        del_keys = copy.deepcopy(del_list)
        del_keys.sort(reverse=True)
        for key in del_keys:
            key_list = key.split(".")
            if len(key_list) >= 1:
                self._del_dic(work_data, key_list)
        return work_data

    def _del_dic_mapper(self, d, delete_key_list, delete_body_key_list):
        """
        指定したリストにしたがって、del_dic_mainに渡すListを作成し、実行する
        :param d: 削除対象となる辞書
        :param delete_key_list: 削除する1階層目のキーリスト
        :param delete_body_key_list: body内のキーリスト body内の1階層目の要素を削除
        :return: 指定された要素削除後の辞書
        """
        del_list = []
        # body_key_list = []
        wk_d = copy.copy(d)
        # 1階層目の要素削除
        if len(delete_key_list) != 0:
            for key in delete_key_list:
                if key in d:
                    del_list.append(key)
        # body内の要素削除
        if len(delete_body_key_list) != 0:
            if "body" in d:
                if type(d["body"]) is collections.OrderedDict:

                    for key in delete_body_key_list:
                        if key in d["body"]:
                            new_key = "body." + key
                            del_list.append(new_key)
        if len(del_list) != 0:
            wk_d = self._del_dic_main(wk_d, del_list)

        return wk_d

    def _change_key_name(self, keyname):
        """
        キャメルケースの属性名を、単語区切りをスペースに変換し、単語の頭を大文字にする
        :param keyname: 属性名
        :return: 編集後の属性名
        """
        new_key_name = self.attribute_dict.get(keyname)
        if new_key_name is None:
            split_key = [
                x
                for x in re.split("([a-z0-9]+)|([A-Z][a-z0-9]+)", keyname)
                if x is not None and x != ""
            ]
            new_key_name = ""
            for item in split_key:
                new_key_name = new_key_name + item.capitalize() + " "
            new_key_name = new_key_name[:-1]
        return new_key_name

    def isJsonFormat(self, data):
        try:
            json.loads(data)
        # python3.5以降にサポートされている
        # except json.JSONDecodeError as e:
        #     print(sys.exc_info())
        #     print(e)
        #     return False
        except ValueError as e:
            click.echo(sys.exc_info())
            click.echo(e)
            return False
        except Exception as e:
            click.echo(sys.exc_info())
            click.echo(e)
            return False
        return True

    def echo_normal(self, response_json: str, form, sub_command):
        """
        通常サブコマンドの出力処理
        :param response_json: Responseデータ（json形式のStrin）
        :param form: 出力形式 text: プレーンテキスト形式, json: json形式, simple-csv: csv形式
        :return: なし
        """
        if self.isJsonFormat(response_json):

            d = self.convert_url_to_sub_command(
                response_json, self.basic_uri_cli_sub_command_dict
            )

            if d["httpStatusCode"] == 204 and d.get("message") is None:
                d["message"] = "Completed."

            # csv形式の場合
            if form == "simple-csv":
                self.check_format_csv(sub_command)
                common_util = CommonUtil()
                common_util.view_error()

                if d["httpStatusCode"] == 200:
                    self.echo_csv(response_json, sub_command)
                else:
                    with redirect_stdout(sys.stderr):
                        exit_code = common_util.get_cli_exit_code_for_api_execution(
                            d["httpStatusCode"]
                        )

                        key_list = ["httpStatusCode"]
                        body_key_list = []

                        d = self._del_dic_mapper(d, key_list, body_key_list)

                        self.dic_to_plain_format(d)

                        exit(exit_code)

            # プレーンテキスト形式の場合
            elif form == "text":
                if d["httpStatusCode"] >= 400:
                    with redirect_stdout(sys.stderr):
                        # statusCodeを取っ払う
                        delete_key_list = ["httpStatusCode"]
                        delete_body_key_list = []

                        d = self._del_dic_mapper(
                            d, delete_key_list, delete_body_key_list
                        )

                        self.dic_to_plain_format(d)
                else:
                    # statusCodeを取っ払う
                    delete_key_list = ["httpStatusCode"]
                    delete_body_key_list = []

                    d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)

                    if "body" in d:
                        if "data" in d["body"] and type(d["body"]["data"]) is list:
                            if len(d["body"]["data"]) > 0:
                                # bodyのdataのみ取り出し (=data以外を削除した辞書作成)
                                delete_key_list = list(d.keys())
                                delete_key_list.remove("body")
                                delete_body_key_list = list(d["body"].keys())
                                delete_body_key_list.remove("data")
                                d_data = self._del_dic_mapper(
                                    d, delete_key_list, delete_body_key_list
                                )

                                # bodyのdataのみ、data以外、の順で出力
                                self.dic_to_plain_format(d_data)
                                self.__echo_normal_of_body_without_data_nor_resources(
                                    d, is_data_echoed=True
                                )
                            else:
                                self.__echo_normal_of_body_without_data_nor_resources(d)
                        elif (
                            "resources" in d["body"]
                            and type(d["body"]["resources"]) is list
                        ):
                            if len(d["body"]["resources"]) > 0:
                                # bodyのresourcesのみ取り出し (=resources以外を削除した辞書作成)
                                delete_key_list = list(d.keys())
                                delete_key_list.remove("body")
                                delete_body_key_list = list(d["body"].keys())
                                delete_body_key_list.remove("resources")
                                d_data = self._del_dic_mapper(
                                    d, delete_key_list, delete_body_key_list
                                )

                                # bodyのresourcesのみ、resources以外、の順で出力
                                self.dic_to_plain_format(d_data)
                                self.__echo_normal_of_body_without_data_nor_resources(
                                    d, is_data_echoed=True
                                )
                            else:
                                self.__echo_normal_of_body_without_data_nor_resources(d)
                        else:
                            self.__echo_normal_of_body_and_others(d)
                    else:
                        self.dic_to_plain_format(d)
            else:  # json形式の場合
                # json形式の場合
                click.echo(json.dumps(d, indent=4))
        else:
            # jsonフォーマットでなかった場合
            click.echo("Response is not in json format.")
            click.echo(response_json)

    def __echo_normal_of_body_without_data_nor_resources(self, d, is_data_echoed=False):
        """
        d['body']における'data'または'resources'以外を出力
        :param d: response (json)を辞書型にしたもの
        :param no_data: Trueのとき、d['body']における'data'または'resources'がなかったとき
        :return: None
        """
        if len(d.keys()) == 1 and len(d["body"].keys()) == 1:
            if is_data_echoed is False:
                # d['body']['data'/'resources']しかなく、かつその要素が空の場合、'(None)'のみ出力
                click.echo("(None)")
        else:
            # d['body']['data'/'resources']を削除し、dの他の要素を出力
            delete_key_list = []
            delete_body_key_list = ["data", "resources"]

            d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)
            self.__echo_normal_of_body_and_others(d, is_data_echoed)

    def __echo_normal_of_body_and_others(self, d, is_data_echoed=False):
        """
        dにある'body'とd直下の値を出力
        :param d: response (json)を辞書型にしたもの
        :return: None
        """
        is_others_in_body_echoed = False
        if len(d["body"].keys()) > 0:
            # d['body']にある'data'/'resources'以外の要素を出力
            if is_data_echoed:
                # d['body']['data'/'resources']を出力済みの場合は、d['body']の他のキー出力前に改行
                click.echo("")
            self.dic_to_plain_format(d["body"])
            is_others_in_body_echoed = True

        delete_key_list = ["body"]
        delete_body_key_list = []
        d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)

        if len(d.keys()) > 0:
            # dにある'body'以外を出力
            if is_data_echoed or is_others_in_body_echoed:
                # d['body']['data'/'resources']を出力済みまたは
                # d['body']にある'data'/'resources'以外の要素出力済みの場合、dの他キー出力前に改行
                click.echo("")

            self.dic_to_plain_format(d)

    def echo_data_list_with_header(self, response_json, form, sub_command, indent=0):
        """
        enumerateContextサブコマンドのヘッダ部分の出力処理
        {
            "httpStatus": 200,
            "body": {
                "data":
                    {
                        "savingEffects": {
                            "systemDataCapacity": null,
                            "preCapacityDataReductionWithoutSystemData": null,
                            "postCapacityDataReduction": null
                        },
                        "id": "0003fc00-7b69-4988-a5c3-fda840d372a4",
                        "nickname": "vol_17703",
                        --- 省略 ---
                        "snapshotAttribute": "-",
                        "snapshotStatus": "Normal",
                        "savingSetting": "_NotSupported",
                        "savingMode": "_NotSupported"
                    },
        をプレーンテキスト形式またはjson形式またはcsv形式で表示する
        :param j: Responseデータ（json形式のStrin）
        :param form: 出力形式 text: プレーンテキスト形式, json: json形式, simple-csv: csv形式
        :param indent:
        :return: なし
        """
        d = json.loads(response_json, object_pairs_hook=collections.OrderedDict)
        # csv形式の場合
        if form == "simple-csv":
            self.check_format_csv(sub_command)
            common_util = CommonUtil()
            common_util.view_error()
            self.echo_csv(response_json, sub_command)

        # プレーンテキスト形式の場合
        elif form == "text":
            if d["httpStatusCode"] >= 400:
                with redirect_stdout(sys.stderr):
                    if "body" in d and "error" in d["body"]:
                        self.dic_to_plain_format(d["body"]["error"], 0, False)
            else:
                # httpStatusCode, count, hasNext, enumerateContext(, error)を除いた辞書を作る
                delete_key_list = ["httpStatusCode"]
                delete_body_key_list = [
                    "totalCount",
                    "hasNext",
                    "enumerateContext",
                    "error",
                ]

                d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)

                if (
                    "body" in d
                    and "data" in d["body"]
                    and type(d["body"]["data"]) is list
                ):
                    if len(d["body"]["data"]) > 0:
                        self.dic_to_plain_format(d, 0, False)
                    else:
                        # d['body']['data']の要素が空の場合、何も出力しない
                        pass
                else:
                    # 異常系。何もしない
                    pass

        else:  # Json形式の場合
            # totalCount, hasNext, enumerateContext(, error)を除いた辞書を作る
            delete_key_list = []
            delete_body_key_list = [
                "totalCount",
                "hasNext",
                "enumerateContext",
                "error",
            ]

            d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)

            # 辞書をjson形式で出力して、'\n'で分割して、Listにする
            json_buf = json.dumps(d, indent=4)
            json_list = json_buf.split("\n")
            for i, print_line in enumerate(json_list):
                if print_line.startswith("        ]"):
                    # '        ]' (=dataの閉じる記号)で終了
                    break
                elif print_line.startswith('        "data": []'):
                    # dataが空のケースもdataの行で終了
                    click.echo("")
                    click.echo('        "data": [', nl=False)
                    break
                else:
                    # 現在の行の改行は次の行の読み込み時に出力する (最終行で改行出力しないため)
                    if i != 0:
                        click.echo("")
                click.echo(print_line, nl=False)

    def echo_data_list(self, response_json, form, sub_command, indent=0):
        """
        enumerateContextサブコマンドのdata[]部
        {
            "savingEffects": {
                "systemDataCapacity": null,
                "preCapacityDataReductionWithoutSystemData": null,
                "postCapacityDataReduction": null
            },
            "id": "0005eb4a-accb-4775-b8b8-534b7b0c9e03",
            "nickname": "vol_14453",
            --- 省略 ---
            "snapshotAttribute": "-",
            "snapshotStatus": "Normal",
            "savingSetting": "_NotSupported",
            "savingMode": "_NotSupported"
        }
        をプレーンテキスト形式または、json形式で画面表示する
        :param response_json: Responseデータ（json形式）
        :param form: 出力形式 text: プレーンテキスト形式, json: json形式, simple-csv: csv形式
        :param indent: 現在未使用
        :return: なし
        """
        d = json.loads(response_json, object_pairs_hook=collections.OrderedDict)
        # csv形式の場合
        if form == "simple-csv":
            self.check_format_csv(sub_command)
            common_util = CommonUtil()
            common_util.view_error()
            self.echo_csv(response_json, sub_command, False)

        # プレーンテキスト形式の場合
        elif form == "text":
            # httpStatusCode, body.count, body.hasNext, body.enumerateContext(, body.error)を除いたdictを作る
            delete_key_list = ["httpStatusCode"]
            delete_body_key_list = [
                "totalCount",
                "hasNext",
                "enumerateContext",
                "error",
            ]
            d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)

            if "body" in d and "data" in d["body"] and type(d["body"]["data"]) is list:
                if len(d["body"]["data"]) > 0:
                    click.echo("")
                    self.dic_to_plain_format(d, 0, False)
                else:
                    # d['body']['data']の要素が空の場合、何も出力しない
                    pass
            else:
                # 異常系。何もしない
                pass
        else:  # Json形式の場合
            # body.dataだけの辞書を作成して、json形式に変換後、'\n'で分割して、Listにする
            data_list = d["body"]["data"]
            json_buf = json.dumps(data_list, indent=4)
            json_list = json_buf.split("\n")
            for i, print_line in enumerate(json_list):
                # 最初の '['は出力しない(i ==0 Listの0番目)
                if print_line.startswith("["):
                    continue
                # 最後の ']'は出力しないで、処理を抜ける
                if print_line.startswith("]"):
                    break
                # 1行めは','をつけて改行する。それ以外は、改行して、その後、改行なしで、json出力
                if i == 1:
                    click.echo(",")
                else:
                    click.echo("")
                click.echo(("        " + print_line), nl=False)

    def _remove_errorSource_in_body_error(self, dict):
        """
        echo_data_list_finalizeのRespons辞書から['body']['error']['errorSource']を削除する
        :param dict:
        :return:
        """
        if "body" in dict:
            if "error" in dict["body"]:
                if "errorSource" in dict["body"]["error"]:
                    dict = self._del_dic_main(dict, ["body.error.errorSource"])

        return dict

    def echo_data_list_finalize(self, response_json, form, sub_command, i=0):
        """
        enumerateContextサブコマンドの最後の出力処理
                ],
                "count": xxx,
                "enumerateContext": null,
                "hasNext": false
                "error": {
                    "messageId": "KARS-XXXXX-X",
                    "message": "XXXX",
                    "cause": "XXXX",
                    "solution": "XXXXX",
                    "solutionType": "SEE_ERROR_DETAIL",
                    "errorCode": "XXXXX"
                }
            }
        をプレーンテキスト形式またはjson形式で画面表示する
        :param response_json: Responseデータ（json形式）
        :param form: 出力フォーマット text: プレーンテキスト形式, json: json形式, simple-csv: csv形式
        :param i: 現在、未使用
        :return:
        """
        d = json.loads(response_json, object_pairs_hook=collections.OrderedDict)

        # d['body']['error']['errorSource'] があれば取り除く
        d = self._remove_errorSource_in_body_error(d)

        # csv形式の場合
        if form == "simple-csv":
            self.check_format_csv(sub_command)
            common_util = CommonUtil()
            common_util.view_error()

            # error:用の辞書を作るため、辞書を複製
            d_stderr = copy.copy(d)

            # body.errorだけの辞書を作る
            key_list_stderr = list(d_stderr.keys())
            wk_key_list_stderr = copy.copy(key_list_stderr)

            # body以外を削除
            if "body" in key_list_stderr:
                # body以外削除するためのlistを作る
                for item in key_list_stderr:
                    if item == "body":
                        wk_key_list_stderr.remove(item)
                # body.error以外削除するためのListを作る
                body_key_list_stderr = list(d_stderr["body"].keys())
                if "error" in d_stderr["body"]:
                    wk_body_key_list_stderr = copy.copy(body_key_list_stderr)
                    for item in body_key_list_stderr:
                        if item == "error":
                            wk_body_key_list_stderr.remove(item)
                    d_stderr = self._del_dic_mapper(
                        d_stderr, wk_key_list_stderr, wk_body_key_list_stderr
                    )
                    # body.errorだけ、stderrに出力する
                    with redirect_stdout(sys.stderr):
                        # 全件取得操作における'error'属性は出力せず、'error'属性の中身をstderrに出力する
                        self.dic_to_plain_format(
                            d_stderr.get("body").get("error"), 0, False
                        )

        # プレーンテキスト形式の場合
        elif form == "text":

            # 改行を入れるかどうかのフラグ
            needs_newline = False

            # 最後にecho_data_listで出力した要素にdataがあるか
            if "body" in d and "data" in d["body"] and len(d["body"]["data"]) != 0:
                needs_newline = True

            # error:用の辞書を作るため、辞書を複製
            d_stderr = copy.copy(d)

            # httpStatusCode, body.data,body.error を除いた辞書を作る(deepcopy)
            delete_key_list = ["httpStatusCode"]
            delete_body_key_list = ["data", "error"]
            d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)

            if "body" in d and len(d["body"]) != 0 and needs_newline is True:
                # dataに要素があり、data,errorを除いた部分(フッター部)がある場合は、
                # フッター部分の出力前に改行を出力
                click.echo("")

            self.dic_to_plain_format(d, 0, False)

            # body.errorだけの辞書を作る
            key_list_stderr = list(d_stderr.keys())
            wk_key_list_stderr = copy.copy(key_list_stderr)

            # body以外を削除
            if "body" in key_list_stderr:
                # body意外削除するためのlistを作る
                for item in key_list_stderr:
                    if item == "body":
                        wk_key_list_stderr.remove(item)
                # body.error以外削除するためのListを作る
                body_key_list_stderr = list(d_stderr["body"].keys())
                if "error" in d_stderr["body"]:
                    wk_body_key_list_stderr = copy.copy(body_key_list_stderr)
                    for item in body_key_list_stderr:
                        if item == "error":
                            wk_body_key_list_stderr.remove(item)
                    d_stderr = self._del_dic_mapper(
                        d_stderr, wk_key_list_stderr, wk_body_key_list_stderr
                    )

                    # body.errorだけ、stderrに出力する
                    with redirect_stdout(sys.stderr):
                        # 全件取得操作における'error'属性は出力せず、'error'属性の中身をstderrに出力する
                        self.dic_to_plain_format(
                            d_stderr.get("body").get("error"), 0, False
                        )

        else:  # Json形式の場合
            if "body" in d and "data" in d["body"] and len(d["body"]["data"]) != 0:
                # 最後にecho_data_listで出力した要素にdataがある場合、改行して、インデントを表示
                click.echo("")
                click.echo("        ", nl=False)
            click.echo("],")

            # httpStatusCodeとdataを除いた辞書を作成して、json形式に変換後、'\n'で分割して、Listにする
            delete_key_list = ["httpStatusCode"]
            delete_body_key_list = ["data"]

            d = self._del_dic_mapper(d, delete_key_list, delete_body_key_list)
            json_list = json.dumps(d, indent=4).split("\n")
            for i, print_line in enumerate(json_list):
                # {
                #     "body": {
                # は表示しない
                if i > 1:
                    click.echo(print_line)

    def dic_to_plain_format(self, d, n=0, blank_block_flag=False):
        """
        辞書形式データをプレーンテキスト形式で出力する
        :param d: 辞書
        :param n: 再帰回数もしくは、print前にあけるインデントの数
        :param blank_block_flag: enumerate_context True: 配列の場合、空行でブロック表示しない False: 配列の場合、空行でブロック表示
        :return: なし
        """
        indent = ""
        for i in range(0, n):
            if n >= 1:
                indent = indent + "  "

        if len(d) != 0:
            for k, v in d.items():
                if type(v) is collections.OrderedDict:
                    # bodyは、表示しない
                    if k == "body":
                        self.dic_to_plain_format(v, n, blank_block_flag)
                    else:
                        click.echo(indent, nl=False)
                        click.echo(self._change_key_name(k) + ":")
                        self.dic_to_plain_format(v, n + 1, blank_block_flag)
                elif type(v) is list:
                    # 階層の場合、親の属性名の次の行に、インデントして子の属性を表示
                    # 一覧参照のdata:[] とヘルスステータスのresources:は省略
                    if k != "data" and k != "resources":
                        click.echo(indent, nl=False)
                        click.echo(self._change_key_name(k) + ":")
                        n = n + 1
                    index = 0

                    if len(v) != 0:
                        for j in v:
                            if type(j) is collections.OrderedDict:
                                self.dic_to_plain_format(j, n, blank_block_flag)

                                # 配列の場合、各要素と要素の間に空行を入れ、ブロック表示する
                                if blank_block_flag is False:
                                    # 最後の要素以外でブロック表示する
                                    if index != len(v) - 1:
                                        click.echo("")

                            elif type(j) is str and len(j) == 0:
                                click.echo(indent, nl=False)
                                click.echo("  " + "(Empty string)")
                            else:
                                click.echo(indent, nl=False)
                                click.echo("  " + str(j))
                            index += 1
                    else:
                        # 配列が空の場合、スペース2個でインデントして(None)を表示する
                        click.echo(indent, nl=False)
                        click.echo("  (None)")

                    # 一つの配列オブジェクトの処理が終わる度にインデントの数をデクリメントする
                    if k != "data" and k != "resources":
                        n = n - 1

                elif type(v) is dict:
                    click.echo(indent, nl=False)
                    click.echo(self._change_key_name(k) + ":")
                    self.dic_to_plain_format(v, n + 1, blank_block_flag)

                elif type(v) is str and len(v) == 0:
                    click.echo(indent, nl=False)
                    click.echo(self._change_key_name(k) + ": (Empty string)")

                else:
                    click.echo(indent, nl=False)
                    click.echo(self._change_key_name(k) + ": " + str(v))

        else:
            # オブジェクトが空の場合、(None)を表示する
            click.echo(indent, nl=False)
            click.echo("(None)")

    def _split_url(self, url: str):
        """
        指定されたURLを'/'で分割したリストを返す
        :type url: str
        :param url:
        :return:
        """
        wk_url = url
        split_url_list = []
        split_url_list = re.split("[/,=]", wk_url)
        return split_url_list

    def _compare_url_lists(self, list1: list, list2: list):
        """
        list1とlist2の要素を比較する。ただし、{}でくくられた要素については比較しない
        :param list1: x-basicUriに定義されたURL
        :param list2: affected_resource
        :return: True: 位置 False: 不一致
        """
        # 個数の比較
        if len(list1) != len(list2):
            return False
        for i, item in enumerate(list1):
            if item.startswith("{") and item.endswith("}"):
                continue
            if item != list2[i]:
                return False
        return True

    def _remove_base_url(self, url):
        """
        Base URL: /ConfigurationManager/simple を取り除いたURLを返す
        :param url:
        :return:
        """
        new_url = url.replace("/ConfigurationManager/simple", "")
        return new_url

    def _get_cli_sub_command(self, url: str, single_basic_uri_sub_command_dict):
        """
        指定されたurl("affectedResources": または"request":中のuri)に該当するcli-sub-command返す
        :param url:
        :param single_basic_uri_sub_command_dict:
        :return:
        """
        wk_uri = self._remove_base_url(url)
        split_wk_uri_list = self._split_url(wk_uri)
        for k, v in single_basic_uri_sub_command_dict.items():
            split_dict_url_list = self._split_url(k)
            if self._compare_url_lists(split_dict_url_list, split_wk_uri_list):
                return v
        return None

    def _generate_cli_option(self, url_list: list, resource_list: list) -> object:
        """
        下記の辞書を作って返す
        key: url_listの{}で囲まれたリクエストパラメータの名前
        value: resource_listの該当する箇所の値
        :param url_list:
        :param resource_list:
        :return:
        """
        option_dic = OrderedDict()
        dic = OrderedDict()
        for i, split_uri in enumerate(url_list):
            # x-basicUriに{}（parametersのx-cli-parameterNameで置換済み）でくくられていたら箇所があったら、その中身をキーにする
            # 例えば、x-basicUri: /v1/objects/volumes/{id} と
            # "/ConfigurationManager/simple/v1/objects/volumes/37809939-21cb-489a-b804-52f7426c5c84"
            # のばあい、key:id value:37809939-21cb-489a-b804-52f7426c5c84の辞書をoption_dicに追加する
            if split_uri.startswith("{") and split_uri.endswith("}"):
                request_parameter_name = split_uri
                request_parameter_name = (
                    request_parameter_name.replace("{", "")
                ).replace("}", "")
                val = resource_list[i]
                dic.clear()
                dic = {request_parameter_name: val}
                option_dic.update(dic)
        return option_dic

    def _get_cli_option(
        self, affected_resource: str, single_basic_uri_sub_command_dict: dict
    ):
        """
        affectedResources に出力されたurlから、該当するcli-optionを返す
        :param affected_resource: "affectedResources": に出力されたURL
        :param single_basic_uri_sub_command_dict: path-cli_sub_command 変換辞書
        :return:
        """
        cli_option_dic = OrderedDict()
        wk_affected_resource = self._remove_base_url(affected_resource)
        split_affected_resource_list = self._split_url(wk_affected_resource)
        for k, v in single_basic_uri_sub_command_dict.items():
            split_url_list = self._split_url(k)
            if self._compare_url_lists(split_url_list, split_affected_resource_list):
                cli_option_dic = self._generate_cli_option(
                    split_url_list, split_affected_resource_list
                )
                break
        return cli_option_dic

    # def _convert_to_snake_case(self, option: str):
    #     """
    #     x-basicUriに定義されたリクエストパラメータの名前をスネークケースに変換して返す
    #     :param option: x-basicUriに定義されたリクエストパラメータの名前
    #     :return:
    #     """
    #     return re.sub("([A-Z])", lambda x: "_" + x.group(1).lower(), option

    def _generate_new_request(
        self, request_dict: object, basic_uri_sub_command_dict: object
    ) -> object:
        """
        request:の編集
        urlとrequestMethodをもとにrequest辞書を作成する
        :type basic_uri_sub_command_dict: object
        :param request_dict:
        :param basic_uri_sub_command_dict:
        :return: 編集済みrequest
        """
        new_request = OrderedDict()
        if "requestUrl" in request_dict:
            request_url = request_dict["requestUrl"]
            if "requestMethod" in request_dict:
                request_method = request_dict["requestMethod"]
                if request_method in basic_uri_sub_command_dict:
                    # request_methodに対応した辞書を使用する
                    single_basic_uri_sub_command_dict = basic_uri_sub_command_dict[
                        request_method
                    ]
                    sub_command = self._get_cli_sub_command(
                        request_url, single_basic_uri_sub_command_dict
                    )
                    sub_command_dic = {"subCommand": sub_command}
                    wk_new_request = {"request": OrderedDict()}
                    wk_new_request["request"].update(sub_command_dic)
                    new_request.update(wk_new_request)

        return new_request

    def _generate_new_affected_resources(
        self, affected_resources: list, basic_uri_sub_command_dict: dict
    ):
        """
        affectedResourcesの編集
        :param affected_resources:
        :param basic_uri_sub_command_dict:
        :return: 騙取済みaffectedResources
        """
        new_affected_resources = []
        new_affected_resource = OrderedDict()
        parameters_wk_dict = OrderedDict()
        parameters_dict_list = []
        for i, uri in enumerate(affected_resources):
            # affectedResourcesで使用するsingle_basic_uri_sub_command_dictは、'GET'固定
            sub_command = self._get_cli_sub_command(
                uri, basic_uri_sub_command_dict["GET"]
            )

            if sub_command is not None:
                # sub_commandが見つかった
                parameters = self._get_cli_option(
                    uri, basic_uri_sub_command_dict["GET"]
                )
                new_affected_resource.clear()
                new_affected_resource["subCommand"] = sub_command
                parameters_dict_list.clear()
                parameters_wk_dict.clear()
                for k, v in parameters.items():
                    name_dict = {"name": k}
                    parameters_wk_dict.update(name_dict)
                    value_dict = {"value": v}
                    parameters_wk_dict.update(value_dict)

                    # append.parameters_wk_dict だとループ2回めでparameters_dict_list[0]も上書きされてしまうので
                    # parameters_wk_dict.copy()を使用する
                    parameters_dict_list.append(parameters_wk_dict.copy())
                new_affected_resource.setdefault(
                    "parameters", parameters_dict_list.copy()
                )
                new_affected_resources.append(new_affected_resource.copy())
            else:
                # 見つからなかった場合、uriをそのまま入れる
                new_affected_resources.append(uri)

        return new_affected_resources

    def is_error_source2(self, wk_diict: dict):
        for k in dict(wk_diict):
            if k == "errorSource":
                return True
        return False

    def is_error_source(self, wk_dict: dict):
        if "error" in dict(wk_dict):
            for k, v in wk_dict.items():
                if k == "error" and isinstance(v, dict):
                    return self.is_error_source2(v)
        return False

    def _convert_url_main(
        self, single_response: dict, basic_uri_sub_command_dict: dict
    ):
        """
        編集 main部
        :param single_response:
        :param basic_uri_sub_command_dict:
        :return: 騙取後のjson
        """
        new_single_response = single_response.copy()

        # "request": の編集
        if "request" in single_response:

            request_dict = single_response["request"]
            if "requestUrl" in request_dict:
                request_url = request_dict["requestUrl"]
                new_request = self._generate_new_request(
                    request_dict, basic_uri_sub_command_dict
                )

                # subCommand見つからなかったら変更しない
                if new_request["request"]["subCommand"] is not None:
                    new_single_response.update(new_request)

        # "affectedResources": の編集
        new_affected_resources = []
        if "affectedResources" in single_response:
            affected_resources = single_response["affectedResources"]
            new_affected_resources.clear()
            assert isinstance(affected_resources, object)
            if affected_resources is not None:
                new_affected_resources = self._generate_new_affected_resources(
                    affected_resources, basic_uri_sub_command_dict
                )
                replace_affected_resources = {
                    "affectedResources": new_affected_resources
                }
                new_single_response.update(replace_affected_resources.copy())

        # "selfの削除"
        if "self" in new_single_response:
            list_self = ["self"]
            new_single_response = self._del_dic_main(new_single_response, list_self)

        # "error": "errorSource"の削除
        if "error" in new_single_response:
            # OrderdDictは、こんな面倒くさいことをやらないといけない
            # if new_single_response.get('error', {}).get('errorSource') is not None:
            if self.is_error_source(new_single_response):
                new_single_response = self._del_dic_main(
                    new_single_response, ["error.errorSource"]
                )

        # "errorSource"の削除
        if "errorSource" in new_single_response:
            new_single_response = self._del_dic_main(
                new_single_response, ["errorSource"]
            )

        return new_single_response

    def convert_url_to_sub_command(
        self, response_data: str, basic_uri_sub_command_dict: dict
    ) -> object:
        """
        下記のようにrequest:のrequestutlとaffectedResourcesのurlをsubコマンドに置き換えた辞書を返す
        Rest API
        "request": {
            "requestUrl": "/ConfigurationManager/simple/v1/objects/servers/c2ce7548-bd91-4cac-b423-09b703c1fd55/hbas/8d6ceba0-2975-407a-8836-03f90a4f6817",
            "requestMethod": "DELETE",
            "requestBody": ""
        },
        "affectedResources": [
            " v1/objects/volumes/XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
        ]
         ⇒
        CLI
        "request": {
            "subCommand": "hba_delete",
        },
        "affectedResources": [
        {
            "subCommand": "volume_show",
            "parameters": [
                 {
                     "name": "id",
                     "value": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
                }
            ]
        }

        :return:
        :param basic_uri_sub_command_dict:
        :param response_data:
        :return: response_dataから変換した辞書を編集したもの
        """
        # responseをpython辞書に変換する
        response_dict = json.loads(
            response_data, object_pairs_hook=collections.OrderedDict
        )
        new_response_dict = response_dict.copy()

        if "body" in response_dict:
            # listの場合
            if "data" in response_dict["body"]:
                data_list = response_dict["body"]["data"]
                new_data_list = []
                for item in data_list:
                    single_json_dict = self._convert_url_main(
                        item, basic_uri_sub_command_dict
                    )
                    new_data_list.append(single_json_dict.copy())
                new_data = {"data": new_data_list}
                new_response_dict["body"].update(new_data.copy())
            # 単体の場合
            else:
                body_dict = response_dict["body"]
                new_body = self._convert_url_main(body_dict, basic_uri_sub_command_dict)
                new_body_dic = {"body": new_body}
                new_response_dict.update(new_body_dic.copy())

        return new_response_dict

    # def echo_normal(self, response_json: str, form):
    #     """
    #     暫定処理
    #     RequestUrl: URLをサブコマンドに変換
    #     affectedResource: URLとIDをサブコマンド+オプション+IDに変換して出力する
    #     :param response_json:
    #     :return:
    #     """
    #     if self.isJsonFormat(response_json):
    #         new_response_dict = self.convert_url_to_sub_command(response_json, self.basic_uri_cli_sub_command_dict)
    #
    #         if form == 'text':
    #             # statusCodeを取っ払う
    #             key_list = ['httpStatusCode']
    #             body_key_list = []
    #
    #             d = self._del_dic_mapper(new_response_dict, key_list, body_key_list)
    #
    #             self.dic_to_plain_format(d)
    #         else:
    #             click.echo(json.dumps(new_response_dict, indent=4))
    #     else:
    #         click.echo('Response is not in json format.')
    #         click.echo(response_json)

    def get_field_names(self, sub_command):
        """
        CLI subCommandに対応したfieldnamesを返す
        :param sub_command:
        :return:
        """

        if sub_command == "server_list":
            return [
                "nickname",
                "id",
                "osType",
                "numberOfPaths",
                "usedCapacity",
                "totalCapacity",
            ]
        elif sub_command == "volume_list":
            return [
                "name",
                "id",
                "nickname",
                "volumeType",
                "statusSummary",
                "status",
                "snapshotStatus",
                "totalCapacity",
                "usedCapacity",
            ]
        elif sub_command == "hba_list":
            return ["name", "id", "protocol"]
        elif sub_command == "port_list":
            return [
                "name",
                "id",
                "protocol",
                "type",
                "statusSummary",
                "status",
                "portSpeed",
                "configuredPortSpeed",
            ]
        elif sub_command == "pool_list":
            return [
                "name",
                "id",
                "statusSummary",
                "status",
                "totalCapacity",
                "usedCapacity",
            ]
        else:
            # 呼び出し元で組み合わせチェックを行っているので残りはchap_user_list
            return ["targetChapUserName", "id", "initiatorChapUserName"]

    def get_csv_header(self, sub_command):
        """
        CLI subCommandに対応したfieldnamesを返す
        :param sub_command:
        :return:
        """

        if sub_command == "server_list":
            return '"Nickname","Id","Os Type","Number Of Paths","Used Capacity","Total Capacity"'
        elif sub_command == "volume_list":
            return '"Name","Id","Nickname","Volume Type","Status Summary","Status","Snapshot Status","Total Capacity","Used Capacity"'
        elif sub_command == "hba_list":
            return '"Name","Id","Protocol"'
        elif sub_command == "port_list":
            return '"Name","Id","Protocol","Type","Status Summary","Status","Port Speed","Configured Port Speed"'
        elif sub_command == "pool_list":
            return (
                '"Name","Id","Status Summary","Status","Total Capacity","Used Capacity"'
            )
        else:
            # 呼び出し元で組み合わせチェックを行っているので残りはchap_user_list
            return '"Target Chap User Name","Id","Initiator Chap User Name"'

    def echo_csv(self, response_data, sub_commnad, print_header=True):
        """
        respons dataの一部の属性をCSV形式で出力する
        :param response_data:
        :param sub_commnad:
        :return:
        """

        if print_header:
            # ヘッダーの出力
            click.echo(self.get_csv_header(sub_commnad))

        # responseをpython辞書に変換する
        response_dict = json.loads(
            response_data, object_pairs_hook=collections.OrderedDict
        )

        if "body" in response_dict:
            # listの場合
            if "data" in response_dict["body"]:
                data_list = response_dict["body"]["data"]

                # csv
                field_names = self.get_field_names(sub_commnad)
                self.writer = csv.DictWriter(
                    sys.stdout,
                    fieldnames=field_names,
                    extrasaction="ignore",
                    lineterminator="\n",
                    quoting=csv.QUOTE_NONNUMERIC,
                )
                writer = self.writer
                # delimiter=",", quotechar='"')
                # writer.writeheader()

                # dataの出力
                for item in data_list:
                    writer.writerow(item)

    def check_format_csv(self, sub_command):
        config = Configuration()

        # server_list, volume_list, hba_list, port_list, pool_list, chap_user_list以外のサブコマンドでsimple-csvを指定した場合、エラーを出力する
        if sub_command == "server_list":
            return
        elif sub_command == "volume_list":
            return
        elif sub_command == "hba_list":
            return
        elif sub_command == "port_list":
            return
        elif sub_command == "pool_list":
            return
        elif sub_command == "chap_user_list":
            return
        else:
            config.messageId = "19021"
            config.messageDict = {"sub_command": sub_command}
            return

    def echo_error(self, response_json: str, form):
        """
        Responseを読み込んでerror属性のオブジェクト(response.bodyまたはresponse.body.error)をstderrに出力する
        textの場合
        body.data.errorSourceまたはbody.errorSourceを削除して出力
        jsonの場合
        そのままjsonフォーマットで出力
        :param response_json: APIのレスポンス
        :param form: 出力フォーマット
        :return:
        """
        # プログレスバーを表示している場合は標準エラー出力に改行を出力
        progress_util = ProgressUtil()
        progress_util.check_progress_shown_and_output_line_feed()

        if self.isJsonFormat(response_json):
            # responseをpython辞書に変換する
            d = json.loads(response_json, object_pairs_hook=collections.OrderedDict)

            if form == "text":
                if "body" in d:
                    body_dict = d["body"]
                    # bodyの中のerror配下(job応答またはjob_show実行時)
                    if "error" in body_dict:
                        with redirect_stdout(sys.stderr):
                            # statusCodeを取っ払う
                            delete_key_list = ["httpStatusCode"]
                            delete_body_key_list = []
                            d = self._del_dic_mapper(
                                d, delete_key_list, delete_body_key_list
                            )
                            # "error": "errorSource"の削除
                            if "error" in body_dict:
                                # OrderedDictは、こんな面倒くさいことをやらないといけない
                                if "errorSource" in body_dict["error"]:
                                    d = self._del_dic_main(
                                        d, ["body.error.errorSource"]
                                    )
                            self.dic_to_plain_format(d.get("body").get("error"))
                        return True

                    # body配下 (errorResponseの時)
                    else:
                        with redirect_stdout(sys.stderr):
                            # statusCodeを取っ払う
                            delete_key_list = ["httpStatusCode"]
                            delete_body_key_list = []
                            d = self._del_dic_mapper(
                                d, delete_key_list, delete_body_key_list
                            )
                            # errorSource"の削除
                            if "errorSource" in body_dict:
                                d = self._del_dic_main(d, ["body.errorSource"])
                            self.dic_to_plain_format(d)
                        return True

            else:
                if "body" in d:
                    body_dict = d["body"]
                    # bodyの中のerror配下(job応答またはjob_show実行時
                    if "error" in body_dict:
                        with redirect_stdout(sys.stderr):
                            click.echo(json.dumps(d.get("body").get("error"), indent=4))
                        return True
                    # body配下 (errorResponseの時)
                    else:
                        with redirect_stdout(sys.stderr):
                            click.echo(json.dumps(d.get("body"), indent=4))
                        return True
        # jsonではない
        else:
            # ありえない
            click.echo(response_json)
            return False
