# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import traceback
import logging as loggingLib
import os

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil

logger = loggingLib.getLogger(__name__)


def server_certificate_import_manual(_server_certificate, _secret_key, callback, debug):
    """
    Imports the server certificate.
    """

    try:
        #ファイルが存在するか
        if not(os.path.isfile(_server_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_server_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        if not(os.path.isfile(_secret_key)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_secret_key)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        from com.hitachi.sophia.rest_client.autogen.apis.secure_communication_management import SecureCommunicationManagement as SecureCommunicationManagementApi
        api = SecureCommunicationManagementApi(ApiClient())

        sub_command = "server_certificate_import"

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

        response = api.import_server_certificate(_server_certificate, _secret_key, callback=callback, debug=debug)
        config = Configuration()
        output_util = OutputUtil()
        output_util.echo_normal(response, config.format, sub_command)
        #click.echo(response)
        commonutil = CommonUtil()
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))

    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _server_certificate) + ', ' + os.path.abspath(_secret_key) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {
            'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(
                _server_certificate) + ', ' + os.path.abspath(_secret_key) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

def web_server_access_setting_set_manual(_is_enabled, _client_names, callback, debug):
    """
    Edits the access settings of the web server.
    """
    from com.hitachi.sophia.rest_client.autogen.apis.secure_communication_management import SecureCommunicationManagement as SecureCommunicationManagementApi
    api = SecureCommunicationManagementApi(ApiClient())

    cliSubCommand = "web_server_access_setting_set"
    commonutil = CommonUtil()
    config = Configuration()

    if _is_enabled is not None:
        if(isinstance(_is_enabled, str)):
            _is_enabled = SeparateArgs.check_backslash(_is_enabled)
            _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")
    if _client_names is not None:
        if(isinstance(_client_names, str)):
            _client_names = SeparateArgs.check_backslash(_client_names)
            _client_names = _client_names.encode("utf-8").decode("unicode-escape")
    
    # 入力チェックのため、allowlistSettingにオプション指定値をセット（WarningBanner取得より先に実施）
    from com.hitachi.sophia.rest_client.autogen.models.AllowlistSettingOfEditWebServerAccessSetting import AllowlistSettingOfEditWebServerAccessSetting
    tmp_allowlist_setting_of_edit_web_server_access_setting = AllowlistSettingOfEditWebServerAccessSetting()
    allowlist_setting_of_edit_web_server_access_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
    
    allowlist_setting_of_edit_web_server_access_setting = commonutil.set_parameter_with_instance(allowlist_setting_of_edit_web_server_access_setting,
        tmp_allowlist_setting_of_edit_web_server_access_setting, 'is_enabled', _is_enabled)
    allowlist_setting_of_edit_web_server_access_setting = commonutil.set_parameter_with_instance(allowlist_setting_of_edit_web_server_access_setting,
        tmp_allowlist_setting_of_edit_web_server_access_setting, 'client_names', _client_names)
    
    # WarningBanner取得
    if not ('Authorization' in config.api_key):
        warningbanner = WarningBanner()
        warningbanner.sub_command_name = cliSubCommand
        login_message_response = warningbanner.get_login_message()
        login_message = warningbanner.view_warning_banner(login_message_response)

        commonutil.view_error()

        #空文字,Nullの場合はログインメッセージを表示しない
        if(login_message):
            click.echo(login_message, err=True)

    commonutil.input_password()

    # ストレージクラスターとCLIのバージョンチェック
    versioncheck = VersionCheck()
    api_version_response = versioncheck.get_api_version()
    versioncheck.version_check(api_version_response)

    # クラスターバージョン≒RESTサーバーのバージョンにより、allowlistSetting／whitelistSettingを使い分ける
    from com.hitachi.sophia.rest_client.autogen.models.PatchWebServerAccessSettingParam import PatchWebServerAccessSettingParam
    tmp_patch_web_server_access_setting_param = PatchWebServerAccessSettingParam()
    _patch_web_server_access_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。

    api_version = versioncheck.get_api_version_from_response(api_version_response)
    if api_version is not None and api_version >= '01.17.00.00':
        # V1.17以降の場合: allowlistSettingをセットする
        _patch_web_server_access_setting_param = commonutil.set_parameter_with_instance(_patch_web_server_access_setting_param, tmp_patch_web_server_access_setting_param,
            'allowlist_setting', allowlist_setting_of_edit_web_server_access_setting)

    else:
        # V1.16以前or取得失敗の場合: whitelistSettingをセットする
        from com.hitachi.sophia.rest_client.autogen.models.WhitelistSettingOfEditWebServerAccessSetting import WhitelistSettingOfEditWebServerAccessSetting
        tmp_whitelist_setting_of_edit_web_server_access_setting = WhitelistSettingOfEditWebServerAccessSetting()
        whitelist_setting_of_edit_web_server_access_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        
        whitelist_setting_of_edit_web_server_access_setting = commonutil.set_parameter_with_instance(whitelist_setting_of_edit_web_server_access_setting,
            tmp_whitelist_setting_of_edit_web_server_access_setting, 'is_enabled', _is_enabled)
        whitelist_setting_of_edit_web_server_access_setting = commonutil.set_parameter_with_instance(whitelist_setting_of_edit_web_server_access_setting,
            tmp_whitelist_setting_of_edit_web_server_access_setting, 'client_names', _client_names)
        _patch_web_server_access_setting_param = commonutil.set_parameter_with_instance(_patch_web_server_access_setting_param, tmp_patch_web_server_access_setting_param,
            'whitelist_setting', whitelist_setting_of_edit_web_server_access_setting)

    # API実行
    response = api.web_server_firewall_setting_set(patch_web_server_access_setting_param = _patch_web_server_access_setting_param, callback=None, debug="false")

    # click.echo(response)
    oup = OutputUtil()
    oup.echo_normal(response, config.format, cliSubCommand)
    status = commonutil.get_response_status(response)
    exit(commonutil.get_cli_exit_code_for_api_execution(status))
