"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import os
import re
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil

class FileUtil(object):
    def __init__(self,_filename):
        self.default_filename = _filename

    def locate_download_file(self,_filepath):
        """
        Constructor of the class.
        """

        # filepathが指定されているかどうか
        if (_filepath is None or _filepath == ''):
            dirname = "./"
            filename = self.default_filename

        # filepathがディレクトリか
        elif(self.isDir(_filepath)):
            dirname = _filepath
            filename = self.default_filename

        # filepathがディレクトリ＋ファイル
        elif(self.isDirFile(_filepath)):
            dirname = os.path.dirname(_filepath)
            filename = os.path.basename(_filepath)

        # filepathがファイル
        elif(self.isFile(_filepath)):
            dirname = "./"
            filename = _filepath

        #それ以外
        else:
            # 指定したディレクトリが存在しない
            mssageManagement = MessageManagement('')
            messageId = '19005'
            messageDict = {'filePath': os.path.abspath(_filepath)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        return dirname,filename

    def isDir(self,_filepath):
        # 末尾が「/」指定の場合
        if (_filepath[-1:] == "/"):
            return True
        # 指定されたディレクトリが存在する
        elif (os.path.isdir(_filepath)):
            return True

        return False

    def isDirFile(self,_filepath):
        # 一つ上のパスがあるかどうか
        pos = _filepath.rfind('/')
        if not (pos==-1):
            dir = _filepath[:pos+1]
            if (os.path.isdir(dir)):
                return True

        return False

    def isFile(self,_filepath):
        # 「/」が含まれない
        if not('/' in _filepath):
            return True

        return False

    @staticmethod
    def getFileNameWithResponse(response):
        download_filename = None
        content_disposition = response.getheader("Content-Disposition")
        if (content_disposition):
            # 汎用メソッドであるため、ここでは特にチェックせず取得可能とする.
            download_filename = re.search('filename="?([^"]+)"?(;|$)', content_disposition).group(1)
            if CommonUtil().check_ignore_filename(download_filename):
                download_filename = None
        if (download_filename is None):
            # レスポンスヘッダーからファイル名が取得できなかった場合、ファイル名は”hsds_log_unknown.bin”とする.
            download_filename = "hsds_log_unknown.bin"
        return download_filename
