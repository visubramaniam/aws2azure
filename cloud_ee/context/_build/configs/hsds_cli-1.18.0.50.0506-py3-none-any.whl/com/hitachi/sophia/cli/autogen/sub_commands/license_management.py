# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--key_code','_key_code',type=str,metavar='<str>',help='License key.',required=True)
def license_install(_key_code,):
    """
    Registers a license. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "license_install"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _key_code is not None:
            subCommandLogtxt += "--key_code " + str(_key_code) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.license_management import LicenseManagement as LicenseManagementApi
        api = LicenseManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "license_install"



















        if _key_code is not None:
            if(isinstance(_key_code, str)):
                _key_code = SeparateArgs.check_backslash(_key_code)
                _key_code = _key_code.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.InstallLicenseParam import InstallLicenseParam
        _install_license = InstallLicenseParam()
        _install_license.key_code = _key_code

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.install_license(install_license = _install_license, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--program_product_name','_program_product_name',metavar='<str>',help='Program Product name. ')
@click.option('--status','_status',metavar='<str>',help='License status. ')
@click.option('--status_summary','_status_summary',metavar='<str>',help='Summary of license status. ')
def license_list(_program_product_name,_status,_status_summary,):
    """
    Obtains the list of license information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "license_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _program_product_name is not None:
            subCommandLogtxt += "--program_product_name " + str(_program_product_name) + " "




        if _status is not None:
            subCommandLogtxt += "--status " + str(_status) + " "




        if _status_summary is not None:
            subCommandLogtxt += "--status_summary " + str(_status_summary) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.license_management import LicenseManagement as LicenseManagementApi
        api = LicenseManagementApi(ApiClient())

        


        
        


        #Enumチェック
        allowed_values = ["Active", "Warning", "Overwritten", "GracePeriod", "Invalid"]

        if _status is not None:
            if _status not in allowed_values:
                raise ValueError(
                    "Invalid value for `status` ({0}), (Select only one) {1}"
                    .format(_status, allowed_values)
            )
        
        


        #Enumチェック
        allowed_values = ["Normal", "Warning", "Error"]

        if _status_summary is not None:
            if _status_summary not in allowed_values:
                raise ValueError(
                    "Invalid value for `status_summary` ({0}), (Select only one) {1}"
                    .format(_status_summary, allowed_values)
            )
        
        


        
        
        
        
        
        #cliSubCommand = "license_list"

        if _program_product_name is not None and len(_program_product_name) > 63:
            raise ValueError("Invalid value for parameter `program_product_name` when calling `" + cliSubCommand + "`, length must be less than or equal to `63`")
#           raise ValueError("Invalid value for parameter `program_product_name` when calling `license_list`, length must be less than or equal to `63`")
        if _program_product_name is not None and len(_program_product_name) < 1:
            raise ValueError("Invalid value for parameter `program_product_name` when calling `" + cliSubCommand + "`, length must be greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `program_product_name` when calling `license_list`, length must be greater than or equal to `1`")





























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.LicenseList import LicenseList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.license_list(program_product_name = _program_product_name, status = _status, status_summary = _status_summary, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--remaining_days','_remaining_days',type=int,metavar='<int>',help='Warning remaining days.')
@click.option('--total_pool_capacity_rate','_total_pool_capacity_rate',type=int,metavar='<int>',help='Warning capacity rate.')
@click.option('--overcapacity_allowed','_overcapacity_allowed',metavar='<bool>',help='Setting to enable or disable maintenance operations exceeding the logical capacity of storage pools allowed by the license on AWS License Manager. This setting can be enabled only for the cloud model products to which contract-based charge applies. Specification of this option is ignored for products other than the cloud model products to which contract-based charge applies.')
def license_setting_set(_remaining_days,_total_pool_capacity_rate,_overcapacity_allowed,):
    """
    Edits the license settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "license_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _remaining_days is not None:
            subCommandLogtxt += "--remaining_days " + str(_remaining_days) + " "




        if _total_pool_capacity_rate is not None:
            subCommandLogtxt += "--total_pool_capacity_rate " + str(_total_pool_capacity_rate) + " "




        if _overcapacity_allowed is not None:
            subCommandLogtxt += "--overcapacity_allowed " + str(_overcapacity_allowed) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.license_management import LicenseManagement as LicenseManagementApi
        api = LicenseManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "license_setting_set"



















        if _remaining_days is not None:
            if(isinstance(_remaining_days, str)):
                _remaining_days = SeparateArgs.check_backslash(_remaining_days)
                _remaining_days = _remaining_days.encode("utf-8").decode("unicode-escape")
        if _total_pool_capacity_rate is not None:
            if(isinstance(_total_pool_capacity_rate, str)):
                _total_pool_capacity_rate = SeparateArgs.check_backslash(_total_pool_capacity_rate)
                _total_pool_capacity_rate = _total_pool_capacity_rate.encode("utf-8").decode("unicode-escape")
        if _overcapacity_allowed is not None:
            if(isinstance(_overcapacity_allowed, str)):
                _overcapacity_allowed = SeparateArgs.check_backslash(_overcapacity_allowed)
                _overcapacity_allowed = _overcapacity_allowed.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchLicenseSettingParam import PatchLicenseSettingParam
        tmp_patch_license_setting_param = PatchLicenseSettingParam()
        patch_license_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.WarningThresholdSettingOfEditLicenseSetting import WarningThresholdSettingOfEditLicenseSetting
        tmp_warning_threshold_setting_of_edit_license_setting = WarningThresholdSettingOfEditLicenseSetting()
        warning_threshold_setting_of_edit_license_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        warning_threshold_setting_of_edit_license_setting = commonutil.set_parameter_with_instance(warning_threshold_setting_of_edit_license_setting, tmp_warning_threshold_setting_of_edit_license_setting, 'remaining_days', _remaining_days)
        

        warning_threshold_setting_of_edit_license_setting = commonutil.set_parameter_with_instance(warning_threshold_setting_of_edit_license_setting, tmp_warning_threshold_setting_of_edit_license_setting, 'total_pool_capacity_rate', _total_pool_capacity_rate)
        

        patch_license_setting_param = commonutil.set_parameter_with_instance(patch_license_setting_param, tmp_patch_license_setting_param, 'overcapacity_allowed', _overcapacity_allowed)
        patch_license_setting_param = commonutil.set_parameter_with_instance(patch_license_setting_param, tmp_patch_license_setting_param, 'warning_threshold_setting', warning_threshold_setting_of_edit_license_setting)
        _patch_license_setting = patch_license_setting_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.license_setting(patch_license_setting = _patch_license_setting, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def license_setting_show():
    """
    Obtains the license settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "license_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.license_management import LicenseManagement as LicenseManagementApi
        api = LicenseManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "license_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.LicenseSetting import LicenseSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.license_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='License ID. ',required=True)
def license_show(_id,):
    """
    Obtains the license information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "license_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.license_management import LicenseManagement as LicenseManagementApi
        api = LicenseManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "license_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.License import License

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.license_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='License ID. ',required=True)
def license_uninstall(_id,):
    """
    Deletes the license. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "license_uninstall"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.license_management import LicenseManagement as LicenseManagementApi
        api = LicenseManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "license_uninstall"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.uninstall_license(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['license_install'] = license_install
    commands['license_list'] = license_list
    commands['license_setting_set'] = license_setting_set
    commands['license_setting_show'] = license_setting_show
    commands['license_show'] = license_show
    commands['license_uninstall'] = license_uninstall
    return commands

