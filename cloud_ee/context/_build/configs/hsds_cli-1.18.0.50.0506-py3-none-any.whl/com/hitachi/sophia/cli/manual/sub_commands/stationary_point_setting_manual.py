# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2021, 2024, Hitachi Vantara, Ltd.
"""
import collections
import json

import click
import logging as loggingLib
import os
import traceback
import time
import ipaddress
from enum import IntEnum
import urllib3
import re
from urllib.parse import urlparse

from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.util.configfile_util import ConfigfileUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.rest_certificate_util import RestCertificateUtil

# 自動生成対象外コード
# 静止点設定CLI
# ESXi版以外で使用

logger = loggingLib.getLogger(__name__)


class Output_message_type(IntEnum):
    success = 0
    internal_error = 1
    time_out = 2

def is_valid_hostname(hostname: str) -> bool:
    if len(hostname) > 255:
        return False

    # strip exactly one dot from the right, if present
    if hostname[-1] == ".":
        hostname = hostname[:-1]
    allowed = re.compile(r"(?!-)[A-Z0-9-]{1,63}(?<!-)$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))

@click.command(options_metavar='<options>')
@click.option('--point', '_point', type=str, metavar='<str>', help='Stationary point.', required=True)
@click.option('--maintenance', '_maintenance', metavar='<bool>', help='Startup maintenance mode.')
@click.option('--initialize_storage_controller', '_clear_svos_mapping', metavar='<bool>', help='Initialize storage controller information.')
@click.option('--system_configuration_file', '_system_configuration_file', type=str, metavar='<str>', help='Specifies the configuration file. (Bare metal)')
@click.option('--vm_configuration_file', '_vm_configuration_file', type=str, metavar='<str>', help='Specifies the VM configuration file. (Cloud for AWS)(Cloud for Microsoft Azure)(Cloud for Google Cloud)')
@click.option('--targets', '_targets', type=str, metavar='<str>',help='List of IP address (IPv4) for the control network or FQDN.')
def set_stationary_point(_point, _maintenance, _clear_svos_mapping, _system_configuration_file, _vm_configuration_file, _targets):
    """
    Sets the stationary point to a storage node.
    """
    # set stationary point(config parameter).
    try:
        config = Configuration()
        common_util = CommonUtil()
        configfile_util = ConfigfileUtil()
        common_util.view_error()

        # 認証パラメータのチェック チケット認証のみサポート
        # manual/util/auth_parameters_util.py
        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('', '', 'true')
        auth_parameter_util.check_auth_parameter('', '', 'true')

        # Configurationインスタンスにエラーメッセージが格納されていたら出力して処理終了
        # 引数指定に問題があればここで終了
        # manual/util/common_util.py
        common_util.view_error()

        sub_command_log_txt = "Sub-command parameters : " + " "
        cli_sub_command = "set_stationary_point"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cli_sub_command)
            common_util.view_error()
        elif config.format == 'json':
            logger.error("Not available sub-command.")
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: When the subcommand is {}, json cannot be specified for --format.".format("set_stationary_point"))
            click.echo("Solution: Specify text for --format.")
            exit(1)

        # サブコマンドパラメータのログ出力 パスワードは、伏せ字
        if _point is not None:
            sub_command_log_txt += "--point " + str(_point) + " "
        if _maintenance is not None:
            sub_command_log_txt += "--maintenance " + str(_maintenance) + " "
        if _clear_svos_mapping is not None:
            sub_command_log_txt += "--initialize_storage_controller " + str(_clear_svos_mapping) + " "
        if _system_configuration_file is not None:
            sub_command_log_txt += "--system_configuration_file " + str(_system_configuration_file) + " "
        if _vm_configuration_file is not None:
            sub_command_log_txt += "--vm_configuration_file " + str(_vm_configuration_file) + " "
        if _targets is not None:
            sub_command_log_txt += "--targets " + str(_targets) + " "

        logger.info(sub_command_log_txt)

        common_util.input_password()

        # 適切なプラットフォーム種別へのCLI実行であるのかを確認するためにNative版専用APIを実行
        logger.info("Check platform and available sub-command.")
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())
        response = api.storage_node_configuration_parameter_polling_mode_show(callback=None, debug="false")
        # httpStatuCode取得
        http_status_code = common_util.get_response_status(response)
        if http_status_code == 200:
            logger.info("Available sub-command.")
        elif http_status_code == 412:
            # 適切なプラットフォームではない場合
            logger.error("Not available sub-command.")
            click.echo("Message: The command could not be executed.")
            click.echo("Cause: This command is not supported by the destination storage cluster.")
            click.echo("Solution: Verify that the destination of the command is correct. If the destination is correct, see the manual corresponding to the platform type to verify that the procedure is correct.")
            exit(1)
        elif http_status_code == 401:
            # 認証失敗の場合
            logger.error("Unauthorized.")
            click.echo("Message: User authentication with the authentication ticket did not succeed.")
            click.echo("Cause: User ID, password, or the authentication ticket is not correct.")
            click.echo("Solution: Review the user ID, password, and authentication ticket to be used.")
            exit(1)
        else:
            logger.error('Failed to check available sub-command.')
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: An unexpected error occurred.")
            click.echo("Solution: Collect the logs, and then contact customer support.")
            exit(1)

        # 引数確認
        # _point
        point_str = _point
        if _point is not None:
            point_str = SeparateArgs.check_backslash(point_str)
            point_str = point_str.encode("utf-8").decode("unicode-escape")
            if point_str not in ["NoService", "UpSOAPI", "UpControlPlane", "NonstopBoot"]:
                raise ValueError("--point that does not exist is specified.")

        # _maintenance
        maintenance_str = 'False'
        if _maintenance is not None:
            if(isinstance(_maintenance, str)):
                maintenance_str = _maintenance
                maintenance_str = SeparateArgs.check_backslash(maintenance_str)
                maintenance_str = maintenance_str.encode("utf-8").decode("unicode-escape")
                if (maintenance_str != 'True' and maintenance_str != 'False')\
                    and (maintenance_str != 'true' and maintenance_str != 'false')\
                    and (maintenance_str is not True and maintenance_str is not False):
                    raise ValueError("--maintenance that not boolean was specified.")

            if _maintenance is True:
                maintenance_str = 'True'
            if _maintenance is False:
                maintenance_str = 'False'
            if _maintenance == 'true':
                maintenance_str = 'True'
            if _maintenance == 'false':
                maintenance_str = 'False'

        # _clear_svos_mapping
        clear_svos_mapping_str = 'False'
        if _clear_svos_mapping is not None:
            if(isinstance(_maintenance, str)):
                clear_svos_mapping_str = _clear_svos_mapping
                clear_svos_mapping_str = SeparateArgs.check_backslash(clear_svos_mapping_str)
                clear_svos_mapping_str = clear_svos_mapping_str.encode("utf-8").decode("unicode-escape")
                if (clear_svos_mapping_str != 'True' and clear_svos_mapping_str != 'False')\
                    and (clear_svos_mapping_str != 'true' and clear_svos_mapping_str != 'false')\
                    and (clear_svos_mapping_str is not True and clear_svos_mapping_str is not False):
                    raise ValueError("--initialize_storage_controller that not boolean was specified.")

            if _clear_svos_mapping is True:
                clear_svos_mapping_str = 'True'
            if _clear_svos_mapping is False:
                clear_svos_mapping_str = 'False'
            if _clear_svos_mapping == 'true':
                clear_svos_mapping_str = 'True'
            if _clear_svos_mapping == 'false':
                clear_svos_mapping_str = 'False'

        # 構成リストア手順上2回目の静止点コマンドで--maintenance trueをつけ忘れた場合ドライブ閉塞を検知してクラスタダウンになる可能性がある
        # AWS版ではドライブIDがすべて変化するため確実にクラスタダウンする
        # 防ぐために --initialize_storage_controller trueが指定された場合に--maintenance trueが指定されていない場合エラーに倒す
        if clear_svos_mapping_str == 'True':
            if _maintenance is None or maintenance_str == 'False':
                logger.error("clear_svos_mapping_str is true, maintenance_str is not true")
                click.echo("Message: An error has occurred when executing the command.")
                click.echo("Cause: --initialize_storage_controller true was specified but --maintenance true was not specified.")
                click.echo("Solution: When specifying --initialize_storage_controller true, --maintenance true must also be specified.")
                exit(1)

        # 静止点設定先のストレージノード情報を取得
        sys_conf_dict = {}
        if _system_configuration_file is None and _vm_configuration_file is None and _targets is None:
            raise ValueError("--system_configuration_file or --targets is required. (Bare metal) --vm_configuration_file or --targets is required.  (Cloud)")
        elif _system_configuration_file is not None:
            if _vm_configuration_file is not None:
                # _system_configuration_fileと_vm_configuration_fileをどちらも指定したケース
                # どのプラットフォーム種別なのか判断がつかないため引数エラーに倒す
                raise ValueError("--system_configuration_file or --targets can be specified. (Bare metal) --vm_configuration_file or --targets can be specified. (Cloud)")
            if _targets is not None:
                click.echo("Both --system_configuration_file and --targets are set. --targets is ignored.")
            # _system_configuration_file
            if os.path.isfile(_system_configuration_file):
                rtrn, control_addr, errmsg = configfile_util.get_control_address_from_csv(_system_configuration_file)
                if rtrn != 0:
                    logger.error(errmsg)
                    click.echo("Message: {}".format(errmsg))
                    click.echo("Cause: Appropriate file is not specified.")
                    click.echo("Solution: Review configuration file and specify the option value correctly.")
                    exit(1)
                sys_conf_dict = {"Nodes": []}
                for addr in control_addr:
                    sys_conf_dict["Nodes"].append({"HostName": "", "ControlNWIPv4": addr})
                with open(_system_configuration_file) as f:
                    # HostNameを取得する。
                    lines = f.readlines()
                    required_line_flag = False
                    for line in lines:
                        if required_line_flag:
                            # [Nodes]セクションより後の行。
                            for node in sys_conf_dict["Nodes"]:
                                if node["ControlNWIPv4"] in line:
                                    # 管理ポートアドレスを含んでいる行からHostNameを取得する。
                                    node["HostName"] = line.split(",")[0]
                        if "[Nodes]" in line:
                            required_line_flag = True
            else:
                raise FileNotFoundError("Specified configuration file does not exist.")
        elif _vm_configuration_file is not None:
            if _targets is not None:
                click.echo("Both --vm_configuration_file and --targets are set. --targets is ignored.")
            # _vm_configuration_file
            rtrn, control_addr, errmsg = configfile_util.get_control_address_from_vm_configuration_file(_vm_configuration_file)
            if rtrn != 0:
                logger.error(errmsg)
                click.echo("Message: {}".format(errmsg))
                click.echo("Cause: Appropriate file is not specified.")
                click.echo("Solution: Review configuration file and specify the option value correctly.")
                exit(1)
            sys_conf_dict = {"Nodes": []}
            for addr in control_addr:
                sys_conf_dict["Nodes"].append({"HostName": "", "ControlNWIPv4": addr})
        else:
            # _targets
            targets_str = _targets
            targets_str = SeparateArgs.check_backslash(targets_str)
            targets_str = targets_str.encode("utf-8").decode("unicode-escape")
            target_list = targets_str.split(",")
            sys_conf_dict["Nodes"] = []
            for target in target_list:
                # IPアドレスの書式チェック
                try:
                    ipaddress.IPv4Address(target.strip())
                except ipaddress.AddressValueError:
                    # FQDNの書式チェック
                    if not is_valid_hostname(target):
                        raise ValueError("--targets has invalid value.")
                sys_conf_dict["Nodes"].append({"HostName": "", "ControlNWIPv4": target.strip()})

        # 実行に時間がかかることを通知しておく
        click.echo('Takes several minutes to complete request.')

        # fingerprint取得
        cert = None
        fingerprint = None
        config = Configuration()
        if config.verify_ssl is True:
            # サーバ証明書検証あり
            parsed_url = urlparse(config.host)
            host = re.sub(r':443', "", parsed_url.netloc)

            restCertUtil = RestCertificateUtil()
            cert, fingerprint, errlist = restCertUtil.get_server_certificate(host, 443)
            if cert is None or fingerprint is None:
                # エラー発生
                click.echo("Message: {}".format(errlist[0][0]))
                click.echo("Cause: {}".format(errlist[0][1]))
                click.echo("Solution: {}".format(errlist[0][2]))
                exit(1)

        click.echo('Stage 1/4 Preparing to set stationary point.')
        # レスキューモード適用(SSH有効化)
        """
        fingerprintを使った証明書検証
        """
        logger.info("Enable rescue mode.")
        from com.hitachi.sophia.rest_client.autogen.apis.rescue import \
            Rescue as RescueApi
        # 出力内容を保持
        output_error_message = None
        for node in sys_conf_dict["Nodes"]:
            # CLI実行時とは別のホストへREST APIを実行するためここでホストを切り替える。
            api = RescueApi(ApiClient(host="https://{}:443/ConfigurationManager/simple".format(node["ControlNWIPv4"])))
            response = api.apply_rescue(callback=None)
            # httpStatuCode取得
            http_status_code = common_util.get_response_status(response)
            if http_status_code == 204:
                # 構成パラメータ設定成功
                logger.info("[{}] success to activate Rescue Mode.".format(node["ControlNWIPv4"]))
                output_error_message = Output_message_type.success
            elif http_status_code == 401 or http_status_code == 403:
                if http_status_code == 401:
                    # 認証失敗の場合
                    logger.error("Unauthorized.")
                elif http_status_code == 403:
                    # 権限不足の場合
                    logger.error("Forbidden.")
                click.echo("Message: User authentication with the authentication ticket did not succeed.")
                click.echo("Cause: User ID, password, or the authentication ticket is not correct.")
                click.echo("Solution: Review the user ID, password, and authentication ticket to be used.")
                exit(1)
            else:
                logger.info("[{}] failed to activate Rescue Mode(internal_error httpStatusCode={}).".format(node["ControlNWIPv4"], http_status_code))
                output_error_message = Output_message_type.internal_error

        if output_error_message == Output_message_type.internal_error:
            logger.error('Failed to activate Rescue Mode.')
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: An unexpected error occurred.")
            click.echo("Solution: Collect the logs, and then contact customer support.")
            exit(1)
        else:
            logger.info('Success to activate Rescue Mode.')

        click.echo('Stage 2/4 Checking precondition.')
        # 構成パラメータ設定モード確認
        """
        fingerprintを使った証明書検証
        """
        logger.info("Check configuration parameter setting mode.")
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        # 出力内容を保持
        mode_check_results = {}
        output_error_message = None
        # 各ストレージへ構成パラメータ設定モード参照APIを実行
        for node in sys_conf_dict["Nodes"]:
            # CLI実行時とは別のホストへREST APIを実行するためここでホストを切り替える。
            api = SystemManagementApi(ApiClient(host="https://{}:443/ConfigurationManager/simple".format(node["ControlNWIPv4"])))
            response = api.storage_node_configuration_parameter_polling_mode_show(callback=None, debug="false")
            # httpStatuCode取得
            http_status_code = common_util.get_response_status(response)
            d = json.loads(response)
            if http_status_code == 200:
                # 構成パラメータ設定モード取得成功
                logger.info("[{}] success to get setting mode.".format(node["ControlNWIPv4"]))
                mode_check_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": http_status_code, "isEnabled": d['body']['isEnabled']}
                output_error_message = Output_message_type.success
            else:
                # 構成パラメータ設定モード取得失敗
                mode_check_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": http_status_code, "isEnabled": None}
                # 最終的に出力するエラーメッセージは優先度の高い1つ
                if http_status_code == 500:
                    # 内部エラー
                    logger.error("[{}] failed to get setting mode(internal_error httpStatusCode=500).".format(node["ControlNWIPv4"]))
                    output_error_message = Output_message_type.internal_error
                    break
                elif http_status_code == 503:
                    # 多重実行の検出によるガード
                    # リトライしておく
                    logger.error("[{}] failed to get setting mode because other processes is running(failed_flock httpStatusCode=503). Retry to get setting mode.".format(node["ControlNWIPv4"]))
                    time.sleep(3)
                    api = SystemManagementApi(ApiClient(host="https://{}:443/ConfigurationManager/simple".format(node["ControlNWIPv4"])))
                    response = api.storage_node_configuration_parameter_polling_mode_show(callback=None, debug="false")
                    http_status_code = common_util.get_response_status(response)
                    d = json.loads(response)
                    if http_status_code == 200:
                        logger.info("[{}] success to get setting mode.".format(node["ControlNWIPv4"]))
                        mode_check_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": http_status_code, "isEnabled": d['body']['isEnabled']}
                        output_error_message = Output_message_type.success
                    else:
                        logger.error("[{}] failed to get setting mode(internal_error).".format(node["ControlNWIPv4"]))
                        output_error_message = Output_message_type.internal_error
                        break
                else:
                    # 到達不能コード
                    logger.error("[{}] failed to get setting mode(internal_error).".format(node["ControlNWIPv4"]))
                    output_error_message = Output_message_type.internal_error
                    break

        if output_error_message == Output_message_type.internal_error:
            logger.error('Failed to check configparameter setting mode.')
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: An unexpected error occurred.")
            click.echo("Solution: Collect the logs, and then contact customer support.")
            exit(1)
        else:
            disable_flag = False
            for key, value in mode_check_results.items():
                logger.info("{}[{}] Configuration parameter setting mode : {}".format(value["hostname"], key, value["isEnabled"]))
                if value["isEnabled"] != True:
                    # 構成パラメータ設定モードが有効化されていないノードがある。
                    disable_flag = True
            if disable_flag:
                click.echo("Message: There exists a storage node where the configuration parameter setting mode is disabled.")
                click.echo("Cause: An unexpected error occurred.")
                click.echo("Solution: Collect the logs, and then contact customer support.")
                exit(1)

        logger.info('Successfully checked configparameter setting mode.')

        click.echo('Stage 3/4 Setting stationary point.')
        # 構成パラメータ設定
        configparameter = {}
        for node in sys_conf_dict["Nodes"]:
            configparameter[node["ControlNWIPv4"]] = {"configurationParameters": []}
            # "guestinfo.hsds.stationary_point"をハッシュ化したものをkey名にする。
            # Native版ではハッシュ化による難読化は不要だが、ESXi版とkey名を統一しておくため。
            configparameter[node["ControlNWIPv4"]]["configurationParameters"].append({"key": "guestinfo.hsds.917e63a76cf92a00f36dbb49b5e40df597c5a3fdbe68ed852b8216c328ecdc8d", "value": point_str})
            # 構成一括変更と静止点設定のどちらの処理であるのかを判別するために使用する。
            # configparameter_reader.shがこの情報を見てroleチェックを行うかどうか判断する。
            configparameter[node["ControlNWIPv4"]]["configurationParameters"].append({"key": "guestinfo.hsds.operation_category", "value": "stationary_point"})
            configparameter[node["ControlNWIPv4"]]["configurationParameters"].append({"key": "guestinfo.hsds.maintenance", "value": maintenance_str})
            configparameter[node["ControlNWIPv4"]]["configurationParameters"].append({"key": "guestinfo.hsds.clear_svos_mapping", "value": clear_svos_mapping_str})
            configparameter[node["ControlNWIPv4"]]["configurationParameters"].append({"key": "guestinfo.hsds.configparam_status", "value": 'set_param'})

        """
        fingerprintを使った証明書検証
        """
        logger.info("Set configuration parameter.")
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi

        from com.hitachi.sophia.rest_client.autogen.models.PatchStorageNodeConfigurationParameterParametersParam import \
                            PatchStorageNodeConfigurationParameterParametersParam as SetConfigParam

        # 出力内容を保持
        parameter_set_results = {}
        output_error_message = None
        for node in sys_conf_dict["Nodes"]:
            # APIに渡すための構成パラメータを作成
            set_config_param = SetConfigParam(configuration_parameters=configparameter[node["ControlNWIPv4"]]["configurationParameters"])

            # CLI実行時とは別のホストへREST APIを実行するためここでホストを切り替える。
            api = SystemManagementApi(ApiClient(host="https://{}:443/ConfigurationManager/simple".format(node["ControlNWIPv4"])))
            response = api.storage_node_configuration_parameter_parameters_set(callback=None, patch_storage_node_configuration_parameter_parameters_param=set_config_param, debug="false")
            # httpStatuCode取得
            http_status_code = common_util.get_response_status(response)

            if http_status_code == 204:
                # 構成パラメータ設定成功
                logger.info("[{}] success to set configuration parameter.".format(node["ControlNWIPv4"]))
                parameter_set_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": http_status_code, "set_parameter": "success"}
                output_error_message = Output_message_type.success
            else:
                # 構成パラメータ設定モード取得失敗
                parameter_set_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": http_status_code, "set_parameter": "fail"}
                # 最終的に出力するエラーメッセージは優先度の高い1つ
                if http_status_code == 500:
                    # 内部エラー
                    logger.error("[{}] failed to set configuration parameter.(internal_error httpStatusCode=500).".format(node["ControlNWIPv4"]))
                    output_error_message = Output_message_type.internal_error
                    break
                elif http_status_code == 503:
                    # 多重実行の検出によるガード
                    # リトライしておく
                    logger.error("[{}] failed to set configuration parameter because other processes is running(failed_flock httpStatusCode=503). Retry to get setting mode.".format(node["ControlNWIPv4"]))
                    time.sleep(3)
                    api = SystemManagementApi(ApiClient(host="https://{}:443/ConfigurationManager/simple".format(node["ControlNWIPv4"])))
                    response = api.storage_node_configuration_parameter_parameters_set(callback=None, configurationParameters=configparameter[node["ControlNWIPv4"]], debug="false")
                    http_status_code = common_util.get_response_status(response)
                    if http_status_code == 204:
                        logger.info("[{}] success to set configuration parameter.".format(node["ControlNWIPv4"]))
                        parameter_set_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": http_status_code, "set_parameter": "success"}
                        output_error_message = Output_message_type.success
                    else:
                        logger.error("[{}] failed to set configuration parameter(internal_error).".format(node["ControlNWIPv4"]))
                        output_error_message = Output_message_type.internal_error
                        break
                else:
                    # 到達不能コード
                    logger.error("[{}] failed to set configuration parameter(internal_error).".format(node["ControlNWIPv4"]))
                    output_error_message = Output_message_type.internal_error
                    break

        if output_error_message == Output_message_type.internal_error:
            logger.error('Failed to set configuration parameter.')
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: An unexpected error occurred.")
            click.echo("Solution: Collect the logs, and then contact customer support.")
            exit(1)
        else:
            for key, value in parameter_set_results.items():
                logger.info("{}[{}] Configuration parameter set : {}".format(value["hostname"], key, value["set_parameter"]))

        logger.info('Successfully set configparameter.')

        click.echo('Stage 4/4 Checking stationary point accepted.')
        # 構成パラメータ参照
        """
        fingerprintを使った証明書検証
        """
        logger.info("Get configuration parameter.")
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        # 出力内容を保持
        parameter_get_results = {}
        output_error_message = None
        for node in sys_conf_dict["Nodes"]:
            parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "configparam_status": "not_enable"}
        for i in range(5):
            logger.info("initialize check result. ({})".format(i))
            checked_all_node = True
            for node in sys_conf_dict["Nodes"]:
                if parameter_get_results[node["ControlNWIPv4"]]["configparam_status"] == "not_enable":
                    # CLI実行時とは別のホストへREST APIを実行するためここでホストを切り替える。
                    api = SystemManagementApi(ApiClient(host="https://{}:443/ConfigurationManager/simple".format(node["ControlNWIPv4"])))
                    response = api.storage_node_configuration_parameter_parameters_show(callback=None, keys="guestinfo.hsds.configparam_status", debug="false")

                    if os.path.isfile(response):
                        # GETのAPI実行結果はファイルパスで返ってくる。
                        with open(response) as f:
                            d = json.load(f)
                            if d.get('messageId') is None:
                                # 正常系
                                manager_status = d["status"]
                                manager_stdout = d["stdout"]
                                manager_stderr = d["stderr"]
                                if manager_status == 0:
                                    # http_statu_code = 200
                                    configparam_status = json.loads(manager_stdout)["guestinfo.hsds.configparam_status"]
                                    if configparam_status == "enable":
                                        logger.info("set enable.")
                                        parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": 200, "configparam_status": "enable"}
                                    else:
                                        logger.info("not enable.")
                                        checked_all_node = False
                            else:
                                # 異常系
                                if d.get('messageId') == "KARS15006-E":
                                    # マネージャーstatus = 30, http_statu_code = 404
                                    checked_all_node = False
                                    # guestinfo.hsds.configparam_statusというkeyが存在しなかった
                                    logger.error("[{}] failed to get configuration parameter.(internal_error httpStatusCode=404).".format(node["ControlNWIPv4"]))
                                    parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": 404, "configparam_status": "failed"}
                                    output_error_message = Output_message_type.internal_error
                                elif d.get('messageId') == "KARS15503-E":
                                    # マネージャーstatus = 126, http_statu_code = 503
                                    checked_all_node = False
                                    # リトライに回す
                                    logger.error("[{}] failed to get configuration parameter because other processes is running(failed_flock httpStatusCode=503). Retry to get setting mode.".format(node["ControlNWIPv4"]))
                                    parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": 503, "configparam_status": "not_enable"}
                                elif d.get('messageId') == "KARS15000-E":
                                    # マネージャーstatus = 127, http_statu_code = 500
                                    checked_all_node = False
                                    logger.error("[{}] failed to get configuration parameter.(internal_error httpStatusCode=500).".format(node["ControlNWIPv4"]))
                                    parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": 500, "configparam_status": "failed"}
                                    output_error_message = Output_message_type.internal_error
                                else:
                                    # http_statu_code =　その他
                                    checked_all_node = False
                                    logger.error("[{}] failed to get configuration parameter.(internal_error httpStatusCode=500, unexpected_status).".format(node["ControlNWIPv4"]))
                                    parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": 500, "configparam_status": "failed"}
                                    output_error_message = Output_message_type.internal_error
                        os.remove(response)
                    else:
                        logger.error("[{}] failed to get configuration parameter.(internal_error. response file not found.).".format(node["ControlNWIPv4"]))
                        parameter_get_results[node["ControlNWIPv4"]] = {"hostname": node["HostName"], "httpStatusCode": "", "configparam_status": "failed"}
                        output_error_message = Output_message_type.internal_error
            if checked_all_node or output_error_message == Output_message_type.internal_error:
                # 全てのノードのconfigparam_statu = enable、もしくは少なくとも1つのノードでinternal_errorがあった場合
                break
            time.sleep(3)
        else:         
            # リトライし続けたがenableを確認できなかった   
            logger.error("failed to get configuration parameter.(time_out).")
            output_error_message = Output_message_type.time_out

        if output_error_message == Output_message_type.internal_error:
            logger.error('Failed to get configuration parameter.')
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: An unexpected error occurred.")
            click.echo("Solution: Collect the logs, and then contact customer support.")
            exit(1)
        elif output_error_message == Output_message_type.time_out:
            logger.error('Failed to get configuration parameter.')
            click.echo("Message: An error has occurred when executing the command.")
            click.echo("Cause: An unexpected error occurred.")
            click.echo("Solution: Collect the logs, and then contact customer support.")
            exit(1)

        logger.info('Successfully checked that configparam_status: enable.')

        # 正常終了メッセージ表示
        logger.info('Message: ' + 'Stationary point setting end successfully.')
        click.echo('Message: ' + 'Stationary point setting end successfully.')

    except FileNotFoundError as e:
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: {}".format(e))
        click.echo("Cause: The file does not exist in the specified path.")
        click.echo("Solution: Specify the file path correctly.")
        exit(1)
    except ValueError as e:
        if (traceback):
            logger.error(traceback.format_exc())
        logger.error(e)
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: {}".format(e))
        click.echo("Cause: Appropriate option is not specified.")
        click.echo("Solution: Specify the option value correctly.")
        exit(1)
    except urllib3.exceptions.MaxRetryError as e:
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: An error has occurred when executing the command.")
        click.echo("Cause: Communication with storage node failed.")
        click.echo("Solution: Check if the specified IP address or FQDN is correct and verify whether network communication between the controller node and the storage node is possible.")
        exit(1)
    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        logger.error(e)
        config = Configuration()
        config.is_progress_shown = False
        click.echo("Message: An error has occurred when executing the command.")
        click.echo("Cause: An unexpected error occurred.")
        click.echo("Solution: Collect the logs, and then contact customer support.")
        exit(1)


def commands():
    commands = {}
    commands['set_stationary_point'] = set_stationary_point
    return commands
