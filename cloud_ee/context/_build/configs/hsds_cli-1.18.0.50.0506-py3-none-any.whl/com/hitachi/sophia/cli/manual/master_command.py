# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import logging as loggingLib
import os
import traceback
import click

from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.autogen import sub_commands
# from ..autogen import sub_commands
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.autogen.master_command import version
from com.hitachi.sophia.cli.manual.command_util import add_subcommands
from com.hitachi.sophia.cli.manual.util.log_util import LogUtil

from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil

# デフォルトのログファイル
defaultCliLogFile = '~/hsds/cli/hsds_cli.log'

script_version = version.getVersion()

CONTEXT_SETTINGS = dict(help_option_names=['--help'])


# @click.command()
@click.group(commands=add_subcommands.commands(), context_settings=CONTEXT_SETTINGS)
@click.option('--host', help='Specifies the IP address or FQDN of the request-destination node of the REST API.', metavar='<str>')
# protocolオプションはHTTP無効化により V1.7以降廃止オプションのためコメントアウト
#@click.option('--protocol', help='Specifies the connection protocol with http or https.',
#              type=click.Choice(['http', 'https']))
@click.option('--user', help='Specifies the authentication user name.', metavar='<str>')
@click.option('--password', hidden=True, help='Specifies the user password for authentication.', metavar='<str>')
@click.option('--auth_token', hidden=True, help='Specifies the authentication token.', metavar='<str>')
@click.option('--auth_ticket', hidden=True, help='Specifies the authentication ticket.', metavar='<str>')
# TODO:languageの対応
# @click.option('--language', help="en or ja", type=click.Choice(['en', 'ja']))
# no-prettyprintオプションはV1.2 Phase2以降廃止オプションのためコメントアウト
# @click.option('--no-prettyprint', help='Disables formatting the execution result of REST API.', is_flag=True)
# V1.2 Phase2以降からオプション名変更。 "no-verifyssl"->"ignore_certificate_errors"
@click.option('--ignore_certificate_errors', help='Disables verification of the certificates.', is_flag=True)
@click.option('--format', help='Specifies the output format of the execution result.',
              type=click.Choice(['text', 'json', 'simple-csv']))
# print_headerオプションはV1.2 Phase2以降廃止オプションのためコメントアウト
# @click.option('--print_header',  help='Displays response header information of REST API.', is_flag=True)
@click.version_option(version=script_version, message='hsds version \"Version %(version)s\"')
def master_command(host, user, password, auth_token, auth_ticket, ignore_certificate_errors, format):
    """Operates Hitachi Virtual Storage Software Block."""

    try:

        comUtil = CommonUtil()
        logutil = LogUtil()
        logutil.cliLogInit()

        logger = loggingLib.getLogger(__name__)

        config = Configuration()

        # IP only
        if host is None:
            host = comUtil.getEnvironmentVariable('HSDS_HOST')

        # hostのチェック
        if host is None:
            config.messageId = '19501'
            config.messageDict = {'valueError': 'host'}

        if host == '':
            config.messageId = '19502'
            config.messageDict = {'argsError': 'No host specified.'}


        # protocol
        # if not protocol:
        #     protocol = comUtil.getEnvironmentVariableDef('HSDS_PROT', 'https')

        # TODO languageの対応
        # if not language:
        #    language = getEnvironmentVariableDef('HSDS_LANG','en')

        language = 'en'
        config.language = language

        url = createUrl(host)
        config.host = url

        setAuthParam(auth_ticket, auth_token, user, password, config)

        # 出力フォーマットの整形無効化
        # config.no_prettyprint = no_prettyprint

        # ヘッダ情報表示フラグ
        # config.print_header = print_header

        # 出力形式切り替え
        if format is None:
            # defult value set
            config.format = 'text'
        else:
            config.format = format

        if (config.messageId):
            return

        if (ignore_certificate_errors):
            config.verify_ssl = False

        commandLogtxt = "Command Excuted:Hitachi Virtual Storage Software Block"
        if host is not None:
            commandLogtxt += " host:" + host
        # if (protocol):
        #     commandLogtxt += " protocol:" + protocol
        if user is not None:
            commandLogtxt += " user:" + user
        # if (no_prettyprint):
        #     commandLogtxt += " no_prettyprint"
        if (ignore_certificate_errors):
            commandLogtxt += " ignore_certificate_errors"
        # if (print_header):
        #     commandLogtxt += " print_header"
        if format is not None:
            commandLogtxt += " format:" + format

        logger.info(commandLogtxt)

        pass

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)


def createUrl(host):
    if not host:
        host = ""

    protocol = "https"
    portnum = str(443)

    url = protocol + "://" + host + ":" + portnum + "/ConfigurationManager/simple"
    return url

def setAuthParam(auth_ticket, auth_token, user, password, config):
    # comUtil = CommonUtil()
    # ユーザ名/パスワードの入力があれば取得
    if user is not None:
        config.username = user
    if password is not None:
        config.password = password

    # チケット入力ケース
    if auth_ticket is not None:
        config.api_key_prefix['Authorization'] = 'Ticket'
        config.api_key['Authorization'] = auth_ticket

        # トークンが入力された場合はパラメータチェック用に取得
        if auth_token is not None:
            config.api_key_prefix['AuthToken'] = 'Session'
            config.api_key['AuthToken'] = auth_token

        return
    # トークン入力ケース
    if auth_token is not None:
        config.api_key_prefix['Authorization'] = 'Session'
        config.api_key['Authorization'] = auth_token
        return

    # auth_token = comUtil.getEnvironmentVariable('HSDS_TOKEN')
    # トークンを環境変数で入力ケース
    # if (auth_token):
    #    config.api_key_prefix['Authorization'] = 'Session'
    #    config.api_key['Authorization'] = auth_token
    #    return

    # ユーザーを環境変数で入力ケース
    # user = comUtil.getEnvironmentVariable('HSDS_USER')
    # if (user):
    #    config.username = user
    #    return

    # config.messageId = '19003'

    return
