"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import json
import os
from contextlib import redirect_stdout

import click
import re

import sys

from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil


class UuidUtil(object):
    def print_parameter_does_not_exist_error(self, param_name):
        """
        パラメーターで指定した情報が存在しないのエラーメッセージを表示する
        :param param_name:
        :return:
        """
        mssageManagement = MessageManagement('')
        messageId = '19026'
        messageDict = {'optionName': param_name}
        mssageManagement.viewMessageTxt(messageId, **messageDict)

    def print_multiple_id_error(self, param_name, str_uuids):
        """
        指定されたリソースのidが重複しているエラーメッセージを表示する
        :param param_name:
        :param str_uuids:
        :return:
        """
        mssageManagement = MessageManagement('')
        messageId = '19027'
        messageDict = {'optionName': param_name, 'uuids': str_uuids}
        mssageManagement.viewMessageTxt(messageId, **messageDict)

    def print_error_when_executing_list_reference(self, http_status_code):
        """
        リスト一覧参照のステータスコードが４００番台、５００番台の場合のエラーメッセージを表示する
        :param param_name:
        :param str_uuids:
        :return:
        """
        mssageManagement = MessageManagement('')
        messageId = '19028'
        # messageDict = {'optionName': param_name, 'uuids': str_uuids}
        messageDict = {'httpStatusCode': str(http_status_code)}
        mssageManagement.viewMessageTxt(messageId, **messageDict)

    def genelate_str_uuids(self, d):
        """
        エラーメッセージ IDで表示するUUIDを生成する
        :param d: 辞書
        :return:
        """
        key_list = list(d.keys())
        if len(d) == 1:
            str_uuids = key_list[0]
        elif len(d) == 2:
            str_uuids = key_list[0] + ', ' + key_list[1]
        else:
            str_uuids = key_list[0] + ', ' + key_list[1] + '...'
        return str_uuids

    def getUuidFromDict(self, json_dict: dict, responseId: object) -> object:
        """
        Responseを辞書に変換したものからresponseIDで定義されたキーに対応する値を返す
        :param json_data:
        :param responseId:
        :return:
        """
        if responseId in json_dict:
            return json_dict[responseId]
        else:
            return None

    def getUuidFromResponse(self, response, param_name, response_id):
        """
        Responsから、指定されたparam_nameにUUIDを抽出する

        :param response:
        :param param_name: エラー表示用
        :param response_id: 取得するuuidが定義
        :return:
        """

        config = Configuration()

        response_dict = json.loads(response)
        if 'body' in response_dict:
            if 'data' in response_dict['body']:
                data_list = response_dict['body']['data']

                if type(data_list) is list:
                    if len(data_list) == 0:
                        # data[]の中身がない
                        self.print_parameter_does_not_exist_error(param_name)
                        exit(1)

                    elif len(data_list) == 1:
                        uuid = self.getUuidFromDict(data_list[0], response_id)
                        if uuid is None:
                            # uuidの値がない
                            self.print_parameter_does_not_exist_error(param_name)
                            exit(1)

                        else:
                            # 唯一正常系
                            return uuid

                    else:
                        # data:[]の中に複数のjson
                        d = {}
                        # 辞書の中にresponse_idで指定したuuidがいくつあるか数える
                        for item in data_list:
                            if response_id in item:
                                wk_uuid = item[response_id]
                                if wk_uuid in d:
                                    num = d[wk_uuid]
                                    d[wk_uuid] = num + 1
                                else:
                                    d[wk_uuid] = 1

                        if len(d) == 0:
                            # response_idで指定したものが一つもなかった
                            self.print_parameter_does_not_exist_error(param_name)
                            exit(1)

                        else:
                            # response_idで指定したものが一つ以上あった
                            str_uuids = self.genelate_str_uuids(d)
                            self.print_multiple_id_error(param_name, str_uuids)
                            exit(1)

        # responseがおかしいとここに到達する
        self.print_parameter_does_not_exist_error(param_name)
        exit(1)

    def getUuidFromResponseForArray(self, response, requestNamesList, param_name, responseNameKey, responseIdKey):
        """
        Responsから、指定されたparam_nameにUUIDを抽出する

        :param requestNamesList: nameのリスト(ユーザ入力)
        :param response:
        :param param_name: エラー表示用
        :param responseNameKey: 取得するnameが定義
        :param responseIdKey: 取得するuuidが定義
        :return:
        """

        # escape文字列対応

        uuidList = ''

        response_dict = json.loads(response)

        for name in requestNamesList:

            config = Configuration()

            if 'body' in response_dict:
                if 'data' in response_dict['body']:
                    data_list = response_dict['body']['data']

                    if type(data_list) is list:
                        if len(data_list) == 0:
                            # data[]の中身がない
                            self.print_parameter_does_not_exist_error(param_name)
                            exit(1)

                        else:
                            # data:[]の中に複数のjson
                            d = {}
                            r_uuid = ''
                            # 辞書の中にresponse_idで指定したuuidがいくつあるか数える
                            for item in data_list:
                                if responseIdKey in item:
                                    wk_uuid = item[responseIdKey]
                                    wk_name = item[responseNameKey]

                                    if (wk_name == name):
                                        # count
                                        if wk_uuid in d:
                                            num = d[wk_uuid]
                                            d[wk_uuid] = num + 1
                                        else:
                                            d[wk_uuid] = 1
                                            r_uuid = wk_uuid
                            if len(d) == 0:
                                # response_idで指定したものが一つもなかった
                                self.print_parameter_does_not_exist_error(param_name)
                                exit(1)

                            if len(d) == 1:
                                if (uuidList == ''):
                                    uuidList = r_uuid
                                else:
                                    uuidList = uuidList + ',' + r_uuid

                            else:
                                # response_idで指定したものが一つ以上あった
                                str_uuids = self.genelate_str_uuids(d)
                                self.print_multiple_id_error(param_name, str_uuids)
                                exit(1)
                    else:
                        # listではない
                        self.print_parameter_does_not_exist_error(param_name)
                        exit(1)
                else:
                    # bodyがない
                    self.print_parameter_does_not_exist_error(param_name)
                    exit(1)
            else:
                # bodyがない
                self.print_parameter_does_not_exist_error(param_name)
                exit(1)

        return uuidList

    def escapeArrayValue(self, arrayStr):
        """
        カンマ区切りの文字列にエスケープ処理を実施し配列で返す

        :param arrayStr: カンマ区切りの文字列
        :return: escape処理をした配列
        """
        array = arrayStr.split(',')

        escapedArray = []
        tmp_name = ''
        for name in array:
            if (name.endswith('\\')):
                tmp_name = tmp_name + name[:-1] + ','
            else:
                name = tmp_name + name
                escapedArray.append(name)
                tmp_name = ''
        else:
            # 次の要素がない場合は、文字列の最後が'\'でもエスケープ文字とはならない
            if (tmp_name != ''):
                escapedArray.append(tmp_name[:-1] + '\\')

        return escapedArray

    def arrayToString(self, array):
        """
        配列をカンマ区切りの文字列にして返す
　　　　　要素内のカンマは、\\をつける
        :param array:
        :return: escape処理をした配列
        """

        if (array == None):
            return None

        if(len(array)==0):
            return None

        str = ''
        for val in array:

            #最初の要素にはカンマ不要
            if(str!=''):
                str += ','
            str += val.replace(',','\\,')

        return str


    # 配列要素の重複値排除処理（
    def delete_duplication_array_value(self, input_array_list):
        """
        配列要素の重複値排除処理
        :param input_array_list:
        :return:
        """
        # 元の順番を保持した重複排除
        new_array_list = sorted(set(input_array_list), key=input_array_list.index)
        return new_array_list

    def determin_status_doce_of_list_reference(self, response):
        """
        httpStatusCodeを判定
        httpStatusCode >= 400ならstderrに出力する
        httpStatusCodeが401, 403, 500, 502. 503, 504 Responseをそのまま出力
        httpStatusCodeが上記以外 メッセージID 19028のエラー出力

        :param response:
        :return:
        """

        d = json.loads(response)

        config = Configuration()
        output_util = OutputUtil()

        from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
        common_util = CommonUtil()

        httpstatus = d['httpStatusCode']
        if httpstatus < 400:
            return
        else:
            if httpstatus == 401 or httpstatus == 403 or \
                    httpstatus == 500 or httpstatus == 502 or httpstatus == 503 or httpstatus == 504:
                output_util.echo_normal(response, config.format, None)
                exit(common_util.get_cli_exit_code_for_api_execution(httpstatus))
            else:
                self.print_error_when_executing_list_reference(httpstatus)
                exit(1)
