# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--label','_label',type=str,metavar='<str>',help='Label name assigned to the dump log file.')
@click.option('--mode','_mode',type=str,metavar='<str>',help='Determines information to be included in the dump log files. For modes to be selected, see the Troubleshooting Guide.')
def dump_file_create_file(_label,_mode,):
    """
    Requests creation of a dump log file of the storage node specified as the connection destination. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','true')
        auth_parameter_util.check_auth_parameter('true','true','true')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "dump_file_create_file"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _label is not None:
            subCommandLogtxt += "--label " + str(_label) + " "




        if _mode is not None:
            subCommandLogtxt += "--mode " + str(_mode) + " "










        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import FailureAnalysis as FailureAnalysisApi
        api = FailureAnalysisApi(ApiClient())

        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "dump_file_create_file"

























        if _label is not None:
            if(isinstance(_label, str)):
                _label = SeparateArgs.check_backslash(_label)
                _label = _label.encode("utf-8").decode("unicode-escape")
        if _mode is not None:
            if(isinstance(_mode, str)):
                _mode = SeparateArgs.check_backslash(_mode)
                _mode = _mode.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateDumpFileParam import CreateDumpFileParam
        _create_dump_file_param = CreateDumpFileParam()
        _create_dump_file_param.label = _label
        _create_dump_file_param.mode = _mode

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DumpStatus import DumpStatus

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.dump_file_create_file(create_dump_file_param = _create_dump_file_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--file_name','_file_name',metavar='<str>',help='Name of the target dump log file. ',required=True)
def dump_file_delete(_file_name,):
    """
    Deletes a dump log file of the storage node specified as the connection destination. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','true')
        auth_parameter_util.check_auth_parameter('true','true','true')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "dump_file_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _file_name is not None:
            subCommandLogtxt += "--file_name " + str(_file_name) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import FailureAnalysis as FailureAnalysisApi
        api = FailureAnalysisApi(ApiClient())



        
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "dump_file_delete"

        if _file_name is not None and len(_file_name) > 255:
            raise ValueError("Invalid value for parameter `file_name` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `file_name` when calling `dump_file_delete`, length must be less than or equal to `255`")
        if _file_name is not None and len(_file_name) < 1:
            raise ValueError("Invalid value for parameter `file_name` when calling `" + cliSubCommand + "`, length must be greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `file_name` when calling `dump_file_delete`, length must be greater than or equal to `1`")
        if  _file_name is not None and not re.search('^[a-zA-Z0-9!#$%&\\\'\\-\\.@\\^_`\\{\\}~]{1,255}$', _file_name):
            raise ValueError("Invalid value for parameter `file_name` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[a-zA-Z0-9!#$%&\\'\\-\\.@\\^_`\\{\\}~]{1,255}$/`")
#           raise ValueError("Invalid value for parameter `file_name` when calling `dump_file_delete`, must conform to the pattern `/^[a-zA-Z0-9!#$%&\\'\\-\\.@\\^_`\\{\\}~]{1,255}$/`")























                

    
        
        

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.dump_file_delete(_file_name, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    




@click.command(options_metavar='<options>')
@click.option('--file_name','_file_name',metavar='<str>',help='Name of the target dump log file. ')
@click.option('--index_of_split_files','_index_of_split_files',type=int,metavar='<int>',help='Index of the split dump log files. ')
def dump_file_download(_file_name,_index_of_split_files,):
    """
    Downloads a dump log file of the storage node specified as the connection destination. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','true')
        auth_parameter_util.check_auth_parameter('true','true','true')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "dump_file_download"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _file_name is not None:
            subCommandLogtxt += "--file_name " + str(_file_name) + " "





        if _index_of_split_files is not None:
            subCommandLogtxt += "--index_of_split_files " + str(_index_of_split_files) + " "






        logger.info(subCommandLogtxt)

        
    

    

    
        defaultFileName = ""        
        fileutil = FileUtil(defaultFileName)

        dirname, filename = fileutil.locate_download_file(defaultFileName)
        download_path = os.path.join(dirname, filename)
        
        #ファイルが存在するか
        if (os.path.isfile(os.path.join(dirname, filename))):
            # 既にファイルが存在している
            mssageManagement = MessageManagement('')
            messageId = '19006'
            messageDict = {'filePath': os.path.abspath(defaultFileName)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

    



        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

        #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()


    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.failure_analysis_manual import dump_file_download_manual
        dump_file_download_manual(_file_name,_index_of_split_files,callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
def dump_status_list():
    """
    Verifies the listed creation statuses of dump log files of the storage node specified as the connection destination. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','true')
        auth_parameter_util.check_auth_parameter('true','true','true')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "dump_status_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import FailureAnalysis as FailureAnalysisApi
        api = FailureAnalysisApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "dump_status_list"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DumpStatusList import DumpStatusList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.dump_status_list(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def dump_status_show():
    """
    Verifies the latest creation status of the dump log file of the storage node specified as the connection destination. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','true')
        auth_parameter_util.check_auth_parameter('true','true','true')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "dump_status_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import FailureAnalysis as FailureAnalysisApi
        api = FailureAnalysisApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "dump_status_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DumpStatus import DumpStatus

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.dump_status_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--max_age_days','_max_age_days',type=int,metavar='<int>',help='Number of days until the ticket expires.')
def ticket_create(_max_age_days,):
    """
    Issues an authentication ticket. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','','')
        auth_parameter_util.check_auth_parameter('true','','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "ticket_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _max_age_days is not None:
            subCommandLogtxt += "--max_age_days " + str(_max_age_days) + " "










        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import FailureAnalysis as FailureAnalysisApi
        api = FailureAnalysisApi(ApiClient())

        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "ticket_create"

























        if _max_age_days is not None:
            if(isinstance(_max_age_days, str)):
                _max_age_days = SeparateArgs.check_backslash(_max_age_days)
                _max_age_days = _max_age_days.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateTicketParam import CreateTicketParam
        _create_ticket_param = CreateTicketParam()
        _create_ticket_param.max_age_days = _max_age_days

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Ticket import Ticket

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.ticket_create(create_ticket_param = _create_ticket_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def ticket_revoke_all():
    """
    Abandons all of the authentication tickets. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "ticket_revoke_all"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import FailureAnalysis as FailureAnalysisApi
        api = FailureAnalysisApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "ticket_revoke_all"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.tickets_revoke(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['dump_file_create_file'] = dump_file_create_file
    commands['dump_file_delete'] = dump_file_delete

    commands['dump_file_download'] = dump_file_download
    commands['dump_status_list'] = dump_status_list
    commands['dump_status_show'] = dump_status_show




    commands['ticket_create'] = ticket_create
    commands['ticket_revoke_all'] = ticket_revoke_all
    return commands

