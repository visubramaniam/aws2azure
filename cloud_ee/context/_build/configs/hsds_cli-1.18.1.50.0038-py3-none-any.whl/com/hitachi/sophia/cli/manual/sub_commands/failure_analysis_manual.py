# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil

logger = loggingLib.getLogger(__name__)


def dump_file_download_manual(file_name, index_of_split_files, callback, debug):
    """
    ダンプファイルをダウンロードする
    """

    from com.hitachi.sophia.rest_client.autogen.apis.failure_analysis import \
        FailureAnalysis as FailureAnalysisApi
    api = FailureAnalysisApi(ApiClient())

    cli_response = collections.OrderedDict()

    response = None

    config = Configuration()

    sub_command = "dump_file_download"

    # ストレージクラスターとCLIのバージョンチェック
    versioncheck = VersionCheck()
    api_version_response = versioncheck.get_api_version()
    versioncheck.version_check(api_version_response)

    try:

        if file_name is not None:
            response = api.dump_files_download(file_name=file_name, index_of_split_files=index_of_split_files, callback=callback, debug=debug,
                                               _preload_content=False)
        else:
            response = api.dump_file_download(index_of_split_files=index_of_split_files, callback=callback, debug=debug, _preload_content=False)

        if (response):

            cli_response['httpStatusCode'] = response.status

            if (response.status != 200):
                if response.data:
                    cli_response['body'] = ApiClient().deserialize_json_to_body_or_exit(response,
                                                                                        _preload_content=False)

                data = json.dumps(cli_response, indent=4, separators=(',', ': '))
                output_util = OutputUtil()
                output_util.echo_normal(data, config.format, sub_command)
                #                click.echo(data)
                commonutil = CommonUtil()
                exit(commonutil.get_cli_exit_code_for_api_execution(response.status))

    except Exception as e:
        if (response):
            response.release_conn()
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    # ダウンロードするファイル名はレスポンスヘッダーに格納されているファイル名にする。
    # ファイル名はレスポンスヘッダーの"Content-Disposition"に格納されている
    content_disposition = response.getheader("Content-Disposition")
    # ファイル名を取得
    defaultFileName = get_fileneme(content_disposition)

    fileutil = FileUtil(defaultFileName)

    dirname, filename = fileutil.locate_download_file(defaultFileName)
    download_path = os.path.join(dirname, filename)

    if (os.path.isfile(os.path.join(dirname, filename))):
        # 既にファイルが存在している
        mssageManagement = MessageManagement('')
        messageId = '19006'
        messageDict = {'filePath': os.path.abspath(defaultFileName)}
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    saveFile = None
    try:
        with open(download_path, 'wb') as saveFile:
            # 10MiB単位で応答データを読み取る
            amt = 10 * 1024 * 1024
            while True:
                data = response.read(amt)
                if not data:
                    break
                saveFile.write(data)

        # ファイルの保存に成功したらメッセージ表示
        if config.format == 'simple-csv':
            output_util.check_format_csv(sub_command)
            common_util = CommonUtil()
            common_util.view_error()

        if config.format == 'text':
            click.echo('Message: ' + 'Download completed.')
            click.echo('Output File Path: ' + os.path.abspath(defaultFileName))
        else:
            cli_response['message'] = 'Download completed.'
            cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
            cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
            click.echo(cli_response)

    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                defaultFileName)+ ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except FileExistsError as e:  # 既にファイルが存在している
        messageId = '19007'
        messageDict = {'exception': 'A file has already existed. (File path = ' + os.path.abspath(defaultFileName)+ ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except OSError as e:  # OSError かつ errno ENOSPCの場合
        if e.errno == errno.ENOSPC:
            messageId = '19007'
            messageDict = {
                'exception': 'No more space for writing is available on the device. (File path = ' + os.path.abspath(
                    defaultFileName)+ ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        else:
            messageId = '19007'
            strErr = ','.join(map(str, e.args))
            messageDict = {'exception': strErr}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(defaultFileName)+ ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        # ファイルの保存に失敗
        messageId = '19007'
        strErr = ' '.join(map(str, e.args))
        messageDict = {'exception': strErr}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)

        exit(1)
    finally:
        if (response):
            response.release_conn()
        if (saveFile):
            saveFile.close()


def get_fileneme(content_disposition):
    download_filename = None
    if (content_disposition):
        download_filename = re.search('filename="?([^"]+)"?(;|$)', content_disposition).group(1)
        if CommonUtil().check_ignore_filename(download_filename):
            download_filename = None
    if (download_filename is None):
        # レスポンスヘッダーからファイル名が取得できなかった場合、ファイル名は”hsds_log_unknown.bin”とする.
        download_filename = "hsds_log_unknown.bin"
    return download_filename
