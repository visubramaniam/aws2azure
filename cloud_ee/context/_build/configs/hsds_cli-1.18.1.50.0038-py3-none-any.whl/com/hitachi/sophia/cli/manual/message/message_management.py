"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
from __future__ import absolute_import

import collections
import json
import pkgutil
import urllib3
import sys
import errno

import logging as loggingLib

from com.hitachi.sophia.cli.manual.util.progress_util import ProgressUtil
from com.hitachi.sophia.rest_client.manual.rest import ApiException

logger = loggingLib.getLogger(__name__)

root_package_name = 'com'
json_defult_file_path = 'hitachi/sophia/sophia_messages_en.json'
add_kars = 'KARS'


class MessageManagement(object):
    def __init__(self, json_file_path):
        """
        Constructor of the class.
        """

        if (json_file_path is None) or (json_file_path == ''):
            json_file_path = json_defult_file_path
        json_bin = pkgutil.get_data(root_package_name, json_file_path)  # from package resources
        json_str = json_bin.decode('utf8')
        self.message_dict = json.loads(json_str)

    def viewMessageTxt(self, message_id, **message_dict):

        # プログレスバーを表示している場合は標準エラー出力に改行を出力
        progress_util = ProgressUtil()
        progress_util.check_progress_shown_and_output_line_feed()

        if message_id in self.message_dict.keys():
            message = self.get_message(message_id)
            message_id_padded = message_id.zfill(5)
            severity = message['severity']
            result_message = self.message_format(message['message'], **message_dict)
            result_cause_message = self.message_format(message['cause'], **message_dict)
            result_action_message = self.message_format(message['action'], **message_dict)

            if message:
                print('Message Id: ' + add_kars + message_id_padded + '-' + severity[0], file=sys.stderr)
                print('Message: ' + result_message, file=sys.stderr)
                print('Cause: ' + result_cause_message, file=sys.stderr)
                print('Solution: ' + result_action_message, file=sys.stderr)

                if severity[0] == 'W':
                    logger.warning('Warning occurred.')
                    logger.warning('id: ' + add_kars + message_id_padded + '-' + severity[0])
                    logger.warning('message: ' + result_message)
                    logger.warning('cause: ' + result_cause_message)
                    logger.warning('solution: ' + result_action_message)
                else:
                    logger.error('Error occurred.')
                    logger.error('id: ' + add_kars + message_id_padded + '-' + severity[0])
                    logger.error('message: ' + result_message)
                    logger.error('cause: ' + result_cause_message)
                    logger.error('solution: ' + result_action_message)

        else:
            # Not found Massage Id
            message_dict = {'messageID': message_id}
            message = self.get_message('19000')
            severity = message['severity']
            result_message = self.message_format(message['message'], **message_dict)
            result_cause_message = self.message_format(message['cause'], **message_dict)
            result_action_message = self.message_format(message['action'], **message_dict)

            print('Message Id: ' + add_kars + '19000' + '-' + severity[0], file=sys.stderr)
            print('Message: ' + result_message, file=sys.stderr)
            print('Cause: ' + result_cause_message, file=sys.stderr)
            print('Solution: ' + result_action_message, file=sys.stderr)

            logger.error('Error occurred.')
            logger.error('id: ' + add_kars + '19000' + '-' + severity[0])
            logger.error('message: ' + result_message)
            logger.error('cause: ' + result_cause_message)
            logger.error('solution: ' + result_action_message)

    def get_message_txt(self, message_id, **message_dict):

        msg_txt = collections.OrderedDict()

        if message_id in self.message_dict.keys():
            message = self.get_message(message_id)
            message_id_padded = message_id.zfill(5)
            severity = message['severity']
            result_message = self.message_format(message['message'], **message_dict)
            result_cause_message = self.message_format(message['cause'], **message_dict)
            result_action_message = self.message_format(message['action'], **message_dict)

            if message:
                msg_txt['messageId'] = add_kars + message_id_padded + '-' + severity[0]
                msg_txt['message'] = result_message
                msg_txt['cause'] = result_cause_message
                msg_txt['solution'] = result_action_message
                msg_txt['solutionType'] = 'SEE_ERROR_DETAIL'
                msg_txt['errorCode'] = None

                if severity[0] == 'W':
                    logger.warning('Warning occurred.')
                    logger.warning('id: ' + add_kars + message_id_padded + '-' + severity[0])
                    logger.warning('message: ' + result_message)
                    logger.warning('cause: ' + result_cause_message)
                    logger.warning('solution: ' + result_action_message)
                else:
                    logger.error('Error occurred.')
                    logger.error('id: ' + add_kars + message_id_padded + '-' + severity[0])
                    logger.error('message: ' + result_message)
                    logger.error('cause: ' + result_cause_message)
                    logger.error('solution: ' + result_action_message)

        else:
            # Not found Massage Id
            message_dict = {'messageID': message_id}
            message = self.get_message('19000')
            severity = message['severity']
            result_message = self.message_format(message['message'], **message_dict)
            result_cause_message = self.message_format(message['cause'], **message_dict)
            result_action_message = self.message_format(message['action'], **message_dict)

            msg_txt['messageId'] = add_kars + '19000' + '-' + severity[0]
            msg_txt['message'] = result_message
            msg_txt['cause'] = result_cause_message
            msg_txt['solution'] = result_action_message
            msg_txt['solutionType'] = 'SEE_ERROR_DETAIL'
            msg_txt['errorCode'] = None

            logger.error('Error occurred.')
            logger.error('id: ' + add_kars + '19000' + '-' + severity[0])
            logger.error('message: ' + result_message)
            logger.error('cause: ' + result_cause_message)
            logger.error('solution: ' + result_action_message)

        msg_txt = json.dumps(msg_txt, indent=4, separators=(',', ': '))
        return msg_txt

    def get_message(self, message_id):
        if self.message_dict:
            message = self.message_dict[message_id]
            return message

    def message_format(self, msg, **msg_dict):
        if msg is None:
            return None

        if not msg_dict:
            return msg

        for k, v in msg_dict.items():
            if v is None:
                continue
            msg = msg.replace('[' + k + ']', v)
        return msg

    def viewMessage(self, e, msg_get=False):

        if isinstance(e, ApiException):

            # logger.error('Exception occurred.(ApiException)')
            message_id = '19505'

            str_err = ','.join(e.args)
            message_dict = {'exception': str_err}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        # UnicodeEncodeErrorは、ValueErrorより先に判定する
        elif isinstance(e, UnicodeEncodeError):

            # logger.error('Exception occurred.(UnicodeEncodeError)')
            message_id = '19016'

            message_dict = {}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        # elif isinstance(e, UnicodeDecodeError):

        #  message_id = '1900X'

        #    message_dict = {}
        #    self.viewMessageTxt(message_id, **message_dict)

        #    exit(1)

        elif isinstance(e, ImportError):

            # logger.error('Exception occurred.(ImportError)')
            message_id = '19503'

            str_err = ','.join(e.args)
            message_dict = {'importError': str_err}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, urllib3.exceptions.MaxRetryError):
            if hasattr(e, 'reason'):
                # 証明書不正
                if isinstance(e.reason, urllib3.exceptions.SSLError):
                    message_id = '19506'
                # NewConnectionError
                elif isinstance(e.reason, urllib3.exceptions.NewConnectionError):
                    message_id = '19504'
                # ReadTimeoutError
                elif isinstance(e.reason, urllib3.exceptions.ReadTimeoutError):
                    message_id = '19504'
                # ResponseError
                elif isinstance(e.reason, urllib3.exceptions.ResponseError):
                    message_id = '19504'
                # ConnectTimeoutError
                elif isinstance(e.reason, urllib3.exceptions.ConnectTimeoutError):
                    message_id = '19504'
                # TimeoutError
                elif isinstance(e.reason, urllib3.exceptions.TimeoutError):
                    message_id = '19504'
                # 上記以外urllib3例外はHTTPErrorで受ける
                elif isinstance(e.reason, urllib3.exceptions.HTTPError):
                    message_id = '19507'
                # 通信エラー以外の場合は予期しないエラー
                else:
                    message_id = '19505'
            else:
                # 属性がない
                message_id = '19505'

            # logger.error('Exception occurred.(MaxRetryError)')
            # message_id = '19504'

            str_err = ','.join(e.args)
            message_dict = {'maxRetryError': str_err}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, urllib3.exceptions.HTTPError):

            message_id = '19504'

            message_dict = {}
            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, PermissionError):

            message_id = '19030'

            str_err = 'An operation was attempted without adequate access rights, such as file system rights.'
            message_dict = {'exception': str_err}
            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, InterruptedError):

            message_id = '19032'

            message_dict = {}
            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, TimeoutError):

            message_id = '19033'

            message_dict = {}
            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, BrokenPipeError):

            message_id = '19031'

            message_dict = {}
            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, OSError):

            if e.errno == errno.ENOSPC:
                message_id = '19030'
                message_dict = {
                    'exception': 'No more space for writing is available on the device.'}
                if msg_get:
                    msg_txt = self.get_message_txt(message_id, **message_dict)
                    return msg_txt
                else:
                    self.viewMessageTxt(message_id, **message_dict)
                    exit(1)

            else:
                message_id = '19030'
                str_err = ','.join(map(str, e.args))
                message_dict = {'exception': str_err}
                if msg_get:
                    msg_txt = self.get_message_txt(message_id, **message_dict)
                    return msg_txt
                else:
                    self.viewMessageTxt(message_id, **message_dict)
                    exit(1)

        elif isinstance(e, MemoryError):

            message_id = '19029'

            message_dict = {}
            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, ValueError):

            # logger.error('Exception occurred.(ValueError)')
            message_id = '19502'

            str_err = ','.join(e.args)
            message_dict = {'argsError': str_err}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, TypeError):

            # logger.error('Exception occurred.(TypeError)')
            message_id = '19502'

            str_err = ','.join(e.args)
            message_dict = {'argsError': str_err}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)

        elif isinstance(e, Exception):

            # logger.error('Exception occurred.(Exception)')
            message_id = '19505'

            str_err = ' '.join(map(str, e.args))
            message_dict = {'exception': str_err}

            if msg_get:
                msg_txt = self.get_message_txt(message_id, **message_dict)
                return msg_txt
            else:
                self.viewMessageTxt(message_id, **message_dict)
                exit(1)
