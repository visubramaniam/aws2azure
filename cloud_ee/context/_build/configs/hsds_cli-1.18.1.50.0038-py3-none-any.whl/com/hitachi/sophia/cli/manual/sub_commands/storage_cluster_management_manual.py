# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import traceback
import logging as loggingLib
import re
import os
import collections
import json

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)

def snmp_setting_set_manual(_is_snmpagent_enabled,_snmp_version,_snmpv2c_sending_trap_settings,_snmpv2c_request_authentication_settings,_storage_system_name,_contact,_location,callback, debug):
    """
    [SNMPの設定を編集する]
    """
    commonutil = CommonUtil()

    cliSubCommand = "snmp_setting_set"

    from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
    api = StorageClusterManagementApi(ApiClient())

    try:

        if _is_snmpagent_enabled is not None:
            if(isinstance(_is_snmpagent_enabled, str)):
                _is_snmpagent_enabled = SeparateArgs.check_backslash(_is_snmpagent_enabled)
                _is_snmpagent_enabled = _is_snmpagent_enabled.encode("utf-8").decode("unicode-escape")
        if _snmp_version is not None:
            if(isinstance(_snmp_version, str)):
                _snmp_version = SeparateArgs.check_backslash(_snmp_version)
                _snmp_version = _snmp_version.encode("utf-8").decode("unicode-escape")
        if _snmpv2c_sending_trap_settings is not None:
            if(isinstance(_snmpv2c_sending_trap_settings, str)):
                _snmpv2c_sending_trap_settings = SeparateArgs.check_backslash(_snmpv2c_sending_trap_settings)
                _snmpv2c_sending_trap_settings = _snmpv2c_sending_trap_settings.encode("utf-8").decode("unicode-escape")
        if _snmpv2c_request_authentication_settings is not None:
            if(isinstance(_snmpv2c_request_authentication_settings, str)):
                _snmpv2c_request_authentication_settings = SeparateArgs.check_backslash(_snmpv2c_request_authentication_settings)
                _snmpv2c_request_authentication_settings = _snmpv2c_request_authentication_settings.encode("utf-8").decode("unicode-escape")
        if _storage_system_name is not None:
            if(isinstance(_storage_system_name, str)):
                _storage_system_name = SeparateArgs.check_backslash(_storage_system_name)
                _storage_system_name = _storage_system_name.encode("utf-8").decode("unicode-escape")
        if _contact is not None:
            if(isinstance(_contact, str)):
                _contact = SeparateArgs.check_backslash(_contact)
                _contact = _contact.encode("utf-8").decode("unicode-escape")
        if _location is not None:
            if(isinstance(_location, str)):
                _location = SeparateArgs.check_backslash(_location)
                _location = _location.encode("utf-8").decode("unicode-escape")

        from com.hitachi.sophia.rest_client.autogen.models.PatchSnmpSettingParam import PatchSnmpSettingParam
        patch_snmp_setting_param = PatchSnmpSettingParam()
        from com.hitachi.sophia.rest_client.autogen.models.SendingTrapSettingOfEditSnmpSetting import SendingTrapSettingOfEditSnmpSetting
        #sending_trap_setting_of_edit_snmp_setting = SendingTrapSettingOfEditSnmpSetting()
        sending_trap_setting_of_edit_snmp_setting = None
        from com.hitachi.sophia.rest_client.autogen.models.RequestAuthenticationSettingOfEditSnmpSetting import RequestAuthenticationSettingOfEditSnmpSetting
        #request_authentication_setting_of_edit_snmp_setting = RequestAuthenticationSettingOfEditSnmpSetting()
        request_authentication_setting_of_edit_snmp_setting = None
        from com.hitachi.sophia.rest_client.autogen.models.SystemGroupInformationOfEditSnmpSetting import SystemGroupInformationOfEditSnmpSetting
        #system_group_information_of_edit_snmp_setting = SystemGroupInformationOfEditSnmpSetting()
        system_group_information_of_edit_snmp_setting = None
        patch_snmp_setting_param.is_snmpagent_enabled = _is_snmpagent_enabled
        patch_snmp_setting_param.snmp_version = _snmp_version
        param_arr = []
        param_arr.append('index')
        param_arr.append('community')
        param_arr.append('send_trap_to')

        from com.hitachi.sophia.rest_client.autogen.models.Snmpv2cSettingOfEditSendingTrapSetting import Snmpv2cSettingOfEditSendingTrapSetting
        arr = []
        param_name = "snmpv2c_sending_trap_settings"

        if _snmpv2c_sending_trap_settings is not None:
            for __value in _snmpv2c_sending_trap_settings:
                snmpv2c_setting_of_edit_sending_trap_setting = Snmpv2cSettingOfEditSendingTrapSetting()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'index',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'index',param_name)
                   
                snmpv2c_setting_of_edit_sending_trap_setting.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'community',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'community',param_name)
                   
                snmpv2c_setting_of_edit_sending_trap_setting.community = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'array' ,'send_trap_to',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'array' ,'send_trap_to',param_name)
                   
                snmpv2c_setting_of_edit_sending_trap_setting.send_trap_to = tempval
                arr.append(snmpv2c_setting_of_edit_sending_trap_setting)
            _snmpv2c_sending_trap_settings = arr

        if (_snmpv2c_sending_trap_settings is not None):
            sending_trap_setting_of_edit_snmp_setting = SendingTrapSettingOfEditSnmpSetting()
            sending_trap_setting_of_edit_snmp_setting.snmpv2c_sending_trap_settings = _snmpv2c_sending_trap_settings

        param_arr = []
        param_arr.append('index')
        param_arr.append('community')
        param_arr.append('requests_permitted')

        from com.hitachi.sophia.rest_client.autogen.models.Snmpv2cSettingOfEditRequestAuthenticationSetting import Snmpv2cSettingOfEditRequestAuthenticationSetting
        arr = []
        param_name = "snmpv2c_request_authentication_settings"

        if _snmpv2c_request_authentication_settings is not None:
            for __value in _snmpv2c_request_authentication_settings:
                snmpv2c_setting_of_edit_request_authentication_setting = Snmpv2cSettingOfEditRequestAuthenticationSetting()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'index',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'index',param_name)
                   
                snmpv2c_setting_of_edit_request_authentication_setting.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'community',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'community',param_name)
                   
                snmpv2c_setting_of_edit_request_authentication_setting.community = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'array' ,'requests_permitted',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'array' ,'requests_permitted',param_name)
                   
                snmpv2c_setting_of_edit_request_authentication_setting.requests_permitted = tempval
                arr.append(snmpv2c_setting_of_edit_request_authentication_setting)
            _snmpv2c_request_authentication_settings = arr

        if (_snmpv2c_request_authentication_settings is not None):
            request_authentication_setting_of_edit_snmp_setting = RequestAuthenticationSettingOfEditSnmpSetting()
            request_authentication_setting_of_edit_snmp_setting.snmpv2c_request_authentication_settings = _snmpv2c_request_authentication_settings
        

        if(_storage_system_name is not None or _contact is not None or _location is not None):
            system_group_information_of_edit_snmp_setting = SystemGroupInformationOfEditSnmpSetting()
            system_group_information_of_edit_snmp_setting.storage_system_name = _storage_system_name
            system_group_information_of_edit_snmp_setting.contact = _contact
            system_group_information_of_edit_snmp_setting.location = _location

        patch_snmp_setting_param.sending_trap_setting = sending_trap_setting_of_edit_snmp_setting
        patch_snmp_setting_param.request_authentication_setting = request_authentication_setting_of_edit_snmp_setting
        patch_snmp_setting_param.system_group_information = system_group_information_of_edit_snmp_setting
        _patch_snmp_setting_param = patch_snmp_setting_param

        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

        config = Configuration()
        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.snmp_setting_set(patch_snmp_setting_param = _patch_snmp_setting_param, callback=None, debug="false")

        sub_Command = "snmp_setting_set"
        output_util = OutputUtil()
        output_util.echo_normal(response, config.format, sub_Command)
        # click.echo(response)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
