# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--location_name','_location_name',type=str,metavar='<str>',help='Location information for Syslog transfer. When specifying this option, also specify syslog_servers.')
@click.option('--syslog_servers','_syslog_servers',metavar='<str>', multiple=True,help='Syslog server to which audit logs are transferred.Up to two servers can be specified. When you want to specify two servers, specify this option twice. index: ID of the Syslog server. is_enabled: Whether audit logs are transferred to the Syslog server. server_name: Host name or IP address (IPv4) of the Syslog server. port: Port number of the Syslog server. transport_protocol: Communication protocol.',required=True)
def audit_log_setting_set(_location_name,_syslog_servers,):
    """
    Edits the audit log settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "audit_log_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _location_name is not None:
            subCommandLogtxt += "--location_name " + str(_location_name) + " "



        if len(_syslog_servers) == 0:
            _syslog_servers = None

        if _syslog_servers is not None:
            subCommandLogtxt += "--syslog_servers " + str(_syslog_servers) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.audit_log_management import AuditLogManagement as AuditLogManagementApi
        api = AuditLogManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "audit_log_setting_set"



















        if _location_name is not None:
            if(isinstance(_location_name, str)):
                _location_name = SeparateArgs.check_backslash(_location_name)
                _location_name = _location_name.encode("utf-8").decode("unicode-escape")
        if _syslog_servers is not None:
            if(isinstance(_syslog_servers, str)):
                _syslog_servers = SeparateArgs.check_backslash(_syslog_servers)
                _syslog_servers = _syslog_servers.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchAuditLogSettingParam import PatchAuditLogSettingParam
        tmp_patch_audit_log_setting_param = PatchAuditLogSettingParam()
        patch_audit_log_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.SyslogForwardingSettingOfEditAuditLogSetting import SyslogForwardingSettingOfEditAuditLogSetting
        tmp_syslog_forwarding_setting_of_edit_audit_log_setting = SyslogForwardingSettingOfEditAuditLogSetting()
        syslog_forwarding_setting_of_edit_audit_log_setting = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        syslog_forwarding_setting_of_edit_audit_log_setting = commonutil.set_parameter_with_instance(syslog_forwarding_setting_of_edit_audit_log_setting, tmp_syslog_forwarding_setting_of_edit_audit_log_setting, 'location_name', _location_name)
        

        

        param_arr = []
        param_arr.append('index')
        param_arr.append('is_enabled')
        param_arr.append('server_name')
        param_arr.append('port')
        param_arr.append('transport_protocol')

        from com.hitachi.sophia.rest_client.autogen.models.SyslogServerSettingOfEditAuditLogSetting import SyslogServerSettingOfEditAuditLogSetting
        arr = []
        param_name = "syslog_servers"

        if _syslog_servers is not None:
            for __value in _syslog_servers:
                syslog_server_setting_of_edit_audit_log_setting = SyslogServerSettingOfEditAuditLogSetting()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'index',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'index',param_name)

                syslog_server_setting_of_edit_audit_log_setting.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'boolean' ,'is_enabled',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'boolean' ,'is_enabled',param_name)

                syslog_server_setting_of_edit_audit_log_setting.is_enabled = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'server_name',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'server_name',param_name)

                syslog_server_setting_of_edit_audit_log_setting.server_name = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'port',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'port',param_name)

                syslog_server_setting_of_edit_audit_log_setting.port = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'transport_protocol',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'transport_protocol',param_name)

                syslog_server_setting_of_edit_audit_log_setting.transport_protocol = tempval
                arr.append(syslog_server_setting_of_edit_audit_log_setting)
            _syslog_servers = arr

        syslog_forwarding_setting_of_edit_audit_log_setting = commonutil.set_parameter_with_instance(syslog_forwarding_setting_of_edit_audit_log_setting, tmp_syslog_forwarding_setting_of_edit_audit_log_setting, 'syslog_servers', _syslog_servers)
        patch_audit_log_setting_param = commonutil.set_parameter_with_instance(patch_audit_log_setting_param, tmp_patch_audit_log_setting_param, 'syslog_forwarding_setting', syslog_forwarding_setting_of_edit_audit_log_setting)
        _patch_audit_log_setting = patch_audit_log_setting_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.audit_log_setting(patch_audit_log_setting = _patch_audit_log_setting, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def audit_log_setting_show():
    """
    Obtains the audit log settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "audit_log_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.audit_log_management import AuditLogManagement as AuditLogManagementApi
        api = AuditLogManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "audit_log_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.AuditLogSetting import AuditLogSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.audit_log_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def audit_log_download():
    """
    Downloads an audit log file.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "audit_log_download"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
    

    

    
        defaultFileName = "download-auditlog.zip"        
        fileutil = FileUtil(defaultFileName)

        dirname, filename = fileutil.locate_download_file(defaultFileName)
        download_path = os.path.join(dirname, filename)
        
        #ファイルが存在するか
        if (os.path.isfile(os.path.join(dirname, filename))):
            # 既にファイルが存在している
            mssageManagement = MessageManagement('')
            messageId = '19006'
            messageDict = {'filePath': os.path.abspath(defaultFileName)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

    



        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

        #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()


    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.audit_log_management_manual import audit_log_download_manual
        audit_log_download_manual(callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
def audit_log_create_file():
    """
    Creates an audit log file.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "audit_log_create_file"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.audit_log_management import AuditLogManagement as AuditLogManagementApi
        api = AuditLogManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "audit_log_create_file"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.create_auditlog_file(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['audit_log_setting_set'] = audit_log_setting_set
    commands['audit_log_setting_show'] = audit_log_setting_show
    commands['audit_log_download'] = audit_log_download
    commands['audit_log_create_file'] = audit_log_create_file
    return commands

