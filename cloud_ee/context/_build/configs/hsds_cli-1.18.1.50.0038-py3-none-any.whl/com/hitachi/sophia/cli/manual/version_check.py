"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import json
import os
from contextlib import redirect_stdout
import click
import re
import sys
import urllib3

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.autogen.master_command.version import getVersion

import logging as loggingLib
import traceback
import re
from com.hitachi.sophia.cli.autogen.master_command.version import getVersion
logger = loggingLib.getLogger(__name__)


class VersionCheck(object):

    def get_api_version(self):

        config = Configuration()
        commonUtil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.overall import Overall as OverallApi
        api = OverallApi(ApiClient())

        try:
            response = api.version_show(callback=None, debug="false")
            return response

        except urllib3.exceptions.MaxRetryError as e:  # 通信エラー発生(応答なし)
            if traceback:
                logger.error(traceback.format_exc())

            if hasattr(e,'reason'):
                # 証明書不正
                if isinstance(e.reason, urllib3.exceptions.SSLError):
                    config.messageId = '19506'
                # NewConnectionError
                elif isinstance(e.reason, urllib3.exceptions.NewConnectionError):
                    config.messageId = '19504'
                # ReadTimeoutError
                elif isinstance(e.reason, urllib3.exceptions.ReadTimeoutError):
                    config.messageId = '19504'
                # ResponseError
                elif isinstance(e.reason, urllib3.exceptions.ResponseError):
                    config.messageId = '19504'
                # ConnectTimeoutError
                elif isinstance(e.reason, urllib3.exceptions.ConnectTimeoutError):
                    config.messageId = '19504'
                # TimeoutError
                elif isinstance(e.reason, urllib3.exceptions.TimeoutError):
                    config.messageId = '19504'
                # 上記以外urllib3例外はHTTPErrorで受ける
                elif isinstance(e.reason, urllib3.exceptions.HTTPError):
                    config.messageId = '19507'
                # 通信エラー以外の場合は予期しないエラー
                else:
                    config.messageId = '19505'
            else:
                # 属性がない
                config.messageId = '19505'

            strErr = ','.join(e.args)
            config.messageDict = {'maxRetryError': strErr}
            commonUtil.view_error()

        except urllib3.exceptions.HTTPError as e:
            if traceback:
                logger.error(traceback.format_exc())

            config.messageId = '19504'
            strErr = ' '.join(map(str, e.args))
            config.messageDict = {'exception': strErr}
            commonUtil.view_error()

        except Exception as e:  # CLI内で予期せぬエラーが発生
            if traceback:
                logger.error(traceback.format_exc())

            config.messageId = '19505'
            strErr = ' '.join(map(str, e.args))
            config.messageDict = {'exception': strErr}
            commonUtil.view_error()

    def get_cli_version(self):

        # CLIバージョン
        cli_version = getVersion()
        return cli_version

    def version_check_format(self, version, version_type):

        # バージョンチェックするフォーマット('AA.BB.CC.DD')
        format = '^(\d{2}\.){3}\d{2}$'
        result = re.match(format, version)

        if not result:
            # フォーマットが適切でない場合
            logger.error('Version check error due to invalid format.(The version of ' + version_type + ' = "' + version + '")')

        return result

    def version_check(self, response):

        UNKNOWN = 'Unknown'
        api_version = UNKNOWN
        cli_version = UNKNOWN

        try:
            # CLIバージョンを取得
            cli_version_info = self.get_cli_version()

            if cli_version_info:
                # CLIバージョンが存在する場合
                if self.version_check_format(cli_version_info, 'CLI'):
                    # CLIバージョンがフォーマットが適切な場合
                    cli_version = cli_version_info
                    # CLIバージョン AA.BB.CC.DDからAA.BB.CCまでを切り取る
                    check_cli_version = cli_version_info[0:8]
            else:
                # CLIバージョンが存在しない場合
                logger.error('The version of CLI does not exist.')

            api_info = json.loads(response)

            if api_info['httpStatusCode'] == 200:
                if 'apiVersion' in api_info['body']:
                    # APIバージョンフィールドが存在する場合
                    api_version_info = api_info['body']['apiVersion']

                    if api_version_info:
                        # APIバージョンが存在する場合
                        if self.version_check_format(api_version_info, 'storage cluster'):
                            # APIバージョンがフォーマットが適切な場合
                            api_version = api_version_info
                            # APIバージョン AA.BB.CC.DDからAA.BB.CCまでを切り取る
                            check_api_version = api_version_info[0:8]

            if api_version == UNKNOWN or cli_version == UNKNOWN:
                # APIバージョンまたはCLIバージョンが"Unknown"の場合
                version_message = 'The version of the storage cluster cannot be compared with that of the CLI. ' \
                                  '(The version of storage cluster ' \
                                  '= "' + api_version + '", The version of CLI = "' + cli_version + '")'
                click.echo(version_message, err=True)

            elif check_cli_version < check_api_version:
                # APIバージョンとCLIのバージョンが不一致の場合(REST APIよりCLIの方が古いケース)
                version_message = 'The CLI version is earlier than the storage cluster version.\n' \
                                  'Update the CLI version to the same or later version of the storage cluster. ' \
                                  '(The version of storage cluster ' \
                                  '= "' + api_version + '", The version of CLI = "' + cli_version + '")'
                click.echo(version_message, err=True)

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())

            version_message = 'The version of the storage cluster cannot be compared with that of the CLI. ' \
                              '(The version of storage cluster ' \
                              '= "' + api_version + '", The version of CLI = "' + cli_version + '")'
            click.echo(version_message, err=True)
            return

    def get_api_version_from_response(self, response):
        """
        APIバージョンを取得
        :param response: APIバージョン情報APIのResponseデータ（json形式）
        :return: APIバージョン(AA.BB.CC.DD形式)、取得失敗時はNoneを返す
        """
        api_version = None
        try:
            api_info = json.loads(response)

            if api_info['httpStatusCode'] == 200:
                if 'apiVersion' in api_info['body']:
                    # APIバージョンフィールドが存在する場合
                    api_version_info = api_info['body']['apiVersion']
                    if api_version_info:
                        # APIバージョンが存在する場合
                        if self.version_check_format(api_version_info, 'storage cluster'):
                            # APIバージョンがフォーマットが適切な場合
                            api_version = api_version_info
            
        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())

        return api_version
