# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2021, 2024, Hitachi Vantara, Ltd.
"""
import collections
import json
import errno

import click
import logging as loggingLib
import os
import shutil
import sys
import traceback
from os.path import expanduser
import tempfile
import time
import tarfile
import glob
from enum import IntEnum

from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.config_backup.config_backup_util import ConfigBackupUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.progress_util import ProgressUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.mnc_check_util import MncCheckUtil

# 自動生成対象外コード

logger = loggingLib.getLogger(__name__)


class Platform_type(IntEnum):
    ESXi = 0
    AWS = 1
    Native = 2
    Azure =3
    GCP = 4
    other = 100

@click.command(options_metavar='<options>')
@click.option('--vcenter_user', 'vcenter_user', type=str, metavar='<str>',
              help='User name of VMware vCenter Server. (Virtual machine)')
@click.option('--vcenter_password', 'vcenter_password', type=str, metavar='<str>',
              help='Password of VMware vCenter Server. (Virtual machine)')
def configuration_backup_file_create(vcenter_user, vcenter_password):
    """
    Creates the configuration backup file.
    """
    platform_type = None
    try:
        config = Configuration()
        common_util = CommonUtil()
        config_backup_util = ConfigBackupUtil()
        output_util = OutputUtil()

        common_util.view_error()

        # 認証パラメータのチェック ベーシック認証のみサポート
        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true', '', '')
        auth_parameter_util.check_auth_parameter('true', '', '')

        common_util.view_error()

        sub_command_log_txt = "Sub-command parameters : " + " "
        cli_sub_command = "configuration_backup_file_create"

        common_util.input_password()

        # ソフトウェアバージョンのDDの先頭でプラットフォーム種別を得る。
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import \
            StorageClusterManagement
        api = StorageClusterManagement(ApiClient())
        for i in range(21):
            response = api.storageinfo_show(callback=None, debug="false")
            http_status = common_util.get_response_status(response)
            if common_util.check_retry(response):
                if i > 19:
                    output_util.echo_error(response, 'text')
                    logger.error('storage_show Failed.')
                    exit(1)
                else:
                    time.sleep(1)
                    continue

            elif http_status != 200:
                d = json.loads(response)
                if http_status == 404:
                    if d.get('body') is not None and d['body'].get('messageId') is not None:
                        rest_message_id = d['body'].get('messageId')
                        if rest_message_id == 'KARS15006-E':
                            message_id = '19505'
                            message_dict = {}
                            message_management = MessageManagement('')
                            message_management.viewMessageTxt(message_id, **message_dict)
                            exit(1)
                elif http_status == 401:
                    if d.get('body') is not None and d['body'].get('messageId') is not None:
                        rest_message_id = d['body'].get('messageId')
                        if rest_message_id == 'KARS20011-E':
                            message_id = '19206'
                            message_dict = {}
                            message_management = MessageManagement('')
                            message_management.viewMessageTxt(message_id, **message_dict)
                            exit(1)
                output_util.echo_error(response, 'text')
                logger.error('storage_show Failed.')
                exit(1)
            else:
                break

        # レスポンスからソフトウェアバージョンを得る。
        _, _, storage_version \
            = config_backup_util.get_storage_internal_id_cluster_id_and_version(response)
        if storage_version is None:
            logger.error('Failed to get version.')
            config.messageId = '19505'
            common_util.view_error()
        else:
            # ソフトウェアバージョン(AA.BB.CC.DD)のDDを見てプラットフォーム識別を得る。
            dd = storage_version.split(".")[3]
            if dd.startswith("0"):
                platform_type = Platform_type.ESXi
            elif dd.startswith("3"):
                platform_type = Platform_type.AWS
            elif dd.startswith("4"):
                platform_type = Platform_type.Native
            elif dd.startswith("5"):
                platform_type = Platform_type.Azure
            elif dd.startswith("6"):
                platform_type = Platform_type.GCP
            else:
                platform_type = Platform_type.other

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cli_sub_command)
            common_util.view_error()

        # サブコマンドパラメータのログ出力 パスワードは、伏せ字
        if platform_type == Platform_type.ESXi:
            if vcenter_user is not None:
                sub_command_log_txt += "--vcenter_user " + str(vcenter_user) + " "

            if vcenter_password is not None:
                sub_command_log_txt += "--vcenter_password " + "**********" + " "

        logger.info(sub_command_log_txt)

        if platform_type == Platform_type.ESXi:
            # CLIを実行している環境がメンテナンスノードか確認する
            if not MncCheckUtil.is_mnc_importable():
                logger.error(
                    cli_sub_command + 'The command was executed in an environment other than the maintenance node.')
                config.messageId = '19202'
                common_util.view_error()

            # メンテナンスコマンド存在確認
            if not config_backup_util.maintenance_command_exists_for_esxi():
                # config_backup_util.maintenance_command_exists()
                logger.error(cli_sub_command + ' /opt/hesmn/mnservice_restricted_bin/vagrant_up.sh not fond.')
                config.messageId = '19203'
                common_util.view_error()

            # 入力パラメータの補正
            if vcenter_user is not None:
                if isinstance(vcenter_user, str):
                    vcenter_user = SeparateArgs.check_backslash(vcenter_user)
                    vcenter_user = vcenter_user.encode("utf-8").decode("unicode-escape")

            if vcenter_password is not None:
                if isinstance(vcenter_password, str):
                    vcenter_password = SeparateArgs.check_backslash(vcenter_password)
                    vcenter_password = vcenter_password.encode("utf-8").decode("unicode-escape")

            # 入力パラメータのチェックは行わない

            # 環境変数設定
            if not config_backup_util.set_environment_variable_vcenter_user(vcenter_user):
                logger.error(cli_sub_command + ' vcenter_user is not set.')
                common_util.view_error()
            if not config_backup_util.set_environment_variable_vcenter_password(vcenter_password):
                logger.error(cli_sub_command + ' vcenter_password is not set.')
                common_util.view_error()

        # ワーニングバナー出力
        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cli_sub_command
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            common_util.view_error()

            # 空文字,Nullの場合はログインメッセージを表示しない
            if (login_message):
                click.echo(login_message, err=True)

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # プログレスバー
        with click.progressbar(length=2785, label='progress:', show_eta=False, file=sys.stderr) as bar:
            progress_util = ProgressUtil()
            progress_util.update_progressbar(bar, 0)

            # 接続先ホスト確認
            if not config_backup_util.is_host_primary_master():
                # 処理終了 200以外ならメッセージが入っている
                common_util.view_error()

            # プログレスバー更新 #1
            # ストレージクラスターマスターノード(プライマリー)確認APIの応答を受けた(最大処理時間:1秒)
            progress_util.update_progressbar(bar, 1)

            # 構成バックアップファイル生成先
            if platform_type == Platform_type.ESXi:
                config_backup_dir = os.path.join(config_backup_util.get_home(), 'config_backup')
            else:
                # CLI実行ディレクトリに生成する
                config_backup_dir = os.getcwd()

            # 作業用ディレクトリの作成
            with tempfile.TemporaryDirectory() as dname:
                # 1回目の構成ファイル比較用ディレクトリを作成
                config_export_dir1 = os.path.join(dname, 'config_export_1')
                os.makedirs(config_export_dir1, exist_ok=True)
                # 2回目の構成ファイル比較用ディレクトリを作成
                config_export_dir2 = os.path.join(dname, 'config_export_2')
                os.makedirs(config_export_dir2, exist_ok=True)

                # 1回目の構成ファイルエクスポート実行
                if platform_type == Platform_type.ESXi:
                    # output_directory
                    #   SystemConfigurationFile.csv
                    #   vagrant_setup.yml
                    result, rc = config_backup_util.config_file_export_for_esxi(config.host, config.username, config.password, config_export_dir1)
                    if not result:
                        common_util.view_error()
                elif platform_type == Platform_type.Native:
                    # output_directory
                    #   ConfigurationFiles.tar.gz
                    #       SystemConfigurationFile.csv
                    # ダウンロードするのはConfigurationFiles_<YYYYMMDD_HHMMSS>.tar.gzだがダウンロード先のパス指定でConfigurationFiles.tar.gzにリネームする
                    compressed_config_file_path = os.path.join(config_export_dir1, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_native(compressed_config_file_path)
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir1)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)
                elif platform_type == Platform_type.AWS:
                    # output_directory
                    #   SystemConfigurationFile.csv
                    #   ConfigurationFiles.tar.gz
                    #       VMConfigurationFile.yml
                    #       VMConfigurationFile_nodeXX.yml(システムで定義されているノード数分)
                    compressed_config_file_path = os.path.join(config_export_dir1, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_aws(compressed_config_file_path)
                    # VMConfigurationFile.ymlとVMConfigurationFile_nodeXX.ymlを取り出す
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir1)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)
                elif platform_type == Platform_type.Azure:
                    # output_directory
                    #   ConfigurationFiles.tar.gz
                    #       SystemConfigurationFile.csv
                    #       VMConfigurationFile.json
                    #       VMConfigurationFile.parameters.json
                    # ダウンロードするのはConfigurationFiles_<YYYYMMDD_HHMMSS>.tar.gzだがダウンロード先のパス指定でConfigurationFiles.tar.gzにリネームする
                    compressed_config_file_path = os.path.join(config_export_dir1, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_azure(compressed_config_file_path)
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir1)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)
                elif platform_type == Platform_type.GCP:
                    # output_directory
                    #   ConfigurationFiles.tar.gz
                    #       SystemConfigurationFile.csv
                    #       main.tf
                    #       variable.tf
                    #       terraform.tfvars
                    #       backend.auto.tfvars
                    # ダウンロードするのはConfigurationFiles_<YYYYMMDD_HHMMSS>.tar.gzだがダウンロード先のパス指定でConfigurationFiles.tar.gzにリネームする
                    compressed_config_file_path = os.path.join(config_export_dir1, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_gcp(compressed_config_file_path)
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir1)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)

                # プログレスバー更新 #2
                # 構成ファイルエクスポート(1回目) 完了(最大処理時間:300秒)
                progress_util.update_progressbar(bar, 300)

                # クラスタ構成バックアップ作成API
                from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
                    SystemManagement as SystemManagementApi
                api = SystemManagementApi(ApiClient())
                for i in range(21):
                    response = api.create_cluster_config_backup(callback=None, debug="false")
                    http_status = common_util.get_response_status(response)
                    if http_status == 202:
                        break
                    elif common_util.check_retry(response):
                        if i > 19:
                            # REST応答をCLIで変換
                            config_backup_util.convert_rest_responses_with_cli_for_config_backup(response)

                            output_util.echo_error(response, 'text')
                            logger.error('create_cluster_config_backup Failed.')
                            exit(1)
                        else:
                            time.sleep(1)
                            continue
                    else:
                        # エラー処理
                        # REST応答をCLIで変換
                        config_backup_util.convert_rest_responses_with_cli_for_config_backup(response)

                        output_util.echo_error(response, 'text')
                        logger.error('create_cluster_config_backup Failed.')
                        exit(1)

                # プログレスバー更新 #3
                # クラスタ構成バックアップファイル作成APIの応答を受けた(最大処理時間:1秒)
                progress_util.update_progressbar(bar, 1)

                job_id = config_backup_util.get_job_id(response)
                if job_id is None:
                    logger.error('get_job_id job_id is None')
                    config.messageId = '19008'
                    common_util.view_error()

                # judge_job_result()にProgressbar objectを渡して関数内でプログレスバーを更新する
                if not config_backup_util.judge_job_result(job_id, bar):
                    common_util.view_error()

                # マニュアル実装のダウンロード関数を呼ぶ
                from com.hitachi.sophia.cli.manual.sub_commands.system_management_manual import \
                    configuration_backup_file_manual
                download_file_name = configuration_backup_file_manual(dname, callback=None, debug="false")

                # プログレスバー更新 #5
                # クラスタ構成バックアップファイルダウンロードAPIの応答を受けた(最大処理時間:1秒)
                progress_util.update_progressbar(bar, 1)

                # バージョン取得
                from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import \
                    StorageClusterManagement
                api = StorageClusterManagement(ApiClient())
                for i in range(21):
                    response = api.storageinfo_show(callback=None, debug="false")
                    http_status = common_util.get_response_status(response)
                    if common_util.check_retry(response):
                        if i > 19:
                            output_util.echo_error(response, 'text')
                            logger.error('storage_show Failed.')
                            exit(1)
                        else:
                            time.sleep(1)
                            continue

                    elif http_status != 200:
                        d = json.loads(response)
                        if http_status == 404:
                            if d.get('body') is not None and d['body'].get('messageId') is not None:
                                rest_message_id = d['body'].get('messageId')
                                if rest_message_id == 'KARS15006-E':
                                    message_id = '19505'
                                    message_dict = {}
                                    message_management = MessageManagement('')
                                    message_management.viewMessageTxt(message_id, **message_dict)
                                    exit(1)
                        elif http_status == 401:
                            if d.get('body') is not None and d['body'].get('messageId') is not None:
                                rest_message_id = d['body'].get('messageId')
                                if rest_message_id == 'KARS20011-E':
                                    message_id = '19218'
                                    message_dict = {}
                                    message_management = MessageManagement('')
                                    message_management.viewMessageTxt(message_id, **message_dict)
                                    exit(1)

                        output_util.echo_error(response, 'text')
                        logger.error('storage_show Failed.')
                        exit(1)
                    else:
                        break

                # プログレスバー更新 #6
                # ストレージクラスター情報取得APIの応答を受けた受けた(最大処理時間:1秒)
                progress_util.update_progressbar(bar, 1)

                internal_id, cluster_id, storage_version \
                    = config_backup_util.get_storage_internal_id_cluster_id_and_version(response)
                if internal_id is None or cluster_id is None or storage_version is None:
                    logger.error('get_storage_internal_id_cluster_id_and_version internal_id is '
                                 + str(internal_id)
                                 + ', and cluster_id is '
                                 + str(cluster_id)
                                 + ', and storage_version is '
                                 + str(storage_version))
                    config.messageId = '19505'

                # 2回目の構成ファイルエクスポート実行
                if platform_type == Platform_type.ESXi:
                    result, rc = config_backup_util.config_file_export_for_esxi(config.host, config.username, config.password, config_export_dir2)
                    if not result:
                        common_util.view_error()
                elif platform_type == Platform_type.Native:
                    # ダウンロードするのはConfigurationFiles_<YYYYMMDD_HHMMSS>.tar.gzだがダウンロード先のパス指定で変更できる。
                    compressed_config_file_path = os.path.join(config_export_dir2, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_native(compressed_config_file_path)
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir2)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)
                elif platform_type == Platform_type.AWS:
                    compressed_config_file_path = os.path.join(config_export_dir2, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_aws(compressed_config_file_path)
                    # VMConfigurationFile.ymlとVMConfigurationFile_nodeXX.ymlを取り出す
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir2)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)
                elif platform_type == Platform_type.Azure:
                    # ダウンロードするのはConfigurationFiles_<YYYYMMDD_HHMMSS>.tar.gzだがダウンロード先のパス指定で変更できる。
                    compressed_config_file_path = os.path.join(config_export_dir2, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_azure(compressed_config_file_path)
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir2)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)
                elif platform_type == Platform_type.GCP:
                    # ダウンロードするのはConfigurationFiles_<YYYYMMDD_HHMMSS>.tar.gzだがダウンロード先のパス指定で変更できる。
                    compressed_config_file_path = os.path.join(config_export_dir2, 'ConfigurationFiles.tar.gz')
                    config_backup_util.config_file_export_for_gcp(compressed_config_file_path)
                    with tarfile.open(compressed_config_file_path) as archive:
                        archive.extractall(path=config_export_dir2)
                    if os.path.isfile(compressed_config_file_path):
                        os.remove(compressed_config_file_path)

                # プログレスバー更新 #7
                # 構成ファイルエクスポート(2回目)完了(最大処理時間:300秒)
                progress_util.update_progressbar(bar, 300)

                # 構成ファイル比較
                if not config_backup_util.dir_compare(config_export_dir1, config_export_dir2):
                    # 構成バックアップ中に構成が変更されました。
                    logger.error('The configuration was changed during the configuration backup.')
                    config.messageId = '19216'
                    common_util.view_error()

                # プログレスバー更新 #8
                # その他標準処理として(最大処理時間:1秒)
                # ・1回目と2回目の構成ファイルの比較完了
                progress_util.update_progressbar(bar, 1)

                # クラスタ構成構成バックアップファイル破損チェック
                cluster_config_backup_file_path = os.path.join(dname, download_file_name)
                if not config_backup_util.check_checksum(cluster_config_backup_file_path):
                    # 構成バックアップファイルの状態が不正
                    logger.error('Corrupted configuration backup file.')
                    config.messageId = '19217'
                    common_util.view_error()

                #構成リストア用デバックオプション追加
                if platform_type == Platform_type.Azure:
                    vm_conf_param_json = os.path.join(config_export_dir1, 'VMConfigurationFile.parameters.json')
                    config_backup_util.add_restore_debug_option_for_azure(vm_conf_param_json)

                # バージョンファイル作成
                try:
                    version_file = config_backup_util.create_version_file(storage_version, dname)
                except Exception as e:
                    if (traceback):
                        logger.error(traceback.format_exc())
                    config.messageId = '19505'
                    config.messageDict = {}
                    common_util = CommonUtil()
                    common_util.view_error()

                # クラスターIDファイル作成
                cluster_id_file = config_backup_util.create_cluster_id_file(cluster_id, dname)

                # dataアーカイブ(hsds_config_backup_yyyymmdd_HHMMSS_data.tarを作る
                # dataディレクトリを作る
                src_csv = os.path.join(config_export_dir1, 'SystemConfigurationFile.csv')
                if platform_type == Platform_type.ESXi:
                    src_setup_yml = os.path.join(config_export_dir1, 'vagrant_setup.yml')
                    data_dir = config_backup_util.create_data_dir(dname, src_csv, src_setup_yml, None, None, None, None, version_file, cluster_id_file,
                                                                cluster_config_backup_file_path)
                elif platform_type == Platform_type.Native:
                    data_dir = config_backup_util.create_data_dir(dname, src_csv, None, None, None, None, None, version_file, cluster_id_file,
                                                                cluster_config_backup_file_path)
                elif platform_type == Platform_type.AWS:
                    src_vm_conf_yml = os.path.join(config_export_dir1, 'VMConfigurationFile.yml')
                    src_partial_vm_conf_yml = [str(os.path.join(config_export_dir1, member)) 
                        for member in os.listdir(config_export_dir1) if member.startswith("VMConfigurationFile_") or member.startswith("IamResourceConfigurationFile") or member.startswith("NetworkResourceConfigurationFile_")]
                    data_dir = config_backup_util.create_data_dir(dname, src_csv, None, src_vm_conf_yml, src_partial_vm_conf_yml, None, None, version_file, cluster_id_file,
                                                                cluster_config_backup_file_path)
                elif platform_type == Platform_type.Azure:
                    src_vm_conf_json = os.path.join(config_export_dir1, 'VMConfigurationFile.json')
                    src_vm_conf_param_json = os.path.join(config_export_dir1, 'VMConfigurationFile.parameters.json')
                    data_dir = config_backup_util.create_data_dir(dname, src_csv, None, src_vm_conf_json, None, src_vm_conf_param_json, None, version_file, cluster_id_file,
                                                                cluster_config_backup_file_path)
                elif platform_type == Platform_type.GCP:
                    src_tf__vm_conf_files = [str(os.path.join(config_export_dir1, member)) for member in os.listdir(config_export_dir1) if member in ["main.tf", "variable.tf", "terraform.tfvars", "backend.auto.tfvars"]]
                    data_dir = config_backup_util.create_data_dir(dname, src_csv, None, None, None, None, src_tf__vm_conf_files, version_file, cluster_id_file,
                                                                cluster_config_backup_file_path)

                # data.tarの作成
                try:
                    member_list = [data_dir]
                    data_tar_file_path = os.path.join(dname, 'data.tar')
                    config_backup_util.create_tar_file(data_tar_file_path, member_list)
                except Exception as e:
                    if (traceback):
                        logger.error(traceback.format_exc())
                    config.messageId = '19505'
                    config.messageDict = {}
                    common_util = CommonUtil()
                    common_util.view_error()

                # data_dirを削除
                config_backup_util.delete_dir(data_dir)

                # チェックサムの作成
                checksum_file_path = os.path.join(dname, 'checksum')
                config_backup_util.create_checksum(data_tar_file_path, checksum_file_path)

                # 構成バックアップファイル名の生成
                config_backup_path_name, config_backup_file_name = \
                    config_backup_util.get_backup_data_file_name(internal_id, storage_version)

                # 構成バックアップファイル用ディレクトリの作成
                config_backup_file_path = os.path.join(dname, config_backup_path_name)
                config_backup_util.create_config_backup_dir(config_backup_file_path, data_tar_file_path,
                                                            checksum_file_path)

                # 構成バックアップファイルの作成
                try:
                    config_backup_file_name_path = os.path.join(dname, config_backup_file_name)
                    config_backup_file_name_path_list = [config_backup_file_path]

                    config_backup_util.create_tar_file(config_backup_file_name_path, config_backup_file_name_path_list)
                except Exception as e:
                    if (traceback):
                        logger.error(traceback.format_exc())
                    config.messageId = '19505'
                    config.messageDict = {}
                    common_util = CommonUtil()
                    common_util.view_error()

                # 移動先ディレクトリの確認
                if not os.path.exists(config_backup_dir):
                    os.makedirs(config_backup_dir, mode=0o755)
                elif os.path.isfile(config_backup_dir):
                    # エラー処理(同じ名前ファイルがあった)
                    config.messageId = '19006'
                    config.messageDict = {'filePath': config_backup_dir}
                    common_util.view_error()

                # 構成バックアップファイル移動
                try:
                    shutil.move(config_backup_file_name_path, config_backup_dir)
                except OSError as e:  # OSError
                    # 中途半端にファイルを生成している場合は削除
                    if os.path.isfile(os.path.join(config_backup_dir, config_backup_file_name)):
                        os.remove(os.path.join(config_backup_dir, config_backup_file_name))
                        logger.info("delete backupfile in the process of creation.")
                    mssageManagement = MessageManagement('')
                    # CLIを実行したディスクの空き容量が不足している
                    if e.errno == errno.ENOSPC:
                        if (traceback):
                            logger.error(traceback.format_exc())
                        config.messageId = '19214'
                        config.messageDict = {}
                        common_util = CommonUtil()
                        common_util.view_error()
                except Exception as e:
                    if (traceback):
                        logger.error(traceback.format_exc())
                    config.messageId = '19220'
                    config.messageDict = {}
                    common_util = CommonUtil()
                    common_util.view_error()

                # プログレスバー更新 #9,10,11,12
                # ファイルの圧縮/作成時間として(最大処理時間:10秒)
                # ・data.tar作成完了
                # ・クラスタ構成バックアップファイル破損チェック完了
                # ・構成バックアップファイル作成完了
                # ・構成バックアップファイル移動完了
                progress_util.update_progressbar(bar, 10)

                # 一時ディレクトリ作成のwithステートメント終了

        # プログレスバーのwithステートメントを抜けたのでフラグOFF
        config.is_progress_shown = False

        # 正常終了メッセージ表示
        file_path_to_display = os.path.join(config_backup_dir, config_backup_file_name)
        if config.format == 'text':
            click.echo('Message: ' + 'Configuration backup file creation completed.')
            click.echo('Output File Path: ' + os.path.abspath(file_path_to_display))
        else:
            cli_response = collections.OrderedDict()
            cli_response['message'] = 'Configuration backup file creation completed.'
            cli_response['outputFilePath'] = os.path.abspath(file_path_to_display)
            cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
            click.echo(cli_response)

    except FileNotFoundError:
        config = Configuration()
        config.is_progress_shown = False
        config.messageId = '19215'
        config.messageDict = {}
        common_util = CommonUtil()
        common_util.view_error()

    except OSError as e:  # OSError
        mssageManagement = MessageManagement('')
        # CLIを実行したディスクの空き容量が不足している
        if e.errno == errno.ENOSPC:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19214'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # CLIを実行したメンテナンスノードの空きメモリーが不足
        elif e.errno == errno.ENOMEM:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19029'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # システム全体でオープンされているファイルが多過ぎる
        elif e.errno == errno.ENFILE:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19034'
            config.messageDict = {}
            common_util = CommonUtil()
            common_util.view_error()

        # その他のOSError
        else:
            if (traceback):
                logger.error(traceback.format_exc())
            config = Configuration()
            config.is_progress_shown = False
            config.messageId = '19060'
            str_err = ','.join(map(str, e.args))
            config.messageDict = {'exception': str_err}
            common_util = CommonUtil()
            common_util.view_error()

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        config = Configuration()
        config.is_progress_shown = False
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)


def commands():
    commands = {}
    commands['configuration_backup_file_create'] = configuration_backup_file_create
    return commands
