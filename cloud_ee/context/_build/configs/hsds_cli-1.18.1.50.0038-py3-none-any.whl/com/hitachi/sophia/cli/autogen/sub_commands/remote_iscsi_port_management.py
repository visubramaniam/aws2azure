# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--local_port_number','_local_port_number',type=str,metavar='<str>',help='Port number of the local storage system in CLx-y format.',required=True)
@click.option('--remote_serial_number','_remote_serial_number',type=str,metavar='<str>',help='Serial number of the remote storage system.',required=True)
@click.option('--remote_storage_type_id','_remote_storage_type_id',type=str,metavar='<str>',help='ID indicating the remote storage system model.',required=True)
@click.option('--remote_port_number','_remote_port_number',type=str,metavar='<str>',help='Port number of the remote storage system in CLx-y format.',required=True)
@click.option('--remote_ip_address','_remote_ip_address',type=str,metavar='<str>',help='IP address of the iSCSI port for the remote storage system.',required=True)
@click.option('--remote_tcp_port','_remote_tcp_port',type=int,metavar='<int>',help='TCP port number of the iSCSI target for the remote storage system.')
def remote_iscsi_port_create(_local_port_number,_remote_serial_number,_remote_storage_type_id,_remote_port_number,_remote_ip_address,_remote_tcp_port,):
    """
    Registers a remote iSCSI port. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remote_iscsi_port_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _local_port_number is not None:
            subCommandLogtxt += "--local_port_number " + str(_local_port_number) + " "




        if _remote_serial_number is not None:
            subCommandLogtxt += "--remote_serial_number " + str(_remote_serial_number) + " "




        if _remote_storage_type_id is not None:
            subCommandLogtxt += "--remote_storage_type_id " + str(_remote_storage_type_id) + " "




        if _remote_port_number is not None:
            subCommandLogtxt += "--remote_port_number " + str(_remote_port_number) + " "




        if _remote_ip_address is not None:
            subCommandLogtxt += "--remote_ip_address " + str(_remote_ip_address) + " "




        if _remote_tcp_port is not None:
            subCommandLogtxt += "--remote_tcp_port " + str(_remote_tcp_port) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remote_iscsi_port_management import RemoteIscsiPortManagement as RemoteIscsiPortManagementApi
        api = RemoteIscsiPortManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remote_iscsi_port_create"



















        if _local_port_number is not None:
            if(isinstance(_local_port_number, str)):
                _local_port_number = SeparateArgs.check_backslash(_local_port_number)
                _local_port_number = _local_port_number.encode("utf-8").decode("unicode-escape")
        if _remote_serial_number is not None:
            if(isinstance(_remote_serial_number, str)):
                _remote_serial_number = SeparateArgs.check_backslash(_remote_serial_number)
                _remote_serial_number = _remote_serial_number.encode("utf-8").decode("unicode-escape")
        if _remote_storage_type_id is not None:
            if(isinstance(_remote_storage_type_id, str)):
                _remote_storage_type_id = SeparateArgs.check_backslash(_remote_storage_type_id)
                _remote_storage_type_id = _remote_storage_type_id.encode("utf-8").decode("unicode-escape")
        if _remote_port_number is not None:
            if(isinstance(_remote_port_number, str)):
                _remote_port_number = SeparateArgs.check_backslash(_remote_port_number)
                _remote_port_number = _remote_port_number.encode("utf-8").decode("unicode-escape")
        if _remote_ip_address is not None:
            if(isinstance(_remote_ip_address, str)):
                _remote_ip_address = SeparateArgs.check_backslash(_remote_ip_address)
                _remote_ip_address = _remote_ip_address.encode("utf-8").decode("unicode-escape")
        if _remote_tcp_port is not None:
            if(isinstance(_remote_tcp_port, str)):
                _remote_tcp_port = SeparateArgs.check_backslash(_remote_tcp_port)
                _remote_tcp_port = _remote_tcp_port.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateRemoteIscsiPortParam import CreateRemoteIscsiPortParam
        _storage_node = CreateRemoteIscsiPortParam()
        _storage_node.local_port_number = _local_port_number
        _storage_node.remote_serial_number = _remote_serial_number
        _storage_node.remote_storage_type_id = _remote_storage_type_id
        _storage_node.remote_port_number = _remote_port_number
        _storage_node.remote_ip_address = _remote_ip_address
        _storage_node.remote_tcp_port = _remote_tcp_port

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_iscsi_port_create(storage_node = _storage_node, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote iSCSI port ID. ',required=True)
def remote_iscsi_port_delete(_id,):
    """
    Deletes information about registered remote iSCSI ports. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remote_iscsi_port_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remote_iscsi_port_management import RemoteIscsiPortManagement as RemoteIscsiPortManagementApi
        api = RemoteIscsiPortManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "remote_iscsi_port_delete"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_iscsi_port_delete(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Remote iSCSI port ID. ',required=True)
def remote_iscsi_port_show(_id,):
    """
    Obtains information about remote iSCSI ports. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remote_iscsi_port_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remote_iscsi_port_management import RemoteIscsiPortManagement as RemoteIscsiPortManagementApi
        api = RemoteIscsiPortManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "remote_iscsi_port_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.RemoteIscsiPort import RemoteIscsiPort

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_iscsi_port_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--local_port_number','_local_port_number',metavar='<str>',help='Port number of the local storage system in CLx-y format. ')
@click.option('--remote_serial_number','_remote_serial_number',metavar='<str>',help='Serial number of the remote storage system. ')
@click.option('--remote_storage_type_id','_remote_storage_type_id',metavar='<str>',help='ID indicating the remote storage system model. ')
@click.option('--remote_port_number','_remote_port_number',metavar='<str>',help='Port number of the remote storage system in CLx-y format. ')
def remote_iscsi_port_list(_local_port_number,_remote_serial_number,_remote_storage_type_id,_remote_port_number,):
    """
    Obtains a list of information about remote iSCSI ports. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "remote_iscsi_port_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _local_port_number is not None:
            subCommandLogtxt += "--local_port_number " + str(_local_port_number) + " "




        if _remote_serial_number is not None:
            subCommandLogtxt += "--remote_serial_number " + str(_remote_serial_number) + " "




        if _remote_storage_type_id is not None:
            subCommandLogtxt += "--remote_storage_type_id " + str(_remote_storage_type_id) + " "




        if _remote_port_number is not None:
            subCommandLogtxt += "--remote_port_number " + str(_remote_port_number) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.remote_iscsi_port_management import RemoteIscsiPortManagement as RemoteIscsiPortManagementApi
        api = RemoteIscsiPortManagementApi(ApiClient())

        


        
        


        
        


        #Enumチェック
        allowed_values = ["R9", "M8"]

        if _remote_storage_type_id is not None:
            if _remote_storage_type_id not in allowed_values:
                raise ValueError(
                    "Invalid value for `remote_storage_type_id` ({0}), (Select only one) {1}"
                    .format(_remote_storage_type_id, allowed_values)
            )
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "remote_iscsi_port_list"

        if  _local_port_number is not None and not re.search('^CL[1-9A-G]-[A-HJ-NP-R]$', _local_port_number):
            raise ValueError("Invalid value for parameter `local_port_number` when calling `" + cliSubCommand + "`, must conform to the pattern `/^CL[1-9A-G]-[A-HJ-NP-R]$/`")
#           raise ValueError("Invalid value for parameter `local_port_number` when calling `remote_iscsi_ports_list`, must conform to the pattern `/^CL[1-9A-G]-[A-HJ-NP-R]$/`")






        if _remote_serial_number is not None and len(_remote_serial_number) > 6:
            raise ValueError("Invalid value for parameter `remote_serial_number` when calling `" + cliSubCommand + "`, length must be equal to `6`")
#           raise ValueError("Invalid value for parameter `remote_serial_number` when calling `remote_iscsi_ports_list`, length must be equal to `6`")
        if _remote_serial_number is not None and len(_remote_serial_number) < 6:
            raise ValueError("Invalid value for parameter `remote_serial_number` when calling `" + cliSubCommand + "`, length must be equal to `6`")
#           raise ValueError("Invalid value for parameter `remote_serial_number` when calling `remote_iscsi_ports_list`, length must be equal to `6`")
        if  _remote_serial_number is not None and not re.search('^[0-9]{6}$', _remote_serial_number):
            raise ValueError("Invalid value for parameter `remote_serial_number` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[0-9]{6}$/`")
#           raise ValueError("Invalid value for parameter `remote_serial_number` when calling `remote_iscsi_ports_list`, must conform to the pattern `/^[0-9]{6}$/`")












        if  _remote_port_number is not None and not re.search('^CL[1-9A-G]-[A-HJ-NP-R]$', _remote_port_number):
            raise ValueError("Invalid value for parameter `remote_port_number` when calling `" + cliSubCommand + "`, must conform to the pattern `/^CL[1-9A-G]-[A-HJ-NP-R]$/`")
#           raise ValueError("Invalid value for parameter `remote_port_number` when calling `remote_iscsi_ports_list`, must conform to the pattern `/^CL[1-9A-G]-[A-HJ-NP-R]$/`")

















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.RemoteIscsiPortList import RemoteIscsiPortList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remote_iscsi_ports_list(local_port_number = _local_port_number, remote_serial_number = _remote_serial_number, remote_storage_type_id = _remote_storage_type_id, remote_port_number = _remote_port_number, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['remote_iscsi_port_create'] = remote_iscsi_port_create
    commands['remote_iscsi_port_delete'] = remote_iscsi_port_delete
    commands['remote_iscsi_port_show'] = remote_iscsi_port_show
    commands['remote_iscsi_port_list'] = remote_iscsi_port_list
    return commands

