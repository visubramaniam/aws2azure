# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--protocol','_protocol',type=str,metavar='<str>',help='Initiator connection protocol.',required=True)
@click.option('--hba_wwn','_hba_wwn',type=str,metavar='<str>',help='The WWN for the initiator. Required if FC is specified using a protocol.')
@click.option('--iscsi_name','_iscsi_name',type=str,metavar='<str>',help='The iSCSI name of the initiator. Required if iSCSI is specified using a protocol.')
@click.option('--host_nqn','_host_nqn',type=str,metavar='<str>',help='Host NQN of an initiator.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def hba_create(_id,_id_nickname,_protocol,_hba_wwn,_iscsi_name,_host_nqn,_vps_id,_vps_id_name,):
    """
    Registers the initiator information of a compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "hba_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "






        if _protocol is not None:
            subCommandLogtxt += "--protocol " + str(_protocol) + " "




        if _hba_wwn is not None:
            subCommandLogtxt += "--hba_wwn " + str(_hba_wwn) + " "




        if _iscsi_name is not None:
            subCommandLogtxt += "--iscsi_name " + str(_iscsi_name) + " "




        if _host_nqn is not None:
            subCommandLogtxt += "--host_nqn " + str(_host_nqn) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "hba_create"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `hba_create`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _protocol is not None:
            if(isinstance(_protocol, str)):
                _protocol = SeparateArgs.check_backslash(_protocol)
                _protocol = _protocol.encode("utf-8").decode("unicode-escape")
        if _hba_wwn is not None:
            if(isinstance(_hba_wwn, str)):
                _hba_wwn = SeparateArgs.check_backslash(_hba_wwn)
                _hba_wwn = _hba_wwn.encode("utf-8").decode("unicode-escape")
        if _iscsi_name is not None:
            if(isinstance(_iscsi_name, str)):
                _iscsi_name = SeparateArgs.check_backslash(_iscsi_name)
                _iscsi_name = _iscsi_name.encode("utf-8").decode("unicode-escape")
        if _host_nqn is not None:
            if(isinstance(_host_nqn, str)):
                _host_nqn = SeparateArgs.check_backslash(_host_nqn)
                _host_nqn = _host_nqn.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.AddHbasServerParam import AddHbasServerParam
        _add_hbas = AddHbasServerParam()
        _add_hbas.protocol = _protocol
        _add_hbas.hba_wwn = _hba_wwn
        _add_hbas.iscsi_name = _iscsi_name
        _add_hbas.host_nqn = _host_nqn
        _add_hbas.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_hbas is None:
                from com.hitachi.sophia.rest_client.autogen.models.AddHbasServerParam import AddHbasServerParam
                _add_hbas = AddHbasServerParam()
            _add_hbas.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.hba_create(_id, add_hbas = _add_hbas, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--hba_id','_hba_id',metavar='<str>',help='The initiator ID of the compute node. ')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def hba_delete(_id,_id_nickname,_hba_id,_hba_id_name,_vps_id,_vps_id_name,):
    """
    Deletes the initiator information of a compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_hba_list_with_hba_id_name(hba_id_name, _id):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.hba_list(id=_id, name=hba_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'hba_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "hba_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "



        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--hba_id', _hba_id,'--hba_id_name', _hba_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "hba_delete"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `hba_delete`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _hba_id_name is not None and not re.search('^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)', _hba_id_name):
            raise ValueError("Invalid value for parameter `hba_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")
#           raise ValueError("Invalid value for parameter `hba_id` when calling `hba_delete`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")










        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteHbasServerParam import DeleteHbasServerParam
        _delete_hbas = DeleteHbasServerParam()
        _delete_hbas.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _hba_id_name is not None:
            # hba_listを使ってhba_id_nameに対応するhba_idを取得
            _hba_id = get_uuid_from_hba_list_with_hba_id_name(_hba_id_name, _id=_id)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_hbas is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteHbasServerParam import DeleteHbasServerParam
                _delete_hbas = DeleteHbasServerParam()
            _delete_hbas.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.hba_delete(_id, _hba_id, delete_hbas = _delete_hbas, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--name','_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators. ')
@click.option('--id_name','_id_name',metavar='<str>',help='Alias of name.')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def hba_list(_id,_id_nickname,_name,_id_name,_vps_id,_vps_id_name,):
    """
    Obtains a list of initiator information of the compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "hba_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "




        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--name', _name,'--id_name', _id_name, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "hba_list"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `hba_list`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")








        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `hba_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `hba_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.HbaList import HbaList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if not _id_name is None:
            _name = _id_name

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.hba_list(_id, name = _name, vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--hba_id','_hba_id',metavar='<str>',help='The initiator ID of the compute node. ')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators.')
def hba_show(_id,_id_nickname,_hba_id,_hba_id_name,):
    """
    Obtains the initiator information of a compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_hba_list_with_hba_id_name(hba_id_name, _id):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.hba_list(id=_id, name=hba_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'hba_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "hba_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "



        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--hba_id', _hba_id,'--hba_id_name', _hba_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "hba_show"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `hba_show`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _hba_id_name is not None and not re.search('^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)', _hba_id_name):
            raise ValueError("Invalid value for parameter `hba_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")
#           raise ValueError("Invalid value for parameter `hba_id` when calling `hba_show`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Hba import Hba

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _hba_id_name is not None:
            # hba_listを使ってhba_id_nameに対応するhba_idを取得
            _hba_id = get_uuid_from_hba_list_with_hba_id_name(_hba_id_name, _id=_id)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.hba_show(_id, _hba_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--server_nickname','_server_nickname',type=str,metavar='<str>',help='The compute node nickname.',required=True)
@click.option('--os_type','_os_type',type=str,metavar='<str>',help='The OS type of the compute node.',required=True)
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def server_create(_server_nickname,_os_type,_vps_id,_vps_id_name,):
    """
    Registers the information of the compute node. 
    """
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "server_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _server_nickname is not None:
            subCommandLogtxt += "--server_nickname " + str(_server_nickname) + " "




        if _os_type is not None:
            subCommandLogtxt += "--os_type " + str(_os_type) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "server_create"





        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _server_nickname is not None:
            if(isinstance(_server_nickname, str)):
                _server_nickname = SeparateArgs.check_backslash(_server_nickname)
                _server_nickname = _server_nickname.encode("utf-8").decode("unicode-escape")
        if _os_type is not None:
            if(isinstance(_os_type, str)):
                _os_type = SeparateArgs.check_backslash(_os_type)
                _os_type = _os_type.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateServerParam import CreateServerParam
        _create_server = CreateServerParam()
        _create_server.server_nickname = _server_nickname
        _create_server.os_type = _os_type
        _create_server.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_server is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateServerParam import CreateServerParam
                _create_server = CreateServerParam()
            _create_server.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_create(create_server = _create_server, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def server_delete(_id,_id_nickname,_vps_id,_vps_id_name,):
    """
    Deletes the information of the compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "server_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "server_delete"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_delete`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")










        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteServerParam import DeleteServerParam
        _delete_server = DeleteServerParam()
        _delete_server.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_server is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteServerParam import DeleteServerParam
                _delete_server = DeleteServerParam()
            _delete_server.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_delete(_id, delete_server = _delete_server, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--nickname','_nickname',type=str,metavar='<str>',help='The new compute node nickname.')
@click.option('--os_type','_os_type',type=str,metavar='<str>',help='The OS type of the compute node.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def server_set(_id,_id_nickname,_nickname,_os_type,_vps_id,_vps_id_name,):
    """
    Edits information about the compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "server_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "






        if _nickname is not None:
            subCommandLogtxt += "--nickname " + str(_nickname) + " "




        if _os_type is not None:
            subCommandLogtxt += "--os_type " + str(_os_type) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "server_set"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_edit`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _nickname is not None:
            if(isinstance(_nickname, str)):
                _nickname = SeparateArgs.check_backslash(_nickname)
                _nickname = _nickname.encode("utf-8").decode("unicode-escape")
        if _os_type is not None:
            if(isinstance(_os_type, str)):
                _os_type = SeparateArgs.check_backslash(_os_type)
                _os_type = _os_type.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchServerParam import PatchServerParam
        _patch_server_param = PatchServerParam()
        _patch_server_param.nickname = _nickname
        _patch_server_param.os_type = _os_type
        _patch_server_param.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _patch_server_param is None:
                from com.hitachi.sophia.rest_client.autogen.models.PatchServerParam import PatchServerParam
                _patch_server_param = PatchServerParam()
            _patch_server_param.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_edit(_id, patch_server_param = _patch_server_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--nickname','_nickname',metavar='<str>',help='The compute node nickname (exact match). ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='Alias of nickname.')
@click.option('--nicknames','_nicknames',metavar='<str>',help='A list of the compute node nicknames (exact match). You can specify plural nicknames (up to 32) by delimiting them with commas (,). When nicknames include commas, escape the commas with \\ (Backslash). ')
@click.option('--id_nicknames','_id_nicknames',metavar='<str>',help='Alias of nicknames.')
@click.option('--hba_name','_hba_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators. ')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='Alias of hba_name.')
@click.option('--hba_id','_hba_id',metavar='<str>',help='The initiator ID of the compute node. ')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def server_list(_nickname,_id_nickname,_nicknames,_id_nicknames,_hba_name,_hba_id_name,_hba_id,_vps_id,_vps_id_name,):
    """
    Obtains a list of compute node information. 
    """
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "server_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _nickname is not None:
            subCommandLogtxt += "--nickname " + str(_nickname) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "



        if _nicknames is not None:
            subCommandLogtxt += "--nicknames " + str(_nicknames) + " "

        if _id_nicknames is not None:
            subCommandLogtxt += "--id_nicknames " + str(_id_nicknames) + " "



        if _hba_name is not None:
            subCommandLogtxt += "--hba_name " + str(_hba_name) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "



        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--nickname', _nickname,'--id_nickname', _id_nickname, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--nicknames', _nicknames,'--id_nicknames', _id_nicknames, 'false')
        commonutil.view_error()


        
        #フィルター配列チェック
        if _nicknames is not None:
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('nicknames',
                                                            _nicknames,
                                                            '^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$',
                                                            '^[a-zA-Z0-9,\\.:@_]([a-zA-Z0-9,\\.:@_\\-]{0,228})$',
                                                            32,
                                                            229)
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--hba_name', _hba_name,'--hba_id_name', _hba_id_name, 'false')
        commonutil.view_error()


        
        


        
        #UUIDチェック
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "server_list"

























        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `server_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `server_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")









        if _id_nicknames is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('id_nicknames',
                                                            _id_nicknames,
                                                            '^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$',
                                                            '^[a-zA-Z0-9,\\.:@_]([a-zA-Z0-9,\\.:@_\\-]{0,228})$',
                                                            32,
                                                            229)




                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ServerSummaryList import ServerSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if not _id_nickname is None:
            _nickname = _id_nickname

        if not _id_nicknames is None:
            _nicknames = _id_nicknames

        if not _hba_id_name is None:
            _hba_name = _hba_id_name

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_list(nickname = _nickname, nicknames = _nicknames, hba_name = _hba_name, hba_id = _hba_id, vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--hba_id','_hba_id',type=str,metavar='<str>',help='The initiator ID of the compute node.')
@click.option('--port_id','_port_id',type=str,metavar='<str>',help='The ID of the allocation destination compute port for the target operation.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators.')
@click.option('--port_id_name','_port_id_name',metavar='<str>',help='WWN of the allocation destination compute port of the target operation for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def path_create(_id,_id_nickname,_hba_id,_hba_id_name,_port_id,_port_id_name,_vps_id,_vps_id_name,):
    """
    Adds path information to a compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_hba_list_with_hba_id_name(hba_id_name, _id):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.hba_list(id=_id, name=hba_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'hba_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_port_list_with_port_id_name(port_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=port_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'port_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "path_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "






        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "



        if _port_id is not None:
            subCommandLogtxt += "--port_id " + str(_port_id) + " "

        if _port_id_name is not None:
            subCommandLogtxt += "--port_id_name " + str(_port_id_name) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--hba_id', _hba_id,'--hba_id_name', _hba_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--port_id', _port_id,'--port_id_name', _port_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        if _port_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _port_id):
            raise ValueError("Invalid value for `port_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "path_create"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_path_create`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _hba_id_name is not None and not re.search('^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)', _hba_id_name):
            raise ValueError("Invalid value for parameter `hba_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")


        if  _port_id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _port_id_name):
            raise ValueError("Invalid value for parameter `port_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")


        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _hba_id is not None:
            if(isinstance(_hba_id, str)):
                _hba_id = SeparateArgs.check_backslash(_hba_id)
                _hba_id = _hba_id.encode("utf-8").decode("unicode-escape")
        if _port_id is not None:
            if(isinstance(_port_id, str)):
                _port_id = SeparateArgs.check_backslash(_port_id)
                _port_id = _port_id.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.AddPathServerParam import AddPathServerParam
        _add_path = AddPathServerParam()
        _add_path.hba_id = _hba_id
        _add_path.port_id = _port_id
        _add_path.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _hba_id_name is not None:
            # hba_listを使ってhba_id_nameに対応するhba_idを取得
            _hba_id = get_uuid_from_hba_list_with_hba_id_name(_hba_id_name, _id=_id)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AddPathServerParam import AddPathServerParam
                _add_path = AddPathServerParam()
            _add_path.hba_id = _hba_id

        if _port_id_name is not None:
            # port_listを使ってport_id_nameに対応するport_idを取得
            _port_id = get_uuid_from_port_list_with_port_id_name(_port_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AddPathServerParam import AddPathServerParam
                _add_path = AddPathServerParam()
            _add_path.port_id = _port_id

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AddPathServerParam import AddPathServerParam
                _add_path = AddPathServerParam()
            _add_path.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_path_create(_id, add_path = _add_path, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--hba_id','_hba_id',metavar='<str>',help='The initiator ID of the compute node. ')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators.')
@click.option('--port_id','_port_id',metavar='<str>',help='The compute port ID of the target operation. ')
@click.option('--port_id_name','_port_id_name',metavar='<str>',help='WWN of the compute port of the target operation for FC connection or the iSCSI name for iSCSI connections.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def path_delete(_id,_id_nickname,_hba_id,_hba_id_name,_port_id,_port_id_name,_vps_id,_vps_id_name,):
    """
    Deletes compute node path information. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_hba_list_with_hba_id_name(hba_id_name, _id):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.hba_list(id=_id, name=hba_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'hba_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_port_list_with_port_id_name(port_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=port_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'port_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "path_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "



        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "



        if _port_id is not None:
            subCommandLogtxt += "--port_id " + str(_port_id) + " "

        if _port_id_name is not None:
            subCommandLogtxt += "--port_id_name " + str(_port_id_name) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--hba_id', _hba_id,'--hba_id_name', _hba_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--port_id', _port_id,'--port_id_name', _port_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _port_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _port_id):
            raise ValueError("Invalid value for `port_id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "path_delete"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_path_delete`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _hba_id_name is not None and not re.search('^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)', _hba_id_name):
            raise ValueError("Invalid value for parameter `hba_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")
#           raise ValueError("Invalid value for parameter `hba_id` when calling `server_path_delete`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")






        if  _port_id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _port_id_name):
            raise ValueError("Invalid value for parameter `port_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `port_id` when calling `server_path_delete`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")










        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeletePathServerParam import DeletePathServerParam
        _delete_path = DeletePathServerParam()
        _delete_path.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _hba_id_name is not None:
            # hba_listを使ってhba_id_nameに対応するhba_idを取得
            _hba_id = get_uuid_from_hba_list_with_hba_id_name(_hba_id_name, _id=_id)

        if _port_id_name is not None:
            # port_listを使ってport_id_nameに対応するport_idを取得
            _port_id = get_uuid_from_port_list_with_port_id_name(_port_id_name)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeletePathServerParam import DeletePathServerParam
                _delete_path = DeletePathServerParam()
            _delete_path.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_path_delete(_id, _hba_id, _port_id, delete_path = _delete_path, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--hba_name','_hba_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators. ')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='Alias of hba_name.')
@click.option('--hba_id','_hba_id',metavar='<str>',help='The initiator ID of the compute node. ')
@click.option('--port_id','_port_id',metavar='<str>',help='The ID of the compute port. ')
@click.option('--port_name','_port_name',metavar='<str>',help='WWN of the compute port for FC connection or the iSCSI name for iSCSI connections. ')
@click.option('--port_id_name','_port_id_name',metavar='<str>',help='Alias of port_name.')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def path_list(_id,_id_nickname,_hba_name,_hba_id_name,_hba_id,_port_id,_port_name,_port_id_name,_vps_id,_vps_id_name,):
    """
    Obtains the path information list of the compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "path_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "




        if _hba_name is not None:
            subCommandLogtxt += "--hba_name " + str(_hba_name) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "



        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "




        if _port_id is not None:
            subCommandLogtxt += "--port_id " + str(_port_id) + " "




        if _port_name is not None:
            subCommandLogtxt += "--port_name " + str(_port_name) + " "

        if _port_id_name is not None:
            subCommandLogtxt += "--port_id_name " + str(_port_id_name) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--hba_name', _hba_name,'--hba_id_name', _hba_id_name, 'false')
        commonutil.view_error()


        
        


        
        #UUIDチェック
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        


        
        #UUIDチェック
        if _port_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _port_id):
            raise ValueError("Invalid value for `port_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--port_name', _port_name,'--port_id_name', _port_id_name, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "path_list"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_path_list`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")


























        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `server_path_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `server_path_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PathList import PathList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if not _hba_id_name is None:
            _hba_name = _hba_id_name

        if not _port_id_name is None:
            _port_name = _port_id_name

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_path_list(_id, hba_name = _hba_name, hba_id = _hba_id, port_id = _port_id, port_name = _port_name, vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--hba_id','_hba_id',metavar='<str>',help='The initiator ID of the compute node. ')
@click.option('--hba_id_name','_hba_id_name',metavar='<str>',help='WWN (for FC connection), iSCSI Name (for iSCSI connection), or host NQN (for NVMe/TCP connection) of compute node initiators.')
@click.option('--port_id','_port_id',metavar='<str>',help='The compute port ID of the target operation. ')
@click.option('--port_id_name','_port_id_name',metavar='<str>',help='WWN of the compute port of the target operation for FC connection or the iSCSI name for iSCSI connections.')
def path_show(_id,_id_nickname,_hba_id,_hba_id_name,_port_id,_port_id_name,):
    """
    Obtains compute node path information. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_hba_list_with_hba_id_name(hba_id_name, _id):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.hba_list(id=_id, name=hba_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'hba_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_port_list_with_port_id_name(port_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_connection_management import ComputeNodeConnectionManagement as ComputeNodeConnectionManagementApi
        api = ComputeNodeConnectionManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.port_list(name=port_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'port_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "path_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "



        if _hba_id is not None:
            subCommandLogtxt += "--hba_id " + str(_hba_id) + " "

        if _hba_id_name is not None:
            subCommandLogtxt += "--hba_id_name " + str(_hba_id_name) + " "



        if _port_id is not None:
            subCommandLogtxt += "--port_id " + str(_port_id) + " "

        if _port_id_name is not None:
            subCommandLogtxt += "--port_id_name " + str(_port_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--hba_id', _hba_id,'--hba_id_name', _hba_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _hba_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _hba_id):
            raise ValueError("Invalid value for `hba_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--port_id', _port_id,'--port_id_name', _port_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _port_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _port_id):
            raise ValueError("Invalid value for `port_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "path_show"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_path_show`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _hba_id_name is not None and not re.search('^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)', _hba_id_name):
            raise ValueError("Invalid value for parameter `hba_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")
#           raise ValueError("Invalid value for parameter `hba_id` when calling `server_path_show`, must conform to the pattern `^[a-f0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$|(^nqn\.2014-08\.org\.nvmexpress:uuid:[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$|^(?!nqn\.2014-08\.org\.nvmexpress:uuid:)nqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211}$)`")






        if  _port_id_name is not None and not re.search('^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$', _port_id_name):
            raise ValueError("Invalid value for parameter `port_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")
#           raise ValueError("Invalid value for parameter `port_id` when calling `server_path_show`, must conform to the pattern `^[a-f0-9]{16}$|^[A-F0-9]{16}$|^((iqn\.[0-9]{4}\-[0-9]{2}\.[a-zA-Z0-9\-:\.]{0,211})|(eui\.[0-9a-fA-F]{16}))$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Path import Path

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)

        if _hba_id_name is not None:
            # hba_listを使ってhba_id_nameに対応するhba_idを取得
            _hba_id = get_uuid_from_hba_list_with_hba_id_name(_hba_id_name, _id=_id)

        if _port_id_name is not None:
            # port_listを使ってport_id_nameに対応するport_idを取得
            _port_id = get_uuid_from_port_list_with_port_id_name(_port_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_path_show(_id, _hba_id, _port_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--id_nickname','_id_nickname',metavar='<str>',help='The nickname of the compute node.')
def server_show(_id,_id_nickname,):
    """
    Obtains the information of the compute node. 
    """
    def get_uuid_from_server_list_with_id_nickname(id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "server_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_nickname is not None:
            subCommandLogtxt += "--id_nickname " + str(_id_nickname) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_nickname', _id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "server_show"





        if  _id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _id_nickname):
            raise ValueError("Invalid value for parameter `id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `id` when calling `server_show`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Server import Server

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_nickname is not None:
            # server_listを使ってid_nicknameに対応するidを取得
            _id = get_uuid_from_server_list_with_id_nickname(_id_nickname)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.server_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--volume_id','_volume_id',type=str,metavar='<str>',help='Volume ID to be allocated')
@click.option('--server_id','_server_id',type=str,metavar='<str>',help='The ID of the allocation destination compute node.')
@click.option('--lun','_lun',type=int,metavar='<int>',help='LUN. If omitted, the smallest unused number is assigned automatically. This option is available when either volume_id or volume_id_name and either server_id or server_id_nickname are specified.')
@click.option('--start_lun','_start_lun',type=int,metavar='<int>',help='The start number of LUN to be allocated. Allocates an unused LUN whose number is equal to or larger than the specified number. This option is available when either volume_ids or volume_id_names and either server_ids or server_id_nicknames are specified.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--volume_id_name','_volume_id_name',metavar='<str>',help='The name of the volume to be allocated.')
@click.option('--volume_ids','_volume_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of volume IDs to be allocated.')
@click.option('--volume_id_names','_volume_id_names',metavar='<str>',help='List of the names of volumes to be allocated.')
@click.option('--server_id_nickname','_server_id_nickname',metavar='<str>',help='The nickname of the allocation destination compute node.')
@click.option('--server_ids','_server_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of compute node IDs to which volumes are allocated.')
@click.option('--server_id_nicknames','_server_id_nicknames',metavar='<str>',help='List of compute node nicknames to which volumes are allocated.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_server_connection_create(_volume_id,_volume_id_name,_volume_ids,_volume_id_names,_server_id,_server_id_nickname,_server_ids,_server_id_nicknames,_lun,_start_lun,_vps_id,_vps_id_name,):
    """
    Connects a volume to a compute node. 
    """
    def get_uuid_from_volume_list_with_volume_id_name(volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_volume_list_with_volume_id_names(volume_id_names):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            volume_id_names_list = uuidutil.escapeArrayValue(volume_id_names)
            volume_id_names_list = uuidutil.delete_duplication_array_value(volume_id_names_list)

            uuid_list = []
            # volume_id_namesがvolume_listのnamesに指定できる数(32)を超えていた場合
            while len(volume_id_names_list) > 32:
                tmp_volume_id_names_list = volume_id_names_list[:32]
                tmp_volume_id_names_list_str = uuidutil.arrayToString(tmp_volume_id_names_list)
                del volume_id_names_list[:32]

                response = api.volume_list(names=tmp_volume_id_names_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, tmp_volume_id_names_list,'volume_id_names','name','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            else:
                volume_id_names_list_str = uuidutil.arrayToString(volume_id_names_list)
                response = api.volume_list(names=volume_id_names_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, volume_id_names_list,'volume_id_names','name','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_id_nickname(server_id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=server_id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'server_id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_id_nicknames(server_id_nicknames):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            server_id_nicknames_list = uuidutil.escapeArrayValue(server_id_nicknames)
            server_id_nicknames_list = uuidutil.delete_duplication_array_value(server_id_nicknames_list)

            uuid_list = []
            # server_id_nicknamesがserver_listのnicknamesに指定できる数(32)を超えていた場合
            while len(server_id_nicknames_list) > 32:
                tmp_server_id_nicknames_list = server_id_nicknames_list[:32]
                tmp_server_id_nicknames_list_str = uuidutil.arrayToString(tmp_server_id_nicknames_list)
                del server_id_nicknames_list[:32]

                response = api.server_list(nicknames=tmp_server_id_nicknames_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, tmp_server_id_nicknames_list,'server_id_nicknames','nickname','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            else:
                server_id_nicknames_list_str = uuidutil.arrayToString(server_id_nicknames_list)
                response = api.server_list(nicknames=server_id_nicknames_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, server_id_nicknames_list,'server_id_nicknames','nickname','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_server_connection_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _volume_id is not None:
            subCommandLogtxt += "--volume_id " + str(_volume_id) + " "

        if _volume_id_name is not None:
            subCommandLogtxt += "--volume_id_name " + str(_volume_id_name) + " "



        if _volume_ids is not None:
            subCommandLogtxt += "--volume_ids " + str(_volume_ids) + " "

        if _volume_id_names is not None:
            subCommandLogtxt += "--volume_id_names " + str(_volume_id_names) + " "



        if _server_id is not None:
            subCommandLogtxt += "--server_id " + str(_server_id) + " "

        if _server_id_nickname is not None:
            subCommandLogtxt += "--server_id_nickname " + str(_server_id_nickname) + " "



        if _server_ids is not None:
            subCommandLogtxt += "--server_ids " + str(_server_ids) + " "

        if _server_id_nicknames is not None:
            subCommandLogtxt += "--server_id_nicknames " + str(_server_id_nicknames) + " "



        if _lun is not None:
            subCommandLogtxt += "--lun " + str(_lun) + " "




        if _start_lun is not None:
            subCommandLogtxt += "--start_lun " + str(_start_lun) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--volume_id', _volume_id,'--volume_id_name', _volume_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--volume_ids', _volume_ids,'--volume_id_names', _volume_id_names, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--server_id', _server_id,'--server_id_nickname', _server_id_nickname, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--server_ids', _server_ids,'--server_id_nicknames', _server_id_nicknames, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        if _volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _volume_id):
            raise ValueError("Invalid value for `volume_id`, the format of UUID is invalid.")
        if _server_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _server_id):
            raise ValueError("Invalid value for `server_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_server_connection_create"





        if  _volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _volume_id_name):
            raise ValueError("Invalid value for parameter `volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")




        if  _server_id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _server_id_nickname):
            raise ValueError("Invalid value for parameter `server_id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")















        if (_volume_id_names is not None):
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('volume_id_names',
                                                            _volume_id_names,
                                                            '^[\-A-Za-z0-9,\.:@_]{1,32}$',
                                                            '^[\\-A-Za-z0-9,\\.:@_]{1,32}$',
                                                            1000,
                                                            32)
        if (_server_id_nicknames is not None):
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('server_id_nicknames',
                                                            _server_id_nicknames,
                                                            '^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$',
                                                            '^[a-zA-Z0-9,\\.:@_]([a-zA-Z0-9,\\.:@_\\-]{0,228})$',
                                                            100,
                                                            229)

        if _volume_id is not None:
            if(isinstance(_volume_id, str)):
                _volume_id = SeparateArgs.check_backslash(_volume_id)
                _volume_id = _volume_id.encode("utf-8").decode("unicode-escape")
        if _volume_ids is not None:
            if(isinstance(_volume_ids, str)):
                _volume_ids = SeparateArgs.check_backslash(_volume_ids)
                _volume_ids = _volume_ids.encode("utf-8").decode("unicode-escape")
        if _server_id is not None:
            if(isinstance(_server_id, str)):
                _server_id = SeparateArgs.check_backslash(_server_id)
                _server_id = _server_id.encode("utf-8").decode("unicode-escape")
        if _server_ids is not None:
            if(isinstance(_server_ids, str)):
                _server_ids = SeparateArgs.check_backslash(_server_ids)
                _server_ids = _server_ids.encode("utf-8").decode("unicode-escape")
        if _lun is not None:
            if(isinstance(_lun, str)):
                _lun = SeparateArgs.check_backslash(_lun)
                _lun = _lun.encode("utf-8").decode("unicode-escape")
        if _start_lun is not None:
            if(isinstance(_start_lun, str)):
                _start_lun = SeparateArgs.check_backslash(_start_lun)
                _start_lun = _start_lun.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.AssignToServerVolumeParam import AssignToServerVolumeParam
        _add_volume_path = AssignToServerVolumeParam()
        _add_volume_path.volume_id = _volume_id
        _add_volume_path.volume_ids = _volume_ids
        _add_volume_path.server_id = _server_id
        _add_volume_path.server_ids = _server_ids
        _add_volume_path.lun = _lun
        _add_volume_path.start_lun = _start_lun
        _add_volume_path.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _volume_id_name is not None:
            # volume_listを使ってvolume_id_nameに対応するvolume_idを取得
            _volume_id = get_uuid_from_volume_list_with_volume_id_name(_volume_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_volume_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AssignToServerVolumeParam import AssignToServerVolumeParam
                _add_volume_path = AssignToServerVolumeParam()
            _add_volume_path.volume_id = _volume_id

        if _volume_id_names is not None:
            # volume_listを使ってvolume_id_namesに対応するvolume_idsを取得
            _volume_ids = get_uuid_from_volume_list_with_volume_id_names(_volume_id_names)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_volume_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AssignToServerVolumeParam import AssignToServerVolumeParam
                _add_volume_path = AssignToServerVolumeParam()
            _add_volume_path.volume_ids = _volume_ids

        if _server_id_nickname is not None:
            # server_listを使ってserver_id_nicknameに対応するserver_idを取得
            _server_id = get_uuid_from_server_list_with_server_id_nickname(_server_id_nickname)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_volume_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AssignToServerVolumeParam import AssignToServerVolumeParam
                _add_volume_path = AssignToServerVolumeParam()
            _add_volume_path.server_id = _server_id

        if _server_id_nicknames is not None:
            # server_listを使ってserver_id_nicknamesに対応するserver_idsを取得
            _server_ids = get_uuid_from_server_list_with_server_id_nicknames(_server_id_nicknames)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_volume_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AssignToServerVolumeParam import AssignToServerVolumeParam
                _add_volume_path = AssignToServerVolumeParam()
            _add_volume_path.server_ids = _server_ids

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _add_volume_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.AssignToServerVolumeParam import AssignToServerVolumeParam
                _add_volume_path = AssignToServerVolumeParam()
            _add_volume_path.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_server_connection_create(add_volume_path = _add_volume_path, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--volume_id','_volume_id',metavar='<str>',help='Volume ID ')
@click.option('--volume_id_name','_volume_id_name',metavar='<str>',help='The volume name.')
@click.option('--server_id','_server_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--server_id_nickname','_server_id_nickname',metavar='<str>',help='The nickname of the compute node.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_server_connection_delete(_volume_id,_volume_id_name,_server_id,_server_id_nickname,_vps_id,_vps_id_name,):
    """
    Releases the connection between the volume and the compute node. 
    """
    def get_uuid_from_volume_list_with_volume_id_name(volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_id_nickname(server_id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=server_id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'server_id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_server_connection_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _volume_id is not None:
            subCommandLogtxt += "--volume_id " + str(_volume_id) + " "

        if _volume_id_name is not None:
            subCommandLogtxt += "--volume_id_name " + str(_volume_id_name) + " "



        if _server_id is not None:
            subCommandLogtxt += "--server_id " + str(_server_id) + " "

        if _server_id_nickname is not None:
            subCommandLogtxt += "--server_id_nickname " + str(_server_id_nickname) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--volume_id', _volume_id,'--volume_id_name', _volume_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _volume_id):
            raise ValueError("Invalid value for `volume_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--server_id', _server_id,'--server_id_nickname', _server_id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _server_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _server_id):
            raise ValueError("Invalid value for `server_id`, the format of UUID is invalid.")
        
        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "volume_server_connection_delete"





        if  _volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _volume_id_name):
            raise ValueError("Invalid value for parameter `volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `volume_id` when calling `volume_server_connection_delete`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






        if  _server_id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _server_id_nickname):
            raise ValueError("Invalid value for parameter `server_id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `server_id` when calling `volume_server_connection_delete`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")






        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")










        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ReleaseFromSingleServerSingleVolumeParam import ReleaseFromSingleServerSingleVolumeParam
        _release_volume_path = ReleaseFromSingleServerSingleVolumeParam()
        _release_volume_path.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _volume_id_name is not None:
            # volume_listを使ってvolume_id_nameに対応するvolume_idを取得
            _volume_id = get_uuid_from_volume_list_with_volume_id_name(_volume_id_name)

        if _server_id_nickname is not None:
            # server_listを使ってserver_id_nicknameに対応するserver_idを取得
            _server_id = get_uuid_from_server_list_with_server_id_nickname(_server_id_nickname)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _release_volume_path is None:
                from com.hitachi.sophia.rest_client.autogen.models.ReleaseFromSingleServerSingleVolumeParam import ReleaseFromSingleServerSingleVolumeParam
                _release_volume_path = ReleaseFromSingleServerSingleVolumeParam()
            _release_volume_path.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_server_connection_delete(_volume_id, _server_id, release_volume_path = _release_volume_path, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--volume_id','_volume_id',metavar='<str>',help='Volume ID. ')
@click.option('--volume_name','_volume_name',metavar='<str>',help='The volume name (exact match).')
@click.option('--volume_id_name','_volume_id_name',metavar='<str>',help='Alias of volume_name.')
@click.option('--server_id','_server_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--server_nickname','_server_nickname',metavar='<str>',help='The nickname of the compute node (exact match).')
@click.option('--server_id_nickname','_server_id_nickname',metavar='<str>',help='Alias of server_nickname.')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def volume_server_connection_list(_volume_id,_volume_name,_volume_id_name,_server_id,_server_nickname,_server_id_nickname,_vps_id,_vps_id_name,):
    """
    Obtains the list of connection information between volumes and compute nodes. 
    """
    def get_uuid_from_volume_list_with_volume_name(volume_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=volume_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'volume_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_volume_list_with_volume_id_name(volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_nickname(server_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=server_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'server_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_id_nickname(server_id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=server_id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'server_id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_server_connection_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _volume_id is not None:
            subCommandLogtxt += "--volume_id " + str(_volume_id) + " "

        if _volume_name is not None:
            subCommandLogtxt += "--volume_name " + str(_volume_name) + " "
        if _volume_id_name is not None:
            subCommandLogtxt += "--volume_id_name " + str(_volume_id_name) + " "



        if _server_id is not None:
            subCommandLogtxt += "--server_id " + str(_server_id) + " "

        if _server_nickname is not None:
            subCommandLogtxt += "--server_nickname " + str(_server_nickname) + " "
        if _server_id_nickname is not None:
            subCommandLogtxt += "--server_id_nickname " + str(_server_id_nickname) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        
        param_validator_util = ParamValidatorUtil()
        ordered_dict_options = collections.OrderedDict()
        ordered_dict_options['volume_id'] = _volume_id
        ordered_dict_options['volume_name'] = _volume_name
        ordered_dict_options['volume_id_name'] = _volume_id_name
        param_validator_util.check_multi_parameter_combinations(ordered_dict_options, 'false')
        commonutil.view_error()


        
        #UUIDチェック
        if _volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _volume_id):
            raise ValueError("Invalid value for `volume_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        ordered_dict_options = collections.OrderedDict()
        ordered_dict_options['server_id'] = _server_id
        ordered_dict_options['server_nickname'] = _server_nickname
        ordered_dict_options['server_id_nickname'] = _server_id_nickname
        param_validator_util.check_multi_parameter_combinations(ordered_dict_options, 'false')
        commonutil.view_error()


        
        #UUIDチェック
        if _server_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _server_id):
            raise ValueError("Invalid value for `server_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "volume_server_connection_list"





        if  _volume_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _volume_name):
            raise ValueError("Invalid value for parameter `volume_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `volume_id` when calling `volume_server_connection_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
        if  _volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _volume_id_name):
            raise ValueError("Invalid value for parameter `volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `volume_id` when calling `volume_server_connection_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






        if  _server_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _server_nickname):
            raise ValueError("Invalid value for parameter `server_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `server_id` when calling `volume_server_connection_list`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
        if  _server_id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _server_id_nickname):
            raise ValueError("Invalid value for parameter `server_id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `server_id` when calling `volume_server_connection_list`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")


        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_server_connection_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `volume_server_connection_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumePathList import VolumePathList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _volume_name is not None:
            # volume_listを使ってvolume_nameに対応するvolume_idを取得
            _volume_id = get_uuid_from_volume_list_with_volume_name(_volume_name)

        if _volume_id_name is not None:
            # volume_listを使ってvolume_id_nameに対応するvolume_idを取得
            _volume_id = get_uuid_from_volume_list_with_volume_id_name(_volume_id_name)

        if _server_nickname is not None:
            # server_listを使ってserver_nicknameに対応するserver_idを取得
            _server_id = get_uuid_from_server_list_with_server_nickname(_server_nickname)

        if _server_id_nickname is not None:
            # server_listを使ってserver_id_nicknameに対応するserver_idを取得
            _server_id = get_uuid_from_server_list_with_server_id_nickname(_server_id_nickname)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_server_connection_list(volume_id = _volume_id, server_id = _server_id, vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--volume_ids','_volume_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of volume IDs to be deallocated.')
@click.option('--volume_id_names','_volume_id_names',metavar='<str>',help='List of the volume names to be deallocated.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
@click.option('--server_ids','_server_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='List of compute node IDs whose volume is to be deallocated.')
@click.option('--server_id_nicknames','_server_id_nicknames',metavar='<str>',help='List of compute node nicknames whose volumes are to be deallocated.')
def volume_server_connection_release_connections(_volume_ids,_volume_id_names,_vps_id,_vps_id_name,_server_ids,_server_id_nicknames,):
    """
    Releases multiple connections between the volumes and compute nodes. 
    """
    def get_uuid_from_volume_list_with_volume_id_names(volume_id_names):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            volume_id_names_list = uuidutil.escapeArrayValue(volume_id_names)
            volume_id_names_list = uuidutil.delete_duplication_array_value(volume_id_names_list)

            uuid_list = []
            # volume_id_namesがvolume_listのnamesに指定できる数(32)を超えていた場合
            while len(volume_id_names_list) > 32:
                tmp_volume_id_names_list = volume_id_names_list[:32]
                tmp_volume_id_names_list_str = uuidutil.arrayToString(tmp_volume_id_names_list)
                del volume_id_names_list[:32]

                response = api.volume_list(names=tmp_volume_id_names_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, tmp_volume_id_names_list,'volume_id_names','name','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            else:
                volume_id_names_list_str = uuidutil.arrayToString(volume_id_names_list)
                response = api.volume_list(names=volume_id_names_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, volume_id_names_list,'volume_id_names','name','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_id_nicknames(server_id_nicknames):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            server_id_nicknames_list = uuidutil.escapeArrayValue(server_id_nicknames)
            server_id_nicknames_list = uuidutil.delete_duplication_array_value(server_id_nicknames_list)

            uuid_list = []
            # server_id_nicknamesがserver_listのnicknamesに指定できる数(32)を超えていた場合
            while len(server_id_nicknames_list) > 32:
                tmp_server_id_nicknames_list = server_id_nicknames_list[:32]
                tmp_server_id_nicknames_list_str = uuidutil.arrayToString(tmp_server_id_nicknames_list)
                del server_id_nicknames_list[:32]

                response = api.server_list(nicknames=tmp_server_id_nicknames_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, tmp_server_id_nicknames_list,'server_id_nicknames','nickname','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            else:
                server_id_nicknames_list_str = uuidutil.arrayToString(server_id_nicknames_list)
                response = api.server_list(nicknames=server_id_nicknames_list_str)
                uuidutil.determin_status_doce_of_list_reference(response)

                tmp_uuid_list = uuidutil.getUuidFromResponseForArray(response, server_id_nicknames_list,'server_id_nicknames','nickname','id')
                uuid_list.extend(uuidutil.escapeArrayValue(tmp_uuid_list))

            return uuid_list

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_server_connection_release_connections"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _volume_ids is not None:
            subCommandLogtxt += "--volume_ids " + str(_volume_ids) + " "

        if _volume_id_names is not None:
            subCommandLogtxt += "--volume_id_names " + str(_volume_id_names) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "



        if _server_ids is not None:
            subCommandLogtxt += "--server_ids " + str(_server_ids) + " "

        if _server_id_nicknames is not None:
            subCommandLogtxt += "--server_id_nicknames " + str(_server_id_nicknames) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--volume_ids', _volume_ids,'--volume_id_names', _volume_id_names, 'true')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--server_ids', _server_ids,'--server_id_nicknames', _server_id_nicknames, 'true')
        commonutil.view_error()


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_server_connection_release_connections"







        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")

















        if (_volume_id_names is not None):
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('volume_id_names',
                                                            _volume_id_names,
                                                            '^[\-A-Za-z0-9,\.:@_]{1,32}$',
                                                            '^[\\-A-Za-z0-9,\\.:@_]{1,32}$',
                                                            1000,
                                                            32)
        if (_server_id_nicknames is not None):
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('server_id_nicknames',
                                                            _server_id_nicknames,
                                                            '^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$',
                                                            '^[a-zA-Z0-9,\\.:@_]([a-zA-Z0-9,\\.:@_\\-]{0,228})$',
                                                            100,
                                                            229)

        if _volume_ids is not None:
            if(isinstance(_volume_ids, str)):
                _volume_ids = SeparateArgs.check_backslash(_volume_ids)
                _volume_ids = _volume_ids.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")
        if _server_ids is not None:
            if(isinstance(_server_ids, str)):
                _server_ids = SeparateArgs.check_backslash(_server_ids)
                _server_ids = _server_ids.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ReleaseFromServerVolumeParam import ReleaseFromServerVolumeParam
        _release_from_server_volume_param = ReleaseFromServerVolumeParam()
        _release_from_server_volume_param.volume_ids = _volume_ids
        _release_from_server_volume_param.vps_id = _vps_id
        _release_from_server_volume_param.server_ids = _server_ids

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _volume_id_names is not None:
            # volume_listを使ってvolume_id_namesに対応するvolume_idsを取得
            _volume_ids = get_uuid_from_volume_list_with_volume_id_names(_volume_id_names)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _release_from_server_volume_param is None:
                from com.hitachi.sophia.rest_client.autogen.models.ReleaseFromServerVolumeParam import ReleaseFromServerVolumeParam
                _release_from_server_volume_param = ReleaseFromServerVolumeParam()
            _release_from_server_volume_param.volume_ids = _volume_ids

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _release_from_server_volume_param is None:
                from com.hitachi.sophia.rest_client.autogen.models.ReleaseFromServerVolumeParam import ReleaseFromServerVolumeParam
                _release_from_server_volume_param = ReleaseFromServerVolumeParam()
            _release_from_server_volume_param.vps_id = _vps_id

        if _server_id_nicknames is not None:
            # server_listを使ってserver_id_nicknamesに対応するserver_idsを取得
            _server_ids = get_uuid_from_server_list_with_server_id_nicknames(_server_id_nicknames)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _release_from_server_volume_param is None:
                from com.hitachi.sophia.rest_client.autogen.models.ReleaseFromServerVolumeParam import ReleaseFromServerVolumeParam
                _release_from_server_volume_param = ReleaseFromServerVolumeParam()
            _release_from_server_volume_param.server_ids = _server_ids


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_server_connection_release_connections(release_from_server_volume_param = _release_from_server_volume_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--volume_id','_volume_id',metavar='<str>',help='Volume ID ')
@click.option('--volume_id_name','_volume_id_name',metavar='<str>',help='The volume name.')
@click.option('--server_id','_server_id',metavar='<str>',help='The ID of the compute node. ')
@click.option('--server_id_nickname','_server_id_nickname',metavar='<str>',help='The nickname of the compute node.')
def volume_server_connection_show(_volume_id,_volume_id_name,_server_id,_server_id_nickname,):
    """
    Obtains the connection information between the volume and the compute node. 
    """
    def get_uuid_from_volume_list_with_volume_id_name(volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_server_list_with_server_id_nickname(server_id_nickname):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.server_list(nickname=server_id_nickname)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'server_id_nickname', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_server_connection_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _volume_id is not None:
            subCommandLogtxt += "--volume_id " + str(_volume_id) + " "

        if _volume_id_name is not None:
            subCommandLogtxt += "--volume_id_name " + str(_volume_id_name) + " "



        if _server_id is not None:
            subCommandLogtxt += "--server_id " + str(_server_id) + " "

        if _server_id_nickname is not None:
            subCommandLogtxt += "--server_id_nickname " + str(_server_id_nickname) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.compute_node_management import ComputeNodeManagement as ComputeNodeManagementApi
        api = ComputeNodeManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--volume_id', _volume_id,'--volume_id_name', _volume_id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _volume_id):
            raise ValueError("Invalid value for `volume_id`, the format of UUID is invalid.")
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--server_id', _server_id,'--server_id_nickname', _server_id_nickname, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _server_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _server_id):
            raise ValueError("Invalid value for `server_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "volume_server_connection_show"





        if  _volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _volume_id_name):
            raise ValueError("Invalid value for parameter `volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `volume_id` when calling `volume_server_connection_show`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")






        if  _server_id_nickname is not None and not re.search('^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$', _server_id_nickname):
            raise ValueError("Invalid value for parameter `server_id_nickname` when calling `" + cliSubCommand + "`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")
#           raise ValueError("Invalid value for parameter `server_id` when calling `volume_server_connection_show`, must conform to the pattern `^[a-zA-Z0-9,\.:@_]([a-zA-Z0-9,\.:@_\-]{0,228})$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.VolumePath import VolumePath

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _volume_id_name is not None:
            # volume_listを使ってvolume_id_nameに対応するvolume_idを取得
            _volume_id = get_uuid_from_volume_list_with_volume_id_name(_volume_id_name)

        if _server_id_nickname is not None:
            # server_listを使ってserver_id_nicknameに対応するserver_idを取得
            _server_id = get_uuid_from_server_list_with_server_id_nickname(_server_id_nickname)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.volume_server_connection_show(_volume_id, _server_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['hba_create'] = hba_create
    commands['hba_delete'] = hba_delete
    commands['hba_list'] = hba_list
    commands['hba_show'] = hba_show
    commands['server_create'] = server_create
    commands['server_delete'] = server_delete
    commands['server_set'] = server_set
    commands['server_list'] = server_list
    commands['path_create'] = path_create
    commands['path_delete'] = path_delete
    commands['path_list'] = path_list
    commands['path_show'] = path_show
    commands['server_show'] = server_show
    commands['volume_server_connection_create'] = volume_server_connection_create
    commands['volume_server_connection_delete'] = volume_server_connection_delete
    commands['volume_server_connection_list'] = volume_server_connection_list
    commands['volume_server_connection_release_connections'] = volume_server_connection_release_connections
    commands['volume_server_connection_show'] = volume_server_connection_show
    return commands

