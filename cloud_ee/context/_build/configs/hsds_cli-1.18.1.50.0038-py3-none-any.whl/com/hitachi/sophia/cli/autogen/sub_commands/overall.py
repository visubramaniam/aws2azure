# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--start_created_time','_start_created_time',metavar='<datetime>',help='The start date and time, including the specified time, of job submission. ')
@click.option('--end_created_time','_end_created_time',metavar='<datetime>',help='The end date and time, excluding the specified time, of job submission. ')
@click.option('--count','_count',type=int,metavar='<int>',help='The number of job records to be obtained. ')
@click.option('--status','_status',metavar='<str>',help='The progress of the job. ')
@click.option('--state','_state',metavar='<str>',help='The job status. ')
@click.option('--user_id','_user_id',metavar='<str>',help='User ID. ')
@click.option('--ids','_ids',metavar='<str>',help='The Job ID. You can specify a maximum of 32 IDs separated by a comma (,).  Example: --ids <id1>,<id2>,<id3>...  HTTP status code 400 (Bad Request) is returned if more than 32 IDs are specified. ')
def job_list(_start_created_time,_end_created_time,_count,_status,_state,_user_id,_ids,):
    """
    Obtains a list of jobs. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "job_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _start_created_time is not None:
            subCommandLogtxt += "--start_created_time " + str(_start_created_time) + " "




        if _end_created_time is not None:
            subCommandLogtxt += "--end_created_time " + str(_end_created_time) + " "




        if _count is not None:
            subCommandLogtxt += "--count " + str(_count) + " "




        if _status is not None:
            subCommandLogtxt += "--status " + str(_status) + " "




        if _state is not None:
            subCommandLogtxt += "--state " + str(_state) + " "




        if _user_id is not None:
            subCommandLogtxt += "--user_id " + str(_user_id) + " "




        if _ids is not None:
            subCommandLogtxt += "--ids " + str(_ids) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.overall import Overall as OverallApi
        api = OverallApi(ApiClient())

        


        
        


        
        


        
        


        #Enumチェック
        allowed_values = ["Initializing", "Running", "Completed"]

        if _status is not None:
            if _status not in allowed_values:
                raise ValueError(
                    "Invalid value for `status` ({0}), (Select only one) {1}"
                    .format(_status, allowed_values)
            )
        
        


        #Enumチェック
        allowed_values = ["Queued", "Started", "Stopping", "Succeeded", "Failed", "Stopped", "Unknown"]

        if _state is not None:
            if _state not in allowed_values:
                raise ValueError(
                    "Invalid value for `state` ({0}), (Select only one) {1}"
                    .format(_state, allowed_values)
            )
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "job_list"













        if _count is not None and _count > 100:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value less than or equal to `100`")
#           raise ValueError("Invalid value for parameter `count` when calling `job_list`, must be a value less than or equal to `100`")
        if _count is not None and _count < 1:
            raise ValueError("Invalid value for parameter `count` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `count` when calling `job_list`, must be a value greater than or equal to `1`")


















        if _user_id is not None and len(_user_id) > 255:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be less than or equal to `255`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `job_list`, length must be less than or equal to `255`")
        if _user_id is not None and len(_user_id) < 3:
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, length must be greater than or equal to `3`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `job_list`, length must be greater than or equal to `3`")
        if  _user_id is not None and not re.search('^all$|^self$|^[\\-A-Za-z0-9!#\\$%&\'\\.@\\^_`\\{\\}~]{5,255}$', _user_id):
            raise ValueError("Invalid value for parameter `user_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^all$|^self$|^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")
#           raise ValueError("Invalid value for parameter `user_id` when calling `job_list`, must conform to the pattern `/^all$|^self$|^[\\-A-Za-z0-9!#\\$%&'\\.@\\^_`\\{\\}~]{5,255}$/`")























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.JobList import JobList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.job_list(start_created_time = _start_created_time, end_created_time = _end_created_time, count = _count, status = _status, state = _state, user_id = _user_id, ids = _ids, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--job_id','_job_id',metavar='<str>',help='Job ID ',required=True)
def job_show(_job_id,):
    """
    Obtains the job. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "job_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _job_id is not None:
            subCommandLogtxt += "--job_id " + str(_job_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.overall import Overall as OverallApi
        api = OverallApi(ApiClient())



        
        #UUIDチェック
        if _job_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _job_id):
            raise ValueError("Invalid value for `job_id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "job_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.job_show(_job_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def version_show():
    """
    Obtains API version information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('','','')
        auth_parameter_util.check_auth_parameter('','','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "version_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.overall import Overall as OverallApi
        api = OverallApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "version_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Version import Version

    
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.version_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['job_list'] = job_list
    commands['job_show'] = job_show
    commands['version_show'] = version_show
    return commands

