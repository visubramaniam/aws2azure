# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Drive ID ',required=True)
@click.option('--operation_type','_operation_type',type=str,metavar='<str>',help='Specifies operation for the locator LED.',required=True)
def drive_control_locator_led(_id,_operation_type,):
    """
    Controls on and off of the locator LED of a drive. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_control_locator_led"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _operation_type is not None:
            subCommandLogtxt += "--operation_type " + str(_operation_type) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_device_management import StorageDeviceManagement as StorageDeviceManagementApi
        api = StorageDeviceManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "drive_control_locator_led"

























        if _operation_type is not None:
            if(isinstance(_operation_type, str)):
                _operation_type = SeparateArgs.check_backslash(_operation_type)
                _operation_type = _operation_type.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DriveLocatorLedParam import DriveLocatorLedParam
        _drive_locator_led_param = DriveLocatorLedParam()
        _drive_locator_led_param.operation_type = _operation_type

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.drive_control_locator_led(_id, drive_locator_led_param = _drive_locator_led_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--status_summary','_status_summary',metavar='<str>',help='Drive status summary ')
@click.option('--status','_status',metavar='<str>',help='Drive status ')
@click.option('--storage_node_id','_storage_node_id',metavar='<str>',help='Storage node ID. ')
@click.option('--locator_led_status','_locator_led_status',metavar='<str>',help='On/off state of the locator LED. ')
def drive_list(_status_summary,_status,_storage_node_id,_locator_led_status,):
    """
    Obtains a list of drive information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _status_summary is not None:
            subCommandLogtxt += "--status_summary " + str(_status_summary) + " "




        if _status is not None:
            subCommandLogtxt += "--status " + str(_status) + " "




        if _storage_node_id is not None:
            subCommandLogtxt += "--storage_node_id " + str(_storage_node_id) + " "




        if _locator_led_status is not None:
            subCommandLogtxt += "--locator_led_status " + str(_locator_led_status) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_device_management import StorageDeviceManagement as StorageDeviceManagementApi
        api = StorageDeviceManagementApi(ApiClient())

        


        #Enumチェック
        allowed_values = ["Normal", "Warning", "Error"]

        if _status_summary is not None:
            if _status_summary not in allowed_values:
                raise ValueError(
                    "Invalid value for `status_summary` ({0}), (Select only one) {1}"
                    .format(_status_summary, allowed_values)
            )
        
        


        #Enumチェック
        allowed_values = ["Offline", "Normal", "TemporaryBlockage", "Blockage"]

        # 内部処理用のフラグが有効の場合privateEnumの指定を有効にする
        allowed_values_message = allowed_values
        config = Configuration()
        if config.private_enum_enable == True:
            allowed_values = ["Offline","Normal","TemporaryBlockage","Blockage","Warning","Critical","Recovered"]

        if _status is not None:
            if _status not in allowed_values:
                raise ValueError(
                    "Invalid value for `status` ({0}), (Select only one) {1}"
                    .format(_status, allowed_values_message)
            )
        
        


        
        #UUIDチェック
        if _storage_node_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_node_id):
            raise ValueError("Invalid value for `storage_node_id`, the format of UUID is invalid.")
        


        #Enumチェック
        allowed_values = ["Off", "On"]

        if _locator_led_status is not None:
            if _locator_led_status not in allowed_values:
                raise ValueError(
                    "Invalid value for `locator_led_status` ({0}), (Select only one) {1}"
                    .format(_locator_led_status, allowed_values)
            )
        
        


        
        
        
        
        
        #cliSubCommand = "drive_list"




































                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.DriveList import DriveList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.drive_list(status_summary = _status_summary, status = _status, storage_node_id = _storage_node_id, locator_led_status = _locator_led_status, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Drive ID ',required=True)
def drive_show(_id,):
    """
    Obtains drive information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_device_management import StorageDeviceManagement as StorageDeviceManagementApi
        api = StorageDeviceManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "drive_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Drive import Drive

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.drive_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Drive ID ',required=True)
def drive_remove(_id,):
    """
    Removes a drive. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "drive_remove"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_device_management import StorageDeviceManagement as StorageDeviceManagementApi
        api = StorageDeviceManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "drive_remove"
























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_device_remove(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['drive_control_locator_led'] = drive_control_locator_led
    commands['drive_list'] = drive_list
    commands['drive_show'] = drive_show
    commands['drive_remove'] = drive_remove
    return commands

