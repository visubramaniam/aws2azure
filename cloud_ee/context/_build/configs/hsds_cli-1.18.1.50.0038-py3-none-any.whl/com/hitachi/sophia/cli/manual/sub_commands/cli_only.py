# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import logging as loggingLib
import os
import traceback

from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration

# 自動生成対象外コード

logger = loggingLib.getLogger(__name__)


@click.command(options_metavar='<options>')
@click.option('--configuration_backup_file', '_configuration_backup_file', type=str, metavar='<str>', required=True,
              help='Specifies the configuration backup file to be used for restoration.')
@click.option('--is_version_verification_enabled', '_is_version_verification_enabled', metavar='<bool>',
              help='Enables or disables the validation of the configuration backup file version. '
                   + 'Set this parameter only when instructed to do so by customer support.')
def storage_restore_from_configuration_backup_file(_configuration_backup_file, _is_version_verification_enabled):
    """
    Restores the storage cluster configuration information from the configuration backup file.\n
    Run this subcommand only when instructed to do so by customer support.
    """

    try:
        import requests
        import urllib3
        import certifi

        config = Configuration()
        common_util = CommonUtil()

        common_util.view_error()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('', '', 'true')
        auth_parameter_util.check_auth_parameter('', '', 'true')

        common_util.view_error()

        cli_sub_command = "storage_restore_from_configuration_backup_file"
        sub_command_logtxt = "Sub-command parameters : " + " "

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cli_sub_command)
            common_util.view_error()

        if _configuration_backup_file is not None:
            sub_command_logtxt += "--configuration_backup_file " + str(_configuration_backup_file) + " "

        if _is_version_verification_enabled is not None:
            sub_command_logtxt += "--is_version_verification_enabled " + str(_is_version_verification_enabled) + " "

        logger.info(sub_command_logtxt)

        # バージョン検証のパラメータチェック
        if _is_version_verification_enabled is None:
            is_version_verification_enabled_str = 'true'
        else:
            is_version_verification_enabled_str = _is_version_verification_enabled
            if isinstance(is_version_verification_enabled_str, str):
                is_version_verification_enabled_str = SeparateArgs.check_backslash(is_version_verification_enabled_str)
                is_version_verification_enabled_str = is_version_verification_enabled_str.encode("utf-8").decode(
                    "unicode-escape")

            if (is_version_verification_enabled_str != 'true' and is_version_verification_enabled_str != 'false') and (
                            is_version_verification_enabled_str is not True and is_version_verification_enabled_str is not False):
                raise ValueError(
                    "Invalid value for `is_version_verification_enabled`, the format of the boolean value is invalid.")

            # Boolean型の場合はString型に変換
            if is_version_verification_enabled_str is True:
                is_version_verification_enabled_str = 'true'
            if is_version_verification_enabled_str is False:
                is_version_verification_enabled_str = 'false'

        # ファイルが存在するか
        if not (os.path.isfile(_configuration_backup_file)):
            message_management = MessageManagement('')
            message_id = '19004'
            message_dict = {'filePath': os.path.abspath(_configuration_backup_file)}
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)

        # パスワード入力
        common_util.input_password()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # ファイルアップロード中に認証失敗すると
        # RESTサーバから拒否応答を受けたケースの
        # エラーハンドリングを行ってしまう。
        # それを回避するため、ファイルアップロード前に
        # ストレージクラスターの構成情報復元状態参照を実行し、
        # 認証失敗ケースのエラーハンドリングを行うようにする。
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        response = api.storage_restoration_status_show(callback=None, debug="false")

        # REST応答をCLIで変換
        common_util.convert_rest_responses_with_cli(response)

        # REST応答をCLIで変換しない場合
        # HTTPステータスコードが200以外の場合は応答をそのまま出力
        status = common_util.get_response_status(response)
        if status != 200:
            oup = OutputUtil()
            oup.echo_normal(response, config.format, cli_sub_command)
            exit(common_util.get_cli_exit_code_for_api_execution(status))

        # HTTPステータスコード200の場合は、
        # 認証成功したとして処理継続する。

        # ファイルが存在するか 2回目
        if not (os.path.isfile(_configuration_backup_file)):
            message_management = MessageManagement('')
            message_id = '19004'
            message_dict = {'filePath': os.path.abspath(_configuration_backup_file)}
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)

        _configuration_backup_file_handle = open(_configuration_backup_file, 'rb')

        from requests_toolbelt import MultipartEncoder
        from com.hitachi.sophia.rest_client.manual.rest import RESTResponseForRequests

        # REST-API実行処理
        multipart_encoder = MultipartEncoder(
            fields={
                'configurationBackupFile': (_configuration_backup_file, _configuration_backup_file_handle),
                'isVersionVerificationEnabled': is_version_verification_enabled_str
            }
        )

        # URL
        url = config.host + '/v1/objects/storage/actions/restore-from-configuration-backup-file/invoke'

        api_client = ApiClient()

        # header
        header_params = {
            'Content-Type': multipart_encoder.content_type,
            'X-Client-type': 'HSDS CLI',
            'Accept': api_client.select_header_accept(['application/json'])
        }
        # header_params['Accept-Language']
        auth_settings = ['ticketAuth']

        header_params = api_client.sanitize_for_serialization(header_params)
        api_client.update_params_for_auth(header_params, None, auth_settings)

        # REST実行
        try:
            if config.verify_ssl is True:
                verify = certifi.where()
            else:
                verify = False

            response = requests.post(url, data=multipart_encoder, headers=header_params, verify=verify)

            response_data = RESTResponseForRequests(response)
            logger.info('Receive HTTP Response:' +
                        ' status:' +
                        str(response_data.status) +
                        ' response_header:' +
                        str(response_data.getheaders()))
            response = api_client.deserialize(response_data, None)

            # REST応答をCLIで変換
            common_util.convert_rest_responses_with_cli(response)

            # REST応答をCLIで変換しない場合は応答をそのまま出力
            # 結果出力
            oup = OutputUtil()
            oup.echo_normal(response, config.format, cli_sub_command)
            status = common_util.get_response_status(response)
            _configuration_backup_file_handle.close()
            exit(common_util.get_cli_exit_code_for_api_execution(status))

        except requests.exceptions.SSLError as e:
            if traceback:
                logger.error(traceback.format_exc())

            _configuration_backup_file_handle.close()

            message_id = '19506'
            message_dict = {}
            message_management = MessageManagement('')
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)

        except requests.exceptions.ConnectionError as e:
            if traceback:
                logger.error(traceback.format_exc())

            _configuration_backup_file_handle.close()

            if len(e.args) == 1:
                if (isinstance(e.args[0], urllib3.exceptions.ProtocolError)
                    or isinstance(e.args[0], requests.packages.urllib3.exceptions.ProtocolError)) \
                        and len(e.args[0].args) == 2 and \
                        (isinstance(e.args[0].args[1], BrokenPipeError)
                         or isinstance(e.args[0].args[1], ConnectionResetError)):
                    # BrokenPipeErrorまたはConnectionResetErrorは、
                    # RESTがリクエストボディ受けきる前に拒否しているケースもあるため、
                    # 特別なメッセージを出して終了
                    message_id = '19400'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)
                elif isinstance(e.args[0], urllib3.exceptions.HTTPError):
                    # urllib3のExceptionの場合は、そのexception内容でメッセージ決める
                    e = e.args[0]
                    message_management = MessageManagement('')
                    message_management.viewMessage(e)

            message_id = '19504'
            message_dict = {}
            message_management = MessageManagement('')
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)
        except requests.exceptions.RequestException as e:
            if traceback:
                logger.error(traceback.format_exc())

            _configuration_backup_file_handle.close()

            message_id = '19504'
            message_dict = {}
            message_management = MessageManagement('')
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        if traceback:
            logger.error(traceback.format_exc())

        message_id = '19007'
        message_dict = {
            'exception': 'An operation was attempted without adequate access rights, '
                         'such as file system rights. (File path = '
                         + os.path.abspath(_configuration_backup_file) + ')'}
        message_management = MessageManagement('')
        message_management.viewMessageTxt(message_id, **message_dict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        if traceback:
            logger.error(traceback.format_exc())

        message_id = '19007'
        message_dict = {'exception': 'The user hit the interrupt key. (File path = '
                                     + os.path.abspath(_configuration_backup_file) + ')'}
        message_management = MessageManagement('')
        message_management.viewMessageTxt(message_id, **message_dict)
        exit(1)

    except Exception as e:
        if traceback:
            logger.error(traceback.format_exc())
        message_management = MessageManagement('')
        message_management.viewMessage(e)


@click.command(options_metavar='<options>')
def storage_restoration_status_show():
    """
    Obtains the restoration status of the storage cluster configuration information.\n
    Run this subcommand only when instructed to do so by customer support.
    """
    try:
        config = Configuration()
        common_util = CommonUtil()

        common_util.view_error()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('', '', 'true')
        auth_parameter_util.check_auth_parameter('', '', 'true')

        common_util.view_error()

        cli_sub_command = "storage_restoration_status_show"
        sub_command_logtxt = "Sub-command parameters : " + " "

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cli_sub_command)
            common_util.view_error()

        logger.info(sub_command_logtxt)

        # パスワード入力
        common_util.input_password()

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
            SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        response = api.storage_restoration_status_show(callback=None, debug="false")

        # REST応答をCLIで変換
        common_util.convert_rest_responses_with_cli(response)

        # REST応答をCLIで変換しない場合は応答をそのまま出力
        # 結果出力
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cli_sub_command)
        status = common_util.get_response_status(response)
        exit(common_util.get_cli_exit_code_for_api_execution(status))

    except Exception as e:
        if traceback:
            logger.error(traceback.format_exc())
        message_management = MessageManagement('')
        message_management.viewMessage(e)


def commands():
    commands = {}
    commands['storage_restore_from_configuration_backup_file'] = storage_restore_from_configuration_backup_file
    commands['storage_restoration_status_show'] = storage_restoration_status_show
    return commands
