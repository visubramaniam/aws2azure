"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import click
import logging as loggingLib

from com.hitachi.sophia.rest_client.manual.configuration import Configuration

logger = loggingLib.getLogger(__name__)


class ProgressUtil(object):
    def update_progressbar(self, bar, length):
        # プログレスバーを更新
        bar.update(length)

        config = Configuration()
        if config.is_progress_shown is False:
            if bar._last_line is not None:
                # プログレスバーが表示された場合はフラグON
                config.is_progress_shown = True
                logger.info('Start displaying the progress bar.')

    def check_progress_shown_and_output_line_feed(self):
        """
        プログレスバーを表示している場合は標準エラー出力に改行を出力
        """
        config = Configuration()
        if config.is_progress_shown is True:
            click.echo('', err=True)
            config.is_progress_shown = False
