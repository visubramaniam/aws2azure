# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_block_for_maintenance(_id,):
    """
    Places the storage node into the blockage state for maintenance operation. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_block_for_maintenance"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "













        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_block_for_maintenance"


































                
        from com.hitachi.sophia.rest_client.autogen.models.BlockStorageNodeForMaintenance import BlockStorageNodeForMaintenance
        _block_storage_node_for_maintenance = BlockStorageNodeForMaintenance()

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.blockade_storage_node_for_maintenance(_id, block_storage_node_for_maintenance = _block_storage_node_for_maintenance, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_recover(_id,):
    """
    Restores the storage node from the blockage state caused by maintenance operation. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_recover"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_recover"
























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.recover_storage_node(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_delete(_id,):
    """
    Deletes a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "











        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_delete"




























                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteStorageNodeParam import DeleteStorageNodeParam
        _delete_storage_node_param = DeleteStorageNodeParam()

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.remove_storage_node(_id, delete_storage_node_param = _delete_storage_node_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
@click.option('--setup_user_password','_setup_user_password',type=str,metavar='<str>',hidden=True,help='Password of a setup user.')
def storage_node_replace(_id,_setup_user_password,):
    """
    Replaces a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_replace"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "











        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_replace"




























                
        from com.hitachi.sophia.rest_client.autogen.models.ReplaceStorageNodeParam import ReplaceStorageNodeParam
        _replace_storage_node_param = ReplaceStorageNodeParam()

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _setup_user_password is None:
            _setup_user_password = commonutil.input_stdin('setup_user_password')

        if _setup_user_password is not None:
            if isinstance(_setup_user_password, str):
                _setup_user_password = SeparateArgs.check_backslash(_setup_user_password)
                _setup_user_password = _setup_user_password.encode("utf-8").decode("unicode-escape")

        _replace_storage_node_param.setup_user_password = _setup_user_password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.replace_storage_node(_id, replace_storage_node_param = _replace_storage_node_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_stop_removing_storage_node():
    """
    Requests to stop storage node removal. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_stop_removing_storage_node"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_stop_removing_storage_node"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.stop_removing_storage_nodes(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_node_bmc_access_setting_list():
    """
    Obtains a list of information about BMC connection for storage nodes. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_bmc_access_setting_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_node_bmc_access_setting_list"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeBmcAccessSettingList import StorageNodeBmcAccessSettingList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_bmc_access_setting_list(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
@click.option('--bmc_name','_bmc_name',type=str,metavar='<str>',help='Host name or IP address (IPv4) of the BMC.',required=True)
@click.option('--bmc_user','_bmc_user',type=str,metavar='<str>',help='User name for BMC connection.',required=True)
@click.option('--bmc_password','_bmc_password',type=str,metavar='<str>',hidden=True,help='Password for BMC connection.')
def storage_node_bmc_access_setting_set(_id,_bmc_name,_bmc_user,_bmc_password,):
    """
    Edits the information about BMC connection for the storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_bmc_access_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _bmc_name is not None:
            subCommandLogtxt += "--bmc_name " + str(_bmc_name) + " "




        if _bmc_user is not None:
            subCommandLogtxt += "--bmc_user " + str(_bmc_user) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_bmc_access_setting_set"

























        if _bmc_name is not None:
            if(isinstance(_bmc_name, str)):
                _bmc_name = SeparateArgs.check_backslash(_bmc_name)
                _bmc_name = _bmc_name.encode("utf-8").decode("unicode-escape")
        if _bmc_user is not None:
            if(isinstance(_bmc_user, str)):
                _bmc_user = SeparateArgs.check_backslash(_bmc_user)
                _bmc_user = _bmc_user.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchStorageNodeBmcAccessSettingParam import PatchStorageNodeBmcAccessSettingParam
        _patch_storage_node_bmc_access_setting_param = PatchStorageNodeBmcAccessSettingParam()
        _patch_storage_node_bmc_access_setting_param.bmc_name = _bmc_name
        _patch_storage_node_bmc_access_setting_param.bmc_user = _bmc_user

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _bmc_password is None:
            _bmc_password = commonutil.input_stdin_allow_empty('bmc_password (if omitted, press the [Enter] key)')

        if _bmc_password is not None:
            if isinstance(_bmc_password, str):
                _bmc_password = SeparateArgs.check_backslash(_bmc_password)
                _bmc_password = _bmc_password.encode("utf-8").decode("unicode-escape")

        _patch_storage_node_bmc_access_setting_param.bmc_password = _bmc_password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_bmc_access_setting_set(_id, patch_storage_node_bmc_access_setting_param = _patch_storage_node_bmc_access_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_bmc_access_setting_show(_id,):
    """
    Obtains the information about BMC connection for the storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_bmc_access_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_bmc_access_setting_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeBmcAccessSetting import StorageNodeBmcAccessSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_bmc_access_setting_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--fault_domain_id','_fault_domain_id',metavar='<str>',help='Fault domain ID. ')
@click.option('--name','_name',metavar='<str>',help='Storage node name (partial match). ')
@click.option('--cluster_role','_cluster_role',metavar='<str>',help='The role of a storage node in a storage cluster. ')
@click.option('--protection_domain_id','_protection_domain_id',metavar='<str>',help='Protection domain ID. ')
def storage_node_list(_fault_domain_id,_name,_cluster_role,_protection_domain_id,):
    """
    Obtains a list of information about storage nodes. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _fault_domain_id is not None:
            subCommandLogtxt += "--fault_domain_id " + str(_fault_domain_id) + " "




        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "




        if _cluster_role is not None:
            subCommandLogtxt += "--cluster_role " + str(_cluster_role) + " "




        if _protection_domain_id is not None:
            subCommandLogtxt += "--protection_domain_id " + str(_protection_domain_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _fault_domain_id):
            raise ValueError("Invalid value for `fault_domain_id`, the format of UUID is invalid.")
        


        
        


        #Enumチェック
        allowed_values = ["Master", "Worker"]

        if _cluster_role is not None:
            if _cluster_role not in allowed_values:
                raise ValueError(
                    "Invalid value for `cluster_role` ({0}), (Select only one) {1}"
                    .format(_cluster_role, allowed_values)
            )
        
        


        
        #UUIDチェック
        if _protection_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _protection_domain_id):
            raise ValueError("Invalid value for `protection_domain_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "storage_node_list"




































                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeList import StorageNodeList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storagenode_list(fault_domain_id = _fault_domain_id, name = _name, cluster_role = _cluster_role, protection_domain_id = _protection_domain_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_show(_id,):
    """
    Obtains the information of a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNode import StorageNode

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storagenode_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
@click.option('--exported_configuration_file','_exported_configuration_file',metavar='<file>',help='Configuration file exported to replace storage node. (Cloud for Microsoft Azure) ')
@click.option('--configuration_file','_configuration_file',metavar='<file>',help='VSSB configuration file to be transferred to the storage cluster. (Cloud for AWS) ')
@click.option('--vm_configuration_file_s3_uri','_vm_configuration_file_s3_uri',metavar='<str>',help='URI (starting with \"s3://\") of Amazon S3 where the VMConfigurationFile.yml VM configuration file is stored. (Cloud for AWS) ')
def storage_node_replace_with_configuration_file(_id,_exported_configuration_file,_configuration_file,_vm_configuration_file_s3_uri,):
    """
    Replaces a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_replace_with_configuration_file"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "





        if _exported_configuration_file is not None:
            subCommandLogtxt += "--exported_configuration_file " + str(_exported_configuration_file) + " "


        if _configuration_file is not None:
            subCommandLogtxt += "--configuration_file " + str(_configuration_file) + " "


        if _vm_configuration_file_s3_uri is not None:
            subCommandLogtxt += "--vm_configuration_file_s3_uri " + str(_vm_configuration_file_s3_uri) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_replace_with_configuration_file"



















        if  _vm_configuration_file_s3_uri is not None and not re.search('^s3:\/\/.+$', _vm_configuration_file_s3_uri):
            raise ValueError("Invalid value for parameter `vm_configuration_file_s3_uri` when calling `" + cliSubCommand + "`, must conform to the pattern `/^s3:\/\/.+$/`")
#           raise ValueError("Invalid value for parameter `vm_configuration_file_s3_uri` when calling `v1_objects_storages_storage_device_id_storage_nodes_id_actions_replace_with_configuration_file_invoke_post`, must conform to the pattern `/^s3:\/\/.+$/`")





























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        
        
        #パラメータチェック ParamName指定有無確認
        if _exported_configuration_file is not None:
            #ファイルが存在するか
            if not(os.path.isfile(_exported_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_exported_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        
        #パラメータチェック ParamName指定有無確認
        if _configuration_file is not None:
            #ファイルが存在するか
            if not(os.path.isfile(_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        
        
        #パラメータチェック ParamName指定有無確認
        if _exported_configuration_file is not None:
            #ファイルが存在するか 2回目
            if not(os.path.isfile(_exported_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_exported_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        
        #パラメータチェック ParamName指定有無確認
        if _configuration_file is not None:
            #ファイルが存在するか 2回目
            if not(os.path.isfile(_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_storages_storage_device_id_storage_nodes_id_actions_replace_with_configuration_file_invoke_post(_id, exported_configuration_file = _exported_configuration_file, configuration_file = _configuration_file, vm_configuration_file_s3_uri = _vm_configuration_file_s3_uri, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _exported_configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_exported_configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--configuration_file','_configuration_file',metavar='<file>',help='VSSB configuration file to be transferred to the storage cluster. (Bare metal) ')
@click.option('--exported_configuration_file','_exported_configuration_file',metavar='<file>',help='Configuration file exported to add storage nodes. (Cloud for Microsoft Azure) ')
@click.option('--setup_user_password','_setup_user_password',metavar='<str>',hidden=True,help='Password of a setup user. (Bare metal) ')
@click.option('--vm_configuration_file_s3_uri','_vm_configuration_file_s3_uri',metavar='<str>',help='URI (starting with \"s3://\") of Amazon S3 where the VMConfigurationFile.yml VM configuration file is stored. (Cloud for AWS) ')
def storage_node_add(_configuration_file,_exported_configuration_file,_setup_user_password,_vm_configuration_file_s3_uri,):
    """
    Adds storage nodes. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_add"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _configuration_file is not None:
            subCommandLogtxt += "--configuration_file " + str(_configuration_file) + " "


        if _exported_configuration_file is not None:
            subCommandLogtxt += "--exported_configuration_file " + str(_exported_configuration_file) + " "




        if _vm_configuration_file_s3_uri is not None:
            subCommandLogtxt += "--vm_configuration_file_s3_uri " + str(_vm_configuration_file_s3_uri) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import StorageNodeManagement as StorageNodeManagementApi
        api = StorageNodeManagementApi(ApiClient())

        


        
        


        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_add"













        if _setup_user_password is not None and len(_setup_user_password) > 256:
            raise ValueError("Invalid value for parameter `setup_user_password` when calling `" + cliSubCommand + "`, length must be less than or equal to `256`")
#           raise ValueError("Invalid value for parameter `setup_user_password` when calling `v1_objects_storages_storage_device_id_storage_nodes_post`, length must be less than or equal to `256`")
        if _setup_user_password is not None and len(_setup_user_password) < 1:
            raise ValueError("Invalid value for parameter `setup_user_password` when calling `" + cliSubCommand + "`, length must be greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `setup_user_password` when calling `v1_objects_storages_storage_device_id_storage_nodes_post`, length must be greater than or equal to `1`")
        if  _setup_user_password is not None and not re.search('^[\\-A-Za-z0-9!#\\$%&\"\'\\(\\)\\*\\+,\\.\/:;<>=\\?@\\[\\]\\\\\\^_`\\{\\}\\|~]{1,256}$', _setup_user_password):
            raise ValueError("Invalid value for parameter `setup_user_password` when calling `" + cliSubCommand + "`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&\"'\\(\\)\\*\\+,\\.\/:;<>=\\?@\\[\\]\\\\\\^_`\\{\\}\\|~]{1,256}$/`")
#           raise ValueError("Invalid value for parameter `setup_user_password` when calling `v1_objects_storages_storage_device_id_storage_nodes_post`, must conform to the pattern `/^[\\-A-Za-z0-9!#\\$%&\"'\\(\\)\\*\\+,\\.\/:;<>=\\?@\\[\\]\\\\\\^_`\\{\\}\\|~]{1,256}$/`")






        if  _vm_configuration_file_s3_uri is not None and not re.search('^s3:\/\/.+$', _vm_configuration_file_s3_uri):
            raise ValueError("Invalid value for parameter `vm_configuration_file_s3_uri` when calling `" + cliSubCommand + "`, must conform to the pattern `/^s3:\/\/.+$/`")
#           raise ValueError("Invalid value for parameter `vm_configuration_file_s3_uri` when calling `v1_objects_storages_storage_device_id_storage_nodes_post`, must conform to the pattern `/^s3:\/\/.+$/`")





























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        
        
        #パラメータチェック ParamName指定有無確認
        if _configuration_file is not None:
            #ファイルが存在するか
            if not(os.path.isfile(_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        
        #パラメータチェック ParamName指定有無確認
        if _exported_configuration_file is not None:
            #ファイルが存在するか
            if not(os.path.isfile(_exported_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_exported_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        if _setup_user_password is None:
            _setup_user_password = commonutil.input_stdin_allow_empty('setup_user_password (if omitted, press the [Enter] key)')
        
        
        #パラメータチェック ParamName指定有無確認
        if _configuration_file is not None:
            #ファイルが存在するか 2回目
            if not(os.path.isfile(_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        
        #パラメータチェック ParamName指定有無確認
        if _exported_configuration_file is not None:
            #ファイルが存在するか 2回目
            if not(os.path.isfile(_exported_configuration_file)):
                mssageManagement = MessageManagement('')
                messageId = '19004'
                messageDict = {'filePath': os.path.abspath(_exported_configuration_file)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)
        
        
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.v1_objects_storages_storage_device_id_storage_nodes_post(configuration_file = _configuration_file, exported_configuration_file = _exported_configuration_file, setup_user_password = _setup_user_password, vm_configuration_file_s3_uri = _vm_configuration_file_s3_uri, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _exported_configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_exported_configuration_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['storage_node_block_for_maintenance'] = storage_node_block_for_maintenance

    commands['storage_node_recover'] = storage_node_recover
    commands['storage_node_delete'] = storage_node_delete
    commands['storage_node_replace'] = storage_node_replace
    commands['storage_stop_removing_storage_node'] = storage_stop_removing_storage_node
    commands['storage_node_bmc_access_setting_list'] = storage_node_bmc_access_setting_list
    commands['storage_node_bmc_access_setting_set'] = storage_node_bmc_access_setting_set
    commands['storage_node_bmc_access_setting_show'] = storage_node_bmc_access_setting_show
    commands['storage_node_list'] = storage_node_list
    commands['storage_node_show'] = storage_node_show

    commands['storage_node_replace_with_configuration_file'] = storage_node_replace_with_configuration_file
    commands['storage_node_add'] = storage_node_add
    return commands

