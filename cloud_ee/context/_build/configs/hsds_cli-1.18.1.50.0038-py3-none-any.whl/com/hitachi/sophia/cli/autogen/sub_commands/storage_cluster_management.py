# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
def bmc_root_certificate_delete():
    """
    Deletes a root certificate for BMC connection. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "bmc_root_certificate_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "bmc_root_certificate_delete"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.bmc_root_certificate_delete(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def bmc_root_certificate_download():
    """
    Obtains a root certificate for BMC connection. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "bmc_root_certificate_download"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "bmc_root_certificate_download"












                

    
        
        
        
        
        try:

            defaultFileName = "bmcRootCertificate.crt"
        
            fileutil = FileUtil(defaultFileName)

            dirname, filename = fileutil.locate_download_file(defaultFileName)
            download_path = os.path.join(dirname, filename)
        
            #ファイルが存在するか
            if (os.path.isfile(os.path.join(dirname, filename))):
                # 既にファイルが存在している
                mssageManagement = MessageManagement('')
                messageId = '19006'
                messageDict = {'filePath': os.path.abspath(defaultFileName)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)


            if not ('Authorization' in config.api_key):
                warningbanner = WarningBanner()
                warningbanner.sub_command_name = cliSubCommand
                login_message_response = warningbanner.get_login_message()
                login_message = warningbanner.view_warning_banner(login_message_response)

                commonutil.view_error()

                #空文字,Nullの場合はログインメッセージを表示しない
                if(login_message):
                    click.echo(login_message, err=True)

            commonutil.input_password()

            #ファイルが存在するか(2回目)
            if (os.path.isfile(os.path.join(dirname, filename))):
                # 既にファイルが存在している
                mssageManagement = MessageManagement('')
                messageId = '19006'
                messageDict = {'filePath': os.path.abspath(defaultFileName)}
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)



            # ストレージクラスターとCLIのバージョンチェック
            versioncheck = VersionCheck()
            api_version_response = versioncheck.get_api_version()
            versioncheck.version_check(api_version_response)

            response = api.bmc_root_certificate_download(callback=None, debug="false" ,_preload_content=False)

        # print(response)
            if(response):
            
                cli_response = collections.OrderedDict()
                cli_response['httpStatusCode'] = response.status
            
                if(response.status!=200):
                    if response.data:
                        cli_response['body'] = ApiClient().deserialize_json_to_body_or_exit(response, _preload_content=False)
                    
                    data = json.dumps(cli_response, indent=4, separators=(',', ': '))
                    output_util = OutputUtil()
                    output_util.echo_normal(data, config.format, cliSubCommand)

                    #click.echo(data)
                    exit(commonutil.get_cli_exit_code_for_api_execution(response.status))

        except Exception as e:
            if (traceback):
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

        saveFile = None
        try:
            with open(download_path, 'wb') as saveFile:
                saveFile.write(response.data)
            if config.format == 'text':
                click.echo('Message: ' + 'Download completed.')
                click.echo('Output File Path: ' + os.path.abspath(defaultFileName))
            else:
                cli_response['message'] = 'Download completed.'
                cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
                cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
                click.echo(cli_response)

            #cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
            cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
            #click.echo(cli_response)

        except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
            messageId = '19007'
            messageDict = {
                'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                    defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except FileExistsError as e:  # 既にファイルが存在している
            messageId = '19007'
            messageDict = {'exception': 'A file has already existed. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except OSError as e:  # OSError かつ errno ENOSPCの場合
            if e.errno == errno.ENOSPC:
                messageId = '19007'
                messageDict = {
                    'exception': 'No more space for writing is available on the device. (File path = ' + os.path.abspath(
                        defaultFileName) + ')'}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

            else:
                messageId = '19007'
                strErr = ','.join(map(str, e.args))
                messageDict = {'exception': strErr}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

        except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
            messageId = '19007'
            messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except Exception as e:
            #ファイルの保存に失敗
            messageId = '19007'
            strErr = ' '.join(map(str, e.args))
            messageDict = {'exception': strErr}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)

            exit(1)
        finally:
            if (saveFile):
                saveFile.close()

        #print('Download external auth server crl file Success')
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--root_certificate','_root_certificate',metavar='<file>',help='Root certificate file used in communication with the BMC of storage nodes. ',required=True)
def bmc_root_certificate_import(_root_certificate,):
    """
    Imports a root certificate for BMC connection. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "bmc_root_certificate_import"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _root_certificate is not None:
            subCommandLogtxt += "--root_certificate " + str(_root_certificate) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "bmc_root_certificate_import"
























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        
        
        
        #ファイルが存在するか
        if not(os.path.isfile(_root_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_root_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        
        
        
        #ファイルが存在するか 2回目
        if not(os.path.isfile(_root_certificate)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_root_certificate)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.bmc_root_certificate_import(_root_certificate, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _root_certificate) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_root_certificate) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the fault domain.',required=True)
def fault_domain_show(_id,):
    """
    Obtains fault domain information.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "fault_domain_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "fault_domain_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.FaultDomain import FaultDomain

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.fault_domain_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--protection_domain_id','_protection_domain_id',metavar='<str>',help='Protection domain ID. ')
def fault_domain_list(_protection_domain_id,):
    """
    Obtains a list of fault domain information.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "fault_domain_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _protection_domain_id is not None:
            subCommandLogtxt += "--protection_domain_id " + str(_protection_domain_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _protection_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _protection_domain_id):
            raise ValueError("Invalid value for `protection_domain_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "fault_domain_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.FaultDomainSummaryList import FaultDomainSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.fault_domain_summary_list(protection_domain_id = _protection_domain_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def health_status_show():
    """
    Obtains a health status.
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "health_status_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "health_status_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.HealthStatus import HealthStatus

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.health_status_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def protection_domain_list():
    """
    Obtains a list of protection domain information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "protection_domain_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "protection_domain_list"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ProtectionDomainSummaryList import ProtectionDomainSummaryList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.protection_domain_list(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Protection domain ID ',required=True)
@click.option('--async_processing_resource_usage_rate','_async_processing_resource_usage_rate',type=str,metavar='<str>',help='Usage of internal processing I/O resources. To set VeryHigh, prerequisites must be met. For details, see the Operation Guide.',required=True)
def protection_domain_set(_id,_async_processing_resource_usage_rate,):
    """
    Edits protection domain settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "protection_domain_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _async_processing_resource_usage_rate is not None:
            subCommandLogtxt += "--async_processing_resource_usage_rate " + str(_async_processing_resource_usage_rate) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "protection_domain_set"

























        if _async_processing_resource_usage_rate is not None:
            if(isinstance(_async_processing_resource_usage_rate, str)):
                _async_processing_resource_usage_rate = SeparateArgs.check_backslash(_async_processing_resource_usage_rate)
                _async_processing_resource_usage_rate = _async_processing_resource_usage_rate.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchProtectionDomainParam import PatchProtectionDomainParam
        _patch_protection_domain_param = PatchProtectionDomainParam()
        _patch_protection_domain_param.async_processing_resource_usage_rate = _async_processing_resource_usage_rate

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.protection_domain_set(_id, patch_protection_domain_param = _patch_protection_domain_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Protection domain ID ',required=True)
def protection_domain_show(_id,):
    """
    Obtains protection domain information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "protection_domain_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "protection_domain_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ProtectionDomain import ProtectionDomain

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.protection_domain_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Whether the metadata drive write reduction mode is enabled or disabled.',required=True)
@click.option('--force','_force',metavar='<bool>',help='Whether the operation is forcibly performed. When "true" is specified, the operation is forcibly performed .')
def storage_metadata_drive_write_reduction_mode_set(_is_enabled,_force,):
    """
    Changes the metadata drive write reduction mode for a storage cluster. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_metadata_drive_write_reduction_mode_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "




        if _force is not None:
            subCommandLogtxt += "--force " + str(_force) + " "










        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_metadata_drive_write_reduction_mode_set"

























        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")
        if _force is not None:
            if(isinstance(_force, str)):
                _force = SeparateArgs.check_backslash(_force)
                _force = _force.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.SetMetadataDriveWriteReductionModeParam import SetMetadataDriveWriteReductionModeParam
        _set_metadata_drive_write_reduction_mode_param = SetMetadataDriveWriteReductionModeParam()
        _set_metadata_drive_write_reduction_mode_param.is_enabled = _is_enabled
        _set_metadata_drive_write_reduction_mode_param.force = _force

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.reduction_of_drive_writes_for_metadata_mode_set(set_metadata_drive_write_reduction_mode_param = _set_metadata_drive_write_reduction_mode_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Protection domain ID ',required=True)
def protection_domain_resume_drive_data_relocation(_id,):
    """
    Requests resume of drive data relocation. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "protection_domain_resume_drive_data_relocation"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "protection_domain_resume_drive_data_relocation"
























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.resume_chnk_rebalance(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--is_snmpagent_enabled','_is_snmpagent_enabled',metavar='<bool>',help='Enables or disables SNMP.',required=True)
@click.option('--snmp_version','_snmp_version',type=str,metavar='<str>',help='SNMP version.',required=True)
@click.option('--storage_system_name','_storage_system_name',type=str,metavar='<str>',help='System name.',required=True)
@click.option('--contact','_contact',type=str,metavar='<str>',help='Administrator name or contact.',required=True)
@click.option('--location','_location',type=str,metavar='<str>',help='Installation location.',required=True)
@click.option('--snmpv2c_sending_trap_settings','_snmpv2c_sending_trap_settings',metavar='<str>', multiple=True,help='List of transmission destinations of traps in SNMPv2c. community: Community name used for reporting SNMP traps. send_trap_to: IP address (IPv4) or host name of the SNMP trap transmission destination.')
@click.option('--snmpv2c_request_authentication_settings','_snmpv2c_request_authentication_settings',metavar='<str>', multiple=True,help='List of request permission settings in SNMPv2c. community: Name of the community which accepts requests. requests_permitted: IP address (IPv4) or host name of the SNMP manager which accepts requests.')
def snmp_setting_set(_is_snmpagent_enabled,_snmp_version,_snmpv2c_sending_trap_settings,_snmpv2c_request_authentication_settings,_storage_system_name,_contact,_location,):
    """
    Edits the SNMP settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "snmp_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _is_snmpagent_enabled is not None:
            subCommandLogtxt += "--is_snmpagent_enabled " + str(_is_snmpagent_enabled) + " "




        if _snmp_version is not None:
            subCommandLogtxt += "--snmp_version " + str(_snmp_version) + " "



        if len(_snmpv2c_sending_trap_settings) == 0:
            _snmpv2c_sending_trap_settings = None

        if _snmpv2c_sending_trap_settings is not None:
            subCommandLogtxt += "--snmpv2c_sending_trap_settings " + str(_snmpv2c_sending_trap_settings) + " "



        if len(_snmpv2c_request_authentication_settings) == 0:
            _snmpv2c_request_authentication_settings = None

        if _snmpv2c_request_authentication_settings is not None:
            subCommandLogtxt += "--snmpv2c_request_authentication_settings " + str(_snmpv2c_request_authentication_settings) + " "




        if _storage_system_name is not None:
            subCommandLogtxt += "--storage_system_name " + str(_storage_system_name) + " "




        if _contact is not None:
            subCommandLogtxt += "--contact " + str(_contact) + " "




        if _location is not None:
            subCommandLogtxt += "--location " + str(_location) + " "








        logger.info(subCommandLogtxt)

        
    

    

    




    # マニュアル実装の関数を呼ぶ
        from com.hitachi.sophia.cli.manual.sub_commands.storage_cluster_management_manual import snmp_setting_set_manual
        snmp_setting_set_manual(_is_snmpagent_enabled,_snmp_version,_snmpv2c_sending_trap_settings,_snmpv2c_request_authentication_settings,_storage_system_name,_contact,_location,callback=None, debug="false")

    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    



@click.command(options_metavar='<options>')
def snmp_setting_show():
    """
    Obtains the SNMP settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "snmp_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "snmp_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.SnmpSetting import SnmpSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.snmp_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--fault_domain_id','_fault_domain_id',type=str,metavar='<str>',help='ID of the fault domain to which the node belongs.',required=True)
@click.option('--control_port_ipv4_address','_control_port_ipv4_address',type=str,metavar='<str>',help='IP address (IPv4) of the control port.',required=True)
@click.option('--setup_user_password','_setup_user_password',type=str,metavar='<str>',hidden=True,help='Password of a setup user.')
@click.option('--bmc_name','_bmc_name',type=str,metavar='<str>',help='Host name or IP address (IPv4) of the BMC.',required=True)
@click.option('--bmc_user','_bmc_user',type=str,metavar='<str>',help='User name for BMC connection.',required=True)
@click.option('--bmc_password','_bmc_password',type=str,metavar='<str>',hidden=True,help='Password for BMC connection.')
def spare_node_create(_fault_domain_id,_control_port_ipv4_address,_setup_user_password,_bmc_name,_bmc_user,_bmc_password,):
    """
    Registers the information about a spare node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "spare_node_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _fault_domain_id is not None:
            subCommandLogtxt += "--fault_domain_id " + str(_fault_domain_id) + " "




        if _control_port_ipv4_address is not None:
            subCommandLogtxt += "--control_port_ipv4_address " + str(_control_port_ipv4_address) + " "




        if _bmc_name is not None:
            subCommandLogtxt += "--bmc_name " + str(_bmc_name) + " "




        if _bmc_user is not None:
            subCommandLogtxt += "--bmc_user " + str(_bmc_user) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        if _fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _fault_domain_id):
            raise ValueError("Invalid value for `fault_domain_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "spare_node_create"



















        if _fault_domain_id is not None:
            if(isinstance(_fault_domain_id, str)):
                _fault_domain_id = SeparateArgs.check_backslash(_fault_domain_id)
                _fault_domain_id = _fault_domain_id.encode("utf-8").decode("unicode-escape")
        if _control_port_ipv4_address is not None:
            if(isinstance(_control_port_ipv4_address, str)):
                _control_port_ipv4_address = SeparateArgs.check_backslash(_control_port_ipv4_address)
                _control_port_ipv4_address = _control_port_ipv4_address.encode("utf-8").decode("unicode-escape")
        if _bmc_name is not None:
            if(isinstance(_bmc_name, str)):
                _bmc_name = SeparateArgs.check_backslash(_bmc_name)
                _bmc_name = _bmc_name.encode("utf-8").decode("unicode-escape")
        if _bmc_user is not None:
            if(isinstance(_bmc_user, str)):
                _bmc_user = SeparateArgs.check_backslash(_bmc_user)
                _bmc_user = _bmc_user.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateSpareNodeParam import CreateSpareNodeParam
        _create_spare_node_param = CreateSpareNodeParam()
        _create_spare_node_param.fault_domain_id = _fault_domain_id
        _create_spare_node_param.control_port_ipv4_address = _control_port_ipv4_address
        _create_spare_node_param.bmc_name = _bmc_name
        _create_spare_node_param.bmc_user = _bmc_user

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _setup_user_password is None:
            _setup_user_password = commonutil.input_stdin('setup_user_password')

        if _setup_user_password is not None:
            if isinstance(_setup_user_password, str):
                _setup_user_password = SeparateArgs.check_backslash(_setup_user_password)
                _setup_user_password = _setup_user_password.encode("utf-8").decode("unicode-escape")

        if _bmc_password is None:
            _bmc_password = commonutil.input_stdin('bmc_password')

        if _bmc_password is not None:
            if isinstance(_bmc_password, str):
                _bmc_password = SeparateArgs.check_backslash(_bmc_password)
                _bmc_password = _bmc_password.encode("utf-8").decode("unicode-escape")

        _create_spare_node_param.setup_user_password = _setup_user_password
        _create_spare_node_param.bmc_password = _bmc_password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.spare_node_create(create_spare_node_param = _create_spare_node_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='ID of a spare node. ',required=True)
def spare_node_delete(_id,):
    """
    Deletes the information about the spare node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "spare_node_delete"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "spare_node_delete"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.spare_node_delete(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--fault_domain_id','_fault_domain_id',metavar='<str>',help='ID of the fault domain to which the node belongs. ')
def spare_node_list(_fault_domain_id,):
    """
    Obtains a list of information about spare nodes. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "spare_node_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _fault_domain_id is not None:
            subCommandLogtxt += "--fault_domain_id " + str(_fault_domain_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _fault_domain_id):
            raise ValueError("Invalid value for `fault_domain_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "spare_node_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.SpareNodeList import SpareNodeList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.spare_node_list(fault_domain_id = _fault_domain_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='ID of a spare node. ',required=True)
@click.option('--fault_domain_id','_fault_domain_id',type=str,metavar='<str>',help='ID of the fault domain to which the node belongs.')
@click.option('--control_port_ipv4_address','_control_port_ipv4_address',type=str,metavar='<str>',help='IP address (IPv4) of the control port.')
@click.option('--setup_user_password','_setup_user_password',type=str,metavar='<str>',hidden=True,help='Password of a setup user.')
@click.option('--bmc_name','_bmc_name',type=str,metavar='<str>',help='Host name or IP address (IPv4) of the BMC.')
@click.option('--bmc_user','_bmc_user',type=str,metavar='<str>',help='User name for BMC connection.')
@click.option('--bmc_password','_bmc_password',type=str,metavar='<str>',hidden=True,help='Password for BMC connection.')
def spare_node_set(_id,_fault_domain_id,_control_port_ipv4_address,_setup_user_password,_bmc_name,_bmc_user,_bmc_password,):
    """
    Edits the information about the spare node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "spare_node_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _fault_domain_id is not None:
            subCommandLogtxt += "--fault_domain_id " + str(_fault_domain_id) + " "




        if _control_port_ipv4_address is not None:
            subCommandLogtxt += "--control_port_ipv4_address " + str(_control_port_ipv4_address) + " "




        if _bmc_name is not None:
            subCommandLogtxt += "--bmc_name " + str(_bmc_name) + " "




        if _bmc_user is not None:
            subCommandLogtxt += "--bmc_user " + str(_bmc_user) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        if _fault_domain_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _fault_domain_id):
            raise ValueError("Invalid value for `fault_domain_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "spare_node_set"

























        if _fault_domain_id is not None:
            if(isinstance(_fault_domain_id, str)):
                _fault_domain_id = SeparateArgs.check_backslash(_fault_domain_id)
                _fault_domain_id = _fault_domain_id.encode("utf-8").decode("unicode-escape")
        if _control_port_ipv4_address is not None:
            if(isinstance(_control_port_ipv4_address, str)):
                _control_port_ipv4_address = SeparateArgs.check_backslash(_control_port_ipv4_address)
                _control_port_ipv4_address = _control_port_ipv4_address.encode("utf-8").decode("unicode-escape")
        if _bmc_name is not None:
            if(isinstance(_bmc_name, str)):
                _bmc_name = SeparateArgs.check_backslash(_bmc_name)
                _bmc_name = _bmc_name.encode("utf-8").decode("unicode-escape")
        if _bmc_user is not None:
            if(isinstance(_bmc_user, str)):
                _bmc_user = SeparateArgs.check_backslash(_bmc_user)
                _bmc_user = _bmc_user.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchSpareNodeParam import PatchSpareNodeParam
        _patch_spare_node_param = PatchSpareNodeParam()
        _patch_spare_node_param.fault_domain_id = _fault_domain_id
        _patch_spare_node_param.control_port_ipv4_address = _control_port_ipv4_address
        _patch_spare_node_param.bmc_name = _bmc_name
        _patch_spare_node_param.bmc_user = _bmc_user

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _setup_user_password is None:
            _setup_user_password = commonutil.input_stdin_allow_empty('setup_user_password (if omitted, press the [Enter] key)')

        if _setup_user_password is not None:
            if isinstance(_setup_user_password, str):
                _setup_user_password = SeparateArgs.check_backslash(_setup_user_password)
                _setup_user_password = _setup_user_password.encode("utf-8").decode("unicode-escape")

        if _bmc_password is None:
            _bmc_password = commonutil.input_stdin_allow_empty('bmc_password (if omitted, press the [Enter] key)')

        if _bmc_password is not None:
            if isinstance(_bmc_password, str):
                _bmc_password = SeparateArgs.check_backslash(_bmc_password)
                _bmc_password = _bmc_password.encode("utf-8").decode("unicode-escape")

        _patch_spare_node_param.setup_user_password = _setup_user_password
        _patch_spare_node_param.bmc_password = _bmc_password

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.spare_node_set(_id, patch_spare_node_param = _patch_spare_node_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='ID of a spare node. ',required=True)
def spare_node_show(_id,):
    """
    Obtains the information about the spare node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "spare_node_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "spare_node_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.SpareNode import SpareNode

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.spare_node_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_show():
    """
    Obtains storage cluster information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Storage import Storage

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storageinfo_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Protection domain ID ',required=True)
def protection_domain_suspend_drive_data_relocation(_id,):
    """
    Requests suspension of drive data relocation. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "protection_domain_suspend_drive_data_relocation"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "protection_domain_suspend_drive_data_relocation"
























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.suspend_chnk_rebalance(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables write back mode with cache protection.',required=True)
@click.option('--force','_force',metavar='<bool>',help='Specifies whether to perform the operation forcibly. When "true" is specified, the operation is performed forcibly.')
def storage_write_back_mode_with_cache_protection_set(_is_enabled,_force,):
    """
    Sets write back mode with cache protection for a storage cluster. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_write_back_mode_with_cache_protection_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "




        if _force is not None:
            subCommandLogtxt += "--force " + str(_force) + " "










        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_cluster_management import StorageClusterManagement as StorageClusterManagementApi
        api = StorageClusterManagementApi(ApiClient())

        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_write_back_mode_with_cache_protection_set"

























        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")
        if _force is not None:
            if(isinstance(_force, str)):
                _force = SeparateArgs.check_backslash(_force)
                _force = _force.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.SetWriteBackModeWithCacheProtectionParam import SetWriteBackModeWithCacheProtectionParam
        _set_write_back_mode_with_cache_protection_param = SetWriteBackModeWithCacheProtectionParam()
        _set_write_back_mode_with_cache_protection_param.is_enabled = _is_enabled
        _set_write_back_mode_with_cache_protection_param.force = _force

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.write_back_mode_with_cache_protection_set(set_write_back_mode_with_cache_protection_param = _set_write_back_mode_with_cache_protection_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['bmc_root_certificate_delete'] = bmc_root_certificate_delete
    commands['bmc_root_certificate_download'] = bmc_root_certificate_download
    commands['bmc_root_certificate_import'] = bmc_root_certificate_import
    commands['fault_domain_show'] = fault_domain_show
    commands['fault_domain_list'] = fault_domain_list
    commands['health_status_show'] = health_status_show
    commands['protection_domain_list'] = protection_domain_list
    commands['protection_domain_set'] = protection_domain_set
    commands['protection_domain_show'] = protection_domain_show
    commands['storage_metadata_drive_write_reduction_mode_set'] = storage_metadata_drive_write_reduction_mode_set
    commands['protection_domain_resume_drive_data_relocation'] = protection_domain_resume_drive_data_relocation

    commands['snmp_setting_set'] = snmp_setting_set
    commands['snmp_setting_show'] = snmp_setting_show
    commands['spare_node_create'] = spare_node_create
    commands['spare_node_delete'] = spare_node_delete
    commands['spare_node_list'] = spare_node_list
    commands['spare_node_set'] = spare_node_set
    commands['spare_node_show'] = spare_node_show
    commands['storage_show'] = storage_show
    commands['protection_domain_suspend_drive_data_relocation'] = protection_domain_suspend_drive_data_relocation
    commands['storage_write_back_mode_with_cache_protection_set'] = storage_write_back_mode_with_cache_protection_set
    return commands

