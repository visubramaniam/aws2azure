# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import traceback
import logging as loggingLib
import os

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil

logger = loggingLib.getLogger(__name__)

def configuration_transfer_manual(_filepath, callback, debug):
    """
    Transfers a configuration definition file.
    """

    from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import \
        StorageNodeManagement as StorageNodeManagementApi

    #ファイルが存在するか
    if not(os.path.isfile(_filepath)):
        mssageManagement = MessageManagement('')
        messageId = '19004'
        messageDict = {'filePath': os.path.abspath(_filepath)}
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    _configuration_file = _filepath

    # ストレージクラスターとCLIのバージョンチェック
    versioncheck = VersionCheck()
    api_version_response = versioncheck.get_api_version()
    versioncheck.version_check(api_version_response)

    api = StorageNodeManagementApi(ApiClient())
    try:
        response = api.configuration_upload(_configuration_file, callback=None,
                                                                           debug=debug)
        click.echo(response)
        commonutil = CommonUtil()
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
    except Exception as e:
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

# TODO: SLIPPED
# 当該APIのコメントアウトを解除する際は、同フォルダ内にある"audit_log_management.py"の実装を参考にし修正すること
# def configuration_download_manual(_filepath, callback, debug):
#     """
#     Downloads a configuration definition file.
#     """
#
#     defaultFileName = "download_config"
#
#     logger = loggingLib.getLogger('hsdsClient')
#
#     from com.hitachi.sophia.rest_client.autogen.apis.storage_node_management import \
#         StorageNodeManagement as StorageNodeManagementApi
#     api = StorageNodeManagementApi(ApiClient())
#
#     fileutil = FileUtil(defaultFileName)
#
#     if (_filepath is None):
#         _filepath = defaultFileName
#
#     dirname, filename = fileutil.locate_download_file(_filepath)
#     download_path = os.path.join(dirname, filename)
#
#     #ファイルが存在するか
#     if (os.path.isfile(os.path.join(dirname, filename))):
#         # 既にファイルが存在している
#         mssageManagement = MessageManagement('')
#         messageId = '19006'
#         messageDict = {'filePath': os.path.abspath(_filepath)}
#         mssageManagement.viewMessageTxt(messageId, **messageDict)
#         exit(1)
#
#     try:
#         response = api.configuration_download(callback=callback, debug=debug , _preload_content=False)
#
#         if(response):
#             if(response.status!=200):
#                 click.echo(response.data)
#                 exit(1)
#
#     except Exception as e:
#         if (traceback):
#             logger.error(traceback.format_exc())
#
#         mssageManagement = MessageManagement('')
#         mssageManagement.viewMessage(e)
#
#     saveFile = None
#     try:
#         with open(download_path, 'wb') as saveFile:
#             saveFile.write(response.data)
#     except Exception as e:
#         #ファイルの保存に失敗
#         messageId = '19007'
#         strErr = ','.join(map(str,e.args))
#         messageDict = {'exception': strErr}
#         mssageManagement = MessageManagement('')
#         mssageManagement.viewMessageTxt(messageId, **messageDict)
#         exit(1)
#     finally:
#         if (saveFile):
#             saveFile.close()
#
#     print('Download config file Success')

