# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--storage_controller_id','_storage_controller_id',metavar='<str>',help='Storage controller ID. ')
def capacity_setting_list(_storage_controller_id,):
    """
    Obtains a list of capacity management settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "capacity_setting_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _storage_controller_id is not None:
            subCommandLogtxt += "--storage_controller_id " + str(_storage_controller_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _storage_controller_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_controller_id):
            raise ValueError("Invalid value for `storage_controller_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "capacity_setting_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.CapacitySettings import CapacitySettings

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.capacity_setting_list(storage_controller_id = _storage_controller_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--type','_type',type=str,metavar='<str>',help='Operation-target resource.',required=True)
@click.option('--id','_id',type=str,metavar='<str>',help='ID of the operation-target resource.')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables the capacity balancing.',required=True)
def capacity_setting_set(_type,_id,_is_enabled,):
    """
    Edits capacity management settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "capacity_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _type is not None:
            subCommandLogtxt += "--type " + str(_type) + " "




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "




        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        


        
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "capacity_setting_set"



















        if _type is not None:
            if(isinstance(_type, str)):
                _type = SeparateArgs.check_backslash(_type)
                _type = _type.encode("utf-8").decode("unicode-escape")
        if _id is not None:
            if(isinstance(_id, str)):
                _id = SeparateArgs.check_backslash(_id)
                _id = _id.encode("utf-8").decode("unicode-escape")
        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchCapacitySettingParam import PatchCapacitySettingParam
        _patch_capacity_setting_param = PatchCapacitySettingParam()
        _patch_capacity_setting_param.type = _type
        _patch_capacity_setting_param.id = _id
        _patch_capacity_setting_param.is_enabled = _is_enabled

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.capacity_setting_set(patch_capacity_setting_param = _patch_capacity_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool for which preliminary calculation of capacity is performed. ',required=True)
@click.option('--number_of_storage_nodes','_number_of_storage_nodes',type=int,metavar='<int>',help='The number of storage nodes that belong to the configuration for which preliminary calculation of capacity is performed. ',required=True)
@click.option('--number_of_drives','_number_of_drives',type=int,metavar='<int>',help='The number of drives for each storage node that belongs to the configuration for which preliminary calculation of capacity is performed. ',required=True)
@click.option('--number_of_tolerable_drive_failures','_number_of_tolerable_drive_failures',type=int,metavar='<int>',help='The number of drive failures that can be allowed in the configuration for which preliminary calculation of capacity is performed. ',required=True)
def estimated_capacity_for_specified_configuration_show(_id,_number_of_storage_nodes,_number_of_drives,_number_of_tolerable_drive_failures,):
    """
    Obtains the preliminary calculation results of the storage pool logical capacity in the specified configuration. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "estimated_capacity_for_specified_configuration_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "




        if _number_of_storage_nodes is not None:
            subCommandLogtxt += "--number_of_storage_nodes " + str(_number_of_storage_nodes) + " "




        if _number_of_drives is not None:
            subCommandLogtxt += "--number_of_drives " + str(_number_of_drives) + " "




        if _number_of_tolerable_drive_failures is not None:
            subCommandLogtxt += "--number_of_tolerable_drive_failures " + str(_number_of_tolerable_drive_failures) + " "









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        


        
        


        
        


        
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "estimated_capacity_for_specified_configuration_show"







        if _number_of_storage_nodes is not None and _number_of_storage_nodes > 18:
            raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `" + cliSubCommand + "`, must be a value less than or equal to `18`")
#           raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `estimated_capacity_for_specified_configuration_show`, must be a value less than or equal to `18`")
        if _number_of_storage_nodes is not None and _number_of_storage_nodes < 2:
            raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `2`")
#           raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `estimated_capacity_for_specified_configuration_show`, must be a value greater than or equal to `2`")






        if _number_of_drives is not None and _number_of_drives > 24:
            raise ValueError("Invalid value for parameter `number_of_drives` when calling `" + cliSubCommand + "`, must be a value less than or equal to `24`")
#           raise ValueError("Invalid value for parameter `number_of_drives` when calling `estimated_capacity_for_specified_configuration_show`, must be a value less than or equal to `24`")
        if _number_of_drives is not None and _number_of_drives < 6:
            raise ValueError("Invalid value for parameter `number_of_drives` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `6`")
#           raise ValueError("Invalid value for parameter `number_of_drives` when calling `estimated_capacity_for_specified_configuration_show`, must be a value greater than or equal to `6`")






        if _number_of_tolerable_drive_failures is not None and _number_of_tolerable_drive_failures > 23:
            raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `" + cliSubCommand + "`, must be a value less than or equal to `23`")
#           raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `estimated_capacity_for_specified_configuration_show`, must be a value less than or equal to `23`")
        if _number_of_tolerable_drive_failures is not None and _number_of_tolerable_drive_failures < 0:
            raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `estimated_capacity_for_specified_configuration_show`, must be a value greater than or equal to `0`")























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.EstimatedCapacityForSpecifiedConfiguration import EstimatedCapacityForSpecifiedConfiguration

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.estimated_capacity_for_specified_configuration_show(_id, _number_of_storage_nodes, _number_of_drives, _number_of_tolerable_drive_failures, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool for which preliminary calculation of capacity is performed. ',required=True)
@click.option('--number_of_storage_nodes','_number_of_storage_nodes',type=int,metavar='<int>',help='The number of storage nodes to be added to the current configuration. ')
@click.option('--number_of_drives','_number_of_drives',type=int,metavar='<int>',help='The number of drives (for each storage node) to be added to the current configuration. ')
@click.option('--number_of_tolerable_drive_failures','_number_of_tolerable_drive_failures',type=int,metavar='<int>',help='The number of drives (for each storage node) to be added to the current configuration. ')
def estimated_capacity_for_updated_configuration_show(_id,_number_of_storage_nodes,_number_of_drives,_number_of_tolerable_drive_failures,):
    """
    Obtains the estimation results of the storage pool logical capacity (TiB) when adding resources to the current configuration or changing the resources of the current configuration. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "estimated_capacity_for_updated_configuration_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "





        if _number_of_storage_nodes is not None:
            subCommandLogtxt += "--number_of_storage_nodes " + str(_number_of_storage_nodes) + " "




        if _number_of_drives is not None:
            subCommandLogtxt += "--number_of_drives " + str(_number_of_drives) + " "




        if _number_of_tolerable_drive_failures is not None:
            subCommandLogtxt += "--number_of_tolerable_drive_failures " + str(_number_of_tolerable_drive_failures) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "estimated_capacity_for_updated_configuration_show"







        if _number_of_storage_nodes is not None and _number_of_storage_nodes > 16:
            raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `" + cliSubCommand + "`, must be a value less than or equal to `16`")
#           raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `estimated_capacity_for_updated_configuration_show`, must be a value less than or equal to `16`")
        if _number_of_storage_nodes is not None and _number_of_storage_nodes < 2:
            raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `2`")
#           raise ValueError("Invalid value for parameter `number_of_storage_nodes` when calling `estimated_capacity_for_updated_configuration_show`, must be a value greater than or equal to `2`")






        if _number_of_drives is not None and _number_of_drives > 18:
            raise ValueError("Invalid value for parameter `number_of_drives` when calling `" + cliSubCommand + "`, must be a value less than or equal to `18`")
#           raise ValueError("Invalid value for parameter `number_of_drives` when calling `estimated_capacity_for_updated_configuration_show`, must be a value less than or equal to `18`")
        if _number_of_drives is not None and _number_of_drives < 1:
            raise ValueError("Invalid value for parameter `number_of_drives` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `1`")
#           raise ValueError("Invalid value for parameter `number_of_drives` when calling `estimated_capacity_for_updated_configuration_show`, must be a value greater than or equal to `1`")






        if _number_of_tolerable_drive_failures is not None and _number_of_tolerable_drive_failures > 23:
            raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `" + cliSubCommand + "`, must be a value less than or equal to `23`")
#           raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `estimated_capacity_for_updated_configuration_show`, must be a value less than or equal to `23`")
        if _number_of_tolerable_drive_failures is not None and _number_of_tolerable_drive_failures < 0:
            raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `" + cliSubCommand + "`, must be a value greater than or equal to `0`")
#           raise ValueError("Invalid value for parameter `number_of_tolerable_drive_failures` when calling `estimated_capacity_for_updated_configuration_show`, must be a value greater than or equal to `0`")























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.EstimatedCapacityForUpdatedConfiguration import EstimatedCapacityForUpdatedConfiguration

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.estimated_capacity_for_updated_configuration_show(_id, number_of_storage_nodes = _number_of_storage_nodes, number_of_drives = _number_of_drives, number_of_tolerable_drive_failures = _number_of_tolerable_drive_failures, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool. ')
@click.option('--id_name','_id_name',metavar='<str>',help='The name of the storage pool.')
@click.option('--drive_ids','_drive_ids',callback=SeparateArgs.separateArgs,metavar='<array>',help='A list of IDs of the drives to be added to the storage pool.',required=True)
def pool_expand(_id,_id_name,_drive_ids,):
    """
    Expands the storage pool capacity. 
    """
    def get_uuid_from_pool_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.pool_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_expand"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _drive_ids is not None:
            subCommandLogtxt += "--drive_ids " + str(_drive_ids) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "pool_expand"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `pool_expand`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")




















        if _drive_ids is not None:
            if(isinstance(_drive_ids, str)):
                _drive_ids = SeparateArgs.check_backslash(_drive_ids)
                _drive_ids = _drive_ids.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.ExpandPoolParam import ExpandPoolParam
        _expand_pool = ExpandPoolParam()
        _expand_pool.drive_ids = _drive_ids

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # pool_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_pool_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.pool_expand(_id, expand_pool = _expand_pool, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--name','_name',metavar='<str>',help='The name of the storage pool (exact match). ')
@click.option('--id_name','_id_name',metavar='<str>',help='Alias of name.')
@click.option('--names','_names',metavar='<str>',help='A list of names of the storage pool (exact match). You can specify plural names (up to 32) by delimiting them with commas (,). ')
@click.option('--id_names','_id_names',metavar='<str>',help='Alias of names.')
def pool_list(_name,_id_name,_names,_id_names,):
    """
    Obtains a list of storage pool information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "



        if _names is not None:
            subCommandLogtxt += "--names " + str(_names) + " "

        if _id_names is not None:
            subCommandLogtxt += "--id_names " + str(_id_names) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--name', _name,'--id_name', _id_name, 'false')
        commonutil.view_error()


        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--names', _names,'--id_names', _id_names, 'false')
        commonutil.view_error()


        
        #フィルター配列チェック
        if _names is not None:
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('names',
                                                            _names,
                                                            '^[\-A-Za-z0-9_]{1,32}$',
                                                            '^[\\-A-Za-z0-9_]{1,32}$',
                                                            32,
                                                            32)
        


        
        
        
        
        
        #cliSubCommand = "pool_list"




















        if _id_names is not None:
            #フィルター配列チェック
            paramvalidatorutil = ParamValidatorUtil()
            paramvalidatorutil.check_filter_array_for_names('id_names',
                                                            _id_names,
                                                            '^[\-A-Za-z0-9_]{1,32}$',
                                                            '^[\\-A-Za-z0-9_]{1,32}$',
                                                            32,
                                                            32)




                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.PoolList import PoolList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if not _id_name is None:
            _name = _id_name

        if not _id_names is None:
            _names = _id_names


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.pool_list(name = _name, names = _names, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool. ')
@click.option('--id_name','_id_name',metavar='<str>',help='The name of the storage pool.')
@click.option('--rebuild_capacity_policy','_rebuild_capacity_policy',type=str,metavar='<str>',help='Rebuild capacity policy.',required=True)
@click.option('--number_of_tolerable_drive_failures','_number_of_tolerable_drive_failures',type=int,metavar='<int>',help='The number of drive failures that can be tolerated.')
def pool_set(_id,_id_name,_rebuild_capacity_policy,_number_of_tolerable_drive_failures,):
    """
    Edits storage pool settings. 
    """
    def get_uuid_from_pool_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.pool_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _rebuild_capacity_policy is not None:
            subCommandLogtxt += "--rebuild_capacity_policy " + str(_rebuild_capacity_policy) + " "




        if _number_of_tolerable_drive_failures is not None:
            subCommandLogtxt += "--number_of_tolerable_drive_failures " + str(_number_of_tolerable_drive_failures) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "pool_set"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `pool_set`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")




















        if _rebuild_capacity_policy is not None:
            if(isinstance(_rebuild_capacity_policy, str)):
                _rebuild_capacity_policy = SeparateArgs.check_backslash(_rebuild_capacity_policy)
                _rebuild_capacity_policy = _rebuild_capacity_policy.encode("utf-8").decode("unicode-escape")
        if _number_of_tolerable_drive_failures is not None:
            if(isinstance(_number_of_tolerable_drive_failures, str)):
                _number_of_tolerable_drive_failures = SeparateArgs.check_backslash(_number_of_tolerable_drive_failures)
                _number_of_tolerable_drive_failures = _number_of_tolerable_drive_failures.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchStoragePoolSettingParam import PatchStoragePoolSettingParam
        tmp_patch_storage_pool_setting_param = PatchStoragePoolSettingParam()
        patch_storage_pool_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.RebuildCapacityResourceSettingParam import RebuildCapacityResourceSettingParam
        tmp_rebuild_capacity_resource_setting_param = RebuildCapacityResourceSettingParam()
        rebuild_capacity_resource_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        patch_storage_pool_setting_param = commonutil.set_parameter_with_instance(patch_storage_pool_setting_param, tmp_patch_storage_pool_setting_param, 'rebuild_capacity_policy', _rebuild_capacity_policy)
        

        rebuild_capacity_resource_setting_param = commonutil.set_parameter_with_instance(rebuild_capacity_resource_setting_param, tmp_rebuild_capacity_resource_setting_param, 'number_of_tolerable_drive_failures', _number_of_tolerable_drive_failures)
        patch_storage_pool_setting_param = commonutil.set_parameter_with_instance(patch_storage_pool_setting_param, tmp_patch_storage_pool_setting_param, 'rebuild_capacity_resource_setting', rebuild_capacity_resource_setting_param)
        _patch_storage_pool_setting_param = patch_storage_pool_setting_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # pool_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_pool_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.pool_set(_id, patch_storage_pool_setting_param = _patch_storage_pool_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='The ID of the storage pool. ')
@click.option('--id_name','_id_name',metavar='<str>',help='The name of the storage pool.')
def pool_show(_id,_id_name,):
    """
    Obtains storage pool information. 
    """
    def get_uuid_from_pool_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.pool_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "pool_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "pool_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `pool_show`, must conform to the pattern `^[\-A-Za-z0-9_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Pool import Pool

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # pool_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_pool_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.pool_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_node_capacity_setting_list():
    """
    Obtains a list of the capacity management settings of a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_capacity_setting_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_node_capacity_setting_list"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeCapacitySettingList import StorageNodeCapacitySettingList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_capacity_setting_list(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_capacity_setting_show(_id,):
    """
    Obtains the capacity management settings of a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_capacity_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_capacity_setting_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeCapacitySetting import StorageNodeCapacitySetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_capacity_setting_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables the capacity balancing.',required=True)
def storage_node_capacity_setting_set(_id,_is_enabled,):
    """
    Edits the capacity management settings of a storage node. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_capacity_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.storage_pool_management import StoragePoolManagement as StoragePoolManagementApi
        api = StoragePoolManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_capacity_setting_set"

























        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.PatchStorageNodeCapacitySettingParam import PatchStorageNodeCapacitySettingParam
        tmp_patch_storage_node_capacity_setting_param = PatchStorageNodeCapacitySettingParam()
        patch_storage_node_capacity_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.CapacityBalancingSettingParam import CapacityBalancingSettingParam
        tmp_capacity_balancing_setting_param = CapacityBalancingSettingParam()
        capacity_balancing_setting_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        capacity_balancing_setting_param = commonutil.set_parameter_with_instance(capacity_balancing_setting_param, tmp_capacity_balancing_setting_param, 'is_enabled', _is_enabled)
        patch_storage_node_capacity_setting_param = commonutil.set_parameter_with_instance(patch_storage_node_capacity_setting_param, tmp_patch_storage_node_capacity_setting_param, 'capacity_balancing_setting', capacity_balancing_setting_param)
        _patch_storage_node_capacity_setting_param = patch_storage_node_capacity_setting_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storagenode_capacity_settings_id(_id, patch_storage_node_capacity_setting_param = _patch_storage_node_capacity_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['capacity_setting_list'] = capacity_setting_list
    commands['capacity_setting_set'] = capacity_setting_set

    commands['estimated_capacity_for_specified_configuration_show'] = estimated_capacity_for_specified_configuration_show
    commands['estimated_capacity_for_updated_configuration_show'] = estimated_capacity_for_updated_configuration_show
    commands['pool_expand'] = pool_expand
    commands['pool_list'] = pool_list
    commands['pool_set'] = pool_set
    commands['pool_show'] = pool_show


    commands['storage_node_capacity_setting_list'] = storage_node_capacity_setting_list
    commands['storage_node_capacity_setting_show'] = storage_node_capacity_setting_show
    commands['storage_node_capacity_setting_set'] = storage_node_capacity_setting_set
    return commands

