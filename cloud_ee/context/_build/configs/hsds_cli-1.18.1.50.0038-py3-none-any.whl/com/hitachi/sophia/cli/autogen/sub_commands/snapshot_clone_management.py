# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--name','_name',type=str,metavar='<str>',help='The name of the volume.')
@click.option('--master_volume_id','_master_volume_id',type=str,metavar='<str>',help='The ID of the volume becoming P-VOL.')
@click.option('--snapshot_volume_id','_snapshot_volume_id',type=str,metavar='<str>',help='The ID of the volume which is S-VOL.')
@click.option('--operation_type','_operation_type',type=str,metavar='<str>',help='Type of the operation.')
@click.option('--upper_limit_for_iops','_upper_limit_for_iops',type=int,metavar='<int>',help='Upper limit for the volume performance (IOPS).')
@click.option('--upper_limit_for_transfer_rate','_upper_limit_for_transfer_rate',type=int,metavar='<int>',help='Upper limit for the volume performance (MiB/sec).')
@click.option('--upper_alert_allowable_time','_upper_alert_allowable_time',type=int,metavar='<int>',help='Alert threshold (second) for the upper limit of volume performance.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--master_volume_id_name','_master_volume_id_name',metavar='<str>',help='The name of the volume becoming P-VOL.')
@click.option('--snapshot_volume_id_name','_snapshot_volume_id_name',metavar='<str>',help='The name of the volume which is S-VOL.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_create_snapshot(_name,_master_volume_id,_master_volume_id_name,_snapshot_volume_id,_snapshot_volume_id_name,_operation_type,_upper_limit_for_iops,_upper_limit_for_transfer_rate,_upper_alert_allowable_time,_vps_id,_vps_id_name,):
    """
    Creates a snapshot. 
    """
    def get_uuid_from_volume_list_with_master_volume_id_name(master_volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=master_volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'master_volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_volume_list_with_snapshot_volume_id_name(snapshot_volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=snapshot_volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'snapshot_volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_create_snapshot"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _name is not None:
            subCommandLogtxt += "--name " + str(_name) + " "




        if _master_volume_id is not None:
            subCommandLogtxt += "--master_volume_id " + str(_master_volume_id) + " "

        if _master_volume_id_name is not None:
            subCommandLogtxt += "--master_volume_id_name " + str(_master_volume_id_name) + " "



        if _snapshot_volume_id is not None:
            subCommandLogtxt += "--snapshot_volume_id " + str(_snapshot_volume_id) + " "

        if _snapshot_volume_id_name is not None:
            subCommandLogtxt += "--snapshot_volume_id_name " + str(_snapshot_volume_id_name) + " "



        if _operation_type is not None:
            subCommandLogtxt += "--operation_type " + str(_operation_type) + " "




        if _upper_limit_for_iops is not None:
            subCommandLogtxt += "--upper_limit_for_iops " + str(_upper_limit_for_iops) + " "




        if _upper_limit_for_transfer_rate is not None:
            subCommandLogtxt += "--upper_limit_for_transfer_rate " + str(_upper_limit_for_transfer_rate) + " "




        if _upper_alert_allowable_time is not None:
            subCommandLogtxt += "--upper_alert_allowable_time " + str(_upper_alert_allowable_time) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.snapshot_clone_management import SnapshotCloneManagement as SnapshotCloneManagementApi
        api = SnapshotCloneManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--master_volume_id', _master_volume_id,'--master_volume_id_name', _master_volume_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--snapshot_volume_id', _snapshot_volume_id,'--snapshot_volume_id_name', _snapshot_volume_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        if _master_volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _master_volume_id):
            raise ValueError("Invalid value for `master_volume_id`, the format of UUID is invalid.")
        if _snapshot_volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _snapshot_volume_id):
            raise ValueError("Invalid value for `snapshot_volume_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_create_snapshot"





        if  _master_volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _master_volume_id_name):
            raise ValueError("Invalid value for parameter `master_volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if  _snapshot_volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _snapshot_volume_id_name):
            raise ValueError("Invalid value for parameter `snapshot_volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _name is not None:
            if(isinstance(_name, str)):
                _name = SeparateArgs.check_backslash(_name)
                _name = _name.encode("utf-8").decode("unicode-escape")
        if _master_volume_id is not None:
            if(isinstance(_master_volume_id, str)):
                _master_volume_id = SeparateArgs.check_backslash(_master_volume_id)
                _master_volume_id = _master_volume_id.encode("utf-8").decode("unicode-escape")
        if _snapshot_volume_id is not None:
            if(isinstance(_snapshot_volume_id, str)):
                _snapshot_volume_id = SeparateArgs.check_backslash(_snapshot_volume_id)
                _snapshot_volume_id = _snapshot_volume_id.encode("utf-8").decode("unicode-escape")
        if _operation_type is not None:
            if(isinstance(_operation_type, str)):
                _operation_type = SeparateArgs.check_backslash(_operation_type)
                _operation_type = _operation_type.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_iops is not None:
            if(isinstance(_upper_limit_for_iops, str)):
                _upper_limit_for_iops = SeparateArgs.check_backslash(_upper_limit_for_iops)
                _upper_limit_for_iops = _upper_limit_for_iops.encode("utf-8").decode("unicode-escape")
        if _upper_limit_for_transfer_rate is not None:
            if(isinstance(_upper_limit_for_transfer_rate, str)):
                _upper_limit_for_transfer_rate = SeparateArgs.check_backslash(_upper_limit_for_transfer_rate)
                _upper_limit_for_transfer_rate = _upper_limit_for_transfer_rate.encode("utf-8").decode("unicode-escape")
        if _upper_alert_allowable_time is not None:
            if(isinstance(_upper_alert_allowable_time, str)):
                _upper_alert_allowable_time = SeparateArgs.check_backslash(_upper_alert_allowable_time)
                _upper_alert_allowable_time = _upper_alert_allowable_time.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



        
        from com.hitachi.sophia.rest_client.autogen.models.CreateSnapshotParam import CreateSnapshotParam
        tmp_create_snapshot_param = CreateSnapshotParam()
        create_snapshot_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        from com.hitachi.sophia.rest_client.autogen.models.VolumeQosParam import VolumeQosParam
        tmp_volume_qos_param = VolumeQosParam()
        volume_qos_param = None # 本変数はオプション指定が無い場合Noneのままとなるため、Noneチェックをしてから使用すること。
        

        create_snapshot_param = commonutil.set_parameter_with_instance(create_snapshot_param, tmp_create_snapshot_param, 'name', _name)
        

        create_snapshot_param = commonutil.set_parameter_with_instance(create_snapshot_param, tmp_create_snapshot_param, 'master_volume_id', _master_volume_id)
        

        create_snapshot_param = commonutil.set_parameter_with_instance(create_snapshot_param, tmp_create_snapshot_param, 'snapshot_volume_id', _snapshot_volume_id)
        

        create_snapshot_param = commonutil.set_parameter_with_instance(create_snapshot_param, tmp_create_snapshot_param, 'operation_type', _operation_type)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_limit_for_iops', _upper_limit_for_iops)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_limit_for_transfer_rate', _upper_limit_for_transfer_rate)
        

        volume_qos_param = commonutil.set_parameter_with_instance(volume_qos_param, tmp_volume_qos_param, 'upper_alert_allowable_time', _upper_alert_allowable_time)
        

        create_snapshot_param = commonutil.set_parameter_with_instance(create_snapshot_param, tmp_create_snapshot_param, 'vps_id', _vps_id)
        create_snapshot_param = commonutil.set_parameter_with_instance(create_snapshot_param, tmp_create_snapshot_param, 'qos_param', volume_qos_param)
        _create_snapshot = create_snapshot_param
        
    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _master_volume_id_name is not None:
            # volume_listを使ってmaster_volume_id_nameに対応するmaster_volume_idを取得
            _master_volume_id = get_uuid_from_volume_list_with_master_volume_id_name(_master_volume_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateSnapshotParam import CreateSnapshotParam
                _create_snapshot = CreateSnapshotParam()
            _create_snapshot.master_volume_id = _master_volume_id

        if _snapshot_volume_id_name is not None:
            # volume_listを使ってsnapshot_volume_id_nameに対応するsnapshot_volume_idを取得
            _snapshot_volume_id = get_uuid_from_volume_list_with_snapshot_volume_id_name(_snapshot_volume_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateSnapshotParam import CreateSnapshotParam
                _create_snapshot = CreateSnapshotParam()
            _create_snapshot.snapshot_volume_id = _snapshot_volume_id

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _create_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.CreateSnapshotParam import CreateSnapshotParam
                _create_snapshot = CreateSnapshotParam()
            _create_snapshot.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.create_snapshot(create_snapshot = _create_snapshot, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--master_volume_id','_master_volume_id',type=str,metavar='<str>',help='The ID of the volume which is P-VOL. Only the volume of which snapshotAttribute is P-VOL can be specified.')
@click.option('--snapshot_volume_id','_snapshot_volume_id',type=str,metavar='<str>',help='The ID of the volume which is S-VOL. Only the volume of which snapshotAttribute is S-VOL can be specified. Deletes the volume which is S-VOL of the parameter specified.')
@click.option('--snapshot_tree','_snapshot_tree',metavar='<bool>',help='Specify whether to forcibly delete all S-VOLs and P/S-VOLs that have been created from the P-VOL specified for master_volume_id or master_volume_id_name.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--master_volume_id_name','_master_volume_id_name',metavar='<str>',help='The name of the volume which is P-VOL. Only the volume of which snapshotAttribute is P-VOL can be specified.')
@click.option('--snapshot_volume_id_name','_snapshot_volume_id_name',metavar='<str>',help='The name of the volume which is S-VOL. Only the volume of which snapshotAttribute is S-VOL can be specified. Deletes the volume which is S-VOL of the parameter specified.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_delete_snapshot(_master_volume_id,_master_volume_id_name,_snapshot_volume_id,_snapshot_volume_id_name,_snapshot_tree,_vps_id,_vps_id_name,):
    """
    Deletes snapshots. 
    """
    def get_uuid_from_volume_list_with_master_volume_id_name(master_volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=master_volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'master_volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_volume_list_with_snapshot_volume_id_name(snapshot_volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=snapshot_volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'snapshot_volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_delete_snapshot"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _master_volume_id is not None:
            subCommandLogtxt += "--master_volume_id " + str(_master_volume_id) + " "

        if _master_volume_id_name is not None:
            subCommandLogtxt += "--master_volume_id_name " + str(_master_volume_id_name) + " "



        if _snapshot_volume_id is not None:
            subCommandLogtxt += "--snapshot_volume_id " + str(_snapshot_volume_id) + " "

        if _snapshot_volume_id_name is not None:
            subCommandLogtxt += "--snapshot_volume_id_name " + str(_snapshot_volume_id_name) + " "



        if _snapshot_tree is not None:
            subCommandLogtxt += "--snapshot_tree " + str(_snapshot_tree) + " "




        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.snapshot_clone_management import SnapshotCloneManagement as SnapshotCloneManagementApi
        api = SnapshotCloneManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--master_volume_id', _master_volume_id,'--master_volume_id_name', _master_volume_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--snapshot_volume_id', _snapshot_volume_id,'--snapshot_volume_id_name', _snapshot_volume_id_name, 'false')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        if _master_volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _master_volume_id):
            raise ValueError("Invalid value for `master_volume_id`, the format of UUID is invalid.")
        if _snapshot_volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _snapshot_volume_id):
            raise ValueError("Invalid value for `snapshot_volume_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_delete_snapshot"





        if  _master_volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _master_volume_id_name):
            raise ValueError("Invalid value for parameter `master_volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if  _snapshot_volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _snapshot_volume_id_name):
            raise ValueError("Invalid value for parameter `snapshot_volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _master_volume_id is not None:
            if(isinstance(_master_volume_id, str)):
                _master_volume_id = SeparateArgs.check_backslash(_master_volume_id)
                _master_volume_id = _master_volume_id.encode("utf-8").decode("unicode-escape")
        if _snapshot_volume_id is not None:
            if(isinstance(_snapshot_volume_id, str)):
                _snapshot_volume_id = SeparateArgs.check_backslash(_snapshot_volume_id)
                _snapshot_volume_id = _snapshot_volume_id.encode("utf-8").decode("unicode-escape")
        if _snapshot_tree is not None:
            if(isinstance(_snapshot_tree, str)):
                _snapshot_tree = SeparateArgs.check_backslash(_snapshot_tree)
                _snapshot_tree = _snapshot_tree.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.DeleteSnapshotParam import DeleteSnapshotParam
        _delete_snapshot = DeleteSnapshotParam()
        _delete_snapshot.master_volume_id = _master_volume_id
        _delete_snapshot.snapshot_volume_id = _snapshot_volume_id
        _delete_snapshot.snapshot_tree = _snapshot_tree
        _delete_snapshot.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _master_volume_id_name is not None:
            # volume_listを使ってmaster_volume_id_nameに対応するmaster_volume_idを取得
            _master_volume_id = get_uuid_from_volume_list_with_master_volume_id_name(_master_volume_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteSnapshotParam import DeleteSnapshotParam
                _delete_snapshot = DeleteSnapshotParam()
            _delete_snapshot.master_volume_id = _master_volume_id

        if _snapshot_volume_id_name is not None:
            # volume_listを使ってsnapshot_volume_id_nameに対応するsnapshot_volume_idを取得
            _snapshot_volume_id = get_uuid_from_volume_list_with_snapshot_volume_id_name(_snapshot_volume_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteSnapshotParam import DeleteSnapshotParam
                _delete_snapshot = DeleteSnapshotParam()
            _delete_snapshot.snapshot_volume_id = _snapshot_volume_id

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _delete_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.DeleteSnapshotParam import DeleteSnapshotParam
                _delete_snapshot = DeleteSnapshotParam()
            _delete_snapshot.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.delete_snapshot(delete_snapshot = _delete_snapshot, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
def master_volume_show(_id,_id_name,):
    """
    Obtains the P-VOL information. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "master_volume_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.snapshot_clone_management import SnapshotCloneManagement as SnapshotCloneManagementApi
        api = SnapshotCloneManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "master_volume_show"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `master_volume_show`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.MasterVolume import MasterVolume

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.master_volume_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--snapshot_volume_id','_snapshot_volume_id',type=str,metavar='<str>',help='The ID of the volume which is S-VOL. Restores S-VOL of the parameter specified to P-VOL.')
@click.option('--vps_id','_vps_id',type=str,metavar='<str>',help='ID of the operation-target virtual private storage (VPS).')
@click.option('--snapshot_volume_id_name','_snapshot_volume_id_name',metavar='<str>',help='The name of the volume which is S-VOL. Restores S-VOL of the parameter specified to P-VOL.')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of the operation-target virtual private storage (VPS).')
def volume_restore_snapshot(_snapshot_volume_id,_snapshot_volume_id_name,_vps_id,_vps_id_name,):
    """
    Restores a snapshot. 
    """
    def get_uuid_from_volume_list_with_snapshot_volume_id_name(snapshot_volume_id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=snapshot_volume_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'snapshot_volume_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "volume_restore_snapshot"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _snapshot_volume_id is not None:
            subCommandLogtxt += "--snapshot_volume_id " + str(_snapshot_volume_id) + " "

        if _snapshot_volume_id_name is not None:
            subCommandLogtxt += "--snapshot_volume_id_name " + str(_snapshot_volume_id_name) + " "



        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.snapshot_clone_management import SnapshotCloneManagement as SnapshotCloneManagementApi
        api = SnapshotCloneManagementApi(ApiClient())

        
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--snapshot_volume_id', _snapshot_volume_id,'--snapshot_volume_id_name', _snapshot_volume_id_name, 'true')
        commonutil.view_error()
        body_param_validator_util = ParamValidatorUtil()
        body_param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        if _snapshot_volume_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _snapshot_volume_id):
            raise ValueError("Invalid value for `snapshot_volume_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "volume_restore_snapshot"





        if  _snapshot_volume_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _snapshot_volume_id_name):
            raise ValueError("Invalid value for parameter `snapshot_volume_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
















        if _snapshot_volume_id is not None:
            if(isinstance(_snapshot_volume_id, str)):
                _snapshot_volume_id = SeparateArgs.check_backslash(_snapshot_volume_id)
                _snapshot_volume_id = _snapshot_volume_id.encode("utf-8").decode("unicode-escape")
        if _vps_id is not None:
            if(isinstance(_vps_id, str)):
                _vps_id = SeparateArgs.check_backslash(_vps_id)
                _vps_id = _vps_id.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.RestoreSnapshotParam import RestoreSnapshotParam
        _restore_snapshot = RestoreSnapshotParam()
        _restore_snapshot.snapshot_volume_id = _snapshot_volume_id
        _restore_snapshot.vps_id = _vps_id

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _snapshot_volume_id_name is not None:
            # volume_listを使ってsnapshot_volume_id_nameに対応するsnapshot_volume_idを取得
            _snapshot_volume_id = get_uuid_from_volume_list_with_snapshot_volume_id_name(_snapshot_volume_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _restore_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.RestoreSnapshotParam import RestoreSnapshotParam
                _restore_snapshot = RestoreSnapshotParam()
            _restore_snapshot.snapshot_volume_id = _snapshot_volume_id

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)
            # サブオブジェクトを持つパラメータの場合、初期値のNoneのまま受け取る可能性があるためここで初期化する。
            if _restore_snapshot is None:
                from com.hitachi.sophia.rest_client.autogen.models.RestoreSnapshotParam import RestoreSnapshotParam
                _restore_snapshot = RestoreSnapshotParam()
            _restore_snapshot.vps_id = _vps_id


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.restore_snapshot(restore_snapshot = _restore_snapshot, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Volume ID ')
@click.option('--id_name','_id_name',metavar='<str>',help='The volume name.')
@click.option('--vps_id','_vps_id',metavar='<str>',help='ID of a virtual private storage (VPS) to which the resource to be obtained belongs. ')
@click.option('--vps_id_name','_vps_id_name',metavar='<str>',help='Name of a virtual private storage (VPS) to which the resource to be obtained belongs.')
def snapshot_volume_list(_id,_id_name,_vps_id,_vps_id_name,):
    """
    Obtains the list of S-VOL information. 
    """
    def get_uuid_from_volume_list_with_id_name(id_name):
        config = Configuration()
        commonutil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.volume_management import VolumeManagement as VolumeManagementApi
        api = VolumeManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.volume_list(name=id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)
    def get_uuid_from_virtual_private_storage_list_with_vps_id_name(vps_id_name):
        config = Configuration()
        commonutil = CommonUtil()
        # systemスコープを指定された場合はvpsIDが存在しないため、文字列のまま返却
        if vps_id_name == "system":
            return "system"

        from com.hitachi.sophia.rest_client.autogen.apis.virtual_private_storage_management import VirtualPrivateStorageManagement as VirtualPrivateStorageManagementApi
        api = VirtualPrivateStorageManagementApi(ApiClient())

        try:
            uuidutil = UuidUtil()

            response = api.virtual_private_storage_list(name=vps_id_name)
            uuidutil.determin_status_doce_of_list_reference(response)

            uuid = uuidutil.getUuidFromResponse(response, 'vps_id_name', 'id')
            return uuid

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "snapshot_volume_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "

        if _id_name is not None:
            subCommandLogtxt += "--id_name " + str(_id_name) + " "






        if _vps_id is not None:
            subCommandLogtxt += "--vps_id " + str(_vps_id) + " "

        if _vps_id_name is not None:
            subCommandLogtxt += "--vps_id_name " + str(_vps_id_name) + " "





        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.snapshot_clone_management import SnapshotCloneManagement as SnapshotCloneManagementApi
        api = SnapshotCloneManagementApi(ApiClient())

        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--id', _id,'--id_name', _id_name, 'true')
        commonutil.view_error()


        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        
        
        
        param_validator_util = ParamValidatorUtil()
        param_validator_util.check_parameter_combinations('--vps_id', _vps_id,'--vps_id_name', _vps_id_name, 'false')
        commonutil.view_error()


        
        


        
        
        
        
        
        #cliSubCommand = "snapshot_volume_list"





        if  _id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _id_name):
            raise ValueError("Invalid value for parameter `id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `id` when calling `snapshot_volume_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")


        if  _vps_id is not None and not re.search('^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$', _vps_id):
            raise ValueError("Invalid value for parameter `vps_id` when calling `" + cliSubCommand + "`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `snapshot_volume_list`, must conform to the pattern `/^system$|^[A-Fa-f0-9]{8}(-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/`")




        if  _vps_id_name is not None and not re.search('^[\-A-Za-z0-9,\.:@_]{1,32}$', _vps_id_name):
            raise ValueError("Invalid value for parameter `vps_id_name` when calling `" + cliSubCommand + "`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")
#           raise ValueError("Invalid value for parameter `vps_id` when calling `snapshot_volume_list`, must conform to the pattern `^[\-A-Za-z0-9,\.:@_]{1,32}$`")













                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.SnapshotVolumeList import SnapshotVolumeList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        



        if _id_name is not None:
            # volume_listを使ってid_nameに対応するidを取得
            _id = get_uuid_from_volume_list_with_id_name(_id_name)

        if _vps_id_name is not None:
            # virtual_private_storage_listを使ってvps_id_nameに対応するvps_idを取得
            _vps_id = get_uuid_from_virtual_private_storage_list_with_vps_id_name(_vps_id_name)


        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.snapshot_volume_list(_id, vps_id = _vps_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}
    commands['volume_create_snapshot'] = volume_create_snapshot
    commands['volume_delete_snapshot'] = volume_delete_snapshot
    commands['master_volume_show'] = master_volume_show
    commands['volume_restore_snapshot'] = volume_restore_snapshot
    commands['snapshot_volume_list'] = snapshot_volume_list
    return commands

