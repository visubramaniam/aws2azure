"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import re

from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.rest_client.manual.configuration import Configuration


class ParamValidatorUtil(object):
    def check_parameter_combinations(self, id, id_value, name, name_value, required='false'):
        config = Configuration()

        # id と name両方指定している場合
        if id_value != None and name_value != None:
            config.messageId = '19022'
            config.messageDict = {'MSKEY_param1': id, 'MSKEY_param2': name}
            return

        # requiredがtrueの場合だけ必須チェックを行う
        if required == 'true':
            # id と nameどちらも指定していない場合
            if id_value is None and name_value is None:
                config.messageId = '19023'
                config.messageDict = {'MSKEY_param1': id, 'MSKEY_param2': name}
                return

    def check_multi_parameter_combinations(self, ordered_dict_options, required='false'):
        """
        ordered_dict_optionsに対して
        * 二つ以上の値がNone以外の値(=指定値)になっていないか確認してエラーをConfigurationに格納する
        * requiredが'true'の時には、すべての値がNoneになっていないか確認してエラーをConfigurationに格納する
        :param ordered_dict_options: オプション名をキー、オプション値を値としたOrderedDict
        :param required: 'true'/'false'の文字列。'true'のときはすべての値がNoneになっていないかチェックする。
        :return: なし
        """
        config = Configuration()

        specified_options = [key for key in ordered_dict_options.keys() if ordered_dict_options[key] is not None]
        num_of_specified_values = len(specified_options)

        # パラメータが二つ以上指定されているとき
        if num_of_specified_values > 1:
            config.messageId = '19025'
            config.messageDict = {'optionNames': ', '.join(specified_options)}
            return

        # requiredがtrueの場合だけ必須チェックを行う
        if required == 'true':
            # 必須にも関わらずパラメータが一つも指定されていないとき
            if num_of_specified_values == 0:
                config.messageId = '19024'
                config.messageDict = {'optionNames': ', '.join(ordered_dict_options.keys())}
                return

    def check_filter_array_for_names(self, param_name, param_value, pattern, pattern_with_escape, max_items, max_length):
        config = Configuration()
        commonutil = CommonUtil()
        uuidutil = UuidUtil()

        MESSAGE_PARAM_NAME = '`' + param_name + '`'
        MESSAGE_ITEMS = '`' + str(max_items) + '`'
        MESSAGE_LENGTH = '`' + str(max_length) + '`'
        MESSAGE_PATTERN = '`/' + pattern + '/`'

        MESSAGE_ITEMS_OVER = ': The number of them must be less than or equal to '
        MESSAGE_LENGTH_OVER_FIRST = ': The '
        MESSAGE_LENGTH_OVER_SECOND = 'th value from the beginning is not correct. '
        MESSAGE_LENGTH_OVER_THIRD = 'The length must be less than or equal to '
        MESSAGE_PATTERN_NOT_MATCH_FIRST = ': The '
        MESSAGE_PATTERN_NOT_MATCH_SECOND = 'th value from the beginning is not correct. '
        MESSAGE_PATTERN_NOT_MATCH_THIRD = 'It must conform to the pattern '

        # ','区切りで要素を分割する
        name_list = uuidutil.escapeArrayValue(param_value)

        # 配列要素数チェック
        if len(name_list) > max_items:
            config.messageId = '19502'
            config.messageDict = { 'argsError': MESSAGE_PARAM_NAME + MESSAGE_ITEMS_OVER + MESSAGE_ITEMS + '.' }
            commonutil.view_error()

        # 各要素のチェック
        i = 1
        for name in name_list:
            # 文字数
            if len(name) > max_length:
                err_msg = MESSAGE_PARAM_NAME + MESSAGE_LENGTH_OVER_FIRST + \
                          str(i) + MESSAGE_LENGTH_OVER_SECOND + \
                          MESSAGE_LENGTH_OVER_THIRD + MESSAGE_LENGTH + '.'
                config.messageId = '19502'
                config.messageDict = { 'argsError': err_msg }
                commonutil.view_error()

            # 正規表現パターン
            match = re.search(pattern, name)
            if match is None:
                err_msg = MESSAGE_PARAM_NAME + MESSAGE_PATTERN_NOT_MATCH_FIRST + \
                          str(i) + MESSAGE_PATTERN_NOT_MATCH_SECOND + \
                          MESSAGE_PATTERN_NOT_MATCH_THIRD + MESSAGE_PATTERN + '.'
                config.messageId = '19502'
                config.messageDict = { 'argsError': err_msg }
                commonutil.view_error()

            i = i + 1

    def get_opt_values_from_dict(self, opt_dict):
        """
        opt_validatorのinvoke関数が返すOrderedDict型から、値だけを取り出してtuple型にて返す関数
        :param opt_dict: オプション名をキー、オプション値を値としたOrderedDict
        :return: オプション値のtuple
        :rtype: tuple
        """

        return tuple(opt_dict.values())
