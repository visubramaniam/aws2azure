"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""
import logging as loggingLib
import traceback
import json
import urllib3

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil

logger = loggingLib.getLogger(__name__)

class WarningBanner(object):

    def get_login_message(self):

        config = Configuration()
        commonUtil = CommonUtil()

        from com.hitachi.sophia.rest_client.autogen.apis.gui import GUI as GUIApi
        api = GUIApi(ApiClient())

        try:

            from com.hitachi.sophia.rest_client.autogen.models.LoginMessage import LoginMessage

            response = api.login_message_show(callback=None, debug="false")
            return response

        except urllib3.exceptions.MaxRetryError as e:  # 通信エラー発生(応答なし)
            if traceback:
                logger.error(traceback.format_exc())

            if hasattr(e,'reason'):
                # 証明書不正
                if isinstance(e.reason, urllib3.exceptions.SSLError):
                    config.messageId = '19506'
                # NewConnectionError
                elif isinstance(e.reason, urllib3.exceptions.NewConnectionError):
                    config.messageId = '19504'
                # ReadTimeoutError
                elif isinstance(e.reason, urllib3.exceptions.ReadTimeoutError):
                    config.messageId = '19504'
                # ResponseError
                elif isinstance(e.reason, urllib3.exceptions.ResponseError):
                    config.messageId = '19504'
                # ConnectTimeoutError
                elif isinstance(e.reason, urllib3.exceptions.ConnectTimeoutError):
                    config.messageId = '19504'
                # TimeoutError
                elif isinstance(e.reason, urllib3.exceptions.TimeoutError):
                    config.messageId = '19504'
                # 上記以外urllib3例外はHTTPErrorで受ける
                elif isinstance(e.reason, urllib3.exceptions.HTTPError):
                    config.messageId = '19507'
                # 通信エラー以外の場合は予期しないエラー
                else:
                    config.messageId = '19505'
            else:
                # 属性がない
                config.messageId = '19505'
            # config.messageId = '19504'
            strErr = ','.join(e.args)
            config.messageDict = {'maxRetryError': strErr}
            commonUtil.view_error()

        except urllib3.exceptions.HTTPError as e:
            if traceback:
                logger.error(traceback.format_exc())

            config.messageId = '19504'
            strErr = ' '.join(map(str, e.args))
            config.messageDict = {'exception': strErr}
            commonUtil.view_error()


        except Exception as e:  # CLI内で予期せぬエラーが発生
            if traceback:
                logger.error(traceback.format_exc())

            config.messageId = '19505'
            strErr = ' '.join(map(str, e.args))
            config.messageDict = {'exception': strErr}
            commonUtil.view_error()

    def view_warning_banner(self, message):

        config = Configuration()
        oup = OutputUtil()
        commonutil = CommonUtil()

        try:
            login_message = json.loads(message)

            if login_message['httpStatusCode'] == 200:
                if 'message' in login_message['body']:
                    return login_message['body']['message']
                else:
                    config.messageId = '19014'
                    return
            elif login_message['httpStatusCode'] >= 500:
                if 'messageId' in login_message['body'] \
                        and 'message' in login_message['body'] \
                        and 'cause' in login_message['body'] \
                        and 'solution' in login_message['body'] \
                        and 'solutionType' in login_message['body']:
                    oup.echo_normal(message, config.format, self.sub_command_name)
                    status = commonutil.get_response_status(message)
                    exit(commonutil.get_cli_exit_code_for_api_execution(status))
                else:
                    config.messageId = '19014'
                    return
            else: # ステータスコードが200,5xx以外
                 config.messageId = '19014'
                 return

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())

            config.messageId = '19014'
            return