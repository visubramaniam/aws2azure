"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import logging as loggingLib
import requests
import urllib3
import certifi
import ssl
import socket
import hashlib
import traceback
from typing import Tuple, Optional, List, Dict
from requests_toolbelt.adapters.fingerprint import FingerprintAdapter
from requests_toolbelt import MultipartEncoder

from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import RESTResponseForRequests
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement

logger = loggingLib.getLogger(__name__)


class RestCertificateUtil(object):
    def get_server_certificate(self, host: str, port: int = 443) -> Tuple[Optional[Dict], Optional[str]]:
        """
        指定したホストの、証明書の辞書と、 sha1 フィンガープリントを返す。
        前者は、トラブルシュートとログ用。
        後者は、以後の https 要求の検証に使う。

        VSSB の認証や、url, rest サーバとは無関係な、 ssl 層で動く。

        fingerprint は、urllib3.PoolManager(assert_fingerprint) に与えて、
        このフィンガープリントを持っている証明書以外の接続を拒否するために使う。
        DER 形式の証明書の、 sha1 sum でよいことは、urllib3/util/ssl_.py から得た。

        getpeercert は、host の証明書の検証を行う。
        binary_form の場合、検証に失敗しても証明書が取れる。
        失敗したら、画面とログにエラーメッセージを出す。
        """
        logger.info("connecting to host={}".format(host))
        cert = fingerprint = None
        errlist = []
        additional_info = None

        context = ssl.create_default_context()

        # OSやLinuxディストリビューションによってsslモジュールとcertifiモジュールが確認するルートCA証明書の場所が一致しない場合があるため明示的にcertifiモジュールが確認するパスに合わせる。
        cafilepath = certifi.where()
        context.load_verify_locations(cafile=cafilepath)

        conn = context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=host)
        try:
            conn.connect((host, port))

            cert = conn.getpeercert()
            if cert is None:
                logger.info("no cert.")
                # 証明書が認証されていない場合、辞書は空です。証明書が認証されていた場合いくつかのキーを持った辞書を返す。
                # 辞書が空だった場合は認証失敗に倒す。
                raise ssl.SSLError

            # DER 形式のバイナリ証明書の、 sha1 sum が、求めるもの。
            dercert = conn.getpeercert(binary_form=True)
            if dercert is None:
                logger.info("no dercert.")
                # クライアント SSL ソケットでは、認証が要求されているかどうかに関わらず、サーバは常に証明書を提供する。
                # 辞書が空だった場合は内部エラーに倒す。
                raise Exception

            m = hashlib.sha1(dercert)
            fingerprint = m.hexdigest()

            return cert, fingerprint, errlist

        except (ssl.CertificateError, ssl.SSLError) as e:
            logger.info("{} {}".format(type(e), e))
            logger.error("Server certificate verification failed for {}.".format(host))
            # hostname 'localhost' doesn't match either of 'kanda-sles15sp2'
            # のような、エラーの詳細を出すことができればそうする。
            if isinstance(e, ssl.CertificateError):
                try:
                    logger.error(e.args[0])
                    additional_info = str(e.args[0])
                except Exception as e2:
                    # 変だな。
                    logger.info(str(e2))
            # [host]でサーバー証明書の検証に失敗しました。
            # errlist.append([23066, {"host": host}, additional_info, None])
            errlist.append([
                "An error occurred while running the command.",
                "The server certificate could not be verified for {}.".format(host),
                "Verify that the server certificate of the storage node is valid and the corresponding root certificate is imported into the storage node. Use the --ignore_certificate_errors option to accept unsafe connection. If the same error occurs after retry, take action according to the Troubleshooting Guide. If the error still persists, collect the logs, and then contact customer support."
            ])

        except OSError as e:
            # TODO XXX これは、 --host 引数の誤りで起きて、画面に出るので、
            # 標準的なメッセージテキストが決まっていれば、それを使うこと。
            logger.error("Failed to connect to {}. {}".format(host, e))
            # [host]への接続に失敗しました。
            additional_info = str(e)
            # errlist.append([23067, {"host": host}, additional_info, None])
            errlist.append([
                "An error occurred while running the command.",
                "Communication with {} failed.".format(host),
                "Verify whether network communication between the controller node and the storage node is possible, troubleshoot any problems, and then retry the operation. If the same error occurs after retry, collect the logs, and then contact customer support."
            ])
        except Exception as e:
            # これは起きないはず。
            logger.info("{} {}".format(type(e), e))
            additional_info = str(e)
            # errlist.append([23904, None, additional_info, None])
            errlist.append([
                "An error has occurred when executing the command.",
                "An unexpected error occurred.",
                "Collect the logs, and then contact customer support."
            ])

        return None, None, errlist

    # fingerprint = a90214b3c2a391f4a750b3d744588c071f12b220
    # ip = 192.168.14.111
    # base_url = "/ConfigurationManager/simple"
    # path = "/v1/objects/storage/actions/restore-from-configuration-backup-file/invoke"
    # body = 
    # quiery_params = [('keys', params['keys']), ('keys', params['keys']) ...]
    def rest_access_on_fingerprint_certificate(self, method, fingerprint, ip, base_url, path, quiery_params=None, body=None, file=None, connection_timeout=None, read_timeout=None):
        # 検証に成功済みのサーバー証明書のfingerprintを使って検証してREST APIを実行するため関数（通常の証明書検証はしない）

        config = Configuration()
        api_client = ApiClient()

        url = "https://{}:443{}{}".format(ip, base_url, path)

        # header
        if file is not None:
            header_params = {
                'Content-Type': file.content_type,
                'X-Client-type': 'HSDS CLI',
                'Accept': api_client.select_header_accept(['application/json'])
            }
        else:
            header_params = {
                'Content-Type': 'application/json',
                'X-Client-type': 'HSDS CLI',
                'Accept': api_client.select_header_accept(['application/json'])
            }
        # header_params['Accept-Language']
        auth_settings = ['ticketAuth']

        header_params = api_client.sanitize_for_serialization(header_params)
        api_client.update_params_for_auth(header_params, None, auth_settings)

        # REST実行
        try:
            logger.info("rest_access_on_fingerprint_certificate execute to: " + url)
            if config.verify_ssl is True:
                # 検証あり
                session = requests.Session()
                session.mount('https://', FingerprintAdapter(fingerprint))
                # 通常の検証はしないがfingerprintによる検証はする。
                if method == "GET":
                    response = session.get(url, params=quiery_params, headers=header_params, verify=False, timeout=(connection_timeout, read_timeout))
                elif method == "POST":
                    response = session.post(url, data=body, headers=header_params, verify=False, timeout=(connection_timeout, read_timeout))
                elif method == "PATCH":
                    response = session.patch(url, data=body, headers=header_params, verify=False, timeout=(connection_timeout, read_timeout))
                else:
                    pass
            else:
                # 検証なし
                # CLI実行時に--ignore_certificate_errorsがついている場合は何も検証しない。
                if method == "GET":
                    response = requests.get(url, params=quiery_params, headers=header_params, verify=False, timeout=(connection_timeout, read_timeout))
                elif method == "POST":
                    response = requests.post(url, data=body, headers=header_params, verify=False, timeout=(connection_timeout, read_timeout))
                elif method == "PATCH":
                    response = requests.patch(url, data=body, headers=header_params, verify=False, timeout=(connection_timeout, read_timeout))

            response_data = RESTResponseForRequests(response)
            logger.info('Receive HTTP Response:' +
                        ' status:' +
                        str(response_data.status) +
                        ' response_header:' +
                        str(response_data.getheaders()))
            response = api_client.deserialize(response_data, None)

        except requests.exceptions.SSLError as e:
            # RESTサーバーのサーバー証明書の正当性を確認できなかった
            if traceback:
                logger.error(traceback.format_exc())
            message_id = '19506'
            message_dict = {}
            return None, message_id, message_dict
        except requests.exceptions.ConnectionError as e:
            if traceback:
                logger.error(traceback.format_exc())
            if len(e.args) == 1:
                if (isinstance(e.args[0], urllib3.exceptions.ProtocolError)
                    or isinstance(e.args[0], requests.packages.urllib3.exceptions.ProtocolError)) \
                        and len(e.args[0].args) == 2 and \
                        (isinstance(e.args[0].args[1], BrokenPipeError)
                            or isinstance(e.args[0].args[1], ConnectionResetError)):
                    # BrokenPipeErrorまたはConnectionResetErrorは、
                    # RESTがリクエストボディ受けきる前に拒否しているケースもあるため、
                    # 特別なメッセージを出して終了
                    message_id = '19400'
                    message_dict = {}
                    return None, message_id, message_dict
                elif isinstance(e.args[0], urllib3.exceptions.HTTPError):
                    # urllib3のExceptionの場合は、そのexception内容でメッセージ決める
                    e = e.args[0]
                    # B169344対策
                    # ノード電断した状態でrequest実施すると、ここに入る
                    # その場合はexceptionで返却し、その内容を上位で決めていたが、19504に倒す
                    message_id = '19504'
                    message_dict = {}
                    return None, message_id, message_dict
            message_id = '19504'
            message_dict = {}
            return None, message_id, message_dict
        except requests.exceptions.RequestException as e:
            if traceback:
                logger.error(traceback.format_exc())
            message_id = '19504'
            message_dict = {}
            return None, message_id, message_dict

        except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
            if traceback:
                logger.error(traceback.format_exc())

            message_id = '19007'
            message_dict = {
                'exception': 'An operation was attempted without adequate access rights, such as file system rights.'}
            return None, message_id, message_dict

        except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
            if traceback:
                logger.error(traceback.format_exc())

            message_id = '19500'
            message_dict = {'apiException': 'The user hit the interrupt key.'}
            return None, message_id, message_dict

        except Exception as e:
            if traceback:
                logger.error(traceback.format_exc())
            return None, 'exception', e
        
        return response, None, None
