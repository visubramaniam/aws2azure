# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import os
import importlib


def commands():
    commands = {}
    files = os.listdir(os.path.dirname(__file__))

    # manual/sub_commands下でcliコマンドを追加する場合はここにsrcを追加すること。
    targets = [
        "cli_only.py",
        "configuration_backup.py",
        "stationary_point_setting_manual.py",
        "configuration_parameter_setting_mode_switching_manual.py",
        "configuration_parameter_setting_mode_getting_manual.py",
        "hsds_modify.py"
    ]

    for file in files:
        name, ext = os.path.splitext(file)
        if file in targets:
            m = importlib.import_module('.' + name, __name__)
            commands.update(m.commands())

    return commands
