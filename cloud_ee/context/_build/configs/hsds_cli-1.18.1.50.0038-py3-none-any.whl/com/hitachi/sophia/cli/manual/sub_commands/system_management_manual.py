# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno
import time

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.config_backup.config_backup_util import ConfigBackupUtil

logger = loggingLib.getLogger(__name__)


def configuration_backup_file_manual(dir_, callback, debug):
    """
    クラスタ構成バックアップファイルをダウンロードする
    """

    from com.hitachi.sophia.rest_client.autogen.apis.system_management import \
        SystemManagement as SystemManagementApi
    api = SystemManagementApi(ApiClient())

    cli_response = collections.OrderedDict()

    response = None

    config = Configuration()

    sub_command = "configuration_backup_file_create"
    try:
        for i in range(21):
            response = api.configuration_backup_file_download(callback=callback, debug=debug, _preload_content=False)

            if response:

                cli_response['httpStatusCode'] = response.status

                if response.status != 200:
                    if response.data:
                        cli_response['body'] = ApiClient().deserialize_json_to_body_or_exit(response,
                                                                                            _preload_content=False)
                        common_util = CommonUtil()
                        cli_response_json = json.dumps(cli_response)
                        if common_util.check_retry(cli_response_json):
                            if i > 19:
                                # REST応答をCLIで変換
                                config_backup_util = ConfigBackupUtil()
                                config_backup_util.convert_rest_responses_with_cli_for_config_backup(cli_response_json)

                                output_util = OutputUtil()
                                output_util.echo_error(cli_response_json, 'text')
                                exit(1)
                            else:
                                time.sleep(1)
                                continue
                        else:
                            # REST応答をCLIで変換
                            config_backup_util = ConfigBackupUtil()
                            config_backup_util.convert_rest_responses_with_cli_for_config_backup(cli_response_json)

                            output_util = OutputUtil()
                            output_util.echo_error(cli_response_json, 'text')
                            exit(1)
                else:
                    break

    except Exception as e:
        if (response):
            response.release_conn()
        if (traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)

    # ダウンロードするファイル名はレスポンスヘッダーに格納されているファイル名にする。
    # ファイル名はレスポンスヘッダーの"Content-Disposition"に格納されている
    content_disposition = response.getheader("Content-Disposition")
    # ファイル名を取得
    defaultFileName = get_filename(content_disposition)

    fileutil = FileUtil(defaultFileName)

    dirname, filename = fileutil.locate_download_file(dir_)
    download_path = os.path.join(dirname, filename)

    saveFile = None
    try:
        with open(download_path, 'wb') as saveFile:
            # 10MiB単位で応答データを読み取る
            amt = 10 * 1024 * 1024
            while True:
                data = response.read(amt)
                if not data:
                    break
                saveFile.write(data)

        return filename

    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19505'
        messageDict = {}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except FileExistsError as e:  # 既にファイルが存在している
        messageId = '19505'
        messageDict = {}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except OSError as e:  # OSError かつ errno ENOSPCの場合
        if e.errno == errno.ENOSPC:
            messageId = '19214'
            messageDict = {}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        else:
            messageId = '19007'
            strErr = ','.join(map(str, e.args))
            messageDict = {'exception': strErr}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        click.echo('Aborted!', err=True)
        exit(1)

    except Exception as e:
        # ファイルの保存に失敗
        messageId = '19007'
        strErr = ' '.join(map(str, e.args))
        messageDict = {'exception': strErr}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)

        exit(1)
    finally:
        if (response):
            response.release_conn()
        if (saveFile):
            saveFile.close()


# レスポンスヘッダーからファイル名を取得する
def get_filename(content_disposition):
    download_filename = None
    if (content_disposition):
        download_filename = re.search('filename="?([^"]+)"?(;|$)', content_disposition).group(1)
        if CommonUtil().check_ignore_filename(download_filename):
            download_filename = None
    if (download_filename is None):
        # レスポンスヘッダーからファイル名が取得できなかった場合、ファイル名は”cluster_unknown.bin”とする.
        download_filename = "cluster_unknown.bin"
    return download_filename
