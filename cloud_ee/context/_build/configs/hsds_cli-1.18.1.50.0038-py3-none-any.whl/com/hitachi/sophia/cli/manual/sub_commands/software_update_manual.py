# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import traceback
import logging as loggingLib
import os

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil

logger = loggingLib.getLogger(__name__)


def storage_upload_software_update_file_manual(_software_update_file, callback, debug):
    """
    Transfers (uploads) the update file of the storage software to the storage cluster.
    """

    try:
        import requests
        import urllib3
        import certifi

        config = Configuration()
        common_util = CommonUtil()
        cli_sub_command = "storage_upload_software_update_file"

        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        # ファイルアップロード中に認証失敗すると
        # RESTサーバから拒否応答を受けたケースの
        # エラーハンドリングを行ってしまう。
        # それを回避するため、ファイルアップロード前に
        # ストレージクラスターに転送したストレージソフトウェアの
        # アップデートファイルの情報参照を実行し、
        # 認証失敗ケースのエラーハンドリングを行うようにする。
        from com.hitachi.sophia.rest_client.autogen.apis.software_update import \
            SoftwareUpdate as SoftwareUpdateApi
        api = SoftwareUpdateApi(ApiClient())

        response = api.software_update_file_show(callback=None, debug="false")

        # HTTPステータスコードが200, 404, 409以外の場合は応答をそのまま出力
        status = common_util.get_response_status(response)
        if status not in [200, 404, 409]:
            oup = OutputUtil()
            oup.echo_normal(response, config.format, cli_sub_command)
            exit(common_util.get_cli_exit_code_for_api_execution(status))

        # HTTPステータスコード200, 404, 409の場合は、
        # 認証成功したとして処理継続する。

        # ファイルが存在するか 2回目
        if not(os.path.isfile(_software_update_file)):
            message_management = MessageManagement('')
            message_id = '19004'
            message_dict = {'filePath': os.path.abspath(_software_update_file)}
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)

        _software_update_file_handle = open(_software_update_file, 'rb')

        from requests_toolbelt import MultipartEncoder
        from com.hitachi.sophia.rest_client.manual.rest import RESTResponseForRequests

        # REST-API実行処理
        multipart_encoder = MultipartEncoder(
            fields={
                'softwareUpdateFile': (_software_update_file, _software_update_file_handle)
            }
        )

        # URL
        url = config.host + '/v1/objects/storage/actions/upload-software-update-file/invoke'

        api_client = ApiClient()

        # header
        header_params = {
            'Content-Type': multipart_encoder.content_type,
            'X-Client-type': 'HSDS CLI',
            'Accept': api_client.select_header_accept(['application/json'])
        }
        # header_params['Accept-Language']
        auth_settings = ['basicAuth', 'sessionAuth']

        header_params = api_client.sanitize_for_serialization(header_params)
        api_client.update_params_for_auth(header_params, None, auth_settings)

        # REST実行
        try:
            if config.verify_ssl is True:
                verify = certifi.where()
            else:
                verify = False

            response = requests.post(url, data=multipart_encoder, headers=header_params, verify=verify)

            response_data = RESTResponseForRequests(response)
            logger.info('Receive HTTP Response:' +
                        ' status:' +
                        str(response_data.status) +
                        ' response_header:' +
                        str(response_data.getheaders()))
            response = api_client.deserialize(response_data, None)

            # 結果出力
            oup = OutputUtil()
            oup.echo_normal(response, config.format, cli_sub_command)
            status = common_util.get_response_status(response)
            _software_update_file_handle.close()
            exit(common_util.get_cli_exit_code_for_api_execution(status))

        except requests.exceptions.SSLError as e:
            if traceback:
                logger.error(traceback.format_exc())

            _software_update_file_handle.close()

            message_id = '19506'
            message_dict = {}
            message_management = MessageManagement('')
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)

        except requests.exceptions.ConnectionError as e:
            if traceback:
                logger.error(traceback.format_exc())

            _software_update_file_handle.close()

            if len(e.args) == 1:
                if (isinstance(e.args[0], urllib3.exceptions.ProtocolError)
                    or isinstance(e.args[0], requests.packages.urllib3.exceptions.ProtocolError)) \
                    and len(e.args[0].args) == 2 and \
                        (isinstance(e.args[0].args[1], BrokenPipeError)
                         or isinstance(e.args[0].args[1], ConnectionResetError)):
                    # BrokenPipeErrorまたはConnectionResetErrorは、
                    # RESTがリクエストボディ受けきる前に拒否しているケースもあるため、
                    # 特別なメッセージを出して終了
                    message_id = '19400'
                    message_dict = {}
                    message_management = MessageManagement('')
                    message_management.viewMessageTxt(message_id, **message_dict)
                    exit(1)
                elif isinstance(e.args[0], urllib3.exceptions.HTTPError):
                    # urllib3のExceptionの場合は、そのexception内容でメッセージ決める
                    e = e.args[0]
                    message_management = MessageManagement('')
                    message_management.viewMessage(e)

            message_id = '19504'
            message_dict = {}
            message_management = MessageManagement('')
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)
        except requests.exceptions.RequestException as e:
            if traceback:
                logger.error(traceback.format_exc())

            _software_update_file_handle.close()

            message_id = '19504'
            message_dict = {}
            message_management = MessageManagement('')
            message_management.viewMessageTxt(message_id, **message_dict)
            exit(1)
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        if traceback:
            logger.error(traceback.format_exc())

        message_id = '19007'
        message_dict = {
            'exception': 'An operation was attempted without adequate access rights, '
                         'such as file system rights. (File path = '
                         + os.path.abspath(_software_update_file) + ')'}
        message_management = MessageManagement('')
        message_management.viewMessageTxt(message_id, **message_dict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        if traceback:
            logger.error(traceback.format_exc())

        message_id = '19007'
        message_dict = {'exception': 'The user hit the interrupt key. (File path = '
                                     + os.path.abspath(_software_update_file) + ')'}
        message_management = MessageManagement('')
        message_management.viewMessageTxt(message_id, **message_dict)
        exit(1)

    except Exception as e:
        if traceback:
            logger.error(traceback.format_exc())
        message_management = MessageManagement('')
        message_management.viewMessage(e)
